---
name: external-worker
description: "External worker: run eligible worker roles externally."
---

# External Worker

## Core stance

- Act as a worker-side execution adapter, not a lead, product owner, reviewer, or consultant.
- Use the shared dispatch contract in [../lead/external-dispatch.md](../lead/external-dispatch.md).
- Execute only the approved worker-side phase or artifact for the eligible internal role that the orchestrator routed here.
- The assigned worker role is provenance and routing metadata only; it does not narrow this adapter's universality.
- Keep the output inside the approved role contract and change surface.
- No silent fallback to internal implementation or `$consultant`.

## Input contract

- Require an accepted brief, plan, or upstream artifact that already authorizes the assigned worker-side role.
- Require the internal worker role label being replaced for provenance.
- Require either an explicit user override or a config preference that selected external dispatch.
- Take only the minimal accepted artifacts and change surface needed for that role.
- Treat any eligible worker-side role as replaceable by the external adapter.

## External execution

- Read and normalize `.agents/.agents-mode.yaml` to the current canonical format before trusting its flags.
- Honor the contract-resolved `externalPriorityProfile`, `reserveResolver`, `externalPriorityProfiles`, and `externalOpinionCounts`; this role does not reimplement their resolution.
- Resolve config, provider, model/profile, workdir, fallback, and transport under the shared external-dispatch contract; do not reproduce its resolution logic here.
- Luna mechanical dispatch is native-only. External-worker never realizes or falls back for it; the native caller consumes `RoleDispatchPolicyV1` from the installed `AGENTS.md`.
- Do not honor `reserve` for worker-side lanes. It is a supplemental read-only candidate only in `advisory.*` and `review.*` profile orders after primary `claude`/`codex`, and `reserveResolver` must not turn it into a worker transport, primary-Claude retry, or implementation/editing fallback.
- Keep explicit-only and unavailable providers out of shipped and repo-local `auto` profiles.
- Never select `gpt-6-sol-ultra` on this subagent lane; it spawns subagents and must not be shipped here.
- Use file-based prompt delivery for substantive task prompts through the approved thin wrapper: write the prompt to a temporary prompt file and feed it through stdin or the provider's supported file-input mechanism; direct prompt argv is only for a fixed synthetic non-substantive smoke token. If the wrapper is unavailable, fail or reroute honestly.
- If the selected Claude CLI path fails for a worker artifact, do not convert that same primary `claude` run to the secret-backed wrapper. Treat Claude as unavailable or reroute honestly.
- This adapter is a direct external launch contract. Do not spawn it as an internal specialist or helper; the orchestrator must launch the selected external provider directly or fail closed.
- A spawned internal subagent is still internal even if the prompt assigns it an external-provider label. That is a routing violation, not a valid external-worker execution path.
- Do not silently fall back to an internal implementer or to `$consultant`.
- Apply the availability-probe evidence and route-change rule owned by `../lead/external-dispatch.md`; do not define a local variant.
- Multiple simultaneous instances of this adapter may target the same provider when each instance owns a different admitted artifact or disjoint slice and the provider runtime supports concurrent non-interactive execution.

## Execution recipe

- Use the approved thin wrapper owned by `../lead/external-dispatch.md`; that owner supplies the strict V2 parser, full external-nonauthorizing tuple, and untrusted/potentially-sensitive resultText contract. Do not retype the schema, consume wrapper-private captures, or substitute a direct closure/manual sidecar path.
- When explicit Kimi engineering is policy-admitted, require the `engineering` mutation class and a taxonomy mapping from the assigned profession to `external-worker`. A validated capability file may select only the caller-scoped worker tools, cwd, and artifact needed by that assignment; cwd selection is not a sandbox, the result remains nonauthorizing, and the integration owner independently verifies every change. Omission of the file preserves empty tools, Model Context Protocol servers, and subagents with permission `reject`.
- Await the wrapper's terminal return, then apply the owner's stall/timeout and tracked-ledger rules; never duplicate a still-running launch.
- Accept completion only when the shared run-completion oracle passes; a failed oracle is `UNVERIFIED`, not a worker artifact.

## Return exactly one artifact

- Return one external worker artifact containing the role-appropriate output, any changed files when code or docs were edited, relevant checks or verification evidence when they exist, explicit assumptions or risks, and a provenance header.
- When a neutral-workdir run produced edits, return a reviewable edit payload and name whether it is a unified diff or a full-file set with repo-relative target paths; in-place editing follows the contract's isolation-worktree binding.
- For the provenance header, use the canonical execution record in `../lead/external-dispatch.md` verbatim instead of defining local fields.

## Gate

- The artifact stays inside the approved change surface for the assigned worker role.
- The adapter may stand in for any eligible worker-side role, but it must still respect the assigned role's artifact contract.
- The package reports changed files and verification evidence when the assigned role produced edits, or the accepted non-code artifact when the assigned role produced analysis, design, planning, or constraint output.
- Provider failure is explicit and does not get normalized away.

## Working rules

- Prefer the narrowest role-appropriate artifact over opportunistic extra work.
- Keep behavior changes explicit when code is touched.
- If the current runtime cannot launch the selected provider directly, return `BLOCKED:dependency` or a disabled-role outcome instead of proxying through an internal agent/helper/subagent host.
- If you observe a provider-labeled internal subagent standing in for this route, treat that as contract failure and report it as disabled or rerouted instead of accepting it as external execution.
- If the assigned worker role cannot be honored, return `BLOCKED:dependency` instead of substituting a different role.

## Non-goals

- Do not do review or QA work.
- Do not become a shadow lead, product-manager, or consultant substitute.
- Do not expand scope beyond the approved worker-side phase.
