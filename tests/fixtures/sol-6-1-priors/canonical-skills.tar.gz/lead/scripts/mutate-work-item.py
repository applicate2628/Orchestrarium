#!/usr/bin/env python3
"""Single synchronous owner for the work-items physical lifecycle V1.

The reusable API raises ``LifecycleError``.  Only ``main`` translates a failure
into a process exit code.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import contextvars
import errno
import functools
import hashlib
import importlib.util
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import threading
import uuid
from collections import Counter
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path, PurePosixPath
from types import MappingProxyType
from typing import Iterable, Literal


README_BEGIN = "<!-- BEGIN GENERATED WORK-ITEMS STATUS -->"
README_END = "<!-- END GENERATED WORK-ITEMS STATUS -->"
TRIAL_OWNER = "work-items-lifecycle-v1-trial"
TRIAL_MARKER = ".work-items-lifecycle-v1-trial.json"
MIGRATION_OWNER = "work-items-lifecycle-v1-migration"
MIGRATION_SCHEMA_VERSION = 1
MIGRATION_DIGEST_ALGORITHMS = {
    "file": "sha256-file-bytes-v1",
    "directory": "sha256-tree-entries-v1",
}
V1_TERMINALIZATION_OWNER = "work-items-lifecycle-v1-terminalization"
V1_TERMINALIZATION_SCHEMA_VERSION = 2
V1_TERMINALIZATION_AUTHORIZATION = "operator-authorized-v1-terminalization"
V1_TERMINALIZATION_FAILURE = "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING"
LEGACY_RETIREMENT_OWNER = "work-items-lifecycle-v1-legacy-retirement"
LEGACY_RETIREMENT_SCHEMA_VERSION = 1
LEGACY_RETIREMENT_FILE = "legacy-retirement.json"
LEGACY_CLEANUP_OWNER = "work-items-lifecycle-v1-legacy-candidate-cleanup"
LEGACY_CLEANUP_SCHEMA_VERSION = 1
LEGACY_CLEANUP_FILE = "legacy-candidate-cleanup.json"
CURRENT_IDENTITY_NORMALIZATION_OWNER = "work-items-lifecycle-v1-current-identity-normalization"
CURRENT_IDENTITY_NORMALIZATION_SCHEMA_VERSION = 1
WORK_ITEM_SCHEMA_KEY = "Lifecycle-schema"
WORK_ITEM_SCHEMA_VALUE = "work-items-physical-v1"
WORK_ITEM_SCHEMA_MARKER = f"{WORK_ITEM_SCHEMA_KEY}: {WORK_ITEM_SCHEMA_VALUE}"
LEGACY_READ_CLASSIFICATION = "WI-LEGACY-READ-COMPAT"
README_SECTIONS = (
    "Current focus",
    "Next actions",
    "Blockers",
    "Roadmap and milestones",
    "Recently completed",
)
UTC_INSTANT_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]*(?:\.[a-z0-9][a-z0-9-]*)*$")
OPTIONAL_RELATION_ABSENCE_MARKERS = frozenset({"none"})
FIELD_RE = re.compile(
    r"^\s*(?:[-*]\s*)?(?:\*\*)?([A-Za-z][A-Za-z0-9 -]*?)(?:\*\*)?\s*:\s*(.*?)\s*$"
)
DECISION_REQUIRED_FIELDS = (
    "id",
    "status",
    "date",
    "decided-by",
    "context",
    "supersedes",
    "superseded-by",
)
DECISION_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
DECISION_LIST_FIELD_RE = re.compile(r"^- ([a-z][a-z0-9-]*):\s*(.*?)\s*$")
DECISION_V0_KEY_RE = re.compile(r"^([A-Za-z][A-Za-z0-9 _-]*):(?: (.*))?$")
DECISION_V0_ACTIVE_VALUE_PREFIXES = ("&", "*", "!", "[", "{", "|", ">")
DECISION_V0_MANIFEST = "decision-v0-compatibility.json"
DECISION_V0_MANIFEST_SCHEMA_VERSION = 1
DECISION_H1_PLAIN_FIELD_RE = re.compile(r"^([A-Za-z][A-Za-z0-9 _-]*): (.+)$")
DECISION_H1_BOLD_FIELD_RE = re.compile(r"^- \*\*([A-Za-z][A-Za-z0-9 _-]*):\*\* (.+)$")
DECISION_H1_MANIFEST = "decision-h1-compatibility.json"
DECISION_H1_MANIFEST_SCHEMA_VERSION = 1
DECISION_FORMAT_V1 = "canonical-list-v1"
DECISION_FORMAT_V0 = "legacy-yaml-v0"
DECISION_FORMAT_H1 = "legacy-markdown-h1-v0"
FENCED_CODE_OPEN_RE = re.compile(
    r"^ {0,3}(?P<fence>`{3,}|~{3,})(?P<info>[^\r\n]*)$"
)
WORK_ITEM_SCHEMA_OCCURRENCE_RE = re.compile(
    r"^\s*(?:-\s*)?(?:\*\*)?(lifecycle-schema)(?:\*\*)?\s*:\s*(.*?)\s*$",
    re.IGNORECASE,
)


class LifecycleError(RuntimeError):
    def __init__(self, failure_id: str, message: str):
        super().__init__(message)
        self.failure_id = failure_id


_AGENT_RUN_LEDGER_MODULE = None


def _load_agent_run_ledger():
    global _AGENT_RUN_LEDGER_MODULE
    if _AGENT_RUN_LEDGER_MODULE is not None:
        return _AGENT_RUN_LEDGER_MODULE
    path = Path(__file__).with_name("agent-run-ledger.py")
    spec = importlib.util.spec_from_file_location("work_item_agent_run_ledger", path)
    if spec is None or spec.loader is None:
        raise LifecycleError("WI-LEDGER-MIGRATION-CANDIDATE-INVALID", "ledger staging owner is unavailable")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _AGENT_RUN_LEDGER_MODULE = module
    return module


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _normalize_sha256_input(value: object) -> object:
    if isinstance(value, str) and re.fullmatch(r"[0-9A-Fa-f]{64}", value):
        return value.casefold()
    return value


LIFECYCLE_CLEANUP_PHASES = (
    "receipt-final",
    "receipt-pending",
    "rollback-parent-chain",
    "rollback-readme",
    "rollback-status:work-item:2026-08-11-pr600-review-fix",
    "rollback-status:work-item:2026-08-11-pr598-review-fix",
    "rollback-postcheck",
    "transaction-release",
)


def _lifecycle_sanitize_diagnostic(value: object) -> str:
    diagnostic = " ".join(str(value).split())[:512]
    diagnostic = re.sub(
        r"(?i)\b[A-Z]:[\\/][^\s;]+",
        "<redacted-path>",
        diagnostic,
    )
    return diagnostic


@dataclass(frozen=True)
class LifecycleCleanupFailure:
    phase: str
    failure_id: str
    resource: str | None
    diagnostic: str
    cause_type: str | None


@dataclass(frozen=True)
class LifecycleOutcomeBundle:
    result: object | None
    primary: BaseException | None
    cleanup_failures: tuple[LifecycleCleanupFailure, ...]
    rollback: str


@dataclass(frozen=True)
class LifecycleDiagnosticCleanupFailure:
    phase: str
    failureId: str
    resource: str | None
    diagnostic: str
    causeType: str | None


@dataclass(frozen=True)
class LifecycleDiagnosticBundle:
    primaryKind: str
    primaryFailureId: str | None
    primaryType: str | None
    topLevelKind: str
    topLevelFailureId: str | None
    rollback: str
    cleanupFailures: tuple[LifecycleDiagnosticCleanupFailure, ...]


@dataclass(frozen=True)
class LifecycleDiagnosticDeliveryFailure:
    failure_id: str
    diagnostic: str


class LifecycleOutcomeComposer:
    """Transport-neutral owner of one primary and the fixed cleanup slots."""

    def __init__(self):
        self._result: object | None = None
        self._primary: BaseException | None = None
        self._cleanup: dict[str, LifecycleCleanupFailure] = {}
        self._rollback = "not-needed"

    def propose_result(self, result: object) -> None:
        self._result = result

    def capture_primary(self, primary: BaseException) -> None:
        if self._primary is None:
            self._primary = primary

    def record_cleanup(
        self,
        *,
        phase: str,
        failure_id: str,
        resource: str | None,
        diagnostic: object,
        cause: BaseException | None = None,
    ) -> None:
        if phase not in LIFECYCLE_CLEANUP_PHASES:
            raise ValueError(f"unknown lifecycle cleanup phase: {phase}")
        if phase in self._cleanup:
            raise ValueError(f"lifecycle cleanup phase already recorded: {phase}")
        self._cleanup[phase] = LifecycleCleanupFailure(
            phase=phase,
            failure_id=failure_id,
            resource=resource,
            diagnostic=_lifecycle_sanitize_diagnostic(diagnostic),
            cause_type=type(cause).__name__ if cause is not None else None,
        )

    def set_rollback(self, rollback: str) -> None:
        if rollback not in {"not-needed", "completed", "incomplete"}:
            raise ValueError(f"invalid rollback state: {rollback}")
        self._rollback = rollback

    def finalize(self) -> LifecycleOutcomeBundle:
        cleanup = tuple(
            self._cleanup[phase]
            for phase in LIFECYCLE_CLEANUP_PHASES
            if phase in self._cleanup
        )
        return LifecycleOutcomeBundle(
            result=self._result,
            primary=self._primary,
            cleanup_failures=cleanup,
            rollback=self._rollback,
        )

    @staticmethod
    def top_level(bundle: LifecycleOutcomeBundle) -> BaseException | None:
        if bundle.primary is not None:
            return bundle.primary
        if bundle.cleanup_failures:
            cleanup = bundle.cleanup_failures[0]
            return LifecycleError(cleanup.failure_id, cleanup.diagnostic)
        return None


def _lifecycle_diagnostic_bundle(
    bundle: LifecycleOutcomeBundle,
) -> LifecycleDiagnosticBundle:
    primary = bundle.primary
    if primary is None:
        primary_kind = "none"
        primary_failure_id = None
        primary_type = None
    elif isinstance(primary, LifecycleError):
        primary_kind = "typed"
        primary_failure_id = primary.failure_id
        primary_type = type(primary).__name__
    elif isinstance(
        primary,
        (asyncio.CancelledError, KeyboardInterrupt, SystemExit, GeneratorExit),
    ):
        primary_kind = "control-flow"
        primary_failure_id = None
        primary_type = type(primary).__name__
    else:
        primary_kind = "unexpected"
        primary_failure_id = None
        primary_type = type(primary).__name__
    if primary is not None:
        top_level_kind = f"{primary_kind}-primary"
        top_level_failure_id = primary_failure_id
    elif bundle.cleanup_failures:
        top_level_kind = "cleanup-only"
        top_level_failure_id = bundle.cleanup_failures[0].failure_id
    else:
        top_level_kind = "result"
        top_level_failure_id = None
    return LifecycleDiagnosticBundle(
        primaryKind=primary_kind,
        primaryFailureId=primary_failure_id,
        primaryType=primary_type,
        topLevelKind=top_level_kind,
        topLevelFailureId=top_level_failure_id,
        rollback=bundle.rollback,
        cleanupFailures=tuple(
            LifecycleDiagnosticCleanupFailure(
                phase=record.phase,
                failureId=record.failure_id,
                resource=record.resource,
                diagnostic=record.diagnostic,
                causeType=record.cause_type,
            )
            for record in bundle.cleanup_failures
        ),
    )


class LifecycleDiagnosticObserver:
    """Concrete invocation-scoped one-shot structured diagnostic mailbox."""

    def __init__(self, *, _reject_delivery: bool = False):
        self._mutex = threading.Lock()
        self._state = "empty"
        self._correlation = None
        self._snapshot = None
        self._delivery_failure = None
        self._delivery_attempts = 0
        self._reject_delivery = bool(_reject_delivery)

    @property
    def state(self) -> str:
        with self._mutex:
            return self._state

    @property
    def snapshot(self) -> LifecycleDiagnosticBundle | None:
        with self._mutex:
            return self._snapshot

    @property
    def delivery_failure(self) -> LifecycleDiagnosticDeliveryFailure | None:
        with self._mutex:
            return self._delivery_failure

    @property
    def delivery_attempts(self) -> int:
        with self._mutex:
            return self._delivery_attempts

    def _claim(self) -> object:
        with self._mutex:
            if self._state != "empty":
                raise TypeError("diagnostic_observer must be empty")
            correlation = object()
            self._correlation = correlation
            self._state = "claimed"
            return correlation

    def _deliver(
        self,
        correlation: object,
        bundle: LifecycleOutcomeBundle,
    ) -> bool:
        with self._mutex:
            if self._state != "claimed":
                return False
            self._delivery_attempts += 1
            if correlation is not self._correlation or self._reject_delivery:
                self._state = "delivery-failed"
                self._delivery_failure = LifecycleDiagnosticDeliveryFailure(
                    failure_id="WI-LIFECYCLE-DIAGNOSTIC-DELIVERY",
                    diagnostic="lifecycle diagnostic delivery was rejected",
                )
                self._correlation = None
                return False
            self._snapshot = _lifecycle_diagnostic_bundle(bundle)
            self._state = "delivered"
            self._correlation = None
            return True

    def _mark_not_needed(self, correlation: object) -> bool:
        with self._mutex:
            if self._state != "claimed" or correlation is not self._correlation:
                return False
            self._state = "not-needed"
            self._correlation = None
            return True


LIFECYCLE_LOCK_BYTES = b"work-items-lifecycle-owner-v1\n"
LIFECYCLE_LOCK_RELATIVE = Path(".scratch") / "work-items-lifecycle-owner.lock"


def _lifecycle_file_identity(info: os.stat_result) -> tuple[int, int]:
    return info.st_dev, info.st_ino


def _lifecycle_file_snapshot_key(info: os.stat_result) -> tuple[int, ...]:
    return (
        info.st_dev,
        info.st_ino,
        info.st_mode,
        info.st_nlink,
        info.st_size,
        info.st_mtime_ns,
        info.st_ctime_ns,
    )


def _lifecycle_path_has_reparse(path: Path) -> bool:
    try:
        info = path.lstat()
    except OSError:
        return False
    return path.is_symlink() or bool(
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
    )


def _lifecycle_unresolved_absolute(path: Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else Path.cwd() / path


def _lifecycle_reject_unreduced_reparse(
    path: Path,
    *,
    failure_id: str,
    message: str,
) -> None:
    """Inspect every caller-supplied path participant without resolving links."""
    candidate = _lifecycle_unresolved_absolute(path)
    cursor = Path(candidate.anchor)
    for part in candidate.parts[1:]:
        if part in {"", "."}:
            continue
        if part == "..":
            cursor = cursor.parent
            continue
        cursor /= part
        try:
            info = cursor.lstat()
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise LifecycleError(failure_id, message) from exc
        if stat.S_ISLNK(info.st_mode) or bool(
            getattr(info, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        ):
            raise LifecycleError(failure_id, message)


class LifecycleTransaction:
    """One fail-fast native lock for a repository's physical lifecycle."""

    def __init__(self, root: Path):
        _lifecycle_reject_unreduced_reparse(
            root,
            failure_id="WI-LIFECYCLE-LOCK-IDENTITY",
            message="lifecycle root or parent is a link or reparse point",
        )
        resolved = root.resolve()
        self.repository_root = resolved.parent if resolved.name == "work-items" else resolved
        self.path = self.repository_root / LIFECYCLE_LOCK_RELATIVE
        self._file = None
        self._identity: tuple[int, int] | None = None
        self._locked = False

    def _ensure_lock_file(self) -> None:
        scratch = self.path.parent
        scratch.mkdir(parents=True, exist_ok=True)
        if _lifecycle_path_has_reparse(scratch):
            raise LifecycleError(
                "WI-LIFECYCLE-LOCK-IDENTITY",
                "lifecycle lock parent is a link or reparse point",
            )
        if self.path.exists():
            if _lifecycle_path_has_reparse(self.path) or not self.path.is_file():
                raise LifecycleError(
                    "WI-LIFECYCLE-LOCK-IDENTITY",
                    "lifecycle lock path is not a regular non-reparse file",
                )
            return
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=".work-items-lifecycle-owner.lock.init-",
            dir=scratch,
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "wb", closefd=True) as stream:
                stream.write(LIFECYCLE_LOCK_BYTES)
                stream.flush()
                os.fsync(stream.fileno())
            try:
                os.link(temporary, self.path)
            except FileExistsError:
                pass
            except OSError as exc:
                raise LifecycleError(
                    "WI-LIFECYCLE-LOCK-UNSUPPORTED",
                    "filesystem cannot atomically initialize lifecycle lock",
                ) from exc
        finally:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass

    def _native_lock(self) -> None:
        assert self._file is not None
        try:
            if os.name == "nt":
                import msvcrt

                self._file.seek(0)
                msvcrt.locking(self._file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self._file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            if exc.errno in {errno.EACCES, errno.EAGAIN, errno.EDEADLK, errno.EPERM}:
                raise LifecycleError(
                    "WI-LIFECYCLE-LOCK-HELD",
                    "another lifecycle owner holds the transaction lock",
                ) from exc
            raise LifecycleError(
                "WI-LIFECYCLE-LOCK-UNSUPPORTED",
                "native non-blocking lifecycle locking is unavailable",
            ) from exc
        self._locked = True

    def _native_unlock(self) -> None:
        assert self._file is not None
        if os.name == "nt":
            import msvcrt

            self._file.seek(0)
            msvcrt.locking(self._file.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(self._file.fileno(), fcntl.LOCK_UN)
        self._locked = False

    def verify(self) -> None:
        if not self._locked or self._file is None or self._identity is None:
            raise LifecycleError(
                "WI-LIFECYCLE-LOCK-IDENTITY",
                "lifecycle transaction is not held",
            )
        try:
            handle = os.fstat(self._file.fileno())
            current = self.path.stat()
        except OSError as exc:
            raise LifecycleError(
                "WI-LIFECYCLE-LOCK-IDENTITY",
                "lifecycle lock identity cannot be revalidated",
            ) from exc
        if (
            _lifecycle_file_identity(handle) != self._identity
            or _lifecycle_file_identity(current) != self._identity
            or handle.st_size != len(LIFECYCLE_LOCK_BYTES)
            or _lifecycle_path_has_reparse(self.path)
        ):
            raise LifecycleError(
                "WI-LIFECYCLE-LOCK-IDENTITY",
                "lifecycle lock handle/path identity changed",
            )

    def __enter__(self) -> "LifecycleTransaction":
        self._ensure_lock_file()
        flags = os.O_RDWR | getattr(os, "O_BINARY", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        try:
            descriptor = os.open(self.path, flags)
            self._file = os.fdopen(descriptor, "r+b", closefd=True)
            self._native_lock()
            handle = os.fstat(self._file.fileno())
            self._identity = _lifecycle_file_identity(handle)
            self.verify()
            self._file.seek(0)
            if self._file.read() != LIFECYCLE_LOCK_BYTES:
                raise LifecycleError(
                    "WI-LIFECYCLE-LOCK-IDENTITY",
                    "lifecycle lock bytes differ",
                )
            return self
        except BaseException:
            if self._file is not None:
                if self._locked:
                    try:
                        self._native_unlock()
                    except OSError:
                        pass
                self._file.close()
                self._file = None
            raise

    def __exit__(self, exc_type, exc, traceback) -> bool:
        release_error: BaseException | None = None
        try:
            self.verify()
            self._native_unlock()
        except BaseException as candidate:
            release_error = candidate
        finally:
            if self._file is not None:
                self._file.close()
                self._file = None
        if release_error is not None:
            if isinstance(release_error, LifecycleError):
                raise release_error
            raise LifecycleError(
                "WI-LIFECYCLE-LOCK-IDENTITY",
                "lifecycle lock release failed",
            ) from release_error
        return False


_CURRENT_LIFECYCLE_TRANSACTION: contextvars.ContextVar[
    LifecycleTransaction | None
] = contextvars.ContextVar("work_items_lifecycle_transaction", default=None)
_CURRENT_LIFECYCLE_OUTCOME_COMPOSER: contextvars.ContextVar[
    LifecycleOutcomeComposer | None
] = contextvars.ContextVar("work_items_lifecycle_outcome_composer", default=None)


def _lifecycle_participant(function):
    @functools.wraps(function)
    def wrapper(root: Path, *args, **kwargs):
        diagnostic_observer = kwargs.pop("diagnostic_observer", None)
        if diagnostic_observer is not None and type(diagnostic_observer) is not LifecycleDiagnosticObserver:
            raise TypeError(
                "diagnostic_observer must be an exact LifecycleDiagnosticObserver"
            )
        current = _CURRENT_LIFECYCLE_TRANSACTION.get()
        current_composer = _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.get()
        if current is not None:
            if diagnostic_observer is not None:
                raise TypeError("nested lifecycle calls cannot claim a second observer")
            if current_composer is None:
                raise LifecycleError(
                    "WI-LIFECYCLE-LOCK-IDENTITY",
                    "nested lifecycle call has no outcome composer",
                )
            _lifecycle_reject_unreduced_reparse(
                Path(root),
                failure_id="WI-LIFECYCLE-LOCK-IDENTITY",
                message="lifecycle root or parent is a link or reparse point",
            )
            resolved = Path(root).resolve()
            repository_root = resolved.parent if resolved.name == "work-items" else resolved
            if current.repository_root != repository_root:
                raise LifecycleError(
                    "WI-LIFECYCLE-LOCK-IDENTITY",
                    "nested lifecycle call targets a different repository",
                )
            current.verify()
            return function(root, *args, **kwargs)

        correlation = (
            diagnostic_observer._claim()
            if diagnostic_observer is not None
            else None
        )
        composer = LifecycleOutcomeComposer()
        transaction = None
        transaction_token = None
        composer_token = _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.set(composer)
        entered = False
        try:
            _lifecycle_reject_unreduced_reparse(
                Path(root),
                failure_id="WI-LIFECYCLE-LOCK-IDENTITY",
                message="lifecycle root or parent is a link or reparse point",
            )
            transaction = LifecycleTransaction(Path(root))
            transaction.__enter__()
            entered = True
            transaction_token = _CURRENT_LIFECYCLE_TRANSACTION.set(transaction)
            try:
                composer.propose_result(function(root, *args, **kwargs))
            except BaseException as exc:
                composer.capture_primary(exc)
        except BaseException as exc:
            composer.capture_primary(exc)
        finally:
            if transaction_token is not None:
                _CURRENT_LIFECYCLE_TRANSACTION.reset(transaction_token)
            if entered and transaction is not None:
                try:
                    transaction.__exit__(None, None, None)
                except BaseException as exc:
                    composer.record_cleanup(
                        phase="transaction-release",
                        failure_id="WI-LIFECYCLE-LOCK-IDENTITY",
                        resource=".scratch/work-items-lifecycle-owner.lock",
                        diagnostic="lifecycle transaction release failed",
                        cause=exc,
                    )
            _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.reset(composer_token)

        bundle = composer.finalize()
        top_level = composer.top_level(bundle)
        if diagnostic_observer is not None:
            if top_level is None:
                diagnostic_observer._mark_not_needed(correlation)
            else:
                diagnostic_observer._deliver(correlation, bundle)
        if top_level is not None:
            raise top_level
        result = bundle.result
        if isinstance(result, PartialRecoveryCommittedCandidate):
            return result.result
        return result

    wrapper.__lifecycle_transaction_participant__ = True
    return wrapper


@dataclass(frozen=True)
class Category:
    name: str
    current_root: str
    current_kind: str
    current_statuses: frozenset[str]
    terminal_statuses: frozenset[str]


CATEGORIES = {
    "work-item": Category(
        "work-item",
        "",
        "work-item",
        frozenset({"candidate", "active", "blocked"}),
        frozenset({"closed", "cancelled", "completed"}),
    ),
    "bug": Category(
        "bug",
        "bugs",
        "flat",
        frozenset({"open", "triaged", "accepted"}),
        frozenset({"fixed", "resolved", "refuted", "superseded", "closed"}),
    ),
    "decision": Category(
        "decision",
        "decisions",
        "flat",
        frozenset({"proposed", "accepted"}),
        frozenset({"dropped", "superseded", "reverted", "no-longer-governing"}),
    ),
    "lesson": Category(
        "lesson",
        "lessons",
        "flat",
        frozenset({"open", "applied"}),
        frozenset({"dropped", "superseded", "archived"}),
    ),
    "roadmap": Category(
        "roadmap",
        "roadmaps",
        "flat",
        frozenset({"draft", "active"}),
        frozenset({"superseded", "archived"}),
    ),
    "epic": Category(
        "epic",
        "epics",
        "flat",
        frozenset({"active"}),
        frozenset({"closed", "cancelled", "archived"}),
    ),
}
CATEGORY_ALIASES = {
    "work-items": "work-item",
    "workitem": "work-item",
    "bugs": "bug",
    "decisions": "decision",
    "lessons": "lesson",
    "roadmaps": "roadmap",
    "epics": "epic",
}


@dataclass
class ReadmeEntry:
    section: str
    logical_reference: str
    label: str
    link: Path
    checked: bool
    detail: str = ""
    source_paths: list[Path] = field(default_factory=list)
    classification: str | None = None


@dataclass(frozen=True)
class CategoryAdmission:
    category: str
    current_reader: str
    terminal_validator: str
    utc_field_owner: str
    negative_fixture: str
    utc_field: str
    detail_field: str
    evidence_field: str


@dataclass(frozen=True)
class ScratchDisposition:
    original: Path
    tombstone: Path
    disposition: str
    proof: dict | None
    canonical_pointer: Path
    snapshot: object | None
    release_receipt: dict | None = None


@dataclass(frozen=True)
class EvidenceRetentionPlan:
    path: Path
    tree_sha256: str
    canonical_pointer: Path
    canonical_pointer_sha256: str
    limits: "PayloadDigestLimits"


BUG_DISPOSITIONS_MANIFEST = "bug-dispositions.json"
BUG_DISPOSITIONS_RECEIPT = "bug-dispositions-receipt.json"
BUG_DISPOSITIONS_SCHEMA_VERSION = 1
BUG_DISPOSITIONS_SCHEMA_VERSIONS = {1, 2, 3}
BUG_DISPOSITIONS_OWNER = "mutate-work-item:close-item-bug-dispositions-v1"
SHA256_RE = re.compile(r"[0-9a-f]{64}")
BUG_DISPOSITION_ACTIONS = {"terminalize", "preserve-current"}
BUG_DISPOSITION_PLACEHOLDER_CONTEXTS = {"adjacent-finding", "standalone"}
BUG_DISPOSITION_TEXT_LIMIT = 2048
TRANSITION_INTENT_INVENTORY_MAX_ENTRIES = 1024
TRANSITION_INTENT_FILE_BYTE_CAP = 256 * 1024
TRANSITION_INTENT_INVENTORY_BYTE_CAP = 8 * 1024 * 1024
LEDGER_LOCATION_PROOF_BYTE_CAP = 4 * 1024 * 1024
BUG_SUPERSESSION_OWNER = "mutate-work-item:current-bug-supersession-v1"
BUG_SUPERSESSION_KIND = "current-bug-supersession-v1"
BUG_SUCCESSOR_BINDING_FIELDS = {
    "schemaVersion",
    "operationId",
    "sourceReference",
    "registryReference",
    "recordReference",
    "recordSha256",
    "acceptedBy",
    "acceptedAt",
    "acceptanceEvidence",
}


@dataclass(frozen=True)
class BugDispositionPlan:
    bug_id: str
    action: str
    source: Path
    target: Path | None
    before: bytes
    after: bytes
    status_before: str
    status_after: str
    context_before: str | None = None
    context_after: str | None = None


@dataclass(frozen=True)
class PartialRecoveryTarget:
    reference: str
    inventory_tree_preimage: str
    status_preimage: str
    status_afterimage: str
    projected_tree_afterimage: str
    closure_sha256: str


@dataclass(frozen=True)
class PartialRecoveryResult:
    receipt_sha256: str
    audit: str
    replay: bool


@dataclass(frozen=True)
class PartialRecoveryCommittedCandidate:
    result: PartialRecoveryResult


@dataclass(frozen=True)
class CapturedPathParentChain:
    participants: tuple[tuple[Path, tuple[int, int]], ...]


@dataclass(frozen=True)
class CapturedFileSnapshot:
    path: Path
    identity: tuple[int, int]
    length: int
    data: bytes
    parent_chain: CapturedPathParentChain
    require_single_link: bool = False


PARTIAL_MIGRATION_RECOVERY_INVENTORY_SHA256 = (
    "909A56FDBE1EC62A7D28B76D7FC682F1618B5956CCA501E525E89C3BC19E622C"
)
PARTIAL_MIGRATION_RECOVERY_README_PREIMAGE_SHA256 = (
    "37AFA08CF7DEC3ECF3A37324A1CABF093CB12C52152A576FDE11F5889E0076C8"
)
PARTIAL_MIGRATION_RECOVERY_TARGETS = {
    "work-item:2026-08-11-pr598-review-fix": PartialRecoveryTarget(
        reference="work-item:2026-08-11-pr598-review-fix",
        inventory_tree_preimage="D952DAEE21E51353687631ED179AA9EFDF0B1B562AF6344996FCDF3FCFB01C25",
        status_preimage="0E6032B6DCE98B4AA2D4F320FB0935C98802966AB4256E81DFB2150EB0FEB263",
        status_afterimage="D9FEB4DA7C0654845B83607EBC62BC065C3C96A0252DEA439AFAAB2E777EA190",
        projected_tree_afterimage="996F678C1F87898EFFE46EF9DFF413C6CA47A827AD398724224B03D5FD840E7B",
        closure_sha256="577777AAA5690F61D454503102321EBD101C2D5BDBEFADF9CF075CCCC645EDE7",
    ),
    "work-item:2026-08-11-pr600-review-fix": PartialRecoveryTarget(
        reference="work-item:2026-08-11-pr600-review-fix",
        inventory_tree_preimage="8391722DFCD41A5C177D88D73FBE2DE7AD2DE1C0BB07D526DF7354DCD16D4D80",
        status_preimage="FBAB061063D35B03425E54EADB17EA3630606FE7B00EECEBC44361A02677FB14",
        status_afterimage="0F1987414B50461CC5F810DA7BF28458054A5D34ED9B7D8DE25A64BBBB678749",
        projected_tree_afterimage="5E67E1A549CD60A2BC67887631B5C3AA9F17E0AC8D78262EE335E959F2FF06BD",
        closure_sha256="30FA23A908E529D763A63A07FB69BF748692BC0BA1A2606D34EE718630F89998",
    ),
}
PARTIAL_MIGRATION_RECOVERY_UNCHANGED_ROWS = {
    "bug:2026-07-25-cleanup-aggressive-exe-extension-index-out-of-range-panic": (
        "ABCA21DC053115D00C0AB7C830204E9DE440A08A53486ABE52F9873044839CCE"
    ),
    "bug:2026-07-26-route-daemon-state-read-unhardened-parent-fallback-writes-hub-mcp-log": (
        "D2DD54B20F24CE36B572F3BF7108B5CFC60974971D22AC3B47DD1BD24F517ABF"
    ),
}


ROOT_CONTRACT_FILE = "root-contract.json"
ROOT_CONTRACT_SCHEMA = "work-items-root-contract"
ROOT_CONTRACT_VERSION = 2
ROOT_CONTRACT_FAILURE = "WI-CATEGORY-ROOT-CONTRACT-INVALID"


def _root_contract_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    value: dict[str, object] = {}
    for key, item in pairs:
        if key in value:
            raise LifecycleError(
                ROOT_CONTRACT_FAILURE,
                f"root contract repeats JSON key: {key}",
            )
        value[key] = item
    return value


def _expanded_root_contract_auxiliary_roots(contract: dict[str, object]) -> dict[str, dict[str, str]]:
    """Validate the expanded v2 envelope without granting its metadata lifecycle authority."""

    def valid_path(value: object, *, direct: bool = False) -> bool:
        if not isinstance(value, str) or not value or "\\" in value or ":" in value:
            return False
        parts = value.split("/")
        if any(part in {"", ".", ".."} for part in parts):
            return False
        return not direct or len(parts) == 1

    def ordered_paths(
        value: object, field: str, *, direct: bool, kinds: set[str] | None = None
    ) -> list[str]:
        if not isinstance(value, list):
            raise LifecycleError(ROOT_CONTRACT_FAILURE, f"root contract {field} must be an array")
        paths: list[str] = []
        for entry in value:
            path = entry
            if kinds is not None:
                if (
                    not isinstance(entry, dict)
                    or set(entry) != {"path", "kind"}
                    or not isinstance(entry.get("kind"), str)
                    or entry["kind"] not in kinds
                ):
                    raise LifecycleError(ROOT_CONTRACT_FAILURE, f"root contract {field} entry is invalid")
                path = entry["path"]
            if not valid_path(path, direct=direct):
                raise LifecycleError(ROOT_CONTRACT_FAILURE, f"root contract {field} path is invalid")
            paths.append(path)
        try:
            encoded = [path.encode("utf-8") for path in paths]
        except UnicodeEncodeError as exc:
            raise LifecycleError(ROOT_CONTRACT_FAILURE, f"root contract {field} path is not UTF-8") from exc
        if encoded != sorted(set(encoded)):
            raise LifecycleError(
                ROOT_CONTRACT_FAILURE, f"root contract {field} paths must be ordered and unique"
            )
        return paths

    root_files = ordered_paths(contract["rootFiles"], "rootFiles", direct=True)
    if ROOT_CONTRACT_FILE not in root_files:
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract rootFiles omits the contract file")
    lifecycle = ordered_paths(
        contract["lifecycleRoots"], "lifecycleRoots", direct=True,
        kinds={"active-items", "archived-items"},
    )
    lifecycle_entries = contract["lifecycleRoots"]
    if lifecycle != ["active", "archive"] or [entry["kind"] for entry in lifecycle_entries] != [
        "active-items", "archived-items"
    ]:
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract lifecycle roots do not match local roots")
    registries = ordered_paths(
        contract["registries"], "registries", direct=True,
        kinds={"flat-markdown", "flat-markdown-with-month-archive"},
    )
    supported_registries = {"backlog"} | {
        category.current_root for category in CATEGORIES.values() if category.current_kind == "flat"
    }
    if set(registries) != supported_registries:
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract registries do not match local roots")
    auxiliary = ordered_paths(
        contract["auxiliaryRoots"], "auxiliaryRoots", direct=True, kinds={"flat-json"}
    )
    if len(set(lifecycle + registries + auxiliary)) != len(lifecycle + registries + auxiliary):
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract root path is declared twice")
    ordered_paths(contract["activeItemSubdirectories"], "activeItemSubdirectories", direct=True)
    ordered_paths(contract["archiveRootFiles"], "archiveRootFiles", direct=True)
    historical = ordered_paths(
        contract["historicalItemDirectoryExceptions"],
        "historicalItemDirectoryExceptions", direct=False,
    )
    if any(len(path.split("/")) < 4 or not path.startswith("archive/") for path in historical):
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract historical exception path is invalid")
    root_file_names = {name.casefold() for name in root_files}
    if any(name.casefold() in root_file_names for name in auxiliary):
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "auxiliary root collides with a declared root file")
    return {entry["path"]: {"kind": entry["kind"]} for entry in contract["auxiliaryRoots"]}


@dataclass(frozen=True)
class ProjectTopology:
    work_items: Path
    auxiliary_roots: frozenset[str]
    read_model_roots: frozenset[str] = frozenset()
    root_contract_present: bool = False

    @property
    def canonical_roots(self) -> frozenset[str]:
        roots = {"backlog", "active", "archive"}
        roots.update(
            category.current_root
            for category in CATEGORIES.values()
            if category.current_kind == "flat"
        )
        return frozenset(roots)

    @property
    def reserved_roots(self) -> frozenset[str]:
        return self.canonical_roots | self.read_model_roots

    @property
    def allowed_roots(self) -> frozenset[str]:
        roots = set(self.reserved_roots)
        roots.update(self.auxiliary_roots)
        return frozenset(roots)

    def assert_known_top_level_roots(self) -> None:
        if not self.work_items.is_dir():
            return
        unknown_roots = sorted(
            path.name
            for path in self.work_items.iterdir()
            if path.is_dir() and path.name not in self.allowed_roots
        )
        if unknown_roots:
            noun = "directory" if len(unknown_roots) == 1 else "directories"
            raise LifecycleError(
                "WI-CATEGORY-UNKNOWN-ROOT",
                f"unknown top-level work-items {noun}: " + ", ".join(unknown_roots),
            )

    def with_read_model_roots(self) -> ProjectTopology:
        if self.read_model_roots:
            return self
        try:
            validator = _load_agent_run_ledger().load_validator()
            historical_storage = validator.historical_artifact_disposition_storage_identity()
            historical_storage = validator.confine_legacy_projection_identifier(
                historical_storage,
                failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID",
            )
        except (FileNotFoundError, ImportError, OSError):
            # Standalone checker bundles intentionally omit the optional
            # lifecycle writer and retain their legacy category set.
            return self
        except (AttributeError, TypeError, ValueError) as exc:
            raise LifecycleError(
                "WI-LEDGER-MIGRATION-MANIFEST-INVALID",
                "historical disposition storage identity is unavailable or invalid",
            ) from exc
        return ProjectTopology(
            work_items=self.work_items,
            auxiliary_roots=self.auxiliary_roots,
            read_model_roots=frozenset({historical_storage}),
            root_contract_present=self.root_contract_present,
        )


def _resolve_project_topology(
    root: Path,
    *,
    root_failure_id: str = ROOT_CONTRACT_FAILURE,
) -> ProjectTopology:
    unresolved = _lifecycle_unresolved_absolute(Path(root))
    resolved = unresolved.resolve()
    work_items = resolved if resolved.name == "work-items" else resolved / "work-items"
    contract_path = work_items / ROOT_CONTRACT_FILE
    try:
        contract_path.lstat()
    except FileNotFoundError:
        return ProjectTopology(work_items=work_items, auxiliary_roots=frozenset())
    except OSError as exc:
        raise LifecycleError(
            ROOT_CONTRACT_FAILURE, "root contract entry cannot be inspected"
        ) from exc
    _lifecycle_reject_unreduced_reparse(
        unresolved,
        failure_id=root_failure_id,
        message="repository root or parent contains a link or reparse point",
    )
    _lifecycle_reject_unreduced_reparse(
        work_items,
        failure_id=root_failure_id,
        message="work-items root contains a link or reparse point",
    )
    _lifecycle_reject_unreduced_reparse(
        contract_path,
        failure_id=ROOT_CONTRACT_FAILURE,
        message="root contract contains a link or reparse point",
    )
    if not contract_path.is_file():
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract must be a regular file")
    try:
        contract = json.loads(
            contract_path.read_text(encoding="utf-8"),
            object_pairs_hook=_root_contract_json_object,
        )
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract must be valid UTF-8 JSON") from exc
    if (
        not isinstance(contract, dict)
        or contract.get("schema") != ROOT_CONTRACT_SCHEMA
        or type(contract.get("version")) is not int
        or contract.get("version") != ROOT_CONTRACT_VERSION
    ):
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract schema is invalid")
    narrow_keys = {"schema", "version", "auxiliaryRoots"}
    expanded_keys = narrow_keys | {
        "rootFiles", "lifecycleRoots", "registries", "activeItemSubdirectories",
        "archiveRootFiles", "historicalItemDirectoryExceptions",
    }
    if set(contract) == narrow_keys and isinstance(contract["auxiliaryRoots"], dict):
        auxiliary_definitions = contract["auxiliaryRoots"]
    elif set(contract) == expanded_keys:
        auxiliary_definitions = _expanded_root_contract_auxiliary_roots(contract)
    else:
        raise LifecycleError(ROOT_CONTRACT_FAILURE, "root contract schema is invalid")
    topology = ProjectTopology(
        work_items=work_items,
        auxiliary_roots=frozenset(),
        root_contract_present=True,
    ).with_read_model_roots()
    auxiliary_roots: set[str] = set()
    for name, definition in auxiliary_definitions.items():
        if not isinstance(name, str) or SLUG_RE.fullmatch(name) is None:
            raise LifecycleError(ROOT_CONTRACT_FAILURE, "auxiliary root name is not a bare root")
        if name in topology.reserved_roots:
            raise LifecycleError(
                ROOT_CONTRACT_FAILURE,
                f"auxiliary root collides with a reserved root: {name}",
            )
        if name.casefold() == "README.md".casefold():
            raise LifecycleError(
                ROOT_CONTRACT_FAILURE,
                f"auxiliary root collides with generated README: {name}",
            )
        if not isinstance(definition, dict) or definition != {"kind": "flat-json"}:
            raise LifecycleError(ROOT_CONTRACT_FAILURE, f"auxiliary root definition is invalid: {name}")
        auxiliary_path = work_items / name
        _lifecycle_reject_unreduced_reparse(
            auxiliary_path,
            failure_id=ROOT_CONTRACT_FAILURE,
            message=f"auxiliary root contains a link or reparse point: {name}",
        )
        if auxiliary_path.exists() and not auxiliary_path.is_dir():
            raise LifecycleError(ROOT_CONTRACT_FAILURE, f"auxiliary root is not a directory: {name}")
        auxiliary_roots.add(name)
    topology = ProjectTopology(
        work_items=topology.work_items,
        auxiliary_roots=frozenset(auxiliary_roots),
        read_model_roots=topology.read_model_roots,
        root_contract_present=True,
    )
    topology.assert_known_top_level_roots()
    return topology


def _work_items_root(
    root: Path,
    *,
    root_failure_id: str = ROOT_CONTRACT_FAILURE,
) -> Path:
    return _resolve_project_topology(root, root_failure_id=root_failure_id).work_items


def is_valid_slug(slug: str) -> bool:
    """Return whether *slug* satisfies the canonical lifecycle identity grammar."""
    return isinstance(slug, str) and SLUG_RE.fullmatch(slug) is not None


def _validate_slug(slug: str) -> None:
    if not is_valid_slug(slug):
        raise LifecycleError("WI-INVALID-SLUG", f"invalid bare slug: {slug!r}")


def _authoritative_markdown_lines(text: str) -> Iterable[tuple[int, str]]:
    """Yield positioned Markdown lines that can own lifecycle fields.

    Fenced code is evidence/content, not record metadata.  Reject an opened
    fence without a valid close so malformed Markdown cannot silently widen or
    shrink the authoritative field surface.
    """
    fence_char: str | None = None
    fence_length = 0
    for line_number, line in enumerate(text.splitlines(), start=1):
        if fence_char is not None:
            closing = re.fullmatch(
                rf" {{0,3}}{re.escape(fence_char)}{{{fence_length},}}[ \t]*",
                line,
            )
            if closing:
                fence_char = None
                fence_length = 0
            continue

        opening = FENCED_CODE_OPEN_RE.fullmatch(line)
        if opening:
            fence = opening.group("fence")
            info = opening.group("info")
            if fence[0] == "`" and "`" in info:
                yield line_number, line
                continue
            fence_char = fence[0]
            fence_length = len(fence)
            continue
        yield line_number, line

    if fence_char is not None:
        raise LifecycleError(
            "WI-CATEGORY-MARKDOWN-INVALID",
            "unterminated fenced code block in lifecycle record",
        )


def _authoritative_field_occurrences(
    text: str,
) -> tuple[tuple[int, str, str, str], ...]:
    occurrences: list[tuple[int, str, str, str]] = []
    for line_number, line in _authoritative_markdown_lines(text):
        match = FIELD_RE.fullmatch(line)
        if match:
            occurrences.append(
                (
                    line_number,
                    match.group(1).strip().casefold(),
                    match.group(2).strip(),
                    line,
                )
            )
    return tuple(occurrences)


def _parse_fields(text: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for _line_number, name, value, _line in _authoritative_field_occurrences(text):
        fields[name] = value
    return fields


@dataclass(frozen=True)
class CurrentDecisionRecord:
    format: str
    fields: Mapping[str, str | tuple[str, ...]]
    raw_status: str
    admitted_current_status: str | None
    body_offset: int
    legacy_read_only: bool


@dataclass(frozen=True)
class DecisionCompatibilityProfile:
    label: str
    format: str
    manifest_name: str
    manifest_schema_version: int
    anchor_manifest_field: str
    anchor_baseline_field: str
    anchor_cutover_field: str
    manifest_missing_failure_id: str
    manifest_invalid_failure_id: str
    unadmitted_failure_id: str
    manifest_stale_failure_id: str
    hash_mismatch_failure_id: str
    retired_reappeared_failure_id: str
    validate_record: Callable[[Path, str, str], CurrentDecisionRecord]


def _read_current_decision_text(path: Path, slug: str) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-DECISION-SCHEMA-INVALID",
            f"decision:{slug} must be UTF-8",
        ) from exc


def _current_decision_format(text: str, slug: str) -> str:
    lines = text.splitlines()
    first = lines[0] if lines else ""
    if first.startswith("- "):
        return DECISION_FORMAT_V1
    if first == "---":
        return DECISION_FORMAT_V0
    if first.startswith("# ") and first[2:].strip():
        return DECISION_FORMAT_H1
    raise LifecycleError(
        "WI-DECISION-FORMAT-UNSUPPORTED",
        f"decision:{slug} has an unsupported first-line format",
    )


def _decision_filename_date_suffix(slug: str) -> tuple[str, str]:
    match = re.fullmatch(r"(\d{4}-\d{2}-\d{2})-(.+)", slug)
    if match is None:
        raise LifecycleError(
            "WI-DECISION-IDENTITY-MISMATCH",
            f"decision:{slug} requires a dated filename with a non-empty suffix",
        )
    date_value, suffix = match.groups()
    try:
        parsed = datetime.strptime(date_value, "%Y-%m-%d")
    except ValueError as exc:
        raise LifecycleError(
            "WI-DECISION-IDENTITY-MISMATCH",
            f"decision:{slug} has an invalid filename date",
        ) from exc
    if parsed.strftime("%Y-%m-%d") != date_value:
        raise LifecycleError(
            "WI-DECISION-IDENTITY-MISMATCH",
            f"decision:{slug} has an invalid filename date",
        )
    return date_value, suffix


def _immutable_decision_fields(
    fields: dict[str, str | tuple[str, ...]],
) -> Mapping[str, str | tuple[str, ...]]:
    return MappingProxyType(dict(fields))


def _validate_current_decision_v1(text: str, slug: str) -> CurrentDecisionRecord:
    lines = text.splitlines()
    heading_index = next(
        (index for index, line in enumerate(lines) if line.startswith("#")),
        None,
    )
    if heading_index is None:
        raise LifecycleError(
            "WI-DECISION-SCHEMA-INVALID",
            f"decision:{slug} has no body heading",
        )
    first_heading = lines[heading_index]
    if not (
        re.match(r"^#\s+\S", first_heading)
        or first_heading == "## Decision"
    ):
        bounded_heading = (
            first_heading
            if len(first_heading) <= 160
            else first_heading[:157] + "..."
        )
        raise LifecycleError(
            "WI-DECISION-SCHEMA-INVALID",
            f"decision:{slug} has unsupported first body heading at line "
            f"{heading_index + 1}: {bounded_heading!r}",
        )

    leading_occurrences: dict[str, tuple[int, str]] = {}
    previous_field = False
    for line_number, line in enumerate(lines[:heading_index], start=1):
        if not line.strip():
            previous_field = False
            continue
        match = DECISION_LIST_FIELD_RE.fullmatch(line)
        if match:
            name = match.group(1).strip().casefold()
            if name in leading_occurrences:
                raise LifecycleError(
                    "WI-DECISION-FIELD-DUPLICATE",
                    f"decision:{slug} duplicates leading field '{name}'",
                )
            leading_occurrences[name] = (line_number, match.group(2).strip())
            previous_field = True
            continue
        if FIELD_RE.fullmatch(line):
            raise LifecycleError(
                "WI-DECISION-SCHEMA-INVALID",
                f"decision:{slug} has a non-list metadata field at line {line_number}",
            )
        if line[:1].isspace() and previous_field:
            continue
        previous_field = False

    occurrences = _authoritative_field_occurrences(text)
    for required in DECISION_REQUIRED_FIELDS:
        matches = [
            (line_number, value)
            for line_number, name, value, _line in occurrences
            if name == required
        ]
        if len(matches) > 1:
            raise LifecycleError(
                "WI-DECISION-FIELD-DUPLICATE",
                f"decision:{slug} duplicates required field '{required}'",
            )
        leading = leading_occurrences.get(required)
        if len(matches) != 1 or leading is None or matches[0][0] != leading[0] or not leading[1]:
            raise LifecycleError(
                "WI-DECISION-SCHEMA-INVALID",
                f"decision:{slug} requires one non-empty leading '{required}' field",
            )

    fields = {name: value for name, (_line_number, value) in leading_occurrences.items()}
    if fields["id"] != slug:
        raise LifecycleError(
            "WI-DECISION-IDENTITY-MISMATCH",
            f"decision:{slug} id does not match its filename",
        )
    date_value = fields["date"]
    try:
        parsed_date = datetime.strptime(date_value, "%Y-%m-%d")
    except ValueError as exc:
        raise LifecycleError(
            "WI-DECISION-IDENTITY-MISMATCH",
            f"decision:{slug} date must be a real YYYY-MM-DD value",
        ) from exc
    if (
        not DECISION_DATE_RE.fullmatch(date_value)
        or parsed_date.strftime("%Y-%m-%d") != date_value
        or not slug.startswith(f"{date_value}-")
    ):
        raise LifecycleError(
            "WI-DECISION-IDENTITY-MISMATCH",
            f"decision:{slug} date does not match its filename prefix",
        )
    if fields["status"] not in CATEGORIES["decision"].current_statuses:
        raise LifecycleError(
            "WI-DECISION-SCHEMA-INVALID",
            f"decision:{slug} has unsupported current status '{fields['status']}'",
        )
    raw_lines = text.splitlines(keepends=True)
    body_offset = len("".join(raw_lines[:heading_index]).encode("utf-8"))
    return CurrentDecisionRecord(
        format=DECISION_FORMAT_V1,
        fields=_immutable_decision_fields(fields),
        raw_status=fields["status"],
        admitted_current_status=fields["status"],
        body_offset=body_offset,
        legacy_read_only=False,
    )


def _normalize_decision_v0_key(key: str) -> str:
    return re.sub(r"[ _-]+", "-", key.casefold())


def _reject_decision_v0_active_value(slug: str, line_number: int, value: str) -> None:
    if value.startswith(DECISION_V0_ACTIVE_VALUE_PREFIXES):
        raise LifecycleError(
            "WI-DECISION-V0-UNSUPPORTED-NESTING",
            f"decision:{slug} has an active YAML value at line {line_number}",
        )


def _validate_current_decision_v0(
    text: str,
    slug: str,
    *,
    v0_cutover_date: str | None,
) -> CurrentDecisionRecord:
    logical_lines = text.splitlines()
    closing_index = next(
        (index for index, line in enumerate(logical_lines[1:], start=1) if line == "---"),
        None,
    )
    if closing_index is None:
        raise LifecycleError(
            "WI-DECISION-V0-SCHEMA-INVALID",
            f"decision:{slug} has no exact closing frontmatter delimiter",
        )
    header = logical_lines[1:closing_index]
    if not header:
        raise LifecycleError(
            "WI-DECISION-V0-SCHEMA-INVALID",
            f"decision:{slug} has an empty V0 header",
        )
    body = "\n".join(logical_lines[closing_index + 1 :])
    if not body.strip():
        raise LifecycleError(
            "WI-DECISION-V0-SCHEMA-INVALID",
            f"decision:{slug} has an empty V0 body",
        )

    fields: dict[str, str | tuple[str, ...]] = {}
    normalized_keys: dict[str, str] = {}
    pending_sequence_key: str | None = None
    sequence_values: list[str] = []

    def finish_pending(line_number: int) -> None:
        nonlocal pending_sequence_key, sequence_values
        if pending_sequence_key is None:
            return
        if not sequence_values:
            raise LifecycleError(
                "WI-DECISION-V0-SCHEMA-INVALID",
                f"decision:{slug} has an empty sequence field before line {line_number}",
            )
        fields[pending_sequence_key] = tuple(sequence_values)
        pending_sequence_key = None
        sequence_values = []

    for line_number, line in enumerate(header, start=2):
        if not line or "\t" in line:
            raise LifecycleError(
                "WI-DECISION-V0-SCHEMA-INVALID",
                f"decision:{slug} has a blank or tab-bearing header line {line_number}",
            )
        if line.startswith("  - "):
            value = line[4:]
            if pending_sequence_key is None or not value:
                raise LifecycleError(
                    "WI-DECISION-V0-UNSUPPORTED-NESTING",
                    f"decision:{slug} has an unsupported sequence at line {line_number}",
                )
            _reject_decision_v0_active_value(slug, line_number, value)
            sequence_values.append(value)
            continue
        if line.startswith("- "):
            raise LifecycleError(
                "WI-DECISION-V0-SCHEMA-INVALID",
                f"decision:{slug} has a V1 list field inside V0 at line {line_number}",
            )
        if line[:1].isspace():
            raise LifecycleError(
                "WI-DECISION-V0-UNSUPPORTED-NESTING",
                f"decision:{slug} has unsupported indentation at line {line_number}",
            )
        finish_pending(line_number)
        match = DECISION_V0_KEY_RE.fullmatch(line)
        if match is None:
            raise LifecycleError(
                "WI-DECISION-V0-SCHEMA-INVALID",
                f"decision:{slug} has an invalid V0 field at line {line_number}",
            )
        key = match.group(1)
        if key != key.strip():
            raise LifecycleError(
                "WI-DECISION-V0-SCHEMA-INVALID",
                f"decision:{slug} has an invalid V0 key at line {line_number}",
            )
        normalized = _normalize_decision_v0_key(key)
        if normalized in normalized_keys:
            raise LifecycleError(
                "WI-DECISION-V0-FIELD-DUPLICATE",
                f"decision:{slug} duplicates V0 key '{key}' at line {line_number}",
            )
        normalized_keys[normalized] = key
        value = match.group(2)
        if value is None or value == "":
            pending_sequence_key = key
            sequence_values = []
            continue
        if value.startswith(" "):
            raise LifecycleError(
                "WI-DECISION-V0-SCHEMA-INVALID",
                f"decision:{slug} has an invalid scalar at line {line_number}",
            )
        _reject_decision_v0_active_value(slug, line_number, value)
        fields[key] = value
    finish_pending(closing_index + 1)

    raw_status = fields.get("status")
    if not isinstance(raw_status, str) or not raw_status:
        raise LifecycleError(
            "WI-DECISION-V0-SCHEMA-INVALID",
            f"decision:{slug} requires one non-empty exact status field",
        )
    filename_date, suffix = _decision_filename_date_suffix(slug)
    identity = fields.get("id")
    if identity is not None and identity != slug:
        raise LifecycleError(
            "WI-DECISION-IDENTITY-MISMATCH",
            f"decision:{slug} V0 id does not match its full filename stem",
        )
    legacy_slug = fields.get("slug")
    if legacy_slug is not None and legacy_slug != suffix:
        raise LifecycleError(
            "WI-DECISION-IDENTITY-MISMATCH",
            f"decision:{slug} V0 slug does not match its undated filename suffix",
        )
    date_value = fields.get("date")
    if date_value is not None and date_value != filename_date:
        raise LifecycleError(
            "WI-DECISION-DATE-MISMATCH",
            f"decision:{slug} V0 date does not match its filename",
        )
    if v0_cutover_date is not None:
        try:
            cutover = datetime.strptime(v0_cutover_date, "%Y-%m-%d")
        except ValueError as exc:
            raise LifecycleError(
                "WI-DECISION-V0-MANIFEST-INVALID",
                "decision V0 manifest has an invalid cutover date",
            ) from exc
        if cutover.strftime("%Y-%m-%d") != v0_cutover_date:
            raise LifecycleError(
                "WI-DECISION-V0-MANIFEST-INVALID",
                "decision V0 manifest has an invalid cutover date",
            )
        if filename_date >= v0_cutover_date:
            raise LifecycleError(
                "WI-DECISION-V0-CUTOVER-VIOLATION",
                f"decision:{slug} V0 date is on or after the cutover",
            )

    raw_lines = text.splitlines(keepends=True)
    body_offset = len("".join(raw_lines[: closing_index + 1]).encode("utf-8"))
    admitted = raw_status if raw_status in CATEGORIES["decision"].current_statuses else None
    return CurrentDecisionRecord(
        format=DECISION_FORMAT_V0,
        fields=_immutable_decision_fields(fields),
        raw_status=raw_status,
        admitted_current_status=admitted,
        body_offset=body_offset,
        legacy_read_only=True,
    )


def _normalize_decision_h1_key(key: str) -> str:
    return re.sub(r"[ _-]+", "-", key.casefold())


def _validate_current_decision_h1(
    text: str,
    slug: str,
    *,
    h1_cutover_date: str | None,
) -> CurrentDecisionRecord:
    logical_lines = text.splitlines()
    if len(logical_lines) < 4 or logical_lines[1] != "":
        raise LifecycleError(
            "WI-DECISION-H1-SCHEMA-INVALID",
            f"decision:{slug} requires an exact blank line 2",
        )
    if logical_lines[2] == "":
        raise LifecycleError(
            "WI-DECISION-H1-STATUS-UNSUPPORTED",
            f"decision:{slug} requires status as its first H1 prefix field",
        )
    prefix_end = next(
        (index for index, line in enumerate(logical_lines[3:], start=3) if line == ""),
        None,
    )
    if prefix_end is None:
        raise LifecycleError(
            "WI-DECISION-H1-SCHEMA-INVALID",
            f"decision:{slug} has no exact H1 prefix terminator",
        )
    body = "\n".join(logical_lines[prefix_end + 1 :])
    if not body.strip():
        raise LifecycleError(
            "WI-DECISION-H1-SCHEMA-INVALID",
            f"decision:{slug} has an empty H1 body",
        )

    first = logical_lines[2]
    list_metadata = DECISION_LIST_FIELD_RE.fullmatch(first) is not None
    if list_metadata:
        if h1_cutover_date is None:
            raise LifecycleError(
                "WI-DECISION-H1-MANIFEST-MISSING",
                f"decision:{slug} list metadata requires the H1 compatibility manifest",
            )
        field_re = DECISION_LIST_FIELD_RE
    elif DECISION_H1_PLAIN_FIELD_RE.fullmatch(first):
        field_re = DECISION_H1_PLAIN_FIELD_RE
    elif DECISION_H1_BOLD_FIELD_RE.fullmatch(first):
        field_re = DECISION_H1_BOLD_FIELD_RE
    else:
        raise LifecycleError(
            "WI-DECISION-H1-SCHEMA-INVALID",
            f"decision:{slug} has an invalid H1 status field at line 3",
        )

    fields: dict[str, str] = {}
    normalized_keys: dict[str, str] = {}
    field_order: list[str] = []
    raw_status: str | None = None
    for index, line in enumerate(logical_lines[2:prefix_end], start=3):
        if "\t" in line or not line or line[:1].isspace():
            raise LifecycleError(
                "WI-DECISION-H1-SCHEMA-INVALID",
                f"decision:{slug} has an invalid H1 prefix line {index}",
            )
        match = field_re.fullmatch(line)
        if match is None:
            raise LifecycleError(
                "WI-DECISION-H1-SCHEMA-INVALID",
                f"decision:{slug} mixes or malforms H1 prefix mode at line {index}",
            )
        key, value = match.groups()
        normalized = _normalize_decision_h1_key(key)
        if normalized in normalized_keys:
            failure_id = (
                "WI-DECISION-H1-STATUS-UNSUPPORTED"
                if normalized == "status"
                else "WI-DECISION-H1-FIELD-DUPLICATE"
            )
            raise LifecycleError(
                failure_id,
                f"decision:{slug} duplicates H1 key '{key}' at line {index}",
            )
        normalized_keys[normalized] = key
        fields[key] = value
        field_order.append(normalized)
        if list_metadata and not value:
            failure_id = (
                "WI-DECISION-H1-STATUS-UNSUPPORTED"
                if normalized == "status"
                else "WI-DECISION-H1-SCHEMA-INVALID"
            )
            raise LifecycleError(
                failure_id,
                f"decision:{slug} has an empty H1 list field '{key}' at line {index}",
            )
        if not list_metadata and index == 3:
            if normalized != "status":
                raise LifecycleError(
                    "WI-DECISION-H1-STATUS-UNSUPPORTED",
                    f"decision:{slug} requires status as its first H1 prefix field",
                )
            raw_status = value

    if list_metadata:
        if not field_order or field_order[0] != "id":
            raise LifecycleError(
                "WI-DECISION-H1-SCHEMA-INVALID",
                f"decision:{slug} requires id as its first H1 list field",
            )
        if len(field_order) < 2 or field_order[1] != "status":
            raise LifecycleError(
                "WI-DECISION-H1-STATUS-UNSUPPORTED",
                f"decision:{slug} requires status as its second H1 list field",
            )
        identity = fields[normalized_keys["id"]]
        if identity != slug:
            raise LifecycleError(
                "WI-DECISION-IDENTITY-MISMATCH",
                f"decision:{slug} id does not match its filename",
            )
        raw_status = fields[normalized_keys["status"]]
        admitted = raw_status
        if admitted not in {"accepted", "proposed"}:
            raise LifecycleError(
                "WI-DECISION-H1-STATUS-UNSUPPORTED",
                f"decision:{slug} has an unsupported H1 status value",
            )
    elif raw_status is None or len([key for key in normalized_keys if key == "status"]) != 1:
        raise LifecycleError(
            "WI-DECISION-H1-STATUS-UNSUPPORTED",
            f"decision:{slug} requires exactly one first H1 status field",
        )
    else:
        status_word = re.match(r"^([A-Za-z]+)(?:\s|$)", raw_status)
        admitted = status_word.group(1).casefold() if status_word else ""
        if admitted not in {"accepted", "proposed"}:
            raise LifecycleError(
                "WI-DECISION-H1-STATUS-UNSUPPORTED",
                f"decision:{slug} has an unsupported H1 status token",
            )

    filename_date, _suffix = _decision_filename_date_suffix(slug)
    if h1_cutover_date is not None:
        try:
            cutover = datetime.strptime(h1_cutover_date, "%Y-%m-%d")
        except ValueError as exc:
            raise LifecycleError(
                "WI-DECISION-H1-MANIFEST-INVALID",
                "decision H1 manifest has an invalid cutover date",
            ) from exc
        if cutover.strftime("%Y-%m-%d") != h1_cutover_date:
            raise LifecycleError(
                "WI-DECISION-H1-MANIFEST-INVALID",
                "decision H1 manifest has an invalid cutover date",
            )
        if filename_date >= h1_cutover_date:
            raise LifecycleError(
                "WI-DECISION-H1-CUTOVER-VIOLATION",
                f"decision:{slug} H1 date is on or after the cutover",
            )

    raw_lines = text.splitlines(keepends=True)
    body_offset = len("".join(raw_lines[: prefix_end + 1]).encode("utf-8"))
    return CurrentDecisionRecord(
        format=DECISION_FORMAT_H1,
        fields=_immutable_decision_fields(fields),
        raw_status=raw_status,
        admitted_current_status=admitted,
        body_offset=body_offset,
        legacy_read_only=True,
    )


def _validate_current_decision_record(
    path: Path,
    slug: str,
    *,
    v0_cutover_date: str | None = None,
    h1_cutover_date: str | None = None,
) -> CurrentDecisionRecord:
    text = _read_current_decision_text(path, slug)
    selected = _current_decision_format(text, slug)
    if selected == DECISION_FORMAT_V1:
        return _validate_current_decision_v1(text, slug)
    if selected == DECISION_FORMAT_V0:
        return _validate_current_decision_v0(
            text,
            slug,
            v0_cutover_date=v0_cutover_date,
        )
    return _validate_current_decision_h1(
        text,
        slug,
        h1_cutover_date=h1_cutover_date,
    )


class _DecisionCompatibilityManifestDuplicateKey(ValueError):
    pass


def _decision_compatibility_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise _DecisionCompatibilityManifestDuplicateKey(key)
        result[key] = value
    return result


def _decision_compatibility_baseline_digest(entries: list[dict[str, str]]) -> str:
    payload = b"".join(
        entry["path"].encode("utf-8")
        + b"\0"
        + entry["sha256"].encode("ascii")
        + b"\n"
        for entry in entries
    )
    return hashlib.sha256(payload).hexdigest().upper()


def _validate_current_decision_v0_manifest_record(
    path: Path,
    slug: str,
    cutover_date: str,
) -> CurrentDecisionRecord:
    return _validate_current_decision_record(
        path,
        slug,
        v0_cutover_date=cutover_date,
    )


def _validate_current_decision_h1_manifest_record(
    path: Path,
    slug: str,
    cutover_date: str,
) -> CurrentDecisionRecord:
    return _validate_current_decision_record(
        path,
        slug,
        h1_cutover_date=cutover_date,
    )


def _verify_current_decision_compatibility_manifest(
    root: Path,
    profile: DecisionCompatibilityProfile,
    *,
    manifest_bytes: bytes | None = None,
) -> dict[str, CurrentDecisionRecord]:
    def manifest_invalid(message: str) -> LifecycleError:
        return LifecycleError(profile.manifest_invalid_failure_id, message)

    work_items = _work_items_root(root)
    decisions = work_items / CATEGORIES["decision"].current_root
    current_paths = sorted(decisions.glob("*.md"), key=lambda path: path.name)
    formats: dict[str, str] = {}
    for path in current_paths:
        text = _read_current_decision_text(path, path.stem)
        try:
            formats[path.name] = _current_decision_format(text, path.stem)
        except LifecycleError as exc:
            if exc.failure_id != "WI-DECISION-FORMAT-UNSUPPORTED":
                raise
            formats[path.name] = "other"
    discovered = tuple(
        name for name, selected in formats.items() if selected == profile.format
    )
    manifest_path = work_items / profile.manifest_name
    if manifest_bytes is None and not manifest_path.is_file():
        if discovered:
            raise LifecycleError(
                profile.manifest_missing_failure_id,
                f"current {profile.label} decision requires work-items/{profile.manifest_name}",
            )
        return {}
    try:
        encoded = (
            manifest_path.read_bytes()
            if manifest_bytes is None
            else manifest_bytes
        )
        payload = json.loads(
            encoded.decode("utf-8"),
            object_pairs_hook=_decision_compatibility_json_object,
        )
    except (
        UnicodeDecodeError,
        json.JSONDecodeError,
        _DecisionCompatibilityManifestDuplicateKey,
    ) as exc:
        raise manifest_invalid(
            f"decision {profile.label} manifest is not strict UTF-8 JSON"
        ) from exc
    if not isinstance(payload, dict) or set(payload) != {
        "schemaVersion",
        "policyDecision",
        "cutoverDate",
        "baselineSha256",
        "entries",
    }:
        raise manifest_invalid(
            f"decision {profile.label} manifest has an invalid top-level shape"
        )
    schema_version = payload["schemaVersion"]
    if (
        type(schema_version) is not int
        or schema_version not in (
            (1, 2) if profile.label == "V0" else (profile.manifest_schema_version,)
        )
    ):
        raise manifest_invalid(
            f"decision {profile.label} manifest has an unsupported schemaVersion"
        )
    policy_slug = payload["policyDecision"]
    cutover_date = payload["cutoverDate"]
    baseline_sha256 = payload["baselineSha256"]
    raw_entries = payload["entries"]
    if (
        not isinstance(policy_slug, str)
        or not is_valid_slug(policy_slug)
        or not isinstance(cutover_date, str)
        or not DECISION_DATE_RE.fullmatch(cutover_date)
        or not isinstance(baseline_sha256, str)
        or not re.fullmatch(r"[0-9A-F]{64}", baseline_sha256)
        or not isinstance(raw_entries, list)
        or not raw_entries
    ):
        raise manifest_invalid(
            f"decision {profile.label} manifest has invalid scalar fields"
        )
    try:
        cutover = datetime.strptime(cutover_date, "%Y-%m-%d")
    except ValueError as exc:
        raise manifest_invalid(
            f"decision {profile.label} manifest cutoverDate is invalid"
        ) from exc
    if cutover.strftime("%Y-%m-%d") != cutover_date:
        raise manifest_invalid(
            f"decision {profile.label} manifest cutoverDate is invalid"
        )

    entries: list[dict[str, object]] = []
    for index, raw_entry in enumerate(raw_entries):
        if not isinstance(raw_entry, dict):
            raise manifest_invalid(
                f"decision {profile.label} manifest entry {index} has invalid shape"
            )
        state = raw_entry.get("state")
        expected_fields = {"path", "sha256", "state"}
        if schema_version == 2 and state == "retired":
            expected_fields.add("archiveEvidence")
        if set(raw_entry) != expected_fields:
            raise manifest_invalid(
                f"decision {profile.label} manifest entry {index} has invalid shape"
            )
        name = raw_entry["path"]
        digest = raw_entry["sha256"]
        if (
            not isinstance(name, str)
            or not name.endswith(".md")
            or Path(name).name != name
            or "/" in name
            or "\\" in name
            or not is_valid_slug(Path(name).stem)
            or not isinstance(digest, str)
            or not re.fullmatch(r"[0-9A-F]{64}", digest)
            or state not in {"admitted", "retired"}
        ):
            raise manifest_invalid(
                f"decision {profile.label} manifest entry {index} is invalid"
            )
        entry = {"path": name, "sha256": digest, "state": state}
        if schema_version == 2 and state == "retired":
            evidence = raw_entry["archiveEvidence"]
            if not isinstance(evidence, dict) or set(evidence) != {
                "archivePath", "archivedAt", "rationale", "evidence"
            }:
                raise manifest_invalid(f"decision V0 manifest entry {index} has invalid archive evidence")
            archived_at = evidence["archivedAt"]
            archive_path = evidence["archivePath"]
            if (
                not isinstance(archived_at, str)
                or not isinstance(archive_path, str)
                or archive_path != f"decisions/archive/{archived_at[:7]}/{name}"
                or any(
                    not isinstance(evidence[field], str) or not evidence[field].strip()
                    for field in ("rationale", "evidence")
                )
            ):
                raise manifest_invalid(f"decision V0 manifest entry {index} has invalid archive evidence")
            try:
                _strict_utc(archived_at)
            except LifecycleError as exc:
                raise manifest_invalid(f"decision V0 manifest entry {index} has invalid archive instant") from exc
            entry["archiveEvidence"] = evidence
        entries.append(entry)
    names = [entry["path"] for entry in entries]
    if names != sorted(names) or len(names) != len(set(names)):
        raise manifest_invalid(
            f"decision {profile.label} manifest entries must be sorted and unique"
        )
    if _decision_compatibility_baseline_digest(entries) != baseline_sha256:
        raise manifest_invalid(
            f"decision {profile.label} manifest baseline digest does not match its rows"
        )

    anchor_path = decisions / f"{policy_slug}.md"
    if not anchor_path.is_file() or formats.get(anchor_path.name) != DECISION_FORMAT_V1:
        raise manifest_invalid(
            f"decision {profile.label} manifest policy anchor is not a current V1 record"
        )
    try:
        anchor = _validate_current_decision_record(anchor_path, policy_slug)
    except LifecycleError as exc:
        raise manifest_invalid(
            f"decision {profile.label} manifest policy anchor is invalid"
        ) from exc
    expected_manifest = f"work-items/{profile.manifest_name}"
    if (
        anchor.raw_status != "accepted"
        or anchor.fields.get(profile.anchor_manifest_field) != expected_manifest
        or anchor.fields.get(profile.anchor_baseline_field) != baseline_sha256
        or anchor.fields.get(profile.anchor_cutover_field) != cutover_date
    ):
        raise manifest_invalid(
            f"decision {profile.label} manifest policy anchor does not match"
        )

    by_name = {entry["path"]: entry for entry in entries}
    for name in discovered:
        entry = by_name.get(name)
        if entry is None:
            raise LifecycleError(
                profile.unadmitted_failure_id,
                f"decisions/{name} is not in the frozen {profile.label} manifest",
            )
        if entry["state"] == "retired":
            raise LifecycleError(
                profile.retired_reappeared_failure_id,
                f"retired decisions/{name} reappeared as {profile.label}",
            )

    admitted: dict[str, CurrentDecisionRecord] = {}
    for entry in entries:
        name = entry["path"]
        path = decisions / name
        selected = formats.get(name)
        if entry["state"] == "retired":
            if schema_version == 2:
                if selected is not None:
                    raise LifecycleError(
                        profile.retired_reappeared_failure_id,
                        f"retired decisions/{name} reappeared as current",
                    )
                archive_relative = entry["archiveEvidence"]["archivePath"]
                archive = work_items / Path(archive_relative)
                try:
                    archived = _capture_file_snapshot(
                        archive, failure_id=profile.manifest_stale_failure_id
                    ).data
                except LifecycleError as exc:
                    raise LifecycleError(
                        profile.manifest_stale_failure_id,
                        f"retired decisions/{name} archive is missing or unsafe",
                    ) from exc
                if hashlib.sha256(archived).hexdigest().upper() != entry["sha256"]:
                    raise LifecycleError(
                        profile.hash_mismatch_failure_id,
                        f"retired decisions/{name} archive differs from its frozen SHA-256",
                    )
                continue
            if selected is None or selected == DECISION_FORMAT_V1:
                continue
            raise LifecycleError(
                profile.manifest_stale_failure_id,
                f"retired decisions/{name} is neither absent nor V1",
            )
        if selected is None or selected != profile.format:
            raise LifecycleError(
                profile.manifest_stale_failure_id,
                f"admitted decisions/{name} is missing or no longer {profile.label}",
            )
        actual_digest = hashlib.sha256(path.read_bytes()).hexdigest().upper()
        if actual_digest != entry["sha256"]:
            raise LifecycleError(
                profile.hash_mismatch_failure_id,
                f"admitted decisions/{name} differs from its frozen SHA-256",
            )
        admitted[name] = profile.validate_record(path, path.stem, cutover_date)
    return admitted


def _preflight_current_decision_v0(root: Path) -> dict[str, CurrentDecisionRecord]:
    return _verify_current_decision_compatibility_manifest(
        root,
        DecisionCompatibilityProfile(
            label="V0",
            format=DECISION_FORMAT_V0,
            manifest_name=DECISION_V0_MANIFEST,
            manifest_schema_version=DECISION_V0_MANIFEST_SCHEMA_VERSION,
            anchor_manifest_field="v0-manifest",
            anchor_baseline_field="v0-baseline-sha256",
            anchor_cutover_field="v0-cutover-date",
            manifest_missing_failure_id="WI-DECISION-V0-MANIFEST-MISSING",
            manifest_invalid_failure_id="WI-DECISION-V0-MANIFEST-INVALID",
            unadmitted_failure_id="WI-DECISION-V0-UNADMITTED",
            manifest_stale_failure_id="WI-DECISION-V0-MANIFEST-STALE",
            hash_mismatch_failure_id="WI-DECISION-V0-HASH-MISMATCH",
            retired_reappeared_failure_id="WI-DECISION-V0-RETIRED-REAPPEARED",
            validate_record=_validate_current_decision_v0_manifest_record,
        ),
    )


def _preflight_current_decision_h1(
    root: Path,
    *,
    manifest_bytes: bytes | None = None,
) -> dict[str, CurrentDecisionRecord]:
    return _verify_current_decision_compatibility_manifest(
        root,
        DecisionCompatibilityProfile(
            label="H1",
            format=DECISION_FORMAT_H1,
            manifest_name=DECISION_H1_MANIFEST,
            manifest_schema_version=DECISION_H1_MANIFEST_SCHEMA_VERSION,
            anchor_manifest_field="h1-manifest",
            anchor_baseline_field="h1-baseline-sha256",
            anchor_cutover_field="h1-cutover-date",
            manifest_missing_failure_id="WI-DECISION-H1-MANIFEST-MISSING",
            manifest_invalid_failure_id="WI-DECISION-H1-MANIFEST-INVALID",
            unadmitted_failure_id="WI-DECISION-H1-UNADMITTED",
            manifest_stale_failure_id="WI-DECISION-H1-MANIFEST-STALE",
            hash_mismatch_failure_id="WI-DECISION-H1-HASH-MISMATCH",
            retired_reappeared_failure_id="WI-DECISION-H1-RETIRED-REAPPEARED",
            validate_record=_validate_current_decision_h1_manifest_record,
        ),
        manifest_bytes=manifest_bytes,
    )


def _validate_canonical_candidate_header(data: bytes) -> None:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID",
            "canonical candidate header must be UTF-8",
        ) from exc

    lines = text.splitlines()
    if lines and lines[0].strip() == "---":
        closing = next(
            (index for index, line in enumerate(lines[1:], start=2) if line.strip() == "---"),
            None,
        )
        if closing is None:
            raise LifecycleError(
                "WI-CATEGORY-STATUS-INVALID",
                "canonical candidate frontmatter is unterminated",
            )
        header_start, header_end = 2, closing - 1
        malformed_header_end = header_end
    else:
        header_start, header_end = 1, 0
        for line_number, line in enumerate(lines, start=1):
            if not FIELD_RE.fullmatch(line):
                break
            header_end = line_number
        malformed_header_end = 0
        for line_number, line in enumerate(lines, start=1):
            if not line.strip():
                break
            malformed_header_end = line_number

    occurrences = _authoritative_field_occurrences(text)
    statuses = [
        (line_number, value)
        for line_number, name, value, _line in occurrences
        if name == "status"
    ]
    malformed_status = any(
        re.match(
            r"^\s*(?:-\s*)?(?:\*\*)?status(?:\*\*)?(?:\s|$)",
            line,
            re.IGNORECASE,
        )
        and not FIELD_RE.fullmatch(line)
        for line_number, line in _authoritative_markdown_lines(text)
        if header_start <= line_number <= malformed_header_end
    )
    if (
        malformed_status
        or len(statuses) != 1
        or not (header_start <= statuses[0][0] <= header_end)
        or statuses[0][1] != "candidate"
    ):
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID",
            "canonical candidate header requires exactly one 'status: candidate' field",
        )


def _terminalization_authoritative_field_occurrences(
    text: str, utc_field: str = "Terminal-at"
) -> tuple[str, ...]:
    authoritative = {utc_field.casefold(), "v1-migration-evidence"}
    occurrences: list[str] = []
    for _line_number, line in _authoritative_markdown_lines(text):
        match = FIELD_RE.fullmatch(line)
        if match:
            name = match.group(1).strip().casefold()
            if name in authoritative:
                occurrences.append(name)
    return tuple(occurrences)


def _schema_marker_occurrences(data: bytes, member: str) -> tuple[tuple[str, str, str], ...]:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-CATEGORY-SCHEMA-INVALID",
            f"{member} schema marker source must be UTF-8",
        ) from exc
    occurrences: list[tuple[str, str, str]] = []
    for _line_number, line in _authoritative_markdown_lines(text):
        match = WORK_ITEM_SCHEMA_OCCURRENCE_RE.fullmatch(line)
        if match:
            occurrences.append((line, match.group(1), match.group(2)))
    return tuple(occurrences)


def _require_canonical_schema_marker(
    occurrences: tuple[tuple[str, str, str], ...],
    member: str,
) -> None:
    if len(occurrences) != 1 or occurrences[0] != (
        WORK_ITEM_SCHEMA_MARKER,
        WORK_ITEM_SCHEMA_KEY,
        WORK_ITEM_SCHEMA_VALUE,
    ):
        raise LifecycleError(
            "WI-CATEGORY-SCHEMA-INVALID",
            f"{member} must contain exactly one canonical {WORK_ITEM_SCHEMA_MARKER!r}",
        )


def _stamp_schema_marker(data: bytes, member: str) -> bytes:
    occurrences = _schema_marker_occurrences(data, member)
    if occurrences:
        _require_canonical_schema_marker(occurrences, member)
        return data
    separator = b"" if data.endswith(b"\n") else b"\n"
    return data + separator + WORK_ITEM_SCHEMA_MARKER.encode("utf-8") + b"\n"


def _optional_relation_values(
    value: str | None,
    *,
    comma_separated: bool,
) -> tuple[str, ...]:
    if value is None:
        return ()
    normalized = value.strip()
    if (
        not normalized
        or normalized in OPTIONAL_RELATION_ABSENCE_MARKERS
    ):
        return ()
    if comma_separated:
        return tuple(part.strip() for part in normalized.split(","))
    return (normalized,)


def _strict_utc(value: str) -> datetime:
    if not UTC_INSTANT_RE.fullmatch(value):
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
            f"terminal instant must be strict UTC YYYY-MM-DDTHH:MM:SSZ: {value!r}",
        )
    try:
        parsed = datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError as exc:
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
            f"invalid terminal instant: {value!r}",
        ) from exc
    if parsed.strftime("%Y-%m-%dT%H:%M:%SZ") != value:
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
            f"non-canonical terminal instant: {value!r}",
        )
    return parsed


def archive_month(terminal_instant: str) -> str:
    return _strict_utc(terminal_instant).strftime("%Y-%m")


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb", dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False
        ) as handle:
            temp_path = Path(handle.name)
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
        temp_path = None
        if _capture_file_snapshot(
            path, failure_id="WI-ATOMIC-BYTE-CHECK", maximum_bytes=len(data)
        ).data != data:
            raise LifecycleError("WI-ATOMIC-BYTE-CHECK", f"byte check failed: {path}")
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink()
            except FileNotFoundError:
                pass


def _canonical_category(reference: str) -> tuple[Category, str]:
    if reference.count(":") != 1:
        raise LifecycleError(
            "WI-REFERENCE-INVALID",
            f"reference must be category-qualified as <category>:<bare-slug>: {reference!r}",
        )
    category_name, slug = reference.split(":", 1)
    category_name = CATEGORY_ALIASES.get(category_name, category_name)
    category = CATEGORIES.get(category_name)
    if category is None:
        raise LifecycleError("WI-REFERENCE-INVALID", f"unknown category: {category_name!r}")
    _validate_slug(slug)
    return category, slug


def _category_locations(root: Path, category: Category, slug: str) -> list[Path]:
    work_items = _work_items_root(root)
    locations: list[Path] = []
    if category.current_kind == "work-item":
        backlog = work_items / "backlog" / f"{slug}.md"
        active = work_items / "active" / slug
        if backlog.is_file():
            locations.append(backlog)
        if active.is_dir():
            locations.append(active)
        archive = work_items / "archive"
        if archive.is_dir():
            locations.extend(
                sorted(
                    month / slug
                    for month in archive.iterdir()
                    if month.is_dir() and (month / slug).is_dir()
                )
            )
    else:
        current = work_items / category.current_root / f"{slug}.md"
        if current.is_file():
            locations.append(current)
        archive = work_items / category.current_root / "archive"
        if archive.is_dir():
            locations.extend(
                sorted(
                    month / f"{slug}.md"
                    for month in archive.iterdir()
                    if month.is_dir() and (month / f"{slug}.md").is_file()
                )
            )
    return locations


def resolve_category(root: Path, reference: str) -> Path:
    category, slug = _canonical_category(reference)
    locations = _category_locations(root, category, slug)
    if len(locations) > 1:
        raise LifecycleError(
            "WI-CATEGORY-DUAL-LOCATION",
            f"{reference} has {len(locations)} physical locations",
        )
    if not locations:
        raise LifecycleError("WI-REFERENCE-MISSING", f"no physical location for {reference}")
    return locations[0].resolve()


def work_item_dependency_state(root: Path, slug: str) -> str:
    """Resolve one dependency through the lifecycle owner.

    Physical location owns the state: backlog and active records are open,
    while only a dated archive record is done. Missing and duplicate identities
    retain ``resolve_category``'s stable fail-closed errors.
    """
    location = resolve_category(root, f"work-item:{slug}")
    archive = (_work_items_root(root) / "archive").resolve()
    return "done" if archive in location.parents else "open"


def resolve_legacy_path(root: Path, legacy_path: str) -> Path:
    candidate = Path(legacy_path)
    if candidate.is_absolute():
        raise LifecycleError("WI-REFERENCE-INVALID", "legacy path must be relative")
    repo_root = _work_items_root(root).parent.resolve()
    resolved = (repo_root / candidate).resolve()
    if resolved != repo_root and repo_root not in resolved.parents:
        raise LifecycleError("WI-REFERENCE-INVALID", "legacy path escapes repository")
    if not resolved.exists():
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED",
            f"legacy path is absent and has no incoming-link inventory: {legacy_path}",
        )
    return resolved


def _relative_link(work_items: Path, path: Path) -> str:
    return Path(os.path.relpath(path, work_items)).as_posix()


def _status_entry(root: Path, item: Path) -> ReadmeEntry:
    status_path = item / "status.md"
    if not status_path.is_file():
        raise LifecycleError("WI-CATEGORY-STATUS-MISSING", f"missing status.md: {item}")
    text = _capture_file_snapshot(
        status_path,
        failure_id="WI-README-STALE",
        maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
    ).data.decode("utf-8")
    fields = _parse_fields(text)
    status = fields.get("status", "")
    if status in CATEGORIES["work-item"].terminal_statuses:
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-IN-CURRENT",
            f"terminal work-item remains active: {item.name}",
        )
    if status not in {"active", "blocked"}:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID", f"active work-item has invalid status {status!r}: {item}"
        )
    section = "Blockers" if status == "blocked" or fields.get("blocker") else "Current focus"
    label = fields.get("task") or item.name
    detail = fields.get("blocker", "") if section == "Blockers" else fields.get("current step", "")
    entry = ReadmeEntry(
        section,
        f"work-item:{item.name}",
        label,
        status_path,
        False,
        detail,
        [status_path],
    )
    progressive: list[str] = []
    for field_name, category in (("roadmap", "roadmap"), ("epic", "epic")):
        related_values = _optional_relation_values(
            fields.get(field_name),
            comma_separated=False,
        )
        if not related_values:
            continue
        related_slug = related_values[0]
        _validate_slug(related_slug)
        related = resolve_category(root, f"{category}:{related_slug}")
        entry.source_paths.append(related)
        progressive.append(
            f"[{field_name}]({_relative_link(_work_items_root(root), related)})"
        )
    progressive.append(f"[work item]({_relative_link(_work_items_root(root), status_path)})")
    suffix = " → ".join(progressive)
    entry.detail = " — ".join(part for part in (entry.detail, suffix) if part)
    return entry


def _legacy_retirement_entry(item: Path, metadata: Path) -> ReadmeEntry:
    try:
        payload = json.loads(metadata.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID",
            f"invalid legacy retirement metadata: {metadata}",
        ) from exc
    expected_scalars = {
        "schemaVersion": LEGACY_RETIREMENT_SCHEMA_VERSION,
        "owner": LEGACY_RETIREMENT_OWNER,
        "kind": "legacy-backlog-retirement",
        "slug": item.name,
        "status": "rejected-before-admission",
        "admissionHistory": "never-admitted",
    }
    if not isinstance(payload, dict) or any(
        payload.get(key) != value for key, value in expected_scalars.items()
    ):
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID",
            f"legacy retirement identity differs: {item}",
        )
    terminal_at = payload.get("terminalAt")
    if not isinstance(terminal_at, str):
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID", f"missing terminalAt: {metadata}"
        )
    _strict_utc(terminal_at)
    if archive_month(terminal_at) != item.parent.name:
        raise LifecycleError(
            "WI-CATEGORY-ARCHIVE-MONTH-MISMATCH",
            f"{item.name} belongs in archive/{archive_month(terminal_at)}",
        )
    disposition = payload.get("productDisposition")
    if not isinstance(disposition, str) or not disposition.strip():
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID",
            f"missing product disposition: {metadata}",
        )
    if payload.get("syntheticTransitions") != []:
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID",
            f"legacy retirement must not synthesize lifecycle transitions: {metadata}",
        )
    incoming = payload.get("incomingLinks")
    try:
        _validate_incoming_link_snapshot(f"work-item:{item.name}", incoming, label="stored")
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID",
            f"invalid incoming-link inventory: {metadata}",
        ) from exc
    rows = payload.get("sourceFiles")
    if not isinstance(rows, list) or not rows:
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID", f"missing source file inventory: {metadata}"
        )
    sources: list[Path] = [metadata]
    seen: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            raise LifecycleError(
                "WI-LEGACY-RETIREMENT-INVALID", f"invalid source row: {metadata}"
            )
        relative = row.get("path")
        if not isinstance(relative, str) or relative in seen:
            raise LifecycleError(
                "WI-LEGACY-RETIREMENT-INVALID", f"duplicate source path: {metadata}"
            )
        candidate = Path(relative)
        if candidate.is_absolute() or ".." in candidate.parts or relative == LEGACY_RETIREMENT_FILE:
            raise LifecycleError(
                "WI-LEGACY-RETIREMENT-INVALID", f"unsafe source path: {relative!r}"
            )
        source = item / candidate
        if source.is_symlink() or not source.is_file():
            raise LifecycleError(
                "WI-LEGACY-RETIREMENT-INVALID", f"missing source payload: {relative}"
            )
        data = source.read_bytes()
        if (
            row.get("byteLength") != len(data)
            or row.get("sha256") != hashlib.sha256(data).hexdigest()
        ):
            raise LifecycleError(
                "WI-LEGACY-RETIREMENT-INVALID", f"source digest differs: {relative}"
            )
        seen.add(relative)
        sources.append(source)
    actual = {
        path.relative_to(item).as_posix()
        for path in item.rglob("*")
        if path.is_file() and path != metadata
    }
    if actual != seen:
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID",
            f"source inventory does not cover the retirement payload: {item}",
        )
    # Retirement is immutable, but its former backlog paths must not remain in
    # mutable records.  The stored inventory is evidence from the transition;
    # this fresh owner-level scan catches a later plain-text citation that the
    # original Markdown/link scanner could not see.  Archived consumers are
    # historical evidence and intentionally do not participate.
    work_items = item.parents[2]
    current_incoming = _incoming_link_result(
        work_items.parent,
        sources,
        f"work-item:{item.name}",
        literal_path_references=(
            f"{work_items.name}/backlog/{item.name}/{relative}"
            for relative in seen
        ),
        mutable_consumers_only=True,
        scan_markdown_links=False,
    )
    try:
        _validate_incoming_link_snapshot(
            f"work-item:{item.name}", current_incoming, label="current"
        )
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID",
            f"mutable record retains a retired backlog path: {item}",
        ) from exc
    return ReadmeEntry(
        "Recently completed",
        f"work-item:{item.name}",
        f"Rejected before admission: {item.name}",
        metadata,
        True,
        disposition.strip().splitlines()[0],
        sources,
        "WI-LEGACY-RETIRED-BEFORE-ADMISSION",
    )


def _archived_work_item_entry(item: Path) -> ReadmeEntry:
    retirement = item / LEGACY_RETIREMENT_FILE
    if retirement.is_file():
        if (item / "status.md").exists() or (item / "closure.md").exists():
            raise LifecycleError(
                "WI-LEGACY-RETIREMENT-INVALID",
                f"direct legacy retirement must not carry active/closure history: {item}",
            )
        return _legacy_retirement_entry(item, retirement)
    closure = item / "closure.md"
    if not closure.is_file():
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
            f"archived work-item lacks closure.md: {item}",
        )
    status = item / "status.md"
    closure_data = _capture_file_snapshot(
        closure,
        failure_id="WI-README-STALE",
        maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
    ).data
    status_data = _capture_file_snapshot(
        status,
        failure_id="WI-README-STALE",
        maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
    ).data if status.is_file() else b""
    closure_markers = _schema_marker_occurrences(closure_data, "closure.md")
    status_markers = _schema_marker_occurrences(status_data, "status.md")
    fields = _parse_fields(closure_data.decode("utf-8"))
    sources = [closure]
    if status.is_file():
        sources.append(status)

    if not closure_markers and not status_markers:
        return ReadmeEntry(
            "Recently completed",
            f"work-item:{item.name}",
            fields.get("outcome") or item.name,
            closure,
            True,
            fields.get("residual risk", ""),
            sources,
            LEGACY_READ_CLASSIFICATION,
        )

    _require_canonical_schema_marker(status_markers, "status.md")
    _require_canonical_schema_marker(closure_markers, "closure.md")
    closed = fields.get("closed", "")
    _validate_closure(closure_data, closed)
    expected_month = archive_month(closed)
    if expected_month != item.parent.name:
        raise LifecycleError(
            "WI-CATEGORY-ARCHIVE-MONTH-MISMATCH",
            f"{item.name} belongs in archive/{expected_month}, not {item.parent.name}",
        )
    status_fields = _parse_fields(status_data.decode("utf-8"))
    status_value = status_fields.get("status", "")
    if status_value in CATEGORIES["work-item"].current_statuses:
        raise LifecycleError(
            "WI-CATEGORY-CURRENT-IN-ARCHIVE",
            f"work-item:{item.name} has current status in archive",
        )
    if status_value not in CATEGORIES["work-item"].terminal_statuses:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID",
            f"work-item:{item.name} has invalid archived V1 status {status_value!r}",
        )
    return ReadmeEntry(
        "Recently completed",
        f"work-item:{item.name}",
        fields.get("outcome") or item.name,
        closure,
        True,
        fields.get("residual risk", ""),
        sources,
    )


def collect_readme_entries(root: Path) -> list[ReadmeEntry]:
    work_items = _work_items_root(root)
    entries: list[ReadmeEntry] = []

    backlog = work_items / "backlog"
    if backlog.is_dir():
        for path in sorted(backlog.glob("*.md")):
            fields = _parse_fields(_capture_file_snapshot(
                path,
                failure_id="WI-README-STALE",
                maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
            ).data.decode("utf-8"))
            status = fields.get("status")
            if status and status != "candidate":
                failure = (
                    "WI-CATEGORY-TERMINAL-IN-CURRENT"
                    if status in CATEGORIES["work-item"].terminal_statuses
                    else "WI-CATEGORY-STATUS-INVALID"
                )
                raise LifecycleError(
                    failure,
                    f"backlog work-item has invalid current status {status!r}: {path.stem}",
                )
            entries.append(
                ReadmeEntry(
                    "Next actions",
                    f"work-item:{path.stem}",
                    fields.get("task") or path.stem,
                    path,
                    False,
                    fields.get("next action", ""),
                    [path],
                )
            )

    active = work_items / "active"
    if active.is_dir():
        for item in sorted(path for path in active.iterdir() if path.is_dir()):
            entries.append(_status_entry(root, item))

    roadmaps = work_items / "roadmaps"
    if roadmaps.is_dir():
        for path in sorted(roadmaps.glob("*.md")):
            text = _capture_file_snapshot(
                path,
                failure_id="WI-README-STALE",
                maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
            ).data.decode("utf-8")
            fields = _parse_fields(text)
            if fields.get("format") != "roadmap-v1":
                continue
            status = fields.get("status", "")
            if status not in {"draft", "active"}:
                raise LifecycleError(
                    "WI-CATEGORY-TERMINAL-IN-CURRENT",
                    f"terminal V1 roadmap remains current: {path.stem}",
                )
            entries.append(
                ReadmeEntry(
                    "Roadmap and milestones",
                    f"roadmap:{path.stem}",
                    fields.get("milestones-or-horizon") or path.stem,
                    path,
                    False,
                    fields.get("order", ""),
                    [path],
                )
            )

    archive = work_items / "archive"
    if archive.is_dir():
        archived: list[ReadmeEntry] = []
        for month in sorted((path for path in archive.iterdir() if path.is_dir()), reverse=True):
            for item in sorted((path for path in month.iterdir() if path.is_dir()), reverse=True):
                archived.append(_archived_work_item_entry(item))
        entries.extend(archived)

    seen: set[str] = set()
    for entry in entries:
        if entry.logical_reference in seen:
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION",
                f"duplicate README logical reference: {entry.logical_reference}",
            )
        seen.add(entry.logical_reference)
    order = {section: index for index, section in enumerate(README_SECTIONS)}
    return sorted(entries, key=lambda entry: (order[entry.section], entry.logical_reference))


def _input_digest(entries: Iterable[ReadmeEntry], work_items: Path) -> str:
    inputs: dict[str, Path] = {}
    for entry in entries:
        for path in entry.source_paths:
            logical_path = _relative_link(work_items, path)
            inputs[logical_path] = path
    digest = hashlib.sha256()
    for logical_path, path in sorted(inputs.items()):
        data = _capture_file_snapshot(
            path,
            failure_id="WI-README-STALE",
            maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
        ).data
        encoded = logical_path.encode("utf-8")
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)
    return digest.hexdigest()


def _canonical_timestamp(entries: Iterable[ReadmeEntry]) -> str:
    instants: list[str] = []
    for entry in entries:
        for path in entry.source_paths:
            if path.name == LEGACY_RETIREMENT_FILE:
                try:
                    value = json.loads(_capture_file_snapshot(
                        path,
                        failure_id="WI-README-STALE",
                        maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
                    ).data.decode("utf-8")).get("terminalAt")
                except (OSError, ValueError, RecursionError, AttributeError) as exc:
                    raise LifecycleError(
                        "WI-LEGACY-RETIREMENT-INVALID",
                        f"cannot read terminal instant: {path}",
                    ) from exc
                if isinstance(value, str) and UTC_INSTANT_RE.fullmatch(value):
                    _strict_utc(value)
                    instants.append(value)
                continue
            fields = _parse_fields(_capture_file_snapshot(
                path,
                failure_id="WI-README-STALE",
                maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
            ).data.decode("utf-8"))
            for key in ("updated", "closed", "terminal-at"):
                value = fields.get(key)
                if value and UTC_INSTANT_RE.fullmatch(value):
                    _strict_utc(value)
                    instants.append(value)
    return max(instants, default="none")


def _default_static_guide() -> str:
    return (
        "# Work items\n\n"
        "Read this page for current delivery status. Make lifecycle changes through "
        "`scripts/mutate-work-item.py`, then follow the generated links for detail.\n\n"
    )


def _static_guide(readme: Path, *, allow_marker_bootstrap: bool = False) -> str:
    if not readme.exists():
        return _default_static_guide()
    text = _capture_file_snapshot(
        readme,
        failure_id="WI-README-STALE",
        maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
    ).data.decode("utf-8")
    begin_count = text.count(README_BEGIN)
    end_count = text.count(README_END)
    if allow_marker_bootstrap and begin_count == 0 and end_count == 0:
        return _default_static_guide()
    if begin_count != 1 or end_count != 1 or text.index(README_BEGIN) > text.index(README_END):
        raise LifecycleError(
            "WI-README-MARKERS",
            "existing README must contain exactly one ordered generated marker pair",
        )
    return text[: text.index(README_BEGIN)].rstrip() + "\n\n"


def render_readme_bytes(
    root: Path,
    *,
    allow_marker_bootstrap: bool = False,
    static_guide_override: str | None = None,
) -> bytes:
    work_items = _work_items_root(root)
    entries = collect_readme_entries(root)
    lines = [
        README_BEGIN,
        "Read-model: work-items-readme-v1",
        "Ordered sources: backlog|active|roadmaps|archive",
        f"Canonical changes through: {_canonical_timestamp(entries)}",
        f"Canonical input digest: sha256:{_input_digest(entries, work_items)}",
        "",
    ]
    by_section = {section: [] for section in README_SECTIONS}
    for entry in entries:
        by_section[entry.section].append(entry)
    for section in README_SECTIONS:
        lines.extend((f"## {section}", ""))
        for entry in by_section[section]:
            marker = "x" if entry.checked else " "
            link = _relative_link(work_items, entry.link)
            if entry.section == "Recently completed" and entry.link.name == "closure.md":
                label = entry.logical_reference.removeprefix("work-item:")
                detail_parts = [entry.classification] if entry.classification else []
            else:
                label = entry.label
                detail_parts = [
                    part for part in (entry.detail, entry.classification) if part
                ]
            detail = f" — {' — '.join(detail_parts)}" if detail_parts else ""
            lines.append(f"- [{marker}] [{label}]({link}){detail}")
        lines.append("")
    lines.append(README_END)
    static_guide = (
        static_guide_override
        if static_guide_override is not None
        else _static_guide(
            work_items / "README.md",
            allow_marker_bootstrap=allow_marker_bootstrap,
        )
    )
    return (
        static_guide
        + "\n".join(lines)
        + "\n"
    ).encode("utf-8")


def refresh_readme(root: Path, *, allow_marker_bootstrap: bool = False) -> str:
    work_items = _work_items_root(root)
    expected = render_readme_bytes(
        root,
        allow_marker_bootstrap=allow_marker_bootstrap,
    )
    readme = work_items / "README.md"
    _atomic_write(readme, expected)
    observed = render_readme_bytes(root)
    if observed != expected or _capture_file_snapshot(
        readme,
        failure_id="WI-README-STALE",
        maximum_bytes=len(expected),
    ).data != expected:
        raise LifecycleError("WI-README-STALE", "README byte verification failed")
    return hashlib.sha256(expected).hexdigest()


def reset_readme_static_guide(root: Path, expected_readme_sha256: str) -> str:
    if not re.fullmatch(r"[0-9A-Fa-f]{64}", expected_readme_sha256):
        raise LifecycleError(
            "WI-README-REPAIR-TARGET-MISMATCH",
            "expected README SHA-256 must be exactly 64 hexadecimal characters",
        )
    work_items = _work_items_root(root)
    readme = work_items / "README.md"
    if not readme.is_file():
        raise LifecycleError(
            "WI-README-MARKERS",
            "static-guide repair requires an existing marker-owned README",
        )
    _static_guide(readme)
    current = readme.read_bytes()
    desired = render_readme_bytes(
        root,
        static_guide_override=_default_static_guide(),
    )
    current_hash = hashlib.sha256(current).hexdigest()
    expected_hash = expected_readme_sha256.casefold()
    if current_hash != expected_hash:
        if current == desired:
            return current_hash
        raise LifecycleError(
            "WI-README-REPAIR-TARGET-MISMATCH",
            "README bytes differ from the explicitly targeted repair input",
        )
    if current == desired:
        return current_hash
    _atomic_write(readme, desired)
    observed = render_readme_bytes(root)
    if observed != desired or readme.read_bytes() != desired:
        raise LifecycleError(
            "WI-README-STALE",
            "README static-guide repair failed complete-byte verification",
        )
    return hashlib.sha256(desired).hexdigest()


def check_readme(root: Path) -> None:
    readme = _work_items_root(root) / "README.md"
    if not readme.is_file() or readme.read_bytes() != render_readme_bytes(root):
        raise LifecycleError("WI-README-STALE", "README does not match canonical inputs")


def _preflight_readme(root: Path) -> None:
    """Validate current canonical inputs and README marker ownership before mutation."""

    render_readme_bytes(root)


def _preflight_readme_markers(root: Path) -> None:
    """Validate README ownership when the current tree is intentionally terminal."""

    _static_guide(_work_items_root(root) / "README.md")


def _validator_module():
    path = Path(__file__).with_name("validate-work-item-state.py")
    spec = importlib.util.spec_from_file_location("work_item_state_validator", path)
    if spec is None or spec.loader is None:
        raise LifecycleError("WI-VALIDATOR-LOAD", f"cannot load validator: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _scratch_classifier_module():
    path = Path(__file__).with_name("maintenance") / "cleanup.py"
    spec = importlib.util.spec_from_file_location("scratch_evidence_classifier", path)
    if spec is None or spec.loader is None:
        raise LifecycleError("WI-SCRATCH-CLASSIFIER-LOAD", f"cannot load classifier: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _agent_run_ledger_module():
    path = Path(__file__).with_name("agent-run-ledger.py")
    try:
        spec = importlib.util.spec_from_file_location("agent_run_ledger", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"no import specification or loader for {path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    except Exception as exc:
        raise LifecycleError(
            "WI-LEDGER-BOOTSTRAP-INVALID",
            f"cannot load ledger helper {path}: {exc}",
        ) from exc


def _staged_admission_ledger_bytes(slug: str, status_data: bytes) -> bytes:
    """Build the settled Lead admission event from the already-validated status."""

    started_at = _parse_fields(status_data.decode("utf-8"))["started"]
    ledger = _agent_run_ledger_module()
    args = argparse.Namespace(
        work_item=Path(slug),
        run_id=f"{slug}-lifecycle-start",
        work_item_name=slug,
        role="lead",
        execution_role="main",
        assigned_role=None,
        provider=None,
        model=None,
        status="completed",
        gate="none",
        scope=["candidate -> active lifecycle admission"],
        prompt_file=None,
        artifact=None,
        evidence=None,
        evidence_json=None,
        started_at=started_at,
        updated_at=started_at,
        notes=None,
        event_kind="standalone",
        launch_run_id=None,
        closes=None,
        artifact_revision=None,
        lane=None,
        effort=None,
        finding_class=None,
    )
    try:
        event = ledger.build_event(args)
        return (ledger.serialize_event(event) + "\n").encode("utf-8")
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise LifecycleError("WI-LEDGER-BOOTSTRAP-INVALID", str(exc)) from exc


def _validate_active_status_bytes(data: bytes) -> None:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise LifecycleError("WI-CATEGORY-STATUS-INVALID", "status must be UTF-8") from exc
    fields = _parse_fields(text)
    if fields.get("status") not in {"active", "blocked"}:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID", "active status must be active or blocked"
        )
    template = fields.get("template")
    if template == "quick-fix":
        errors: list[str] = []
        _validator_module().validate_quick_fix_status(text, errors)
        if errors:
            raise LifecycleError("WI-CATEGORY-STATUS-INVALID", "; ".join(errors))
        return
    if template != "staged":
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID", "V1 status template must be quick-fix or staged"
        )
    required = {
        "started",
        "updated",
        "task",
        "current step",
        "last result",
        "next action",
        "scope boundary",
        "owner",
        "integration owner",
        "evidence gate",
    }
    missing = sorted(required - set(fields))
    if missing:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID", f"staged status missing fields: {', '.join(missing)}"
        )
    for slug in _optional_relation_values(
        fields.get("depends-on"),
        comma_separated=True,
    ):
        if ":" in slug:
            raise LifecycleError(
                "WI-DEPENDENCY-NON-WORK-ITEM",
                "Depends-on accepts bare work-item slugs only",
            )
        _validate_slug(slug)


def create_candidate(root: Path, slug: str, data: bytes, *, inject_readme_failure: bool = False) -> Path:
    _validate_slug(slug)
    work_items = _work_items_root(root)
    if _category_locations(root, CATEGORIES["work-item"], slug):
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", f"slug already exists: {slug}")
    _preflight_readme(root)
    target = work_items / "backlog" / f"{slug}.md"
    _atomic_write(target, data)
    if inject_readme_failure:
        raise LifecycleError("WI-README-STALE", "injected failure after canonical success")
    try:
        refresh_readme(root)
    except LifecycleError as exc:
        if exc.failure_id == "WI-README-STALE":
            raise
        raise LifecycleError("WI-README-STALE", str(exc)) from exc
    return target


def _legacy_backlog_source(root: Path, slug: str) -> Path:
    _validate_slug(slug)
    locations = _category_locations(root, CATEGORIES["work-item"], slug)
    if locations:
        raise LifecycleError(
            "WI-CATEGORY-DUAL-LOCATION", f"canonical work-item identity already exists: {slug}"
        )
    source = _work_items_root(root) / "backlog" / slug
    if source.is_symlink() or not source.is_dir():
        raise LifecycleError(
            "WI-INVALID-TARGET", f"legacy backlog folder is missing: {slug}"
        )
    return source


def _legacy_source_rows(source: Path) -> list[tuple[str, bytes, str]]:
    rows: list[tuple[str, bytes, str]] = []
    for path in sorted(source.rglob("*"), key=lambda item: item.relative_to(source).as_posix()):
        if path.is_symlink():
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD", f"symbolic-link source is not admitted: {path}"
            )
        if path.is_dir():
            continue
        if not path.is_file():
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD", f"unsupported legacy source: {path}"
            )
        relative = path.relative_to(source).as_posix()
        if relative == LEGACY_RETIREMENT_FILE:
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD",
                f"legacy source uses reserved owner metadata name: {relative}",
            )
        data = path.read_bytes()
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD", f"legacy source is not UTF-8 text: {path}"
            ) from exc
        rows.append((relative, data, text))
    if not rows:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-PAYLOAD", f"legacy backlog folder is empty: {source}"
        )
    return rows


def _candidate_with_legacy_appendices(
    candidate_data: bytes,
    rows: Iterable[tuple[str, bytes, str]],
) -> bytes:
    try:
        candidate_data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-PAYLOAD", "candidate input must be UTF-8 text"
        ) from exc
    result = bytearray(candidate_data)
    if not result.endswith(b"\n"):
        result.extend(b"\n")
    result.extend(b"\n## Preserved legacy source appendices\n")
    for relative, data, text in rows:
        longest = max((len(match.group(0)) for match in re.finditer(r"`+", text)), default=0)
        fence = "`" * max(3, longest + 1)
        header = (
            f"\n### `{relative}`\n\n"
            f"Source SHA-256: `{hashlib.sha256(data).hexdigest()}`\n\n"
            f"Source byte length: `{len(data)}`\n\n"
            f"{fence}markdown\n"
        ).encode("utf-8")
        result.extend(header)
        result.extend(data)
        if not data.endswith(b"\n"):
            result.extend(b"\n")
        result.extend(f"{fence}\n".encode("utf-8"))
    return bytes(result)


def _restore_readme_snapshot(readme: Path, before: bytes | None) -> None:
    if before is None:
        readme.unlink(missing_ok=True)
    else:
        _atomic_write(readme, before)


def _preflight_legacy_transition_admission(
    root: Path,
    source: Path,
    reference: str,
) -> dict:
    """Reject a legacy transition before it can orphan a physical consumer."""
    incoming = _incoming_link_result(root, {source}, reference)
    _validate_incoming_link_snapshot(reference, incoming, label="legacy transition")
    return incoming


def _legacy_cleanup_metadata(
    slug: str,
    target: Path,
    transaction: Path,
    converted: bytes,
    rows: Iterable[tuple[str, bytes, str]],
) -> bytes:
    payload = {
        "schemaVersion": LEGACY_CLEANUP_SCHEMA_VERSION,
        "owner": LEGACY_CLEANUP_OWNER,
        "slug": slug,
        "transactionId": transaction.name,
        "canonicalTarget": f"{target.parent.name}/{target.name}",
        "candidateSha256": hashlib.sha256(converted).hexdigest(),
        "sourceFiles": [
            {
                "path": relative,
                "byteLength": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
            for relative, data, _text in rows
        ],
    }
    return (json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _legacy_cleanup_sidecar(backlog: Path, transaction_id: str) -> Path:
    return backlog / f".legacy-candidate-cleanup.{transaction_id.removeprefix('.')}.json"


def _validated_legacy_cleanup_residue(
    backlog: Path, slug: str, target: Path
) -> tuple[Path | None, Path, str]:
    prefix = f".{slug}.legacy-candidate."
    parent = backlog.resolve()
    residues = sorted(path for path in backlog.glob(f"{prefix}*") if path.name.startswith(prefix))
    if len(residues) > 1:
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"committed cleanup requires exactly one owned residue for {slug}, found {len(residues)}",
        )
    residue = residues[0] if residues else None
    if residue is not None and (
        residue.is_symlink() or not residue.is_dir() or residue.resolve().parent != parent
    ):
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"unsafe committed-cleanup residue for {slug}: {residue}",
        )
    sidecar_prefix = f".legacy-candidate-cleanup.{slug}.legacy-candidate."
    sidecars = sorted(backlog.glob(f"{sidecar_prefix}*.json"))
    markers = list(sidecars)
    if residue is not None:
        embedded_marker = residue / LEGACY_CLEANUP_FILE
        if embedded_marker.exists() or embedded_marker.is_symlink():
            markers.append(embedded_marker)
    if len(markers) != 1:
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"committed cleanup requires exactly one owner marker for {slug}, found {len(markers)}",
        )
    marker = markers[0]
    if marker.is_symlink() or not marker.is_file() or marker.resolve().parent not in {parent, residue}:
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"unsafe owner cleanup marker for {slug}: {marker}",
        )
    if marker.parent == backlog:
        transaction_id = "." + marker.name.removeprefix(".legacy-candidate-cleanup.").removesuffix(
            ".json"
        )
    elif residue is not None and marker.parent == residue:
        transaction_id = residue.name
    else:
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"owner cleanup marker has no transaction parent for {slug}: {marker}",
        )
    if not transaction_id.startswith(prefix) or (residue is not None and transaction_id != residue.name):
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"owner cleanup marker transaction differs from residue for {slug}: {marker}",
        )
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"invalid owner cleanup marker for {slug}: {marker}",
        ) from exc
    expected = {
        "schemaVersion": LEGACY_CLEANUP_SCHEMA_VERSION,
        "owner": LEGACY_CLEANUP_OWNER,
        "slug": slug,
        "transactionId": transaction_id,
        "canonicalTarget": f"{target.parent.name}/{target.name}",
        "candidateSha256": hashlib.sha256(target.read_bytes()).hexdigest(),
    }
    if not isinstance(payload, dict) or any(payload.get(key) != value for key, value in expected.items()):
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"owner cleanup marker differs from committed candidate for {slug}",
        )
    candidate_text = target.read_text(encoding="utf-8")
    rows = payload.get("sourceFiles")
    if not isinstance(rows, list) or not rows:
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"owner cleanup marker has no source inventory for {slug}",
        )
    expected_files: dict[str, tuple[int, str]] = {}
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("path"), str):
            raise LifecycleError(
                "WI-LEGACY-CLEANUP-REPLAY-INVALID",
                f"owner cleanup marker has invalid source row for {slug}",
            )
        relative = row["path"]
        candidate = Path(relative)
        byte_length = row.get("byteLength")
        digest = row.get("sha256")
        if (
            candidate.is_absolute()
            or ".." in candidate.parts
            or not relative
            or relative in expected_files
            or not isinstance(byte_length, int)
            or byte_length < 0
            or not isinstance(digest, str)
            or not re.fullmatch(r"[0-9a-f]{64}", digest)
        ):
            raise LifecycleError(
                "WI-LEGACY-CLEANUP-REPLAY-INVALID",
                f"owner cleanup marker source inventory is invalid for {slug}",
            )
        expected_files[relative] = (byte_length, digest)
        source_identity = (
            f"### `{relative}`\n\n"
            f"Source SHA-256: `{digest}`\n\n"
            f"Source byte length: `{byte_length}`\n\n"
        )
        if source_identity not in candidate_text:
            raise LifecycleError(
                "WI-LEGACY-CLEANUP-REPLAY-INVALID",
                f"owner cleanup marker source identity is not committed for {slug}: {relative}",
            )
    source_root = residue / "source" if residue is not None else None
    actual_files: set[str] = set()
    if residue is not None:
        for path in residue.rglob("*"):
            if path.is_symlink() or not (path.is_dir() or path.is_file()):
                raise LifecycleError(
                    "WI-LEGACY-CLEANUP-REPLAY-INVALID",
                    f"owner cleanup residue contains unsafe path for {slug}: {path}",
                )
            if path == marker:
                continue
            try:
                relative = path.relative_to(source_root).as_posix()
            except ValueError as exc:
                raise LifecycleError(
                    "WI-LEGACY-CLEANUP-REPLAY-INVALID",
                    f"owner cleanup residue contains unowned path for {slug}: {path}",
                ) from exc
            if path.is_dir():
                continue
            expected_file = expected_files.get(relative)
            data = path.read_bytes()
            if expected_file is None or expected_file != (len(data), hashlib.sha256(data).hexdigest()):
                raise LifecycleError(
                    "WI-LEGACY-CLEANUP-REPLAY-INVALID",
                    f"owner cleanup residue source differs for {slug}: {relative}",
                )
            actual_files.add(relative)
    if not actual_files <= expected_files.keys():
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"owner cleanup residue has unowned files for {slug}",
        )
    return residue, marker, transaction_id


def _finish_committed_legacy_cleanup(
    backlog: Path,
    residue: Path | None,
    marker: Path,
    transaction_id: str,
) -> None:
    if residue is not None:
        source = residue / "source"
        if source.exists():
            shutil.rmtree(source)
        sidecar = _legacy_cleanup_sidecar(backlog, transaction_id)
        if marker.parent == residue:
            os.replace(marker, sidecar)
            marker = sidecar
        residue.rmdir()
    marker.unlink()


def _committed_cleanup_failure(target: Path, residue: Path, cause: BaseException) -> LifecycleError:
    return LifecycleError(
        "WI-LEGACY-CLEANUP-AFTER-COMMIT",
        f"state=committed target={target} residue={residue}: {cause}",
    )


def _replay_legacy_candidate_cleanup(root: Path, slug: str, candidate_data: bytes) -> Path | None:
    """Remove exactly one safe residue without replaying a committed conversion."""

    work_items = _work_items_root(root)
    backlog = work_items / "backlog"
    source = backlog / slug
    target = backlog / f"{slug}.md"
    if source.exists() or not target.is_file():
        return None
    canonical = _category_locations(root, CATEGORIES["work-item"], slug)
    if canonical != [target]:
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"committed cleanup has ambiguous canonical identity for {slug}",
        )
    candidate_prefix = candidate_data if candidate_data.endswith(b"\n") else candidate_data + b"\n"
    if not target.read_bytes().startswith(candidate_prefix + b"\n## Preserved legacy source appendices\n"):
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"committed cleanup target does not match requested conversion input: {target}",
        )
    check_readme(root)
    residue, marker, transaction_id = _validated_legacy_cleanup_residue(backlog, slug, target)
    target_before = target.read_bytes()
    readme = work_items / "README.md"
    readme_before = readme.read_bytes()
    try:
        _finish_committed_legacy_cleanup(backlog, residue, marker, transaction_id)
    except OSError as exc:
        raise _committed_cleanup_failure(target, residue, exc) from exc
    if (residue is not None and residue.exists()) or marker.exists() or target.read_bytes() != target_before or readme.read_bytes() != readme_before:
        raise LifecycleError(
            "WI-LEGACY-CLEANUP-REPLAY-INVALID",
            f"committed cleanup replay changed canonical state for {slug}",
        )
    return target


def convert_legacy_candidate(
    root: Path,
    slug: str,
    candidate_data: bytes,
    *,
    inject_readme_failure: bool = False,
) -> Path:
    _validate_slug(slug)
    replay = _replay_legacy_candidate_cleanup(root, slug, candidate_data)
    if replay is not None:
        return replay
    source = _legacy_backlog_source(root, slug)
    _preflight_legacy_transition_admission(root, source, f"work-item:{slug}")
    rows = _legacy_source_rows(source)
    _validate_canonical_candidate_header(candidate_data)
    converted = _candidate_with_legacy_appendices(candidate_data, rows)
    _preflight_readme(root)
    work_items = _work_items_root(root)
    readme = work_items / "README.md"
    readme_before = readme.read_bytes() if readme.is_file() else None
    target = work_items / "backlog" / f"{slug}.md"
    transaction = Path(tempfile.mkdtemp(prefix=f".{slug}.legacy-candidate.", dir=target.parent))
    staged_source = transaction / "source"
    staged_candidate = transaction / target.name
    cleanup_marker = transaction / LEGACY_CLEANUP_FILE
    committed = False
    try:
        _atomic_write(staged_candidate, converted)
        _atomic_write(
            cleanup_marker,
            _legacy_cleanup_metadata(slug, target, transaction, converted, rows),
        )
        os.replace(source, staged_source)
        os.replace(staged_candidate, target)
        if inject_readme_failure:
            raise LifecycleError("WI-README-STALE", "injected legacy conversion failure")
        refresh_readme(root)
        if source.exists() or target.read_bytes() != converted:
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD", "legacy candidate byte verification failed"
            )
        check_readme(root)
        # The flat candidate, regenerated read-model, and byte check form the
        # irreversible commit point. Its appendices carry every staged legacy
        # byte, so disposal of the no-longer-authoritative transaction copy
        # cannot roll this committed transition back.
        committed = True
        try:
            _finish_committed_legacy_cleanup(target.parent, transaction, cleanup_marker, transaction.name)
        except OSError as exc:
            raise _committed_cleanup_failure(target, transaction, exc) from exc
    except BaseException:
        if not committed:
            if target.exists():
                target.unlink()
            if staged_source.exists() and not source.exists():
                os.replace(staged_source, source)
            _restore_readme_snapshot(readme, readme_before)
            if staged_candidate.exists():
                staged_candidate.unlink()
            cleanup_marker.unlink(missing_ok=True)
            transaction.rmdir()
        raise
    return target


def retire_legacy_backlog(
    root: Path,
    slug: str,
    disposition_data: bytes,
    terminal_instant: str,
    *,
    inject_readme_failure: bool = False,
) -> Path:
    source = _legacy_backlog_source(root, slug)
    reference = f"work-item:{slug}"
    incoming = _preflight_legacy_transition_admission(root, source, reference)
    rows = _legacy_source_rows(source)
    try:
        disposition = disposition_data.decode("utf-8").strip()
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID", "product disposition must be UTF-8 text"
        ) from exc
    if not disposition:
        raise LifecycleError(
            "WI-LEGACY-RETIREMENT-INVALID", "product disposition must not be empty"
        )
    month = archive_month(terminal_instant)
    _preflight_readme(root)
    work_items = _work_items_root(root)
    metadata_payload = {
        "schemaVersion": LEGACY_RETIREMENT_SCHEMA_VERSION,
        "owner": LEGACY_RETIREMENT_OWNER,
        "kind": "legacy-backlog-retirement",
        "slug": slug,
        "status": "rejected-before-admission",
        "terminalAt": terminal_instant,
        "productDisposition": disposition,
        "admissionHistory": "never-admitted",
        "syntheticTransitions": [],
        "sourceFiles": [
            {
                "path": relative,
                "byteLength": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
            for relative, data, _text in rows
        ],
        "incomingLinks": incoming,
    }
    metadata_data = (
        json.dumps(metadata_payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    readme = work_items / "README.md"
    readme_before = readme.read_bytes() if readme.is_file() else None
    archive = work_items / "archive"
    month_dir = archive / month
    target = month_dir / slug
    if target.exists():
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", f"archive target exists: {target}")
    transaction = Path(tempfile.mkdtemp(prefix=f".{slug}.legacy-retire.", dir=source.parent))
    staged_source = transaction / "source"
    created_archive = not archive.exists()
    created_month = not month_dir.exists()
    try:
        os.replace(source, staged_source)
        _atomic_write(staged_source / LEGACY_RETIREMENT_FILE, metadata_data)
        month_dir.mkdir(parents=True, exist_ok=True)
        os.replace(staged_source, target)
        if inject_readme_failure:
            raise LifecycleError("WI-README-STALE", "injected legacy retirement failure")
        refresh_readme(root)
        _legacy_retirement_entry(target, target / LEGACY_RETIREMENT_FILE)
    except BaseException:
        if target.exists() and not staged_source.exists():
            os.replace(target, staged_source)
        (staged_source / LEGACY_RETIREMENT_FILE).unlink(missing_ok=True)
        if staged_source.exists() and not source.exists():
            os.replace(staged_source, source)
        _restore_readme_snapshot(readme, readme_before)
        if created_month and month_dir.is_dir() and not any(month_dir.iterdir()):
            month_dir.rmdir()
        if created_archive and archive.is_dir() and not any(archive.iterdir()):
            archive.rmdir()
        raise
    finally:
        shutil.rmtree(transaction, ignore_errors=True)
    return target


def _postcommit_readme_stale(operation: str) -> LifecycleError:
    return LifecycleError(
        "WI-README-STALE",
        f"{operation} committed canonical state; README refresh required; "
        f"do not retry {operation}; run refresh, then verify the target.",
    )


def start_item(root: Path, slug: str, status_data: bytes, *, inject_readme_failure: bool = False) -> Path:
    _validate_slug(slug)
    _validate_active_status_bytes(status_data)
    is_staged = _parse_fields(status_data.decode("utf-8")).get("template") == "staged"
    admission_ledger = _staged_admission_ledger_bytes(slug, status_data) if is_staged else None
    work_items = _work_items_root(root)
    locations = _category_locations(root, CATEGORIES["work-item"], slug)
    backlog = work_items / "backlog" / f"{slug}.md"
    if locations != [backlog]:
        failure = "WI-CATEGORY-DUAL-LOCATION" if len(locations) > 1 else "WI-INVALID-TARGET"
        raise LifecycleError(failure, f"start requires exactly one backlog candidate: {slug}")
    transfer_relation = _validate_started_transfer_relation(backlog.read_bytes(), status_data)
    _validate_obligation_transfer_ownership(root)
    _preflight_readme(root)
    active_parent = work_items / "active"
    active_parent.mkdir(parents=True, exist_ok=True)
    target = active_parent / slug
    temp = Path(tempfile.mkdtemp(prefix=f".{slug}.", dir=active_parent))
    moved_candidate = temp / "admission.md"
    committed = False
    try:
        os.replace(backlog, moved_candidate)
        _atomic_write(temp / "status.md", status_data)
        if admission_ledger is not None:
            _atomic_write(temp / "agent-runs.jsonl", admission_ledger)
            errors = _validator_module().validate_work_item(
                temp, strict_revise=transfer_relation is None
            )
            if errors:
                raise LifecycleError("WI-LEDGER-BOOTSTRAP-INVALID", "; ".join(errors))
        os.replace(temp, target)
        committed = True
    finally:
        if not committed:
            if moved_candidate.exists() and not backlog.exists():
                backlog.parent.mkdir(parents=True, exist_ok=True)
                os.replace(moved_candidate, backlog)
            shutil.rmtree(temp, ignore_errors=True)
    if inject_readme_failure:
        raise _postcommit_readme_stale("start")
    try:
        refresh_readme(root)
    except LifecycleError as exc:
        raise _postcommit_readme_stale("start") from exc
    return target


def update_status(root: Path, slug: str, status_data: bytes, *, inject_readme_failure: bool = False) -> Path:
    _validate_active_status_bytes(status_data)
    target = resolve_category(root, f"work-item:{slug}")
    if target.parent.name != "active" or not target.is_dir():
        raise LifecycleError("WI-INVALID-TARGET", "status update requires an active work-item")
    _preflight_readme(root)
    status = target / "status.md"
    _atomic_write(status, status_data)
    if inject_readme_failure:
        raise _postcommit_readme_stale("update")
    try:
        refresh_readme(root)
    except LifecycleError as exc:
        raise _postcommit_readme_stale("update") from exc
    return status


def _validate_closure(data: bytes, terminal_instant: str) -> None:
    try:
        fields = _parse_fields(data.decode("utf-8"))
    except UnicodeDecodeError as exc:
        raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "closure must be UTF-8") from exc
    required = {"closed", "outcome", "evidence", "residual risk"}
    missing = sorted(key for key in required if not fields.get(key))
    if missing:
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
            f"closure missing fields: {', '.join(missing)}",
        )
    if fields["closed"] != terminal_instant:
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
            "closure Closed does not match requested terminal instant",
        )
    _strict_utc(fields["closed"])


def _terminalize_status(data: bytes) -> bytes:
    if _schema_marker_occurrences(data, "status.md"):
        raise LifecycleError(
            "WI-CATEGORY-SCHEMA-INVALID",
            "active status must not contain a lifecycle schema marker",
        )
    text = data.decode("utf-8")
    replaced, count = re.subn(
        r"(?im)^(\s*status\s*:\s*)(active|blocked)\s*$",
        r"\1completed",
        text,
        count=1,
    )
    if count != 1:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID",
            "active V1 status has no single active/blocked status field",
        )
    return _stamp_schema_marker(replaced.encode("utf-8"), "status.md")


SCRATCH_REGENERATION_MARKER = (
    "Scratch evidence: regeneration-only; all load-bearing observations retained."
)


def _scratch_tombstone(original: Path, slug: str, run_id: str, entry_id: str) -> Path:
    name = _validator_module().scratch_tombstone_name(slug, run_id, entry_id)
    return original.with_name(name)


def _classify_scratch_entry(classifier, path: Path, root: Path):
    try:
        return classifier.classify_owned_tree(path, root)
    except classifier.OwnedTreeClassificationError as exc:
        failure = {
            "SCRATCH-INVENTORY-UNSAFE": "WI-SCRATCH-UNSAFE-ENTRY",
            "SCRATCH-INVENTORY-DRIFT": "WI-SCRATCH-IDENTITY-DRIFT",
        }.get(exc.failure_id, "WI-SCRATCH-PROOF-FAILED")
        raise LifecycleError(failure, str(exc)) from exc


def _verify_scratch_proof(
    snapshot,
    proof: dict,
    canonical_pointer: Path,
) -> None:
    kind = proof["kind"]
    if kind == "git-object-set":
        if not snapshot.git_check_complete or not snapshot.all_git_recoverable:
            raise LifecycleError(
                "WI-SCRATCH-PROOF-FAILED",
                "scratch bytes are not completely recoverable from the repository object store",
            )
        return
    if kind != "accepted-artifact":
        raise LifecycleError("WI-SCRATCH-PROOF-FAILED", f"unsupported proof kind: {kind!r}")
    try:
        artifact = canonical_pointer.read_bytes()
    except OSError as exc:
        raise LifecycleError(
            "WI-SCRATCH-PROOF-FAILED", "accepted artifact is unreadable"
        ) from exc
    if hashlib.sha256(artifact).hexdigest() != proof["artifactSha256"]:
        raise LifecycleError("WI-SCRATCH-PROOF-FAILED", "accepted artifact digest differs")
    try:
        text = artifact.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-SCRATCH-PROOF-FAILED", "accepted artifact is not UTF-8"
        ) from exc
    if SCRATCH_REGENERATION_MARKER not in text:
        raise LifecycleError(
            "WI-SCRATCH-PROOF-FAILED", "accepted artifact lacks the regeneration marker"
        )


def _relocate_scratch_pointer(root: Path, pointer: Path) -> Path:
    if pointer.is_file():
        return pointer
    try:
        relative = pointer.relative_to(root)
    except ValueError:
        return pointer
    parts = relative.parts
    if len(parts) < 4 or parts[:2] != ("work-items", "active"):
        return pointer
    locations = _category_locations(root, CATEGORIES["work-item"], parts[2])
    archived = [path for path in locations if "archive" in path.parts]
    return archived[0].joinpath(*parts[3:]) if len(archived) == 1 else pointer


def _scratch_namespace_entries(owner_root: Path) -> tuple[set[Path], set[Path]]:
    """Return present original/tombstone leaf roots without following links."""

    classifier = _scratch_classifier_module()
    try:
        inspection = classifier.inspect_owned_namespace(owner_root)
    except LifecycleError:
        raise
    except (OSError, classifier.OwnedTreeClassificationError) as exc:
        raise LifecycleError("WI-SCRATCH-UNSAFE-ENTRY", str(exc)) from exc
    return set(inspection.originals), set(inspection.tombstones)


def _release_receipt_path(item: Path, run_id: str, entry_id: str) -> Path:
    identity = _sha256_bytes(f"{run_id}\0{entry_id}".encode("utf-8"))
    return item / "retained-scratch-releases" / f"{identity}.json"


def _release_event_binding(item: Path, run_id: str, entry_id: str) -> tuple[str, dict]:
    matches: list[tuple[str, dict]] = []
    for raw_line in (item / "agent-runs.jsonl").read_bytes().splitlines():
        try:
            event = json.loads(raw_line)
        except (ValueError, TypeError) as exc:
            raise LifecycleError("WI-LEDGER-UNSETTLED", "archived ledger is malformed") from exc
        if isinstance(event, dict) and event.get("runId") == run_id:
            matches.append((_sha256_bytes(raw_line), event))
    if len(matches) != 1 or matches[0][1].get("eventKind") != "terminal":
        raise LifecycleError("WI-SCRATCH-RELEASE-IDENTITY", "one exact terminal event is required")
    entries = matches[0][1].get("scratchEvidence", [])
    selected = [entry for entry in entries if isinstance(entry, dict) and entry.get("entryId") == entry_id]
    if len(selected) != 1 or selected[0].get("disposition") != "retain":
        raise LifecycleError("WI-SCRATCH-RELEASE-IDENTITY", "one exact retained entry is required")
    return matches[0][0], selected[0]


def _release_artifact_snapshot(item: Path, artifact: str) -> str:
    relative = PurePosixPath(artifact)
    if (
        not artifact or relative.is_absolute() or Path(artifact).drive or "\\" in artifact
        or any(part in {"", ".", ".."} for part in relative.parts)
        or relative.parts[0] == "retained-scratch-releases"
    ):
        raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "canonical artifact path is unsafe")
    path = item.joinpath(*relative.parts)
    _lifecycle_reject_unreduced_reparse(
        path, failure_id="WI-SCRATCH-RELEASE-EVIDENCE",
        message="canonical artifact crosses a link or reparse point",
    )
    if not path.is_file():
        raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "canonical artifact is missing")
    return _sha256_bytes(_capture_file_snapshot(
        path, failure_id="WI-SCRATCH-RELEASE-EVIDENCE", require_single_link=True,
    ).data)


def _release_inventory(
    root: Path, source: Path, original: Path, *, verify_link_targets: bool,
) -> tuple[dict[str, str], ...]:
    classifier = _scratch_classifier_module()
    try:
        return classifier.snapshot_release_tree(
            Path(os.path.abspath(source)), Path(os.path.abspath(root)),
            original_root=Path(os.path.abspath(original)),
            verify_link_targets=verify_link_targets,
        )
    except (OSError, classifier.OwnedTreeClassificationError) as exc:
        raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", str(exc)) from exc


def _assign_release_target_custody(
    root: Path, item: Path, rows: tuple[dict, ...], artifact_sha256: str,
) -> tuple[dict, ...]:
    assigned: list[dict] = []
    for row in rows:
        bound = dict(row)
        if row["kind"] == "symlink":
            if row["targetClass"] == "inside-root":
                bound["targetCustody"] = "accepted-rationale"
            else:
                target = root / Path(row["targetPath"])
                if item in target.parents:
                    bound["targetCustody"] = "archive-target"
                elif row["targetKind"] == "file" and row["targetSha256"] == artifact_sha256:
                    bound["targetCustody"] = "artifact"
                else:
                    raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "repository link target lacks durable custody")
        assigned.append(bound)
    return tuple(assigned)


def _verify_release_targets(
    root: Path, item: Path, source: Path, rows: tuple[dict, ...], artifact_sha256: str,
) -> None:
    classifier = _scratch_classifier_module()
    saved = {row["path"]: row for row in rows}
    for row in rows:
        if row["kind"] != "symlink":
            continue
        target = root / Path(row["targetPath"])
        inside = target == source or source in target.parents
        if ("inside-root" if inside else "repository") != row["targetClass"]:
            raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "link target class differs from source root")
        if inside:
            if row["targetCustody"] != "accepted-rationale":
                raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "inside-root target custody differs")
            relative = target.relative_to(source).as_posix()
            target_row = saved.get(relative)
            if target_row is None or target_row["kind"] != row["targetKind"]:
                raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "inside-root target is absent from release inventory")
            if row["targetKind"] == "file":
                digest = target_row["sha256"]
            else:
                prefix = "" if relative == "." else f"{relative}/"
                subtree = []
                for candidate in rows:
                    path = candidate["path"]
                    if path == relative or (prefix and path.startswith(prefix)) or relative == ".":
                        if candidate["kind"] == "symlink":
                            raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "inside-root target directory contains a link")
                        subtree.append({
                            **candidate,
                            "path": "." if path == relative else path[len(prefix):],
                        })
                digest = _sha256_bytes(json.dumps(
                    sorted(subtree, key=lambda candidate: candidate["path"]),
                    sort_keys=True, separators=(",", ":"),
                ).encode("utf-8"))
            if digest != row["targetSha256"]:
                raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "inside-root target digest differs from release inventory")
            continue
        if row["targetCustody"] == "artifact":
            if row["targetKind"] != "file" or row["targetSha256"] != artifact_sha256:
                raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "promoted target differs from artifact")
            continue
        if row["targetCustody"] != "archive-target" or target == item or item not in target.parents:
            raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "repository link target lacks archive custody")
        _lifecycle_reject_unreduced_reparse(
            target, failure_id="WI-SCRATCH-RELEASE-EVIDENCE",
            message="repository link target crosses a link or reparse point",
        )
        try:
            kind, digest = classifier.release_target_digest(target, root)
        except (OSError, classifier.OwnedTreeClassificationError) as exc:
            raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "retained repository target is unsafe") from exc
        if kind != row["targetKind"] or digest != row["targetSha256"]:
            raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "retained repository target changed")


def _valid_release_inventory_rows(rows: object) -> bool:
    if not isinstance(rows, list) or not rows or len(rows) > _scratch_classifier_module().MAX_OWNED_TREE_ENTRIES:
        return False
    seen: set[str] = set()
    kinds: dict[str, str] = {}
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("path"), str):
            return False
        path = row["path"]
        parts = PurePosixPath(path).parts
        if (
            path in seen or "\\" in path or Path(path).drive or (path != "." and (
                not parts or PurePosixPath(path).is_absolute()
                or PurePosixPath(path).as_posix() != path
                or any(part in {"", ".", ".."} for part in parts)
            ))
        ):
            return False
        seen.add(path)
        kind = row.get("kind")
        if kind == "directory":
            if set(row) != {"path", "kind"}:
                return False
        elif kind == "file":
            if set(row) != {"path", "kind", "sha256"} or not isinstance(row.get("sha256"), str) or SHA256_RE.fullmatch(row["sha256"]) is None:
                return False
        elif kind == "symlink":
            if (
                path == "." or set(row) != {"path", "kind", "rawTargetSha256", "targetPath", "targetClass", "targetKind", "targetSha256", "targetCustody"}
                or any(not isinstance(row.get(key), str) or SHA256_RE.fullmatch(row[key]) is None for key in ("rawTargetSha256", "targetSha256"))
                or row.get("targetClass") not in {"inside-root", "repository"}
                or row.get("targetKind") not in {"file", "directory"}
                or row.get("targetCustody") not in {"accepted-rationale", "archive-target", "artifact"}
                or not isinstance(row.get("targetPath"), str)
            ):
                return False
            target_path = PurePosixPath(row["targetPath"])
            if (
                target_path.is_absolute() or Path(row["targetPath"]).drive
                or "\\" in row["targetPath"]
                or target_path.as_posix() != row["targetPath"]
                or any(part in {"", ".", ".."} for part in target_path.parts)
            ):
                return False
        else:
            return False
        kinds[path] = kind
    if rows[0]["path"] != "." or kinds["."] not in {"file", "directory"}:
        return False
    if kinds["."] == "file" and len(rows) != 1:
        return False
    return all(path == "." or kinds.get(str(PurePosixPath(path).parent)) == "directory" or (
        PurePosixPath(path).parent == PurePosixPath(".") and kinds["."] == "directory"
    ) for path in seen)


def _release_receipt(
    root: Path, item: Path, run_id: str, entry_id: str, entry: dict,
) -> dict | None:
    path = _release_receipt_path(item, run_id, entry_id)
    _lifecycle_reject_unreduced_reparse(
        path, failure_id="WI-SCRATCH-RELEASE-RECEIPT",
        message="release receipt crosses a link or reparse point",
    )
    if not path.exists():
        return None
    stage_prefix = f".{path.name}."
    try:
        with os.scandir(path.parent) as entries:
            stages = sorted(
                (Path(candidate.path) for candidate in entries
                 if candidate.name.startswith(stage_prefix) and candidate.name.endswith(".tmp")),
                key=lambda candidate: candidate.name,
            )
    except OSError as exc:
        raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt staging cannot be inspected") from exc
    reconciliation_stage: Path | None = None
    if stages:
        if len(stages) != 1:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt has ambiguous staging")
        reconciliation_stage = stages[0]
        _lifecycle_reject_unreduced_reparse(
            reconciliation_stage, failure_id="WI-SCRATCH-RELEASE-RECEIPT",
            message="release receipt staging path is unsafe",
        )
        try:
            final_info = path.lstat()
            stage_info = reconciliation_stage.lstat()
        except OSError as exc:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt pair cannot be inspected") from exc
        if not (
            stat.S_ISREG(final_info.st_mode) and stat.S_ISREG(stage_info.st_mode)
            and final_info.st_nlink == stage_info.st_nlink == 2
            and (final_info.st_dev, final_info.st_ino)
            == (stage_info.st_dev, stage_info.st_ino)
        ):
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt stage is not its sole hard link")
        raw = _capture_file_snapshot(
            path, failure_id="WI-SCRATCH-RELEASE-RECEIPT",
        ).data
        if _capture_file_snapshot(
            reconciliation_stage, failure_id="WI-SCRATCH-RELEASE-RECEIPT",
        ).data != raw:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt stage bytes differ")
    else:
        raw = _capture_file_snapshot(
            path, failure_id="WI-SCRATCH-RELEASE-RECEIPT", require_single_link=True,
        ).data
    try:
        receipt = json.loads(raw)
    except (TypeError, ValueError) as exc:
        raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt is malformed") from exc
    event_hash, bound_entry = _release_event_binding(item, run_id, entry_id)
    expected_keys = {
        "schemaVersion", "archive", "runId", "entryId", "eventSha256", "entrySha256",
        "sourcePath", "artifact", "artifactSha256", "rationale", "inventory", "inventorySha256",
    }
    if not isinstance(receipt, dict) or set(receipt) != expected_keys:
        raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt shape differs")
    rows = receipt["inventory"]
    try:
        valid_rows = _valid_release_inventory_rows(rows)
        digest = _sha256_bytes(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode("utf-8")) if valid_rows else ""
    except (TypeError, ValueError, KeyError):
        valid_rows, digest = False, ""
    if not valid_rows or digest != receipt["inventorySha256"]:
        raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release inventory is malformed")
    archive_relative = item.relative_to(root).as_posix()
    entry_hash = _sha256_bytes(json.dumps(bound_entry, sort_keys=True, separators=(",", ":")).encode("utf-8"))
    if (
        receipt["schemaVersion"] != 1 or receipt["archive"] != archive_relative
        or receipt["runId"] != run_id or receipt["entryId"] != entry_id
        or receipt["eventSha256"] != event_hash or receipt["entrySha256"] != entry_hash
        or receipt["sourcePath"] != entry["path"]
        or not isinstance(receipt["rationale"], str) or not receipt["rationale"].strip()
        or not isinstance(receipt["artifact"], str)
        or receipt["artifactSha256"] != _release_artifact_snapshot(item, receipt["artifact"])
    ):
        raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release identity or evidence differs")
    _verify_release_targets(root, item, root / Path(entry["path"]), tuple(rows), receipt["artifactSha256"])
    if reconciliation_stage is not None:
        try:
            rebound_final = path.lstat()
            rebound_stage = reconciliation_stage.lstat()
            if not (
                rebound_final.st_nlink == rebound_stage.st_nlink == 2
                and (rebound_final.st_dev, rebound_final.st_ino)
                == (rebound_stage.st_dev, rebound_stage.st_ino)
                == (final_info.st_dev, final_info.st_ino)
            ):
                raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt pair changed before settlement")
            reconciliation_stage.unlink()
        except OSError as exc:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt stage cannot be settled") from exc
        if _capture_file_snapshot(
            path, failure_id="WI-SCRATCH-RELEASE-RECEIPT", require_single_link=True,
        ).data != raw:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt changed after stage settlement")
    return receipt


def _release_rows_match(actual: tuple[dict, ...], expected: tuple[dict, ...], *, subset: bool) -> bool:
    original = {row["path"]: row for row in expected}
    if not subset and len(actual) != len(expected):
        return False
    for row in actual:
        reference = original.get(row["path"])
        if reference is None:
            return False
        if row["kind"] == "symlink":
            reference = {key: value for key, value in reference.items() if key not in {"targetSha256", "targetKind", "targetCustody"}}
        if row != reference:
            return False
    return True


def _scratch_disposition_plan(
    root: Path,
    item: Path,
    *,
    archived: bool,
    retention_paths: frozenset[Path] = frozenset(),
) -> tuple[ScratchDisposition, ...]:
    root = Path(os.path.abspath(root))
    ledger = item / "agent-runs.jsonl"
    owner_root = root / ".scratch" / "work-items" / item.name
    classifier = _scratch_classifier_module()
    try:
        owner_inspection = classifier.inspect_root_no_follow(owner_root)
    except classifier.OwnedTreeClassificationError as exc:
        raise LifecycleError("WI-SCRATCH-UNSAFE-ENTRY", str(exc)) from exc
    if not ledger.exists():
        if archived and retention_paths:
            return ()
        originals, tombstones = _scratch_namespace_entries(owner_root)
        if owner_inspection.exists and (set(originals) != set(retention_paths) or tombstones):
            raise LifecycleError(
                "WI-SCRATCH-OWNERSHIP-INCOMPLETE",
                "canonical scratch namespace exists without a terminal owner declaration",
            )
        return ()

    validator = _validator_module()
    errors: list[str] = []
    raw_metadata: list[dict[str, object]] = []
    events = validator.load_jsonl(ledger, errors, raw_metadata)
    effective_events, _migration_counts, projection_errors = validator.project_legacy_obligation_migrations(
        events, raw_metadata, item
    )
    errors.extend(projection_errors)
    for event in effective_events:
        entries = event.get("scratchEvidence")
        if entries is not None and (
            not isinstance(entries, list) or any(not isinstance(entry, dict) for entry in entries)
        ):
            errors.append(f"{event.get('runId')}: scratchEvidence must be a list of objects")
    validator.validate_scratch_ownership(effective_events, item, errors)
    if errors:
        raise LifecycleError("WI-LEDGER-UNSETTLED", "; ".join(errors))
    recorded: list[tuple[str, dict]] = []
    for event in effective_events:
        for entry in event.get("scratchEvidence", []):
            recorded.append((event["runId"], entry))
    if not recorded:
        originals, tombstones = _scratch_namespace_entries(owner_root)
        if owner_inspection.exists and (set(originals) != set(retention_paths) or tombstones):
            raise LifecycleError(
                "WI-SCRATCH-OWNERSHIP-INCOMPLETE",
                "canonical scratch namespace exists without a terminal owner declaration",
            )
        return ()

    originals_present, tombstones_present = _scratch_namespace_entries(owner_root)
    expected_originals: set[Path] = set()
    expected_tombstones: set[Path] = set()
    plans: list[ScratchDisposition] = []
    for run_id, entry in recorded:
        original = root / Path(entry["path"])
        tombstone = _scratch_tombstone(original, item.name, run_id, entry["entryId"])
        expected_originals.add(original)
        expected_tombstones.add(tombstone)
        original_exists = original in originals_present
        tombstone_exists = tombstone in tombstones_present
        if original_exists and tombstone_exists:
            raise LifecycleError(
                "WI-SCRATCH-DISPOSITION-CONFLICT",
                f"both original and tombstone exist for {entry['path']}",
            )
        release_receipt = (
            _release_receipt(root, item, run_id, entry["entryId"], entry)
            if archived and entry["disposition"] == "retain" else None
        )
        if entry["disposition"] == "retain" and release_receipt is None and (tombstone_exists or not original_exists):
            raise LifecycleError(
                "WI-SCRATCH-RETAINED-EVIDENCE-MISSING",
                f"retained scratch evidence is missing or tombstoned: {entry['path']}",
            )
        if not original_exists and not tombstone_exists:
            if not archived:
                raise LifecycleError(
                    "WI-SCRATCH-OWNERSHIP-INCOMPLETE",
                    f"declared scratch evidence is missing: {entry['path']}",
                )
            if entry["disposition"] == "delete":
                continue
        pointer_errors: list[str] = []
        pointer = validator.resolve_scratch_pointer(
            item,
            entry["canonicalPointer"],
            "scratchEvidence.canonicalPointer",
            run_id,
            pointer_errors,
        )
        if pointer is None or pointer_errors:
            raise LifecycleError(
                "WI-SCRATCH-POINTER-OUTSIDE-ITEM",
                "; ".join(pointer_errors) or "missing canonical pointer",
            )
        if release_receipt is not None:
            expected_rows = tuple(release_receipt["inventory"])
            if original_exists or tombstone_exists:
                source = tombstone if tombstone_exists else original
                actual_rows = _release_inventory(root, source, original, verify_link_targets=False)
                if not _release_rows_match(actual_rows, expected_rows, subset=tombstone_exists):
                    raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", "release source differs from bound inventory")
            snapshot = None
            proof = None
        elif entry["disposition"] == "retain":
            try:
                retained = classifier.inspect_root_no_follow(original)
            except classifier.OwnedTreeClassificationError as exc:
                raise LifecycleError("WI-SCRATCH-RETAINED-EVIDENCE-MISSING", str(exc)) from exc
            if (
                not retained.exists
                or retained.is_link_or_reparse
                or not (retained.is_directory or retained.is_regular_file)
            ):
                raise LifecycleError(
                    "WI-SCRATCH-RETAINED-EVIDENCE-MISSING",
                    f"retained scratch root is unavailable: {entry['path']}",
                )
            snapshot = None
            proof = None
        else:
            source = tombstone if tombstone_exists else original
            snapshot = _classify_scratch_entry(classifier, source, root)
            proof = entry["proof"]
            _verify_scratch_proof(snapshot, proof, pointer)
        plans.append(
            ScratchDisposition(
                original=original,
                tombstone=tombstone,
                disposition="release" if release_receipt is not None else entry["disposition"],
                proof=proof,
                canonical_pointer=pointer,
                snapshot=snapshot,
                release_receipt=release_receipt,
            )
        )

    if retention_paths & expected_originals:
        raise LifecycleError(
            "WI-SCRATCH-OWNERSHIP-INCOMPLETE",
            "declared scratch evidence cannot also be retained by close",
        )
    if (
        originals_present - expected_originals - set(retention_paths)
        or tombstones_present - expected_tombstones
    ):
        raise LifecycleError(
            "WI-SCRATCH-OWNERSHIP-INCOMPLETE",
            "scratch namespace contains an undeclared evidence root",
        )
    return tuple(plans)


def _remove_scratch_tree(tree_root: Path) -> None:
    """Remove one already-proven tree without following links or reparses."""

    classifier = _scratch_classifier_module()
    directories: list[Path] = []
    stack = [tree_root]
    while stack:
        directory = stack.pop()
        inspection = classifier.inspect_root_no_follow(directory)
        if not inspection.exists or inspection.is_link_or_reparse or not inspection.is_directory:
            raise OSError(f"unsafe directory during removal: {directory.name}")
        directories.append(directory)
        with os.scandir(directory) as entries:
            children = list(entries)
        for entry in children:
            child = classifier.inspect_root_no_follow(Path(entry.path))
            if child.is_link_or_reparse:
                raise OSError(f"unsafe link or reparse during removal: {entry.name}")
            if child.is_directory:
                stack.append(Path(entry.path))
            elif child.exists and stat.S_ISREG(os.lstat(entry.path).st_mode):
                Path(entry.path).unlink()
            else:
                raise OSError(f"unsafe non-regular entry during removal: {entry.name}")
    for directory in reversed(directories):
        directory.rmdir()


def _settle_released_scratch(
    root: Path, plan: ScratchDisposition, *, inject_failure_at: str | None = None,
) -> None:
    """Resume one receipt-bound removal; never walk a symbolic-link target."""
    root = Path(os.path.abspath(root))
    receipt = plan.release_receipt
    assert receipt is not None
    item = root / Path(receipt["archive"])
    _event_hash, entry = _release_event_binding(item, receipt["runId"], receipt["entryId"])
    checked = _release_receipt(root, item, receipt["runId"], receipt["entryId"], entry)
    if checked != receipt:
        raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt changed after preflight")
    classifier = _scratch_classifier_module()
    original = classifier.inspect_root_no_follow(plan.original)
    tombstone = classifier.inspect_root_no_follow(plan.tombstone)
    if original.exists and tombstone.exists:
        raise LifecycleError("WI-SCRATCH-DISPOSITION-CONFLICT", "both release source and tombstone exist")
    if not original.exists and not tombstone.exists:
        return
    expected = tuple(receipt["inventory"])
    source = plan.tombstone if tombstone.exists else plan.original
    actual = _release_inventory(root, source, plan.original, verify_link_targets=False)
    if not _release_rows_match(actual, expected, subset=tombstone.exists):
        raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", "release source differs before removal")
    if original.exists:
        rebound = classifier.inspect_root_no_follow(plan.original)
        if rebound != original or rebound.is_link_or_reparse:
            raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", "release root identity changed before rename")
        os.replace(plan.original, plan.tombstone)
        if inject_failure_at == "after-rename":
            raise LifecycleError("WI-SCRATCH-DISPOSITION-PENDING", "injected after-rename")
    actual = _release_inventory(root, plan.tombstone, plan.original, verify_link_targets=False)
    if not _release_rows_match(actual, expected, subset=True):
        raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", "release tombstone differs after rename")
    remaining = {row["path"] for row in actual}
    file_unlinked = False
    link_unlinked = False
    for row in sorted(expected, key=lambda candidate: (candidate["kind"] != "symlink", -len(PurePosixPath(candidate["path"]).parts), candidate["path"])):
        relative = row["path"]
        if relative not in remaining or row["kind"] == "directory":
            continue
        target = plan.tombstone if relative == "." else plan.tombstone / Path(relative)
        logical = plan.original if relative == "." else plan.original / Path(relative)
        _lifecycle_reject_unreduced_reparse(
            target.parent, failure_id="WI-SCRATCH-RELEASE-DRIFT",
            message="release descendant parent became a link or reparse point",
        )
        before = classifier.inspect_root_no_follow(target)
        current = _release_inventory(root, target, logical, verify_link_targets=False)
        expected_leaf = {key: value for key, value in row.items() if key not in {"targetSha256", "targetClass", "targetKind", "targetCustody"}}
        expected_leaf["path"] = "."
        if len(current) != 1 or {
            key: value for key, value in current[0].items() if key != "targetClass"
        } != expected_leaf:
            raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", "release descendant changed before unlink")
        after = classifier.inspect_root_no_follow(target)
        if after != before or (row["kind"] == "symlink") != after.is_link_or_reparse:
            raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", "release descendant identity changed before unlink")
        target.unlink()
        if row["kind"] == "symlink" and not link_unlinked:
            link_unlinked = True
            if inject_failure_at == "after-first-link-unlink":
                raise LifecycleError("WI-SCRATCH-DISPOSITION-PENDING", "injected after-first-link-unlink")
        if row["kind"] == "file" and not file_unlinked:
            file_unlinked = True
            if inject_failure_at == "after-first-file-unlink":
                raise LifecycleError("WI-SCRATCH-DISPOSITION-PENDING", "injected after-first-file-unlink")
    for row in sorted(expected, key=lambda candidate: (-len(PurePosixPath(candidate["path"]).parts), candidate["path"])):
        if row["kind"] != "directory" or row["path"] not in remaining:
            continue
        target = plan.tombstone if row["path"] == "." else plan.tombstone / Path(row["path"])
        inspection = classifier.inspect_root_no_follow(target)
        if not inspection.exists or inspection.is_link_or_reparse or not inspection.is_directory:
            raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", "release directory changed before removal")
        target.rmdir()
    if inject_failure_at == "after-final-removal":
        raise LifecycleError("WI-SCRATCH-DISPOSITION-PENDING", "injected after-final-removal")


def _settle_scratch_dispositions(root: Path, plans: tuple[ScratchDisposition, ...]) -> None:
    classifier = _scratch_classifier_module()
    for plan in plans:
        if plan.disposition == "retain":
            continue
        if plan.disposition == "release":
            try:
                _settle_released_scratch(root, plan)
            except LifecycleError:
                raise
            except (OSError, classifier.OwnedTreeClassificationError) as exc:
                raise LifecycleError("WI-SCRATCH-DISPOSITION-PENDING", str(exc)) from exc
            continue
        try:
            original_state = classifier.inspect_root_no_follow(plan.original)
            tombstone_state = classifier.inspect_root_no_follow(plan.tombstone)
        except classifier.OwnedTreeClassificationError as exc:
            raise LifecycleError("WI-SCRATCH-DISPOSITION-PENDING", str(exc)) from exc
        if original_state.exists and tombstone_state.exists:
            raise LifecycleError(
                "WI-SCRATCH-DISPOSITION-CONFLICT", "both original and tombstone exist"
            )
        source = plan.tombstone if tombstone_state.exists else plan.original
        source_state = tombstone_state if tombstone_state.exists else original_state
        if not source_state.exists:
            continue
        if source_state.is_link_or_reparse or not source_state.is_directory:
            raise LifecycleError(
                "WI-SCRATCH-DISPOSITION-PENDING",
                "scratch root changed to an unsafe identity after preflight",
            )
        try:
            snapshot = classifier.classify_owned_tree(source, root)
            if plan.snapshot is None or not classifier.identity_matches(snapshot, plan.snapshot):
                raise LifecycleError(
                    "WI-SCRATCH-DISPOSITION-PENDING", "scratch identity drifted after preflight"
                )
            canonical_pointer = _relocate_scratch_pointer(root, plan.canonical_pointer)
            assert plan.proof is not None
            _verify_scratch_proof(snapshot, plan.proof, canonical_pointer)
            if source == plan.original:
                os.replace(plan.original, plan.tombstone)
            tombstone_snapshot = classifier.classify_owned_tree(plan.tombstone, root)
            if not classifier.identity_matches(tombstone_snapshot, plan.snapshot):
                raise LifecycleError(
                    "WI-SCRATCH-DISPOSITION-PENDING", "scratch identity drifted after tombstone"
                )
            _verify_scratch_proof(tombstone_snapshot, plan.proof, canonical_pointer)
            _remove_scratch_tree(plan.tombstone)
        except LifecycleError:
            raise
        except (OSError, classifier.OwnedTreeClassificationError) as exc:
            raise LifecycleError(
                "WI-SCRATCH-DISPOSITION-PENDING",
                f"archived item retains retryable scratch disposition: {exc}",
            ) from exc


def release_retained_scratch(
    root: Path,
    slug: str,
    *,
    terminal_run_id: str,
    expected_event_sha256: str,
    entry_id: str,
    artifact: str,
    rationale: str,
    apply: bool = False,
    inject_failure_at: str | None = None,
) -> Path:
    """Opt-in post-close release of one exact ledger-declared retained root."""
    if not apply:
        raise LifecycleError("WI-SCRATCH-RELEASE-APPLY-REQUIRED", "release requires explicit apply")
    _validate_slug(slug)
    root = Path(os.path.abspath(root))
    locations = _category_locations(root, CATEGORIES["work-item"], slug)
    if len(locations) != 1 or "archive" not in locations[0].parts:
        raise LifecycleError("WI-SCRATCH-RELEASE-IDENTITY", "one exact archived item is required")
    item = locations[0]
    _archived_work_item_entry(item)
    event_hash, entry = _release_event_binding(item, terminal_run_id, entry_id)
    if expected_event_sha256 != event_hash:
        raise LifecycleError("WI-SCRATCH-RELEASE-IDENTITY", "terminal event digest differs")
    if not isinstance(rationale, str) or not rationale.strip():
        raise LifecycleError("WI-SCRATCH-RELEASE-EVIDENCE", "accepted-evidence rationale is required")
    artifact_hash = _release_artifact_snapshot(item, artifact)
    path = _release_receipt_path(item, terminal_run_id, entry_id)
    existing = _release_receipt(root, item, terminal_run_id, entry_id, entry)
    if existing is None:
        plans = _scratch_disposition_plan(root, item, archived=True)
        selected = [plan for plan in plans if plan.original == root / Path(entry["path"])]
        if len(selected) != 1 or selected[0].disposition != "retain":
            raise LifecycleError("WI-SCRATCH-RELEASE-IDENTITY", "selected retained root is unavailable")
        source = selected[0].original
        inspection = _scratch_classifier_module().inspect_root_no_follow(source)
        if not inspection.exists or inspection.is_link_or_reparse or not (
            inspection.is_directory or inspection.is_regular_file
        ):
            raise LifecycleError("WI-SCRATCH-RELEASE-DRIFT", "selected root is not ordinary")
        rows = _assign_release_target_custody(
            root, item, _release_inventory(root, source, source, verify_link_targets=True), artifact_hash,
        )
        _verify_release_targets(root, item, source, rows, artifact_hash)
        entry_hash = _sha256_bytes(json.dumps(entry, sort_keys=True, separators=(",", ":")).encode("utf-8"))
        inventory = list(rows)
        receipt = {
            "schemaVersion": 1,
            "archive": item.relative_to(root).as_posix(),
            "runId": terminal_run_id,
            "entryId": entry_id,
            "eventSha256": event_hash,
            "entrySha256": entry_hash,
            "sourcePath": entry["path"],
            "artifact": artifact,
            "artifactSha256": artifact_hash,
            "rationale": rationale,
            "inventory": inventory,
            "inventorySha256": _sha256_bytes(json.dumps(inventory, sort_keys=True, separators=(",", ":")).encode("utf-8")),
        }
        _lifecycle_reject_unreduced_reparse(
            path.parent, failure_id="WI-SCRATCH-RELEASE-RECEIPT",
            message="release receipt parent crosses a link or reparse point",
        )
        try:
            receipt_bytes = (
                json.dumps(receipt, sort_keys=True, separators=(",", ":")) + "\n"
            ).encode("utf-8")
        except (OSError, TypeError, ValueError, UnicodeError) as exc:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt cannot be serialized") from exc
        path.parent.mkdir(exist_ok=True)
        stage_prefix = f".{path.name}."
        try:
            with os.scandir(path.parent) as entries:
                prior_stages = sorted(
                    (Path(entry.path) for entry in entries
                     if entry.name.startswith(stage_prefix) and entry.name.endswith(".tmp")),
                    key=lambda candidate: candidate.name,
                )
            for stage in prior_stages:
                _lifecycle_reject_unreduced_reparse(
                    stage, failure_id="WI-SCRATCH-RELEASE-RECEIPT",
                    message="release receipt staging path is unsafe",
                )
                staged = _capture_file_snapshot(
                    stage, failure_id="WI-SCRATCH-RELEASE-RECEIPT",
                    require_single_link=True,
                ).data
                if staged != receipt_bytes:
                    raise LifecycleError(
                        "WI-SCRATCH-RELEASE-RECEIPT",
                        "unsettled release receipt staging bytes require review",
                    )
                stage.unlink()
        except OSError as exc:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt staging cannot be settled") from exc
        temporary: Path | None = None
        try:
            descriptor, name = tempfile.mkstemp(
                prefix=f".{path.name}.", suffix=".tmp", dir=path.parent,
            )
            temporary = Path(name)
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(receipt_bytes)
                stream.flush()
                os.fsync(stream.fileno())
            os.link(temporary, path)
        except FileExistsError as exc:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt already exists") from exc
        except OSError as exc:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "atomic create-once release receipt is unavailable") from exc
        finally:
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError as exc:
                    raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt staging residue remains") from exc
        if _capture_file_snapshot(
            path, failure_id="WI-SCRATCH-RELEASE-RECEIPT", require_single_link=True,
        ).data != receipt_bytes:
            raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "release receipt readback differs")
        existing = _release_receipt(root, item, terminal_run_id, entry_id, entry)
    elif (
        existing["artifact"] != artifact or existing["artifactSha256"] != artifact_hash
        or existing["rationale"] != rationale
    ):
        raise LifecycleError("WI-SCRATCH-RELEASE-RECEIPT", "replay request differs from release receipt")
    if inject_failure_at == "after-receipt":
        raise LifecycleError("WI-SCRATCH-DISPOSITION-PENDING", "injected after-receipt")
    plans = _scratch_disposition_plan(root, item, archived=True)
    selected = [plan for plan in plans if plan.original == root / Path(entry["path"])]
    if len(selected) != 1 or selected[0].disposition != "release":
        raise LifecycleError("WI-SCRATCH-RELEASE-IDENTITY", "selected receipt did not bind one root")
    try:
        _settle_released_scratch(root, selected[0], inject_failure_at=inject_failure_at)
    except LifecycleError:
        raise
    except (OSError, _scratch_classifier_module().OwnedTreeClassificationError) as exc:
        raise LifecycleError("WI-SCRATCH-DISPOSITION-PENDING", str(exc)) from exc
    return path


def _validate_item_before_close(item: Path) -> None:
    validator = _validator_module()
    ledger = item / "agent-runs.jsonl"
    status_text = (item / "status.md").read_text(encoding="utf-8")
    v1_staged = _parse_fields(status_text).get("template") == "staged"
    if ledger.exists():
        errors = validator.validate_work_item(
            item,
            validate_status_file=not v1_staged,
        )
        if v1_staged:
            _validate_active_status_bytes(status_text.encode("utf-8"))
    else:
        errors = []
        validator.validate_status(item, [], errors)
        if v1_staged:
            errors = []
            _validate_active_status_bytes(status_text.encode("utf-8"))
    if errors:
        raise LifecycleError("WI-LEDGER-UNSETTLED", "; ".join(errors))


def _bug_disposition_fail(failure_id: str, message: str) -> LifecycleError:
    return LifecycleError(failure_id, message)


def _single_line_manifest_text(row: dict, key: str) -> str:
    value = row.get(key)
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value) > BUG_DISPOSITION_TEXT_LIMIT
        or "\n" in value
        or "\r" in value
    ):
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID",
            f"bug disposition {key} must be one non-empty bounded line",
        )
    return value.strip()


def _load_bug_disposition_manifest(
    item: Path,
    slug: str,
    terminal_instant: str,
) -> tuple[Path, bytes, dict]:
    manifest = item / BUG_DISPOSITIONS_MANIFEST
    if manifest.is_symlink() or not manifest.is_file():
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-MISSING",
            f"active work-item requires {BUG_DISPOSITIONS_MANIFEST}: {slug}",
        )
    try:
        data = manifest.read_bytes()
        payload = json.loads(data.decode("utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID",
            f"invalid {BUG_DISPOSITIONS_MANIFEST}: {slug}",
        ) from exc
    schema_version = payload.get("schemaVersion") if isinstance(payload, dict) else None
    expected_keys = {"schemaVersion", "workItem", "closedAt", "bugs"}
    if schema_version == 3:
        expected_keys.add("evidenceRetention")
    if (
        not isinstance(payload, dict)
        or set(payload) != expected_keys
        or schema_version not in BUG_DISPOSITIONS_SCHEMA_VERSIONS
        or payload.get("workItem") != slug
        or payload.get("closedAt") != terminal_instant
        or not isinstance(payload.get("bugs"), list)
        or (schema_version == 3 and (not isinstance(payload.get("evidenceRetention"), list) or not payload["evidenceRetention"]))
    ):
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID",
            f"bug disposition manifest header differs: {slug}",
        )
    return manifest, data, payload


def _prepare_evidence_retention(
    root: Path,
    item: Path,
    manifest: dict,
) -> tuple[EvidenceRetentionPlan, ...]:
    if manifest["schemaVersion"] != 3:
        return ()
    owner_root = root / ".scratch" / "work-items" / item.name
    classifier = _scratch_classifier_module()
    limits = PayloadDigestLimits(
        max_files=classifier.MAX_OWNED_TREE_FILES,
        max_entries=classifier.MAX_OWNED_TREE_ENTRIES,
        max_bytes=classifier.MAX_OWNED_TREE_BYTES,
    )
    try:
        originals, tombstones = _scratch_namespace_entries(owner_root)
    except classifier.OwnedTreeClassificationError as exc:
        raise LifecycleError("WI-SCRATCH-UNSAFE-ENTRY", str(exc)) from exc
    rows = manifest["evidenceRetention"]
    plans: list[EvidenceRetentionPlan] = []
    seen: set[Path] = set()
    for row in rows:
        if (
            not isinstance(row, dict)
            or set(row) != {"path", "disposition", "treeSha256", "canonicalPointer", "canonicalPointerSha256"}
            or row.get("disposition") != "retain"
            or not isinstance(row.get("path"), str)
            or not isinstance(row.get("canonicalPointer"), str)
            or not isinstance(row.get("treeSha256"), str)
            or not isinstance(row.get("canonicalPointerSha256"), str)
            or SHA256_RE.fullmatch(row["treeSha256"]) is None
            or SHA256_RE.fullmatch(row["canonicalPointerSha256"]) is None
        ):
            raise LifecycleError("WI-BUG-DISPOSITIONS-INVALID", "invalid evidenceRetention row")
        relative = Path(row["path"])
        candidate = root / relative
        if (
            relative.is_absolute()
            or any(part in {"", ".", ".."} for part in relative.parts)
            or relative.parts[:3] != (".scratch", "work-items", item.name)
            or len(relative.parts) != 5
            or candidate not in originals
            or candidate in seen
        ):
            raise LifecycleError("WI-BUG-DISPOSITIONS-INVALID", "evidenceRetention path is not one unmatched scratch root")
        pointer_relative = Path(row["canonicalPointer"])
        pointer = item / pointer_relative
        if (
            pointer_relative.is_absolute()
            or any(part in {"", ".", ".."} for part in pointer_relative.parts)
        ):
            raise LifecycleError("WI-BUG-DISPOSITIONS-INVALID", "evidenceRetention canonical pointer is unsafe")
        try:
            _lifecycle_reject_unreduced_reparse(
                pointer,
                failure_id="WI-BUG-DISPOSITIONS-INVALID",
                message="evidenceRetention canonical pointer crosses a link or reparse point",
            )
            resolved_item = item.resolve(strict=True)
            resolved_pointer = pointer.resolve(strict=True)
        except (LifecycleError, OSError) as exc:
            raise LifecycleError(
                "WI-BUG-DISPOSITIONS-INVALID", "evidenceRetention canonical pointer is unsafe"
            ) from exc
        if (
            not resolved_pointer.is_relative_to(resolved_item)
            or not pointer.is_file()
        ):
            raise LifecycleError("WI-BUG-DISPOSITIONS-INVALID", "evidenceRetention canonical pointer is unsafe")
        try:
            pointer_snapshot = _capture_file_snapshot(
                pointer, failure_id="WI-BUG-DISPOSITIONS-INVALID"
            )
            pointer_bytes = pointer_snapshot.data
            pointer_text = pointer_bytes.decode("utf-8", errors="strict")
        except (LifecycleError, UnicodeDecodeError) as exc:
            raise LifecycleError(
                "WI-BUG-DISPOSITIONS-INVALID", "evidenceRetention canonical pointer is unsafe"
            ) from exc
        if (
            hashlib.sha256(pointer_bytes).hexdigest() != row["canonicalPointerSha256"]
            or not _pointer_names_retained_root(
                pointer_text, candidate.name, relative.as_posix()
            )
        ):
            raise LifecycleError("WI-BUG-DISPOSITIONS-DRIFT", "evidenceRetention canonical pointer differs")
        try:
            inspection = classifier.inspect_root_no_follow(candidate)
        except classifier.OwnedTreeClassificationError as exc:
            raise LifecycleError("WI-SCRATCH-UNSAFE-ENTRY", str(exc)) from exc
        if (
            inspection.is_link_or_reparse
            or not (inspection.is_directory or inspection.is_regular_file)
        ):
            raise LifecycleError(
                "WI-BUG-DISPOSITIONS-INVALID",
                "evidenceRetention root is not an ordinary file or directory",
            )
        try:
            digest = _payload_digest(candidate, limits=limits)[1]
        except LifecycleError as exc:
            raise LifecycleError(
                "WI-SCRATCH-UNSAFE-ENTRY", "retained scratch evidence is unreadable"
            ) from exc
        if digest != row["treeSha256"]:
            raise LifecycleError("WI-BUG-DISPOSITIONS-DRIFT", "evidenceRetention tree hash differs")
        seen.add(candidate)
        plans.append(
            EvidenceRetentionPlan(
                candidate,
                digest,
                pointer,
                row["canonicalPointerSha256"],
                limits,
            )
        )
    return tuple(plans)


def _context_bug_files(root: Path, slug: str) -> dict[str, Path]:
    bug_root = _work_items_root(root) / CATEGORIES["bug"].current_root
    result: dict[str, Path] = {}
    if not bug_root.is_dir():
        return result
    for path in sorted(bug_root.glob("*.md")):
        if path.is_symlink() or not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-INVALID",
                f"current bug record is not readable UTF-8: {path.name}",
            ) from exc
        fields = _parse_fields(text)
        if fields.get("context") != slug:
            continue
        _validate_slug(path.stem)
        if path.stem in result:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-INCOMPLETE",
                f"duplicate context-linked bug identity: {path.stem}",
            )
        result[path.stem] = path
    return result


def _terminal_bug_bytes(
    before: bytes,
    *,
    current_status: str,
    terminal_status: str,
    terminal_instant: str,
    resolution: str,
    evidence: str,
    successor: str | None = None,
    context_before: str | None = None,
    context_after: str | None = None,
) -> bytes:
    try:
        text = before.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID", "bug record is not UTF-8"
        ) from exc
    fields = _parse_fields(text)
    if fields.get("status") != current_status:
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-DRIFT", "bug status changed after preflight"
        )
    if (context_before is None) != (context_after is None):
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID",
            "bug context transition must provide both before and after values",
        )
    if context_before is not None and fields.get("context") != context_before:
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-DRIFT", "bug context changed after preflight"
        )
    if any(
        fields.get(key)
        for key in ("terminal-at", "resolution", "evidence", "successor")
    ):
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID",
            "current bug already carries terminal evidence",
        )
    replaced, count = re.subn(
        r"(?im)^(\s*(?:-\s*)?status\s*:\s*)[^\r\n]+(?=\r?$)",
        rf"\g<1>{terminal_status}",
        text,
        count=1,
    )
    if count != 1:
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID", "bug requires one status field"
        )
    if context_before is not None:
        replaced, context_count = re.subn(
            r"(?im)^(\s*(?:-\s*)?context\s*:\s*)[^\r\n]+(?=\r?$)",
            rf"\g<1>{context_after}",
            replaced,
            count=1,
        )
        if context_count != 1:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-INVALID", "bug requires one context field"
            )
    newline = "\r\n" if "\r\n" in text and text.count("\n") == text.count("\r\n") else "\n"
    separator = "" if replaced.endswith("\n") else newline
    return (
        replaced
        + separator
        + newline
        + f"Terminal-at: {terminal_instant}{newline}"
        + f"Resolution: {resolution}{newline}"
        + f"Evidence: {evidence}{newline}"
        + (f"Successor: {successor}{newline}" if successor is not None else "")
    ).encode("utf-8")


def _prepare_bug_dispositions(
    root: Path,
    item: Path,
    slug: str,
    terminal_instant: str,
    *,
    allow_placeholder_context: bool = False,
) -> tuple[Path, bytes, tuple[BugDispositionPlan, ...]]:
    manifest, manifest_data, payload = _load_bug_disposition_manifest(
        item, slug, terminal_instant
    )
    schema_version = payload["schemaVersion"]
    if schema_version == 2 and not allow_placeholder_context:
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID",
            "bug disposition schema version 2 is admitted only by close_item",
        )
    linked = _context_bug_files(root, slug)
    rows = payload["bugs"]
    ids = [row.get("id") for row in rows if isinstance(row, dict)]
    if (
        len(ids) != len(rows)
        or any(not isinstance(value, str) or not is_valid_slug(value) for value in ids)
        or len(set(ids)) != len(ids)
    ):
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INVALID",
            "bug disposition ids must be unique canonical slugs",
        )
    selected = dict(linked)
    if schema_version == 2:
        bug_root = _work_items_root(root) / CATEGORIES["bug"].current_root
        for bug_id in set(ids) - set(linked):
            source = bug_root / f"{bug_id}.md"
            if source.is_symlink() or not source.is_file():
                continue
            try:
                fields = _parse_fields(source.read_text(encoding="utf-8"))
            except (OSError, UnicodeError) as exc:
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-INVALID",
                    f"selected placeholder bug is not readable UTF-8: {bug_id}",
                ) from exc
            if fields.get("context") in BUG_DISPOSITION_PLACEHOLDER_CONTEXTS:
                selected[bug_id] = source
    if set(ids) != set(selected):
        missing = sorted(set(linked) - set(ids))
        extra = sorted(set(ids) - set(selected))
        raise _bug_disposition_fail(
            "WI-BUG-DISPOSITIONS-INCOMPLETE",
            f"bug disposition set differs (missing={missing}, extra={extra})",
        )
    plans: list[BugDispositionPlan] = []
    bug_category = CATEGORIES["bug"]
    for row in rows:
        assert isinstance(row, dict)
        bug_id = row["id"]
        action = row.get("action")
        if action not in BUG_DISPOSITION_ACTIONS:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-INVALID", f"invalid bug action: {action!r}"
            )
        expected_fields = (
            {"id", "action", "inputSha256", "status", "resolution", "evidence"}
            if action == "terminalize"
            else {"id", "action", "inputSha256", "status", "reason", "evidence"}
        )
        if schema_version == 2:
            expected_fields |= {"contextBefore", "contextAfter"}
        if set(row) != expected_fields:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-INVALID",
                f"bug disposition fields differ: {bug_id}",
            )
        source = selected[bug_id]
        before = source.read_bytes()
        digest = row.get("inputSha256")
        if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-INVALID", f"invalid inputSha256: {bug_id}"
            )
        if hashlib.sha256(before).hexdigest() != digest:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-DRIFT", f"bug bytes changed: {bug_id}"
            )
        try:
            fields = _parse_fields(before.decode("utf-8"))
        except UnicodeDecodeError as exc:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-INVALID",
                f"current bug record is not UTF-8: {bug_id}",
            ) from exc
        current_status = fields.get("status", "")
        if current_status not in bug_category.current_statuses:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-DRIFT",
                f"bug is not current: {bug_id} ({current_status!r})",
            )
        context_before: str | None = None
        context_after: str | None = None
        if schema_version == 2:
            text = before.decode("utf-8")
            occurrences = _authoritative_field_occurrences(text)
            statuses = [
                value for _line, name, value, _raw in occurrences if name == "status"
            ]
            contexts = [
                value for _line, name, value, _raw in occurrences if name == "context"
            ]
            if statuses != [current_status] or len(contexts) != 1:
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-INVALID",
                    f"bug requires exactly one current status and context: {bug_id}",
                )
            current_context = contexts[0]
            context_before = row.get("contextBefore")
            context_after = row.get("contextAfter")
            if (
                not isinstance(context_before, str)
                or context_before != current_context
            ):
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-DRIFT",
                    f"bug context before-image differs: {bug_id}",
                )
            if context_after != slug:
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-INVALID",
                    f"bug context after-image must equal the closing work item: {bug_id}",
                )
            if (
                current_context in BUG_DISPOSITION_PLACEHOLDER_CONTEXTS
                and action != "terminalize"
            ):
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-INVALID",
                    f"placeholder-context bug must be terminalized: {bug_id}",
                )
            if any(
                fields.get(key)
                for key in ("terminal-at", "resolution", "evidence", "successor")
            ):
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-INVALID",
                    f"current bug already carries terminal evidence: {bug_id}",
                )
        desired_status = row.get("status")
        _single_line_manifest_text(row, "evidence")
        if action == "preserve-current":
            if desired_status != current_status:
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-INVALID",
                    f"preserve-current status differs: {bug_id}",
                )
            _single_line_manifest_text(row, "reason")
            target = None
            after = before
        else:
            if desired_status not in bug_category.terminal_statuses:
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-INVALID",
                    f"terminal bug status is invalid: {bug_id}",
                )
            resolution = _single_line_manifest_text(row, "resolution")
            evidence = _single_line_manifest_text(row, "evidence")
            after = _terminal_bug_bytes(
                before,
                current_status=current_status,
                terminal_status=desired_status,
                terminal_instant=terminal_instant,
                resolution=resolution,
                evidence=evidence,
                context_before=context_before,
                context_after=context_after,
            )
            _validate_flat_terminal(bug_category, after)
            target = (
                _work_items_root(root)
                / bug_category.current_root
                / "archive"
                / archive_month(terminal_instant)
                / source.name
            )
            if target.exists():
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-DRIFT",
                    f"bug archive target already exists: {bug_id}",
                )
        plans.append(
            BugDispositionPlan(
                bug_id=bug_id,
                action=action,
                source=source,
                target=target,
                before=before,
                after=after,
                status_before=current_status,
                status_after=desired_status,
                context_before=context_before,
                context_after=context_after,
            )
        )
    return manifest, manifest_data, tuple(sorted(plans, key=lambda plan: plan.bug_id))


def _bug_disposition_receipt_bytes(
    root: Path,
    slug: str,
    terminal_instant: str,
    manifest_data: bytes,
    closure_data: bytes,
    plans: tuple[BugDispositionPlan, ...],
    readme_sha256: str,
    evidence_retention: tuple[EvidenceRetentionPlan, ...] = (),
) -> bytes:
    manifest = json.loads(manifest_data.decode("utf-8"))
    schema_version = manifest["schemaVersion"]
    payload = {
        "schemaVersion": schema_version,
        "owner": BUG_DISPOSITIONS_OWNER,
        "workItem": slug,
        "closedAt": terminal_instant,
        "manifestSha256": hashlib.sha256(manifest_data).hexdigest(),
        "closureSha256": hashlib.sha256(closure_data).hexdigest(),
        "readmeSha256": readme_sha256,
        "bugs": [
            {
                "id": plan.bug_id,
                "action": plan.action,
                "statusBefore": plan.status_before,
                "statusAfter": plan.status_after,
                "beforeSha256": hashlib.sha256(plan.before).hexdigest(),
                "afterSha256": hashlib.sha256(plan.after).hexdigest(),
                "source": plan.source.relative_to(_work_items_root(root)).as_posix(),
                "target": (
                    plan.target.relative_to(_work_items_root(root)).as_posix()
                    if plan.target is not None
                    else None
                ),
                **(
                    {
                        "contextBefore": plan.context_before,
                        "contextAfter": plan.context_after,
                    }
                    if schema_version == 2
                    else {}
                ),
            }
            for plan in plans
        ],
        **(
            {
                "evidenceRetention": [
                    {
                        "path": plan.path.relative_to(root).as_posix(),
                        "disposition": "retain",
                        "treeSha256": plan.tree_sha256,
                        "canonicalPointer": plan.canonical_pointer.relative_to(
                            _work_items_root(root) / "active" / slug
                        ).as_posix(),
                        "canonicalPointerSha256": plan.canonical_pointer_sha256,
                    }
                    for plan in evidence_retention
                ]
            }
            if schema_version == 3
            else {}
        ),
    }
    return (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _verify_archived_bug_dispositions(
    root: Path,
    archived: Path,
    closure_data: bytes,
    terminal_instant: str,
) -> None:
    slug = archived.name
    try:
        _manifest, manifest_data, manifest = _load_bug_disposition_manifest(
            archived, slug, terminal_instant
        )
    except LifecycleError as exc:
        raise _bug_disposition_fail(
            "WI-IMMUTABLE-ARCHIVE",
            f"archived bug disposition manifest differs: {slug}",
        ) from exc
    schema_version = manifest["schemaVersion"]
    receipt_path = archived / BUG_DISPOSITIONS_RECEIPT
    if receipt_path.is_symlink() or not receipt_path.is_file():
        raise _bug_disposition_fail(
            "WI-IMMUTABLE-ARCHIVE",
            f"archived work-item lacks {BUG_DISPOSITIONS_RECEIPT}: {slug}",
        )
    try:
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise _bug_disposition_fail(
            "WI-IMMUTABLE-ARCHIVE", f"invalid bug disposition receipt: {slug}"
        ) from exc
    expected_keys = {
        "schemaVersion",
        "owner",
        "workItem",
        "closedAt",
        "manifestSha256",
        "closureSha256",
        "readmeSha256",
        "bugs",
    }
    if schema_version == 3:
        expected_keys.add("evidenceRetention")
    if (
        not isinstance(receipt, dict)
        or set(receipt) != expected_keys
        or receipt.get("schemaVersion") != schema_version
        or receipt.get("owner") != BUG_DISPOSITIONS_OWNER
        or receipt.get("workItem") != slug
        or receipt.get("closedAt") != terminal_instant
        or receipt.get("manifestSha256") != hashlib.sha256(manifest_data).hexdigest()
        or receipt.get("closureSha256") != hashlib.sha256(closure_data).hexdigest()
        or not isinstance(receipt.get("readmeSha256"), str)
        or not SHA256_RE.fullmatch(receipt["readmeSha256"])
        or not isinstance(receipt.get("bugs"), list)
        or (schema_version == 3 and not isinstance(receipt.get("evidenceRetention"), list))
    ):
        raise _bug_disposition_fail(
            "WI-IMMUTABLE-ARCHIVE", f"bug disposition receipt binding differs: {slug}"
        )
    rows = manifest["bugs"]
    if len(receipt["bugs"]) != len(rows):
        raise _bug_disposition_fail(
            "WI-IMMUTABLE-ARCHIVE", f"bug disposition receipt count differs: {slug}"
        )
    by_id = {
        row.get("id"): row for row in receipt["bugs"] if isinstance(row, dict)
    }
    if set(by_id) != {row.get("id") for row in rows if isinstance(row, dict)}:
        raise _bug_disposition_fail(
            "WI-IMMUTABLE-ARCHIVE", f"bug disposition receipt ids differ: {slug}"
        )
    if schema_version == 3:
        manifest_retention = manifest["evidenceRetention"]
        receipt_retention = receipt["evidenceRetention"]
        if (
            len(receipt_retention) != len(manifest_retention)
            or any(not isinstance(row, dict) for row in receipt_retention)
            or receipt_retention != manifest_retention
        ):
            raise _bug_disposition_fail(
                "WI-IMMUTABLE-ARCHIVE", f"retained scratch receipt differs: {slug}"
            )
    work_items = _work_items_root(root)
    for decision in rows:
        if not isinstance(decision, dict):
            raise _bug_disposition_fail(
                "WI-IMMUTABLE-ARCHIVE", f"invalid archived decision row: {slug}"
            )
        action = decision.get("action")
        required_decision_keys = (
            {"id", "action", "inputSha256", "status", "resolution", "evidence"}
            if action == "terminalize"
            else {"id", "action", "inputSha256", "status", "reason", "evidence"}
        )
        if schema_version == 2:
            required_decision_keys |= {"contextBefore", "contextAfter"}
        if action not in BUG_DISPOSITION_ACTIONS or set(decision) != required_decision_keys:
            raise _bug_disposition_fail(
                "WI-IMMUTABLE-ARCHIVE",
                f"archived bug disposition decision differs: {decision.get('id')}",
            )
        result = by_id[decision["id"]]
        required_result_keys = {
            "id",
            "action",
            "statusBefore",
            "statusAfter",
            "beforeSha256",
            "afterSha256",
            "source",
            "target",
        }
        if schema_version == 2:
            required_result_keys |= {"contextBefore", "contextAfter"}
        if (
            set(result) != required_result_keys
            or result.get("id") != decision["id"]
            or result.get("action") != decision["action"]
            or result.get("beforeSha256") != decision["inputSha256"]
            or result.get("statusAfter") != decision["status"]
            or result.get("statusBefore") not in CATEGORIES["bug"].current_statuses
            or result.get("source") != f"bugs/{decision['id']}.md"
            or not isinstance(result.get("afterSha256"), str)
            or not SHA256_RE.fullmatch(result["afterSha256"])
            or (
                schema_version == 2
                and (
                    result.get("contextBefore") != decision.get("contextBefore")
                    or result.get("contextAfter") != decision.get("contextAfter")
                    or decision.get("contextAfter") != slug
                    or decision.get("contextBefore")
                    not in ({slug} | BUG_DISPOSITION_PLACEHOLDER_CONTEXTS)
                )
            )
        ):
            raise _bug_disposition_fail(
                "WI-IMMUTABLE-ARCHIVE",
                f"archived bug disposition row differs: {decision['id']}",
            )
        if decision["action"] == "terminalize":
            target_relative = result.get("target")
            expected_target = (
                f"bugs/archive/{archive_month(terminal_instant)}/{decision['id']}.md"
            )
            if target_relative != expected_target:
                raise _bug_disposition_fail(
                    "WI-IMMUTABLE-ARCHIVE",
                    f"terminal bug target differs: {decision['id']}",
                )
            assert isinstance(target_relative, str)
            target = _terminalization_bound_path(
                work_items, target_relative, label="archived bug disposition target"
            )
            current = work_items / CATEGORIES["bug"].current_root / f"{decision['id']}.md"
            if (
                not target.is_file()
                or current.exists()
                or hashlib.sha256(target.read_bytes()).hexdigest()
                != result["afterSha256"]
            ):
                raise _bug_disposition_fail(
                    "WI-IMMUTABLE-ARCHIVE",
                    f"terminal bug archive differs: {decision['id']}",
                )
            _validate_flat_terminal(CATEGORIES["bug"], target.read_bytes())
            if (
                schema_version == 2
                and _parse_fields(target.read_text(encoding="utf-8")).get("context")
                != decision.get("contextAfter")
            ):
                raise _bug_disposition_fail(
                    "WI-IMMUTABLE-ARCHIVE",
                    f"terminal bug context differs: {decision['id']}",
                )
        elif (
            result.get("target") is not None
            or result.get("statusBefore") != decision["status"]
            or result.get("afterSha256") != decision["inputSha256"]
            or (
                schema_version == 2
                and (
                    decision.get("contextBefore") != slug
                    or decision.get("contextAfter") != slug
                )
            )
        ):
            raise _bug_disposition_fail(
                "WI-IMMUTABLE-ARCHIVE",
                f"preserved bug receipt differs: {decision['id']}",
            )


def _mkdir_parents_tracked(path: Path, created: list[Path]) -> None:
    missing: list[Path] = []
    cursor = path
    while not cursor.exists():
        missing.append(cursor)
        cursor = cursor.parent
    for directory in reversed(missing):
        directory.mkdir()
        created.append(directory)


def close_item(
    root: Path,
    slug: str,
    closure_data: bytes,
    terminal_instant: str,
    *,
    inject_readme_failure: bool = False,
    inject_bug_failure_after: int | None = None,
) -> Path:
    _validate_slug(slug)
    month = archive_month(terminal_instant)
    _validate_closure(closure_data, terminal_instant)
    archived_closure_data = _stamp_schema_marker(closure_data, "closure.md")
    root = Path(os.path.abspath(root))
    work_items = _work_items_root(root)
    locations = _category_locations(root, CATEGORIES["work-item"], slug)
    if len(locations) > 1:
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", f"duplicate slug: {slug}")
    if len(locations) == 1 and "archive" in locations[0].parts:
        archived = locations[0]
        _archived_work_item_entry(archived)
        existing = archived / "closure.md"
        if (
            not existing.is_file()
            or existing.read_bytes() != archived_closure_data
            or archived.parent.name != month
        ):
            raise LifecycleError("WI-IMMUTABLE-ARCHIVE", f"archived identity differs: {slug}")
        manifest_present = (archived / BUG_DISPOSITIONS_MANIFEST).exists()
        receipt_present = (archived / BUG_DISPOSITIONS_RECEIPT).exists()
        if manifest_present or receipt_present:
            _verify_archived_bug_dispositions(
                root, archived, archived_closure_data, terminal_instant
            )
        archived_retention_paths = frozenset()
        if manifest_present:
            _manifest_path, _manifest_data, archived_manifest = _load_bug_disposition_manifest(
                archived, slug, terminal_instant
            )
            if archived_manifest["schemaVersion"] == 3:
                archived_retention_paths = frozenset(
                    root / Path(row["path"])
                    for row in archived_manifest["evidenceRetention"]
                    if isinstance(row, dict) and isinstance(row.get("path"), str)
                )
        scratch_plan = _scratch_disposition_plan(
            root, archived, archived=True, retention_paths=archived_retention_paths
        )
        if inject_readme_failure:
            raise LifecycleError("WI-README-STALE", "injected failure after canonical success")
        refresh_readme(root)
        _settle_scratch_dispositions(root, scratch_plan)
        return archived
    active = work_items / "active" / slug
    if locations != [active]:
        raise LifecycleError("WI-INVALID-TARGET", f"close requires one active item: {slug}")
    _validate_item_before_close(active)
    _manifest_path, _manifest_preview, manifest_preview = _load_bug_disposition_manifest(
        active, slug, terminal_instant
    )
    evidence_retention = _prepare_evidence_retention(root, active, manifest_preview)
    scratch_plan = _scratch_disposition_plan(
        root,
        active,
        archived=False,
        retention_paths=frozenset(plan.path for plan in evidence_retention),
    )
    _manifest, manifest_data, bug_plans = _prepare_bug_dispositions(
        root,
        active,
        slug,
        terminal_instant,
        allow_placeholder_context=True,
    )
    _preflight_readme(root)
    closure_path = active / "closure.md"
    prior_closure = closure_path.read_bytes() if closure_path.exists() else None
    status_path = active / "status.md"
    prior_status = status_path.read_bytes()
    target = work_items / "archive" / month / slug
    readme = work_items / "README.md"
    readme_existed = readme.is_file()
    readme_before = readme.read_bytes() if readme_existed else b""
    created_dirs: list[Path] = []
    touched_bugs: list[BugDispositionPlan] = []
    item_moved = False
    receipt_path = target / BUG_DISPOSITIONS_RECEIPT
    try:
        for index, plan in enumerate(bug_plans, start=1):
            if plan.action != "terminalize":
                continue
            if plan.source.read_bytes() != plan.before or plan.target is None:
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-DRIFT",
                    f"bug changed after preflight: {plan.bug_id}",
                )
            touched_bugs.append(plan)
            _atomic_write(plan.source, plan.after)
            _mkdir_parents_tracked(plan.target.parent, created_dirs)
            os.replace(plan.source, plan.target)
            if inject_bug_failure_after == index:
                raise _bug_disposition_fail(
                    "WI-BUG-DISPOSITIONS-DRIFT",
                    f"injected bug disposition failure after row {index}",
                )
        _atomic_write(closure_path, archived_closure_data)
        _atomic_write(status_path, _terminalize_status(prior_status))
        _mkdir_parents_tracked(target.parent, created_dirs)
        os.replace(active, target)
        item_moved = True
        if inject_readme_failure:
            raise LifecycleError("WI-README-STALE", "injected failure after canonical success")
        readme_sha256 = refresh_readme(root)
        for retention in evidence_retention:
            try:
                observed_retention_digest = _payload_digest(
                    retention.path, limits=retention.limits
                )[1]
            except LifecycleError as exc:
                raise LifecycleError(
                    "WI-SCRATCH-UNSAFE-ENTRY",
                    "retained scratch evidence is unreadable after preflight",
                ) from exc
            if observed_retention_digest != retention.tree_sha256:
                raise LifecycleError("WI-BUG-DISPOSITIONS-DRIFT", "retained scratch evidence changed after preflight")
        receipt_data = _bug_disposition_receipt_bytes(
            root,
            slug,
            terminal_instant,
            manifest_data,
            archived_closure_data,
            bug_plans,
            readme_sha256,
            evidence_retention,
        )
        _atomic_write(receipt_path, receipt_data)
        _verify_archived_bug_dispositions(
            root, target, archived_closure_data, terminal_instant
        )
    except BaseException as exc:
        rollback_failures: list[str] = []

        def attempt(label: str, action) -> None:
            try:
                action()
            except BaseException as rollback_exc:
                rollback_failures.append(f"{label}: {rollback_exc}")

        if receipt_path.exists():
            attempt("remove receipt", receipt_path.unlink)
        if item_moved and target.exists() and not active.exists():
            attempt("restore active item", lambda: os.replace(target, active))
        if active.is_dir():
            restored_closure = active / "closure.md"
            restored_status = active / "status.md"
            if prior_closure is None:
                if restored_closure.exists():
                    attempt("remove closure", restored_closure.unlink)
            else:
                attempt(
                    "restore closure",
                    lambda: _atomic_write(restored_closure, prior_closure),
                )
            attempt("restore status", lambda: _atomic_write(restored_status, prior_status))
        else:
            rollback_failures.append("restore active item: active directory is unavailable")
        for plan in reversed(touched_bugs):
            assert plan.target is not None
            if plan.target.exists() and not plan.source.exists():
                attempt(
                    f"restore bug location {plan.bug_id}",
                    lambda plan=plan: os.replace(plan.target, plan.source),
                )
            if plan.source.exists():
                attempt(
                    f"restore bug bytes {plan.bug_id}",
                    lambda plan=plan: _atomic_write(plan.source, plan.before),
                )
            else:
                rollback_failures.append(
                    f"restore bug bytes {plan.bug_id}: current source is unavailable"
                )
        if readme_existed:
            attempt("restore README", lambda: _atomic_write(readme, readme_before))
        elif readme.exists():
            attempt("remove generated README", readme.unlink)
        for directory in reversed(created_dirs):
            try:
                directory.rmdir()
            except OSError:
                pass
        if rollback_failures:
            raise _bug_disposition_fail(
                "WI-BUG-DISPOSITIONS-ROLLBACK",
                "bug disposition rollback failed: " + "; ".join(rollback_failures),
            ) from exc
        raise
    _settle_scratch_dispositions(root, scratch_plan)
    return target


def reopen_item(
    root: Path,
    archived_slug: str,
    successor_slug: str,
    status_data: bytes,
    *,
    inject_readme_failure: bool = False,
) -> Path:
    archived = resolve_category(root, f"work-item:{archived_slug}")
    if "archive" not in archived.parts:
        raise LifecycleError("WI-INVALID-TARGET", "reopen source must be archived")
    _validate_slug(successor_slug)
    _validate_active_status_bytes(status_data)
    fields = _parse_fields(status_data.decode("utf-8"))
    if fields.get("reopens") != archived_slug:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID",
            f"successor must declare Reopens: {archived_slug}",
        )
    if _category_locations(root, CATEGORIES["work-item"], successor_slug):
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", "successor slug already exists")
    _preflight_readme(root)
    active_parent = _work_items_root(root) / "active"
    active_parent.mkdir(parents=True, exist_ok=True)
    target = active_parent / successor_slug
    temp = Path(tempfile.mkdtemp(prefix=f".{successor_slug}.", dir=active_parent))
    committed = False
    try:
        _atomic_write(temp / "status.md", status_data)
        os.replace(temp, target)
        committed = True
    finally:
        if not committed:
            shutil.rmtree(temp, ignore_errors=True)
    if inject_readme_failure:
        raise _postcommit_readme_stale("reopen")
    try:
        refresh_readme(root)
    except LifecycleError as exc:
        raise _postcommit_readme_stale("reopen") from exc
    return target


def audit_categories(root: Path) -> tuple[str, ...]:
    topology = _resolve_project_topology(root).with_read_model_roots()
    work_items = topology.work_items
    if not topology.root_contract_present:
        topology.assert_known_top_level_roots()
    decision_v0_records = _preflight_current_decision_v0(root)
    decision_h1_records = _preflight_current_decision_h1(root)
    legacy_read_compatible: list[str] = []
    for category in CATEGORIES.values():
        slugs: set[str] = set()
        if category.current_kind == "work-item":
            slugs.update(path.stem for path in (work_items / "backlog").glob("*.md"))
            slugs.update(path.name for path in (work_items / "active").glob("*") if path.is_dir())
            archive = work_items / "archive"
        else:
            current = work_items / category.current_root
            slugs.update(path.stem for path in current.glob("*.md"))
            archive = current / "archive"
        if archive.is_dir():
            for month in archive.iterdir():
                if not month.is_dir():
                    continue
                if category.current_kind == "work-item":
                    slugs.update(path.name for path in month.iterdir() if path.is_dir())
                else:
                    slugs.update(path.stem for path in month.glob("*.md"))
        for slug in sorted(slugs):
            locations = _category_locations(root, category, slug)
            if len(locations) > 1:
                raise LifecycleError(
                    "WI-CATEGORY-DUAL-LOCATION",
                    f"{category.name}:{slug} has {len(locations)} locations",
                )
            if not is_valid_slug(slug):
                if len(locations) != 1 or "archive" not in locations[0].parts:
                    _validate_slug(slug)
                legacy = locations[0]
                if category.name == "work-item":
                    entry = _archived_work_item_entry(legacy)
                    if entry.classification == LEGACY_READ_CLASSIFICATION:
                        fields = _parse_fields((legacy / "closure.md").read_text(encoding="utf-8"))
                        closed = fields.get("closed", "")
                        if not closed or not fields.get("outcome"):
                            raise LifecycleError(
                                "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
                                f"legacy archive lacks terminal evidence: {legacy}",
                            )
                        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", closed) or closed[:7] != legacy.parent.name:
                            raise LifecycleError(
                                "WI-CATEGORY-ARCHIVE-MONTH-MISMATCH",
                                f"{category.name}:{slug} does not match archive month",
                            )
                else:
                    instant = _validate_flat_terminal(category, legacy.read_bytes())
                    if legacy.parent.name != archive_month(instant):
                        raise LifecycleError(
                            "WI-CATEGORY-ARCHIVE-MONTH-MISMATCH",
                            f"{category.name}:{slug} belongs in archive/{archive_month(instant)}",
                        )
                legacy_read_compatible.append(
                    legacy.relative_to(work_items).as_posix()
                )
                continue
            if category.current_kind == "flat" and locations:
                path = locations[0]
                archived = "archive" in path.parts
                decision_v0 = (
                    decision_v0_records.get(path.name)
                    if category.name == "decision" and not archived
                    else None
                )
                decision_h1 = (
                    decision_h1_records.get(path.name)
                    if category.name == "decision" and not archived
                    else None
                )
                if decision_v0 is not None:
                    status = decision_v0.raw_status
                elif decision_h1 is not None:
                    status = decision_h1.admitted_current_status or ""
                else:
                    fields = _parse_fields(path.read_text(encoding="utf-8"))
                    status = fields.get("status", "")
                if archived and status in category.current_statuses:
                    raise LifecycleError(
                        "WI-CATEGORY-CURRENT-IN-ARCHIVE",
                        f"{category.name}:{slug} has current status in archive",
                    )
                if not archived and status in category.terminal_statuses:
                    raise LifecycleError(
                        "WI-CATEGORY-TERMINAL-IN-CURRENT",
                        f"{category.name}:{slug} has terminal status in current root",
                    )
                if (
                    category.name == "decision"
                    and not archived
                    and status in category.current_statuses
                ):
                    decision = decision_v0 or decision_h1 or _validate_current_decision_record(path, slug)
                    if decision.format in {DECISION_FORMAT_V0, DECISION_FORMAT_H1}:
                        legacy_read_compatible.append(
                            path.relative_to(work_items).as_posix()
                        )

    active = work_items / "active"
    if active.is_dir():
        for item in sorted(path for path in active.iterdir() if path.is_dir()):
            if (item / BUG_DISPOSITIONS_MANIFEST).exists():
                raise LifecycleError(
                    "WI-BUG-DISPOSITIONS-PENDING",
                    f"work-item:{item.name} has an unapplied bug disposition manifest",
                )
            fields = _parse_fields((item / "status.md").read_text(encoding="utf-8"))
            if fields.get("status") in CATEGORIES["work-item"].terminal_statuses:
                raise LifecycleError(
                    "WI-CATEGORY-TERMINAL-IN-CURRENT",
                    f"work-item:{item.name} has terminal status in active/",
                )
    archive_root = work_items / "archive"
    if archive_root.is_dir():
        for month in sorted(path for path in archive_root.iterdir() if path.is_dir()):
            for item in sorted(path for path in month.iterdir() if path.is_dir()):
                manifest = item / BUG_DISPOSITIONS_MANIFEST
                receipt = item / BUG_DISPOSITIONS_RECEIPT
                if not manifest.exists() and not receipt.exists():
                    continue
                closure = item / "closure.md"
                if not closure.is_file():
                    raise LifecycleError(
                        "WI-IMMUTABLE-ARCHIVE",
                        f"archived disposition owner lacks closure: {item.name}",
                    )
                closure_data = closure.read_bytes()
                fields = _parse_fields(closure_data.decode("utf-8"))
                _verify_archived_bug_dispositions(
                    root, item, closure_data, fields.get("closed", "")
                )
    return tuple(sorted(legacy_read_compatible))


def _validate_obligation_transfer_ownership(root: Path) -> None:
    transfer_errors = _validator_module().validate_obligation_transfer_ownership(
        Path(root).resolve()
    )
    if transfer_errors:
        failure_id = transfer_errors[0].split(":", 1)[0]
        if failure_id not in {
            "WI-OBLIGATION-TRANSFER-COVERAGE",
            "WI-OBLIGATION-TRANSFER-OWNER",
            "WI-OBLIGATION-TRANSFER-DRIFT",
        }:
            failure_id = "WI-OBLIGATION-TRANSFER-OWNER"
        raise LifecycleError(failure_id, "; ".join(transfer_errors))


def _transition_intent_operation_id(root: Path, intent_path: Path) -> str:
    intent = _load_transition_intent(root, intent_path)
    operation_id = intent.get("operationId")
    if not isinstance(operation_id, str):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "transition intent operation id is absent",
        )
    expected_path = _transition_intent_path(root, operation_id)
    if expected_path.absolute() != intent_path.absolute():
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "transition intent path differs from its operation id",
        )
    return operation_id


def audit(root: Path) -> tuple[str, ...]:
    pending_operations: list[str] = []
    for intent_path in _iter_transition_intents(root):
        pending_operations.append(
            _transition_intent_operation_id(root, intent_path)
        )
    if pending_operations:
        commands = "; ".join(
            "recover-transition --root <repo> "
            f"--operation-id {operation_id} --apply"
            for operation_id in pending_operations
        )
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-RECOVERY-REQUIRED",
            "pending lifecycle transition(s): "
            f"{', '.join(pending_operations)}; run: {commands}",
        )
    legacy_read_compatible = audit_categories(root)
    _validate_obligation_transfer_ownership(root)
    check_readme(root)
    return legacy_read_compatible


def _active_migration_item(root: Path, slug: str) -> Path:
    _validate_slug(slug)
    item = _work_items_root(root) / "active" / slug
    if not item.is_dir() or _lifecycle_path_has_reparse(item):
        raise LifecycleError("WI-INVALID-TARGET", f"active work item is missing or unsafe: {slug}")
    return item


def _repository_root_for_item(item: Path) -> Path:
    for parent in (item, *item.parents):
        if parent.name == "work-items":
            return parent.parent
    raise LifecycleError("WI-INVALID-TARGET", "path is not owned by a work-items root")


def _require_lifecycle_mutation_path(root: Path, path: Path, *, failure_id: str) -> Path:
    path = _lifecycle_unresolved_absolute(path)
    _lifecycle_reject_unreduced_reparse(
        path, failure_id=failure_id, message="lifecycle mutation path contains a link or reparse point"
    )
    repository = _lifecycle_unresolved_absolute(Path(root))
    _lifecycle_reject_unreduced_reparse(
        repository, failure_id=failure_id, message="repository root contains a link or reparse point"
    )
    repository = repository.resolve()
    candidate = path.resolve(strict=False)
    try:
        candidate.relative_to(repository)
    except ValueError as exc:
        raise LifecycleError(failure_id, "lifecycle mutation path escapes repository") from exc
    return path


def _migration_receipt_bytes(facts: dict) -> bytes:
    return (json.dumps(facts, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _reconcile_migration_receipt(item: Path, facts: dict) -> None:
    root = _repository_root_for_item(item)
    receipt = item / "ledger-migration-receipts" / f"{facts['operationId']}.json"
    receipt = _require_lifecycle_mutation_path(
        root, receipt, failure_id="WI-LEDGER-MIGRATION-RECEIPT-MISMATCH"
    )
    wanted = _migration_receipt_bytes(facts)
    if receipt.exists():
        current = receipt.read_bytes()
        if current == wanted:
            return
        quarantine = receipt.with_name(f"{receipt.name}.conflict-{_sha256_bytes(current)[:16]}")
        quarantine = _require_lifecycle_mutation_path(
            root, quarantine, failure_id="WI-LEDGER-MIGRATION-RECEIPT-MISMATCH"
        )
        if quarantine.exists() and quarantine.read_bytes() != current:
            raise LifecycleError("WI-LEDGER-MIGRATION-RECEIPT-MISMATCH", "receipt quarantine conflicts")
        if not quarantine.exists():
            os.replace(receipt, quarantine)
    _atomic_write(receipt, wanted)
    if receipt.read_bytes() != wanted:
        raise LifecycleError("WI-LEDGER-MIGRATION-RECEIPT-MISMATCH", "receipt readback differs")


def _committed_migration_facts(
    item: Path,
    *,
    target_run_id: str,
    target_event_sha256: str,
    expected_before_sha256: str,
    operation_id: str,
    normalization_kind: str,
) -> dict | None:
    ledger_owner = _load_agent_run_ledger()
    ledger_path = item / "agent-runs.jsonl"
    root = _repository_root_for_item(item)
    ledger_path = _require_lifecycle_mutation_path(
        root, ledger_path, failure_id="WI-LEDGER-MIGRATION-TOPOLOGY"
    )
    data = ledger_path.read_bytes()
    raw_lines = data.splitlines(keepends=True)
    validator = ledger_owner.load_validator()
    parse_errors: list[str] = []
    metadata: list[dict[str, object]] = []
    events = validator.load_jsonl(ledger_path, parse_errors, metadata)
    if parse_errors:
        raise LifecycleError("WI-LEDGER-MIGRATION-TOPOLOGY", "; ".join(parse_errors))
    _effective, _counters, projection_errors = validator.project_legacy_obligation_migrations(
        events, metadata, item
    )
    if projection_errors:
        raise LifecycleError("WI-LEDGER-MIGRATION-TOPOLOGY", "; ".join(projection_errors))
    for index, raw in enumerate(raw_lines):
        text = raw.rstrip(b"\r\n")
        try:
            event = json.loads(text.decode("utf-8"))
        except (UnicodeError, json.JSONDecodeError):
            continue
        if event.get("runId") != f"ledger-migration-{operation_id}":
            continue
        control_errors: list[str] = []
        validator.validate_event(event, item, set(), control_errors)
        if control_errors:
            raise LifecycleError("WI-LEDGER-MIGRATION-TOPOLOGY", "; ".join(control_errors))
        if (
            event.get("eventKind") != "legacy-obligation-migration"
            or event.get("migrationAction") != "apply"
            or event.get("normalizationKind", "invalid-finding-class") != normalization_kind
            or event.get("migratesRunId") != target_run_id
            or event.get("migratesEventSha256") != target_event_sha256
        ):
            raise LifecycleError("WI-LEDGER-MIGRATION-TOPOLOGY", "operation id is bound to different inputs")
        before = b"".join(raw_lines[:index])
        if _sha256_bytes(before) != expected_before_sha256:
            raise LifecycleError("WI-LEDGER-MIGRATION-TOPOLOGY", "committed operation has a different before digest")
        replacement = event.get("replacementEvent")
        if not isinstance(replacement, dict):
            raise LifecycleError("WI-LEDGER-MIGRATION-TOPOLOGY", "committed anchor replacement is missing")
        target = next(
            (
                candidate for candidate, candidate_metadata in zip(events[:index], metadata[:index])
                if candidate.get("runId") == target_run_id
                and candidate_metadata.get("sha256") == target_event_sha256
            ),
            None,
        )
        if target is None:
            raise LifecycleError("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "committed target no longer resolves")
        finding_class = target.get("findingClass") if normalization_kind == "remove-string-scratch-evidence" else "legacy-unclassified"
        diagnostic_id = (
            validator.LEDGER_EVENT_SCRATCH_EVIDENCE_INVALID
            if normalization_kind == "remove-string-scratch-evidence"
            else "LEDGER-EVENT-FINDING-CLASS-INVALID"
        )
        committed_after = b"".join(raw_lines[: index + 1])
        facts = {
            "schemaVersion": 1,
            "status": "committed",
            "operationId": operation_id,
            "targetRunId": target_run_id,
            "targetEventSha256": target_event_sha256,
            "anchorRunId": event["runId"],
            "anchorEventSha256": _sha256_bytes(text),
            "beforeLedgerBytes": len(before),
            "beforeLedgerSha256": _sha256_bytes(before),
            "afterLedgerBytes": len(committed_after),
            "afterLedgerSha256": _sha256_bytes(committed_after),
            "replacementEventSha256": _sha256_bytes(ledger_owner.serialize_event(replacement).encode("utf-8")),
            "normalizationKind": normalization_kind,
            "diagnosticId": diagnostic_id,
            "sourcePath": f"work-items/active/{item.name}/agent-runs.jsonl",
            "receiptPath": f"work-items/active/{item.name}/ledger-migration-receipts/{operation_id}.json",
            "recordedAt": event["startedAt"],
        }
        if finding_class is not None:
            facts["findingClass"] = finding_class
        return facts
    return None


def _migrate_legacy_ledger_obligation_locked(
    root: Path,
    slug: str,
    target_run_id: str,
    target_event_sha256: str,
    expected_ledger_sha256: str,
    operation_id: str,
    recorded_at: str,
    normalization_kind: str,
    *,
    inject_failure: str | None = None,
) -> dict:
    item = _active_migration_item(root, slug)
    committed = _committed_migration_facts(
        item,
        target_run_id=target_run_id,
        target_event_sha256=target_event_sha256,
        expected_before_sha256=expected_ledger_sha256,
        operation_id=operation_id,
        normalization_kind=normalization_kind,
    )
    if committed is not None:
        _reconcile_migration_receipt(item, committed)
        return committed
    ledger_owner = _load_agent_run_ledger()
    try:
        staged = ledger_owner.stage_legacy_obligation_migration(
            item,
            target_run_id,
            target_event_sha256,
            expected_ledger_sha256,
            operation_id,
            recorded_at,
            normalization_kind,
        )
    except ledger_owner.LedgerMigrationError as exc:
        raise LifecycleError(exc.failure_id, str(exc)) from exc
    ledger_path = item / "agent-runs.jsonl"
    ledger_path = _require_lifecycle_mutation_path(
        root, ledger_path, failure_id="WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE"
    )
    _atomic_write(ledger_path, staged.staged_bytes)
    if inject_failure == "post-replace-corrupt":
        ledger_path.write_bytes(staged.staged_bytes + b"corrupt")
    try:
        actual = ledger_path.read_bytes()
    except OSError as exc:
        raise LifecycleError("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "ledger readback failed") from exc
    if _sha256_bytes(actual) != staged.receipt_facts["afterLedgerSha256"]:
        raise LifecycleError("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "ledger is neither exact before nor exact after")
    if inject_failure == "after-anchor":
        raise LifecycleError("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "injected crash after anchor")
    _reconcile_migration_receipt(item, staged.receipt_facts)
    return staged.receipt_facts


def migrate_legacy_ledger_obligation(
    root: Path,
    slug: str,
    target_run_id: str,
    target_event_sha256: str,
    expected_ledger_sha256: str,
    operation_id: str,
    recorded_at: str,
    *,
    normalization_kind: str = "invalid-finding-class",
    inject_failure: str | None = None,
) -> dict:
    item = _active_migration_item(root, slug)
    ledger_owner = _load_agent_run_ledger()
    try:
        with ledger_owner.ledger_write_lock(item):
            return _migrate_legacy_ledger_obligation_locked(
                root, slug, target_run_id, target_event_sha256,
                expected_ledger_sha256, operation_id, recorded_at,
                normalization_kind,
                inject_failure=inject_failure,
            )
    except ledger_owner.LedgerWriteLockError as exc:
        raise LifecycleError("WI-LIFECYCLE-LOCK-HELD", str(exc)) from exc


def _revoke_legacy_ledger_obligation_locked(
    root: Path,
    slug: str,
    apply_run_id: str,
    apply_event_sha256: str,
    expected_ledger_sha256: str,
    operation_id: str,
    recorded_at: str,
) -> dict:
    item = _active_migration_item(root, slug)
    if (item / "lifecycle-transition-receipt.json").exists() or any(
        item.glob("lifecycle-transition-*.json")
    ):
        raise LifecycleError("WI-LEDGER-MIGRATION-REVOCATION-FROZEN", "physical transition has started")
    ledger_owner = _load_agent_run_ledger()
    ledger_owner._strict_migration_inputs(operation_id, recorded_at)
    ledger_path = item / "agent-runs.jsonl"
    ledger_path = _require_lifecycle_mutation_path(
        root, ledger_path, failure_id="WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE"
    )
    before = ledger_path.read_bytes()
    if _sha256_bytes(before) != expected_ledger_sha256:
        raise LifecycleError("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "ledger digest changed")
    validator = ledger_owner.load_validator()
    errors: list[str] = []
    metadata: list[dict[str, object]] = []
    events = validator.load_jsonl(ledger_path, errors, metadata)
    positions = [i for i, event in enumerate(events) if event.get("runId") == apply_run_id]
    if len(positions) != 1:
        raise LifecycleError("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "apply anchor is missing or non-unique")
    pos = positions[0]
    apply_event = events[pos]
    if (
        apply_event.get("eventKind") != "legacy-obligation-migration"
        or apply_event.get("migrationAction") != "apply"
        or metadata[pos].get("sha256") != apply_event_sha256
    ):
        raise LifecycleError("WI-LEDGER-MIGRATION-TARGET-DIGEST", "apply anchor digest changed")
    if any(event.get("eventKind") == "legacy-obligation-migration" and event.get("migrationAction") == "revoke" and event.get("revokesMigrationRunId") == apply_run_id for event in events):
        raise LifecycleError("WI-LEDGER-MIGRATION-TOPOLOGY", "apply already revoked")
    normalization_kind = apply_event.get("normalizationKind", "invalid-finding-class")
    row = validator.LEGACY_MIGRATION_NORMALIZATIONS.get(normalization_kind)
    if row is None:
        raise LifecycleError("WI-LEDGER-MIGRATION-NORMALIZATION-KIND", "apply normalization kind is not closed")
    revoke = {
        "schemaVersion": 2,
        "runId": f"ledger-migration-{operation_id}",
        "workItem": apply_event["workItem"],
        "role": "lead",
        "executionRole": "main",
        "status": "completed",
        "gate": "none",
        "scope": row["scope"],
        "eventKind": "legacy-obligation-migration",
        "migrationAction": "revoke",
        "revokesMigrationRunId": apply_run_id,
        "revokesMigrationEventSha256": apply_event_sha256,
        "evidence": [{"kind": "manual-check", "ref": f"revoke {apply_run_id} {apply_event_sha256}"}],
        "startedAt": recorded_at,
        "updatedAt": recorded_at,
    }
    line = ledger_owner.serialize_event(revoke).encode("utf-8") + b"\n"
    candidate = before + (b"" if before.endswith(b"\n") else b"\n") + line
    temporary = item / ".ledger-revoke-candidate.jsonl"
    try:
        temporary.write_bytes(candidate)
        parse_errors: list[str] = []
        candidate_metadata: list[dict[str, object]] = []
        candidate_events = validator.load_jsonl(temporary, parse_errors, candidate_metadata)
        control_errors: list[str] = []
        validator.validate_event(revoke, item, {str(event.get("runId", "")).casefold() for event in events}, control_errors)
        _effective, _counters, projection_errors = validator.project_legacy_obligation_migrations(
            candidate_events, candidate_metadata, item
        )
        candidate_errors = parse_errors + control_errors + projection_errors
    finally:
        temporary.unlink(missing_ok=True)
    if candidate_errors:
        raise LifecycleError("WI-LEDGER-MIGRATION-CANDIDATE-INVALID", "; ".join(candidate_errors))
    _atomic_write(ledger_path, candidate)
    return {
        "schemaVersion": 1,
        "status": "revoked",
        "operationId": operation_id,
        "applyRunId": apply_run_id,
        "applyEventSha256": apply_event_sha256,
        "afterLedgerSha256": _sha256_bytes(candidate),
        "recordedAt": recorded_at,
    }


def revoke_legacy_ledger_obligation(
    root: Path,
    slug: str,
    apply_run_id: str,
    apply_event_sha256: str,
    expected_ledger_sha256: str,
    operation_id: str,
    recorded_at: str,
) -> dict:
    _validate_slug(slug)
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    transition_root = repository / ".scratch" / "work-items-lifecycle-transitions"
    if transition_root.is_dir():
        _lifecycle_reject_unreduced_reparse(
            transition_root,
            failure_id="WI-LEDGER-MIGRATION-REVOCATION-FROZEN",
            message="transition staging root is a link or reparse point",
        )
        for intent_path in _bounded_transition_intent_inventory(
            transition_root,
            failure_id="WI-LEDGER-MIGRATION-REVOCATION-FROZEN",
            unreadable="transition staging root is unreadable",
        ):
            intent = _load_transition_intent(root, intent_path)
            if intent.get("slug") == slug:
                raise LifecycleError(
                    "WI-LEDGER-MIGRATION-REVOCATION-FROZEN",
                    "physical transition intent already exists",
                )
    locations = _category_locations(root, CATEGORIES["work-item"], slug)
    if any("archive" in path.parts for path in locations):
        raise LifecycleError(
            "WI-LEDGER-MIGRATION-REVOCATION-FROZEN",
            "work item is already archived",
        )
    item = _active_migration_item(root, slug)
    ledger_owner = _load_agent_run_ledger()
    try:
        with ledger_owner.ledger_write_lock(item):
            return _revoke_legacy_ledger_obligation_locked(
                root, slug, apply_run_id, apply_event_sha256,
                expected_ledger_sha256, operation_id, recorded_at,
            )
    except ledger_owner.LedgerWriteLockError as exc:
        raise LifecycleError("WI-LIFECYCLE-LOCK-HELD", str(exc)) from exc


TRANSITION_OWNER = "mutate-work-item:archive-with-successor-v1"
TRANSFER_TRANSITION_OWNER = "mutate-work-item:archive-with-successor-v2"
SUCCESSOR_IMPORT_OWNER = "mutate-work-item:import-active-successor-v1"
SUCCESSOR_IMPORT_KIND = "active-successor-import-v1"
SUCCESSOR_IMPORT_RECEIPT = "active-successor-import-receipt.json"
SUCCESSOR_IMPORT_INTENT_FIELDS = {
    "schemaVersion", "owner", "kind", "status", "operationId",
    "preflightDigest", "sourcePath", "archivePath", "successorPath",
    "sourceHoldPath", "successorStagePath", "receiptPath", "plan",
    "statusData", "images",
}
SUCCESSOR_IMPORT_PLAN_FIELDS = {
    "schemaVersion", "owner", "operationId", "predecessor", "successor",
    "sourceTreeSha256", "archiveTreeSha256", "archiveReceiptSha256",
    "archiveFiles", "fileBindings", "ledgerArchivePrefix", "statusSha256",
    "compatibilityIndex", "links", "readme", "canonicalInputs",
}
SUCCESSOR_IMPORT_RECEIPT_FIELDS = SUCCESSOR_IMPORT_PLAN_FIELDS | {
    "state", "preflightDigest", "dispositionsSha256",
    "successorTreeSha256ExcludingReceipt", "receiptPath",
}
TRANSITION_INTENT_FIELDS = {
    "schemaVersion", "owner", "status", "operationId", "slug", "terminalInstant",
    "activePath", "archivePath", "successorPath", "expectedLedgerSha256",
    "expectedReadmeSha256", "statusBefore", "statusAfter", "closureBefore",
    "closureAfter", "successorData", "manifestData", "migrationReceiptPath", "bugs",
    "closureInputSha256", "successorSlug", "finalReadmeSha256",
    "bugReceiptBefore", "bugReceiptAfter",
}
LEGACY_TRANSFER_TRANSITION_INTENT_FIELDS = TRANSITION_INTENT_FIELDS | {
    "transferInputSha256", "archiveIdentity", "predecessorOperationId", "obligations",
}
TRANSFER_TRANSITION_INTENT_FIELDS = (
    TRANSITION_INTENT_FIELDS - {"migrationReceiptPath"}
) | {
    "migrationReceipts", "transferInputSha256", "archiveIdentity",
    "predecessorOperationId", "obligations",
}
TRANSITION_SETTLEMENT_FIELDS = {
    "schemaVersion", "owner", "status", "operationId", "workItem",
    "terminalInstant", "archivePath", "successorPath", "successorSha256",
    "ledgerSha256", "statusSha256", "closureSha256",
    "bugDispositionReceiptSha256", "migrationReceiptSha256", "readmeSha256",
    "requestClosureSha256", "requestSuccessorSlug", "requestSuccessorSha256",
    "requestTerminalInstant", "requestExpectedLedgerSha256",
    "requestExpectedReadmeSha256",
}
LEGACY_TRANSFER_TRANSITION_SETTLEMENT_FIELDS = TRANSITION_SETTLEMENT_FIELDS | {
    "transferInputSha256", "archiveIdentity", "predecessorOperationId", "obligations",
}
TRANSFER_TRANSITION_SETTLEMENT_FIELDS = (
    TRANSITION_SETTLEMENT_FIELDS - {"migrationReceiptSha256"}
) | {
    "migrationReceipts", "transferInputSha256", "archiveIdentity",
    "predecessorOperationId", "obligations",
}
MIGRATION_RECEIPT_BINDING_FIELDS = {"path", "sha256"}
BUG_SUPERSESSION_INTENT_FIELDS = {
    "schemaVersion", "owner", "kind", "status", "operationId", "terminalInstant",
    "sourcePath", "archivePath", "receiptPath", "expectedReadmeSha256",
    "finalReadmeSha256", "sourceBefore", "sourceAfter", "receiptBefore",
    "receiptAfter", "successorBindingSha256", "successorRegistryReference",
    "successorRecordReference", "successorRecordSha256", "acceptedBy", "acceptedAt",
    "acceptanceEvidence", "incomingLinksInventorySha256", "links",
}
BUG_SUPERSESSION_LINK_INTENT_FIELDS = {
    "path", "before", "after", "beforeSha256", "afterSha256",
}
BUG_SUPERSESSION_RECEIPT_FIELDS = {
    "schemaVersion", "owner", "kind", "status", "operationId", "terminalInstant",
    "sourceReference", "sourcePath", "archivePath", "archivedBugSha256",
    "successorBindingSha256", "successorRegistryReference", "successorRecordReference",
    "successorRecordSha256", "acceptedBy", "acceptedAt", "acceptanceEvidence",
    "incomingLinksInventorySha256", "links", "readmeSha256",
    "requestExpectedBugSha256", "requestExpectedReadmeSha256",
}
FIXED_BUG_ARCHIVE_OWNER = "mutate-work-item:fixed-bug-archive-v1"
FIXED_BUG_ARCHIVE_KIND = "fixed-bug-archive-v1"
FIXED_BUG_ARCHIVE_INTENT_FIELDS = {
    "schemaVersion", "owner", "kind", "status", "operationId", "terminalInstant",
    "sourcePath", "archivePath", "receiptPath", "expectedReadmeSha256",
    "finalReadmeSha256", "sourceBefore", "sourceAfter", "receiptBefore",
    "receiptAfter", "links",
}
FIXED_BUG_ARCHIVE_RECEIPT_FIELDS = {
    "schemaVersion", "owner", "kind", "status", "operationId",
    "sourceReference", "sourcePath", "archivePath", "terminalInstant",
    "sourceBeforeSha256", "archivedBugSha256", "links", "readmeSha256",
}
BUG_SUPERSESSION_INVENTORY_FIELDS = {
    "schemaVersion", "owner", "operationId", "sourceReference", "sourceBugSha256",
    "successorBindingSha256", "links",
}
BUG_SUPERSESSION_INVENTORY_LINK_FIELDS = {
    "path", "beforeSha256", "afterSha256", "afterBytesBase64",
}


def _bounded_transition_intent_inventory(
    directory: Path, *, failure_id: str, unreadable: str
) -> list[Path]:
    """Inventory transition intents within finite count and byte budgets."""
    candidates: list[Path] = []
    total_bytes = 0
    json_suffix = os.path.normcase(".json")
    try:
        with os.scandir(directory) as entries:
            for entry_count, entry in enumerate(entries, start=1):
                if entry_count > TRANSITION_INTENT_INVENTORY_MAX_ENTRIES:
                    raise LifecycleError(
                        failure_id, "transition intent inventory limit exceeded"
                    )
                if not os.path.normcase(entry.name).endswith(json_suffix):
                    continue
                path = Path(entry.path)
                metadata = path.lstat()
                if (
                    not stat.S_ISREG(metadata.st_mode)
                    or stat.S_ISLNK(metadata.st_mode)
                    or metadata.st_nlink != 1
                    or bool(
                        getattr(metadata, "st_file_attributes", 0)
                        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
                    )
                ):
                    raise LifecycleError(
                        failure_id, "transition intent is not an owned regular file"
                    )
                if metadata.st_size > TRANSITION_INTENT_FILE_BYTE_CAP:
                    raise LifecycleError(
                        failure_id, "transition intent byte limit exceeded"
                    )
                total_bytes += metadata.st_size
                if total_bytes > TRANSITION_INTENT_INVENTORY_BYTE_CAP:
                    raise LifecycleError(
                        failure_id, "transition intent cumulative byte limit exceeded"
                    )
                candidates.append(path)
    except LifecycleError:
        raise
    except OSError as exc:
        raise LifecycleError(failure_id, unreadable) from exc
    return sorted(candidates)


def _validate_transfer_migration_receipt_bindings(
    root: Path,
    archive_path: object,
    value: object,
    *,
    failure_id: str,
) -> tuple[dict[str, str], ...]:
    if not isinstance(archive_path, str) or not isinstance(value, list):
        raise LifecycleError(failure_id, "migration receipt binding list differs")
    expected_parent = PurePosixPath(archive_path) / "ledger-migration-receipts"
    rows: list[dict[str, str]] = []
    paths: list[str] = []
    for row in value:
        if (
            not isinstance(row, dict)
            or set(row) != MIGRATION_RECEIPT_BINDING_FIELDS
            or not isinstance(row.get("path"), str)
            or not isinstance(row.get("sha256"), str)
            or SHA256_RE.fullmatch(row["sha256"]) is None
        ):
            raise LifecycleError(failure_id, "migration receipt binding row differs")
        path = row["path"]
        _intent_path(root, path)
        pure = PurePosixPath(path)
        if pure.parent != expected_parent or pure.suffix != ".json":
            raise LifecycleError(failure_id, "migration receipt binding path differs")
        paths.append(path)
        rows.append({"path": path, "sha256": row["sha256"]})
    if paths != sorted(paths, key=lambda item: item.encode("utf-8")) or len(
        paths
    ) != len(set(paths)):
        raise LifecycleError(
            failure_id, "migration receipt binding paths are not sorted and unique"
        )
    return tuple(rows)


@dataclass(frozen=True)
class WorkItemLedgerLocationV1:
    logical_work_item: str
    logical_ledger_path: str
    physical_work_item: str
    physical_ledger_path: str
    phase: Literal["active", "active-intent", "moved-intent", "settled-archive"]
    ledger_sha256: str
    operation_id: str | None
    provenance_path: str | None
    provenance_sha256: str | None


def _validate_successor_transfer_fields(
    successor_data: bytes, source_slug: str, operation_id: str
) -> None:
    try:
        text = successor_data.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-COVERAGE", "successor transfer fields require UTF-8"
        ) from exc
    occurrences = _authoritative_field_occurrences(text)
    expected = {"continues": source_slug, "obligation-transfer": operation_id}
    for field, value in expected.items():
        matches = [observed for _line, name, observed, _raw in occurrences if name == field]
        if matches != [value]:
            raise LifecycleError(
                "WI-OBLIGATION-TRANSFER-COVERAGE",
                f"successor requires exactly one {field} field bound to {value}",
            )


def _transfer_relation_fields(data: bytes, *, required: bool) -> tuple[str, str] | None:
    try:
        text = data.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-OWNER", "transfer relation fields require UTF-8"
        ) from exc
    occurrences = _authoritative_field_occurrences(text)
    values = {
        name: [value for _line, observed, value, _raw in occurrences if observed == name]
        for name in ("continues", "obligation-transfer")
    }
    if not any(values.values()) and not required:
        return None
    if any(len(values[name]) != 1 or not values[name][0] for name in values):
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-OWNER",
            "transfer owner requires exactly one Continues and Obligation-transfer field",
        )
    return values["continues"][0], values["obligation-transfer"][0]


def _validate_started_transfer_relation(
    backlog_data: bytes, status_data: bytes
) -> tuple[str, str] | None:
    backlog_relation = _transfer_relation_fields(backlog_data, required=False)
    status_relation = _transfer_relation_fields(status_data, required=False)
    if backlog_relation != status_relation:
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-OWNER",
            "active status must preserve the backlog transfer owner fields exactly",
        )
    return backlog_relation


def _inspect_transfer_obligations(root: Path, item: Path) -> tuple[object, ...]:
    validator = _validator_module()
    status_text = (item / "status.md").read_text(encoding="utf-8")
    v1_staged = _parse_fields(status_text).get("template") == "staged"
    states: list[object] = []
    errors = validator.validate_work_item(
        item,
        strict_revise=False,
        validate_status_file=not v1_staged,
        obligation_state_out=states,
    )
    if v1_staged:
        _validate_active_status_bytes(status_text.encode("utf-8"))
    if errors:
        raise LifecycleError("WI-LEDGER-UNSETTLED", "; ".join(errors))
    if len(states) != 1:
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-COVERAGE", "validator did not return one obligation state"
        )
    state = states[0]
    if state.open_launches:
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-COVERAGE", "running launches cannot be transferred"
        )
    return state.open_revise


def _prepare_obligation_transfer(
    root: Path,
    active: Path,
    archive: Path,
    slug: str,
    successor_slug: str,
    successor_data: bytes,
    operation_id: str,
    expected_ledger_sha256: str,
    transfer_data: bytes,
) -> tuple[dict, list[dict], str, tuple[CapturedFileSnapshot, ...]]:
    validator = _validator_module()
    try:
        payload = validator.decode_json_object(
            transfer_data,
            source="obligation transfer input",
            maximum_bytes=max(1, len(transfer_data)),
        )
    except ValueError as exc:
        raise LifecycleError("WI-OBLIGATION-TRANSFER-COVERAGE", str(exc)) from exc
    required = {
        "schemaVersion", "sourceWorkItem", "successorWorkItem",
        "expectedSourceLedgerSha256", "obligations",
    }
    if (
        set(payload) != required
        or payload.get("schemaVersion") != 1
        or payload.get("sourceWorkItem") != slug
        or payload.get("successorWorkItem") != successor_slug
        or payload.get("expectedSourceLedgerSha256") != expected_ledger_sha256
        or not isinstance(payload.get("obligations"), list)
    ):
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-COVERAGE", "obligation transfer input shape or owner binding differs"
        )
    _validate_successor_transfer_fields(successor_data, slug, operation_id)
    open_rows = _inspect_transfer_obligations(root, active)
    row_fields = {
        "runId", "rawLineOrdinal", "rawLineSha256", "rawEventSha256",
        "projectedEventSha256",
    }
    declared: dict[tuple[str, int, str, str, str], dict] = {}
    declared_run_ids: set[str] = set()
    for row in payload["obligations"]:
        if not isinstance(row, dict) or set(row) != row_fields:
            raise LifecycleError(
                "WI-OBLIGATION-TRANSFER-COVERAGE", "obligation row shape differs"
            )
        identity = (
            row.get("runId"), row.get("rawLineOrdinal"), row.get("rawLineSha256"),
            row.get("rawEventSha256"), row.get("projectedEventSha256"),
        )
        if (
            not isinstance(identity[0], str)
            or type(identity[1]) is not int
            or identity[1] < 1
            or any(not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None for value in identity[2:])
            or identity in declared
            or identity[0] in declared_run_ids
        ):
            raise LifecycleError(
                "WI-OBLIGATION-TRANSFER-COVERAGE", "duplicate or invalid obligation identity"
            )
        declared[identity] = row
        declared_run_ids.add(identity[0])
    observed = {
        (
            row.run_id, row.raw_line_ordinal, row.raw_line_sha256,
            row.raw_event_sha256, row.projected_event_sha256,
        ): row
        for row in open_rows
    }
    declared_positions = {(identity[0], identity[1]) for identity in declared}
    observed_positions = {(identity[0], identity[1]) for identity in observed}
    if declared_positions != observed_positions or len(observed) != len(open_rows):
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-COVERAGE", "declared obligations do not exactly cover open REVISE rows"
        )
    if set(declared) != set(observed):
        raise LifecycleError(
            "WI-OBLIGATION-TRANSFER-DRIFT", "declared obligation evidence bindings differ"
        )
    archive_relative = archive.relative_to(Path(root).resolve()).as_posix()
    archive_identity = validator.archived_ledger_identity(
        archive_relative, expected_ledger_sha256
    )
    obligations = []
    for identity in sorted(observed, key=lambda value: (value[1], value[0].encode("utf-8"))):
        row = observed[identity]
        obligations.append({
            **declared[identity],
            "obligationId": (
                row.obligation_id
                if row.obligation_id is not None
                else validator.obligation_transfer_id(
                    archive_identity,
                    row.raw_line_ordinal,
                    row.raw_line_sha256,
                    row.raw_event_sha256,
                    row.run_id,
                )
            ),
            "predecessorOperationId": row.predecessor_operation_id,
        })
    migration_receipts = sorted(
        (active / "ledger-migration-receipts").glob("*.json"),
        key=lambda path: path.relative_to(active).as_posix().encode("utf-8"),
    )
    ledger_owner = _load_agent_run_ledger()
    migrated_rows = {
        (
            row.run_id,
            _sha256_bytes(
                ledger_owner.serialize_event(dict(row.event)).encode("utf-8")
            ),
        ): row
        for row in open_rows
        if row.source_kind == "migration-replaced"
    }
    if len(migrated_rows) != sum(
        row.source_kind == "migration-replaced" for row in open_rows
    ) or len(migration_receipts) != len(migrated_rows):
        raise LifecycleError(
            "WI-LEDGER-MIGRATION-RECEIPT-MISMATCH",
            "transfer requires the exact migration receipt set",
        )
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    snapshots: dict[tuple[str, str], CapturedFileSnapshot] = {}
    for migration_receipt in migration_receipts:
        snapshot = _capture_file_snapshot(
            migration_receipt,
            failure_id="WI-LEDGER-MIGRATION-RECEIPT-MISMATCH",
        )
        try:
            facts = validator.decode_json_object(
                snapshot.data,
                source=str(migration_receipt),
                maximum_bytes=max(1, len(snapshot.data)),
            )
        except ValueError as exc:
            raise LifecycleError(
                "WI-LEDGER-MIGRATION-RECEIPT-MISMATCH",
                "migration receipt is not one strict JSON object",
            ) from exc
        required_strings = (
            "operationId",
            "targetRunId",
            "targetEventSha256",
            "beforeLedgerSha256",
            "replacementEventSha256",
            "normalizationKind",
        )
        if any(not isinstance(facts.get(key), str) for key in required_strings):
            raise LifecycleError(
                "WI-LEDGER-MIGRATION-RECEIPT-MISMATCH",
                "migration receipt identity fields differ",
            )
        try:
            canonical_facts = _committed_migration_facts(
                active,
                target_run_id=facts["targetRunId"],
                target_event_sha256=facts["targetEventSha256"],
                expected_before_sha256=facts["beforeLedgerSha256"],
                operation_id=facts["operationId"],
                normalization_kind=facts["normalizationKind"],
            )
        except LifecycleError as exc:
            raise LifecycleError(
                "WI-LEDGER-MIGRATION-RECEIPT-MISMATCH",
                "migration receipt does not reconstruct from the source ledger",
            ) from exc
        actual_path = migration_receipt.relative_to(repository).as_posix()
        identity = (facts["targetRunId"], facts["replacementEventSha256"])
        if (
            canonical_facts is None
            or canonical_facts != facts
            or facts.get("receiptPath") != actual_path
            or identity not in migrated_rows
            or identity in snapshots
        ):
            raise LifecycleError(
                "WI-LEDGER-MIGRATION-RECEIPT-MISMATCH",
                "migration receipt set does not match migrated open obligations",
            )
        snapshots[identity] = snapshot
    if set(snapshots) != set(migrated_rows):
        raise LifecycleError(
            "WI-LEDGER-MIGRATION-RECEIPT-MISMATCH",
            "migration receipt set does not exactly cover migrated open obligations",
        )
    return (
        payload,
        obligations,
        archive_identity,
        tuple(
            sorted(
                snapshots.values(),
                key=lambda snapshot: snapshot.path.relative_to(repository)
                .as_posix()
                .encode("utf-8"),
            )
        ),
    )


def _b64(data: bytes | None) -> str | None:
    return None if data is None else base64.b64encode(data).decode("ascii")


def _unb64(value: str | None) -> bytes | None:
    if value is None:
        return None
    try:
        return base64.b64decode(value, validate=True)
    except (ValueError, TypeError) as exc:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "invalid intent byte image") from exc


def _bug_successor_binding_fail(message: str) -> LifecycleError:
    return LifecycleError("WI-BUG-SUCCESSOR-BINDING", message)


def _bug_successor_json_pairs(pairs: list[tuple[str, object]]) -> dict:
    value: dict[str, object] = {}
    for key, item in pairs:
        if key in value:
            raise _bug_successor_binding_fail(f"successor binding repeats JSON key: {key}")
        value[key] = item
    return value


def _bug_successor_single_line(payload: dict, key: str) -> str:
    value = payload.get(key)
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value) > BUG_DISPOSITION_TEXT_LIMIT
        or "\n" in value
        or "\r" in value
    ):
        raise _bug_successor_binding_fail(
            f"successor binding {key} must be one non-empty bounded line"
        )
    return value


def _parse_bug_successor_binding_data(
    slug: str,
    binding_data: bytes | None,
    operation_id: str,
) -> dict:
    if binding_data is None:
        raise _bug_successor_binding_fail("successor binding is required")
    try:
        payload = json.loads(
            binding_data.decode("utf-8"), object_pairs_hook=_bug_successor_json_pairs
        )
    except LifecycleError:
        raise
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise _bug_successor_binding_fail("successor binding is not strict UTF-8 JSON") from exc
    if (
        not isinstance(payload, dict)
        or set(payload) != BUG_SUCCESSOR_BINDING_FIELDS
        or payload.get("schemaVersion") != 1
    ):
        raise _bug_successor_binding_fail("successor binding shape differs")
    for key in (
        "operationId",
        "sourceReference",
        "registryReference",
        "recordReference",
        "recordSha256",
        "acceptedBy",
        "acceptedAt",
        "acceptanceEvidence",
    ):
        _bug_successor_single_line(payload, key)
    if (
        payload["operationId"] != operation_id
        or payload["sourceReference"] != f"bug:{slug}"
        or not SHA256_RE.fullmatch(payload["recordSha256"])
    ):
        raise _bug_successor_binding_fail("successor binding identity differs")
    try:
        _strict_utc(payload["acceptedAt"])
    except LifecycleError as exc:
        raise _bug_successor_binding_fail("successor acceptance time differs") from exc
    return payload


def _parse_bug_successor_binding(
    slug: str,
    successor_record: Path,
    binding_data: bytes | None,
    operation_id: str,
) -> tuple[dict, CapturedFileSnapshot]:
    payload = _parse_bug_successor_binding_data(slug, binding_data, operation_id)
    try:
        successor = _capture_file_snapshot(
            Path(successor_record), failure_id="WI-BUG-SUCCESSOR-BINDING"
        )
    except LifecycleError as exc:
        raise _bug_successor_binding_fail("successor record identity differs") from exc
    if _sha256_bytes(successor.data) != payload["recordSha256"]:
        raise _bug_successor_binding_fail("successor record hash differs")
    return payload, successor


def _bug_supersession_inventory_pairs(pairs: list[tuple[str, object]]) -> dict:
    value: dict[str, object] = {}
    for key, item in pairs:
        if key in value:
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-INVENTORY",
                f"bug successor inventory repeats JSON key: {key}",
            )
        value[key] = item
    return value


def _parse_bug_supersession_inventory(data: bytes) -> dict:
    try:
        payload = json.loads(
            data.decode("utf-8"), object_pairs_hook=_bug_supersession_inventory_pairs
        )
    except LifecycleError:
        raise
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            "bug successor inventory is not strict UTF-8 JSON",
        ) from exc
    if (
        not isinstance(payload, dict)
        or set(payload) != BUG_SUPERSESSION_INVENTORY_FIELDS
        or payload.get("schemaVersion") != 1
        or payload.get("owner") != BUG_SUPERSESSION_OWNER
        or not isinstance(payload.get("links"), list)
    ):
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            "bug successor inventory shape differs",
        )
    paths: list[str] = []
    for row in payload["links"]:
        if (
            not isinstance(row, dict)
            or set(row) != BUG_SUPERSESSION_INVENTORY_LINK_FIELDS
            or not isinstance(row.get("path"), str)
            or not row["path"]
            or not isinstance(row.get("beforeSha256"), str)
            or not SHA256_RE.fullmatch(row["beforeSha256"])
            or not isinstance(row.get("afterSha256"), str)
            or not SHA256_RE.fullmatch(row["afterSha256"])
            or not isinstance(row.get("afterBytesBase64"), str)
        ):
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-INVENTORY",
                "bug successor inventory link row differs",
            )
        paths.append(row["path"])
    if paths != sorted(paths) or len(paths) != len(set(paths)):
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            "bug successor inventory paths are not sorted and unique",
        )
    return payload


def _bug_successor_link_after(
    consumer: Path,
    source: Path,
    before: bytes,
    source_reference: str,
    successor_reference: str,
) -> bytes:
    try:
        text = before.decode("utf-8")
    except UnicodeError as exc:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            f"bug successor link consumer is not UTF-8: {consumer}",
        ) from exc
    replacements = [
        (link.href_start, link.href_end)
        for link in _markdown_local_links(text)
        if _markdown_href_resolves(consumer.parent, link.href, source)
    ]
    for start, end in reversed(replacements):
        text = text[:start] + successor_reference + text[end:]
    text = text.replace(source_reference, successor_reference)
    return text.encode("utf-8")


def _prepare_bug_supersession_links(
    root: Path,
    source: Path,
    source_reference: str,
    successor_reference: str,
    inventory: dict,
) -> list[dict]:
    current = _incoming_link_result(
        root,
        {source},
        source_reference,
        mutable_consumers_only=True,
        strict_consumer_reads=True,
    )
    repository = _work_items_root(root).parent
    expected_paths = sorted(
        {
            (repository / "work-items" / row["consumer"]).relative_to(repository).as_posix()
            for row in current["references"]
        }
    )
    supplied_paths = [row["path"] for row in inventory["links"]]
    if supplied_paths != expected_paths:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            "bug successor inventory does not exactly cover live incoming links",
        )
    plans: list[dict] = []
    for row in inventory["links"]:
        path = _intent_path(root, row["path"])
        try:
            snapshot = _capture_file_snapshot(
                path, failure_id="WI-CATEGORY-MIGRATION-INVENTORY"
            )
            after = base64.b64decode(row["afterBytesBase64"], validate=True)
        except (LifecycleError, ValueError, TypeError) as exc:
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-INVENTORY",
                f"bug successor link image cannot be captured: {row['path']}",
            ) from exc
        expected_after = _bug_successor_link_after(
            path, source, snapshot.data, source_reference, successor_reference
        )
        if (
            _sha256_bytes(snapshot.data) != row["beforeSha256"]
            or _sha256_bytes(after) != row["afterSha256"]
            or after != expected_after
            or after == snapshot.data
        ):
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-INVENTORY",
                f"bug successor link image differs: {row['path']}",
            )
        plans.append(
            {
                "path": path,
                "pathRelative": row["path"],
                "before": snapshot.data,
                "after": after,
                "beforeSha256": row["beforeSha256"],
                "afterSha256": row["afterSha256"],
            }
        )
    return plans


def _precompute_single_bug_readme_sha256(
    root: Path,
    source: Path,
    archive: Path,
    source_after: bytes,
    links: list[dict],
) -> str:
    work_items = _work_items_root(root)
    repository = work_items.parent
    static_guide = _static_guide(work_items / "README.md")
    with tempfile.TemporaryDirectory(prefix="single-bug-readme-") as directory:
        shadow_root = Path(directory)
        shadow_work_items = shadow_root / "work-items"
        shutil.copytree(work_items, shadow_work_items, symlinks=True)

        def shadow(path: Path) -> Path:
            return shadow_root / path.relative_to(repository)

        for plan in links:
            _atomic_write(shadow(plan["path"]), plan["after"])
        shadow_source = shadow(source)
        shadow_archive = shadow(archive)
        _atomic_write(shadow_source, source_after)
        shadow_archive.parent.mkdir(parents=True, exist_ok=True)
        os.replace(shadow_source, shadow_archive)
        transaction_token = _CURRENT_LIFECYCLE_TRANSACTION.set(None)
        composer_token = _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.set(None)
        try:
            rendered = render_readme_bytes(
                shadow_root, static_guide_override=static_guide
            )
        finally:
            _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.reset(composer_token)
            _CURRENT_LIFECYCLE_TRANSACTION.reset(transaction_token)
        return _sha256_bytes(rendered)


def _bug_supersession_receipt_payload(
    *,
    operation_id: str,
    terminal_instant: str,
    source_reference: str,
    source_path: str,
    archive_path: str,
    archived_bug_sha256: str,
    binding_data: bytes,
    binding: dict,
    inventory_data: bytes,
    links: list[dict],
    readme_sha256: str,
    expected_bug_sha256: str,
    expected_readme_sha256: str,
) -> dict:
    return {
        "schemaVersion": 1,
        "owner": BUG_SUPERSESSION_OWNER,
        "kind": BUG_SUPERSESSION_KIND,
        "status": "settled",
        "operationId": operation_id,
        "terminalInstant": terminal_instant,
        "sourceReference": source_reference,
        "sourcePath": source_path,
        "archivePath": archive_path,
        "archivedBugSha256": archived_bug_sha256,
        "successorBindingSha256": _sha256_bytes(binding_data),
        "successorRegistryReference": binding["registryReference"],
        "successorRecordReference": binding["recordReference"],
        "successorRecordSha256": binding["recordSha256"],
        "acceptedBy": binding["acceptedBy"],
        "acceptedAt": binding["acceptedAt"],
        "acceptanceEvidence": binding["acceptanceEvidence"],
        "incomingLinksInventorySha256": _sha256_bytes(inventory_data),
        "links": [
            {
                "path": row["pathRelative"] if "pathRelative" in row else row["path"],
                "beforeSha256": row["beforeSha256"],
                "afterSha256": row["afterSha256"],
            }
            for row in links
        ],
        "readmeSha256": readme_sha256,
        "requestExpectedBugSha256": expected_bug_sha256,
        "requestExpectedReadmeSha256": expected_readme_sha256,
    }


def _bug_supersession_replay(
    root: Path,
    slug: str,
    receipt_path: Path,
    successor_binding_data: bytes | None,
    incoming_links_inventory_data: bytes,
    terminal_instant: str,
    expected_bug_sha256: str,
    expected_readme_sha256: str,
    operation_id: str,
) -> dict:
    try:
        binding = _parse_bug_successor_binding_data(
            slug, successor_binding_data, operation_id
        )
        inventory = _parse_bug_supersession_inventory(
            incoming_links_inventory_data
        )
        receipt = _verify_bug_supersession_settlement(root, receipt_path)
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "bug supersession replay evidence differs",
        ) from exc
    inventory_links = [
        {
            "path": row["path"],
            "beforeSha256": row["beforeSha256"],
            "afterSha256": row["afterSha256"],
        }
        for row in inventory["links"]
    ]
    if (
        receipt["operationId"] != operation_id
        or receipt["terminalInstant"] != terminal_instant
        or receipt["sourceReference"] != f"bug:{slug}"
        or receipt["successorBindingSha256"]
        != _sha256_bytes(successor_binding_data or b"")
        or receipt["successorRegistryReference"] != binding["registryReference"]
        or receipt["successorRecordReference"] != binding["recordReference"]
        or receipt["successorRecordSha256"] != binding["recordSha256"]
        or receipt["acceptedBy"] != binding["acceptedBy"]
        or receipt["acceptedAt"] != binding["acceptedAt"]
        or receipt["acceptanceEvidence"] != binding["acceptanceEvidence"]
        or receipt["incomingLinksInventorySha256"]
        != _sha256_bytes(incoming_links_inventory_data)
        or receipt["links"] != inventory_links
        or receipt["requestExpectedBugSha256"] != expected_bug_sha256
        or receipt["requestExpectedReadmeSha256"] != expected_readme_sha256
        or inventory["operationId"] != operation_id
        or inventory["sourceReference"] != f"bug:{slug}"
        or inventory["sourceBugSha256"] != expected_bug_sha256
        or inventory["successorBindingSha256"]
        != _sha256_bytes(successor_binding_data or b"")
    ):
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "bug supersession replay inputs differ",
        )
    return receipt


def supersede_current_bug(
    root: Path,
    slug: str,
    successor_record: Path,
    successor_binding_data: bytes | None,
    terminal_instant: str,
    incoming_links_inventory_data: bytes,
    expected_bug_sha256: str,
    expected_readme_sha256: str,
    operation_id: str,
    *,
    inject_failure_at: str | None = None,
) -> dict:
    _validate_slug(slug)
    month = archive_month(terminal_instant)
    intent_path = _transition_intent_path(root, operation_id)
    work_items = _work_items_root(root)
    repository = work_items.parent
    source_reference = f"bug:{slug}"
    source = work_items / "bugs" / f"{slug}.md"
    archive = work_items / "bugs" / "archive" / month / f"{slug}.md"
    receipt = archive.with_name(f"{slug}.supersession-receipt.json")
    _recover_all_transitions(root)
    if receipt.is_file():
        return _bug_supersession_replay(
            root,
            slug,
            receipt,
            successor_binding_data,
            incoming_links_inventory_data,
            terminal_instant,
            expected_bug_sha256,
            expected_readme_sha256,
            operation_id,
        )
    binding, successor_snapshot = _parse_bug_successor_binding(
        slug, successor_record, successor_binding_data, operation_id
    )
    if (
        not isinstance(expected_bug_sha256, str)
        or not SHA256_RE.fullmatch(expected_bug_sha256)
        or not isinstance(expected_readme_sha256, str)
        or not SHA256_RE.fullmatch(expected_readme_sha256)
    ):
        raise LifecycleError(
            "WI-BUG-DISPOSITIONS-DRIFT", "bug supersession request hash differs"
        )
    locations = _category_locations(root, CATEGORIES["bug"], slug)
    if locations != [source]:
        failure_id = "WI-CATEGORY-DUAL-LOCATION" if locations else "WI-REFERENCE-MISSING"
        raise LifecycleError(failure_id, "bug supersession source is not uniquely current")
    if archive.exists() or receipt.exists():
        raise LifecycleError(
            "WI-CATEGORY-DUAL-LOCATION", "bug supersession archive or receipt already exists"
        )
    source_snapshot = _capture_file_snapshot(
        source, failure_id="WI-BUG-DISPOSITIONS-DRIFT"
    )
    if _sha256_bytes(source_snapshot.data) != expected_bug_sha256:
        raise LifecycleError(
            "WI-BUG-DISPOSITIONS-DRIFT", "bug supersession source hash differs"
        )
    fields = _parse_fields(source_snapshot.data.decode("utf-8"))
    current_status = fields.get("status", "")
    if current_status not in CATEGORIES["bug"].current_statuses:
        raise LifecycleError(
            "WI-BUG-DISPOSITIONS-DRIFT", "bug supersession source is not current"
        )
    readme = work_items / "README.md"
    readme_snapshot = _capture_file_snapshot(
        readme, failure_id="WI-README-STALE"
    )
    if _sha256_bytes(readme_snapshot.data) != expected_readme_sha256:
        raise LifecycleError("WI-README-STALE", "bug supersession README hash differs")
    binding_data = successor_binding_data or b""
    inventory = _parse_bug_supersession_inventory(incoming_links_inventory_data)
    if (
        inventory["operationId"] != operation_id
        or inventory["sourceReference"] != source_reference
        or inventory["sourceBugSha256"] != expected_bug_sha256
        or inventory["successorBindingSha256"] != _sha256_bytes(binding_data)
    ):
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            "bug successor inventory binding differs",
        )
    successor_reference = (
        f"{binding['registryReference']}#{binding['recordReference']}"
    )
    links = _prepare_bug_supersession_links(
        root,
        source,
        source_reference,
        successor_reference,
        inventory,
    )
    source_after = _terminal_bug_bytes(
        source_snapshot.data,
        current_status=current_status,
        terminal_status="superseded",
        terminal_instant=terminal_instant,
        resolution=f"Superseded by {successor_reference}.",
        evidence=binding["acceptanceEvidence"],
        successor=successor_reference,
    )
    _validate_flat_terminal(CATEGORIES["bug"], source_after)
    final_readme_sha256 = _precompute_single_bug_readme_sha256(
        root, source, archive, source_after, links
    )
    source_path = source.relative_to(repository).as_posix()
    archive_path = archive.relative_to(repository).as_posix()
    receipt_path = receipt.relative_to(repository).as_posix()
    receipt_payload = _bug_supersession_receipt_payload(
        operation_id=operation_id,
        terminal_instant=terminal_instant,
        source_reference=source_reference,
        source_path=source_path,
        archive_path=archive_path,
        archived_bug_sha256=_sha256_bytes(source_after),
        binding_data=binding_data,
        binding=binding,
        inventory_data=incoming_links_inventory_data,
        links=links,
        readme_sha256=final_readme_sha256,
        expected_bug_sha256=expected_bug_sha256,
        expected_readme_sha256=expected_readme_sha256,
    )
    receipt_after = _migration_receipt_bytes(receipt_payload)
    intent = {
        "schemaVersion": 1,
        "owner": BUG_SUPERSESSION_OWNER,
        "kind": BUG_SUPERSESSION_KIND,
        "status": "intent",
        "operationId": operation_id,
        "terminalInstant": terminal_instant,
        "sourcePath": source_path,
        "archivePath": archive_path,
        "receiptPath": receipt_path,
        "expectedReadmeSha256": expected_readme_sha256,
        "finalReadmeSha256": final_readme_sha256,
        "sourceBefore": _b64(source_snapshot.data),
        "sourceAfter": _b64(source_after),
        "receiptBefore": None,
        "receiptAfter": _b64(receipt_after),
        "successorBindingSha256": _sha256_bytes(binding_data),
        "successorRegistryReference": binding["registryReference"],
        "successorRecordReference": binding["recordReference"],
        "successorRecordSha256": binding["recordSha256"],
        "acceptedBy": binding["acceptedBy"],
        "acceptedAt": binding["acceptedAt"],
        "acceptanceEvidence": binding["acceptanceEvidence"],
        "incomingLinksInventorySha256": _sha256_bytes(
            incoming_links_inventory_data
        ),
        "links": [
            {
                "path": row["pathRelative"],
                "before": _b64(row["before"]),
                "after": _b64(row["after"]),
                "beforeSha256": row["beforeSha256"],
                "afterSha256": row["afterSha256"],
            }
            for row in links
        ],
    }
    _verify_captured_file(successor_snapshot, "WI-BUG-SUCCESSOR-BINDING")
    return _apply_single_bug_transition(
        root, source_snapshot, readme_snapshot, source, archive, source_after,
        links, intent_path, intent, inject_failure_at=inject_failure_at,
    )


def _single_bug_failure_id(intent: dict, phase: str) -> str:
    prefix = (
        "WI-FIXED-BUG" if intent["kind"] == FIXED_BUG_ARCHIVE_KIND
        else "WI-BUG-SUPERSESSION"
    )
    return f"{prefix}-{phase}-INDETERMINATE"


def _single_bug_transition_label(intent: dict) -> str:
    return "fixed-bug archive" if intent["kind"] == FIXED_BUG_ARCHIVE_KIND else "bug supersession"


def _apply_single_bug_transition(
    root: Path,
    source_snapshot: CapturedFileSnapshot,
    readme_snapshot: CapturedFileSnapshot,
    source: Path,
    archive: Path,
    source_after: bytes,
    links: list[dict],
    intent_path: Path,
    intent: dict,
    *,
    inject_failure_at: str | None,
) -> dict:
    rollback_id = _single_bug_failure_id(intent, "ROLLBACK")
    forward_id = _single_bug_failure_id(intent, "ROLLFORWARD")
    failpoint = "F" if intent["kind"] == FIXED_BUG_ARCHIVE_KIND else "B"
    preflight_id = (
        "WI-BUG-DISPOSITIONS-DRIFT" if intent["kind"] == BUG_SUPERSESSION_KIND
        else "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING"
    )
    readme_preflight_id = (
        "WI-BUG-DISPOSITIONS-DRIFT" if intent["kind"] == BUG_SUPERSESSION_KIND
        else "WI-README-STALE"
    )
    _verify_captured_file(source_snapshot, preflight_id)
    _verify_captured_file(readme_snapshot, readme_preflight_id)
    for row in links:
        if _read_lifecycle_image(row["path"], row["before"], failure_id=rollback_id) != row["before"]:
            raise LifecycleError(rollback_id, f"bug link drifted: {row['pathRelative']}")
    _atomic_write(intent_path, _migration_receipt_bytes(intent))
    _transition_fsync_directory(intent_path.parent)
    if inject_failure_at == f"{failpoint}0":
        raise LifecycleError(rollback_id, f"injected {failpoint}0")
    for row in links:
        if _read_lifecycle_image(row["path"], row["before"], failure_id=rollback_id) != row["before"]:
            raise LifecycleError(rollback_id, f"bug link drifted: {row['pathRelative']}")
        _atomic_write(row["path"], row["after"])
    if inject_failure_at == f"{failpoint}1":
        raise LifecycleError(rollback_id, f"injected {failpoint}1")
    _verify_captured_file(source_snapshot, rollback_id)
    _atomic_write(source, source_after)
    if inject_failure_at == f"{failpoint}2":
        raise LifecycleError(rollback_id, f"injected {failpoint}2")
    archive.parent.mkdir(parents=True, exist_ok=True)
    os.replace(source, archive)
    if inject_failure_at == f"{failpoint}3":
        raise LifecycleError(forward_id, f"injected {failpoint}3")
    return _recover_single_bug_transition(
        root, intent_path, intent, inject_failure_at=inject_failure_at,
    )


def _fixed_bug_terminal_image(
    source: bytes, slug: str, terminal_instant: str, resolution: str, evidence: str,
    root: Path,
) -> bytes:
    for label, value in (("resolution", resolution), ("evidence", evidence)):
        if not value or len(value) > 4096 or any(character in value for character in "\r\n\x00"):
            raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", f"{label} must be one bounded line")
    try:
        text = source.decode("utf-8")
    except UnicodeError as exc:
        raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "bug record must be UTF-8") from exc
    occurrences = _authoritative_field_occurrences(text)
    by_name: dict[str, list[str]] = {}
    for _line, name, value, _raw in occurrences:
        by_name.setdefault(name, []).append(value)
    for name in ("id", "context", "status", "terminal-at", "resolution", "evidence"):
        if len(by_name.get(name, [])) > 1:
            raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", f"duplicate bug {name} field")
    if by_name.get("id") != [slug] or by_name.get("status") != ["fixed"]:
        raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "bug identity or fixed status differs")
    context = by_name.get("context", [""])[0]
    if not SLUG_RE.fullmatch(context):
        raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "bug context is not a work-item slug")
    parent = _work_items_root(root) / "active" / context
    if _category_locations(root, CATEGORIES["work-item"], context) != [parent]:
        raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "bug parent is not uniquely active")
    required = {"terminal-at": terminal_instant, "resolution": resolution, "evidence": evidence}
    for name, value in required.items():
        if name in by_name and by_name[name] != [value]:
            raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", f"bug {name} conflicts with request")
    additions = [f"- {name}: {value}\n" for name, value in required.items() if name not in by_name]
    after = source + ((b"\n" if source and not source.endswith(b"\n") else b"") + "".join(additions).encode("utf-8") if additions else b"")
    if _validate_flat_terminal(CATEGORIES["bug"], after) != terminal_instant:
        raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "bug terminal instant differs")
    return after


def _physical_archive_link_plans(
    root: Path, source: Path, archive: Path, references: list[dict],
    *, failure_id: str,
) -> list[dict]:
    repository = _work_items_root(root).parent
    physical_paths: set[str] = set()
    for row in references:
        if row["kind"] != "physical":
            continue
        if "archive" in PurePosixPath(row["consumer"]).parts:
            raise LifecycleError(failure_id, "immutable archived consumer has a physical link")
        physical_paths.add(row["consumer"])
    plans: list[dict] = []
    for relative in sorted(physical_paths):
        consumer = _work_items_root(root) / relative
        snapshot = _capture_file_snapshot(consumer, failure_id=failure_id)
        text = snapshot.data.decode("utf-8")
        replacements: list[tuple[int, int, str]] = []
        for link in _markdown_local_links(text):
            if _markdown_href_resolves(consumer.parent, link.href, source):
                parts = _local_markdown_href_parts(link.href)
                if parts is None:
                    raise LifecycleError(failure_id, f"unclassifiable link: {relative}")
                href = os.path.relpath(archive, consumer.parent).replace(os.sep, "/") + parts[1]
                replacements.append((link.href_start, link.href_end, href))
        if not replacements:
            raise LifecycleError(failure_id, f"physical link has no safe rewrite: {relative}")
        for start, end, href in reversed(replacements):
            text = text[:start] + href + text[end:]
        after = text.encode("utf-8")
        plans.append({
            "path": consumer,
            "pathRelative": consumer.relative_to(repository).as_posix(),
            "before": snapshot.data,
            "after": after,
            "beforeSha256": _sha256_bytes(snapshot.data),
            "afterSha256": _sha256_bytes(after),
        })
    return plans


def _fixed_bug_link_plans(root: Path, source: Path, archive: Path, slug: str) -> list[dict]:
    references = _incoming_link_result(
        root, {source}, f"bug:{slug}", strict_consumer_reads=True,
    )["references"]
    return _physical_archive_link_plans(
        root, source, archive, references, failure_id="WI-FIXED-BUG-LINK-INVENTORY"
    )


def archive_fixed_bug(
    root: Path, slug: str, terminal_instant: str, resolution: str, evidence: str,
    *, inject_failure_at: str | None = None,
) -> dict:
    _validate_slug(slug)
    month = archive_month(terminal_instant)
    work_items = _work_items_root(root)
    repository = work_items.parent
    source = work_items / "bugs" / f"{slug}.md"
    archive = work_items / "bugs" / "archive" / month / f"{slug}.md"
    receipt = archive.with_name(f"{slug}.fixed-archive-receipt.json")
    _recover_all_transitions(root)
    locations = _category_locations(root, CATEGORIES["bug"], slug)
    if locations == [archive] and receipt.is_file():
        settled = _verify_fixed_bug_archive_settlement(root, receipt)
        fields = _parse_fields(archive.read_text(encoding="utf-8"))
        if (settled["terminalInstant"], fields.get("resolution"), fields.get("evidence")) != (
            terminal_instant, resolution, evidence,
        ):
            raise LifecycleError("WI-FIXED-BUG-SETTLEMENT-MISMATCH", "fixed bug replay request differs")
        return settled
    if locations != [source] or archive.exists() or receipt.exists():
        failure_id = "WI-CATEGORY-DUAL-LOCATION" if locations else "WI-REFERENCE-MISSING"
        raise LifecycleError(failure_id, "fixed bug source is not uniquely current")
    source_snapshot = _capture_file_snapshot(source, failure_id="WI-CATEGORY-TERMINAL-EVIDENCE-MISSING")
    source_after = _fixed_bug_terminal_image(
        source_snapshot.data, slug, terminal_instant, resolution, evidence, root,
    )
    links = _fixed_bug_link_plans(root, source, archive, slug)
    readme_snapshot = _capture_file_snapshot(work_items / "README.md", failure_id="WI-README-STALE")
    final_readme_sha256 = _precompute_single_bug_readme_sha256(
        root, source, archive, source_after, links,
    )
    operation_id = f"fixed-bug-{uuid.uuid4().hex}"
    intent_path = _transition_intent_path(root, operation_id)
    if os.path.lexists(intent_path):
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "fixed bug intent identity collides")
    source_path = source.relative_to(repository).as_posix()
    archive_path = archive.relative_to(repository).as_posix()
    receipt_path = receipt.relative_to(repository).as_posix()
    receipt_payload = {
        "schemaVersion": 1, "owner": FIXED_BUG_ARCHIVE_OWNER,
        "kind": FIXED_BUG_ARCHIVE_KIND, "status": "settled",
        "operationId": operation_id, "sourceReference": f"bug:{slug}",
        "sourcePath": source_path, "archivePath": archive_path,
        "terminalInstant": terminal_instant,
        "sourceBeforeSha256": _sha256_bytes(source_snapshot.data),
        "archivedBugSha256": _sha256_bytes(source_after),
        "links": [
            {"path": row["pathRelative"], "beforeSha256": row["beforeSha256"],
             "afterSha256": row["afterSha256"]}
            for row in links
        ],
        "readmeSha256": final_readme_sha256,
    }
    intent = {
        "schemaVersion": 1, "owner": FIXED_BUG_ARCHIVE_OWNER,
        "kind": FIXED_BUG_ARCHIVE_KIND, "status": "intent",
        "operationId": operation_id, "terminalInstant": terminal_instant,
        "sourcePath": source_path, "archivePath": archive_path,
        "receiptPath": receipt_path,
        "expectedReadmeSha256": _sha256_bytes(readme_snapshot.data),
        "finalReadmeSha256": final_readme_sha256,
        "sourceBefore": _b64(source_snapshot.data), "sourceAfter": _b64(source_after),
        "receiptBefore": None,
        "receiptAfter": _b64(_migration_receipt_bytes(receipt_payload)),
        "links": [
            {"path": row["pathRelative"], "before": _b64(row["before"]),
             "after": _b64(row["after"]), "beforeSha256": row["beforeSha256"],
             "afterSha256": row["afterSha256"]}
            for row in links
        ],
    }
    return _apply_single_bug_transition(
        root, source_snapshot, readme_snapshot, source, archive, source_after,
        links, intent_path, intent, inject_failure_at=inject_failure_at,
    )


def _transition_intent_path(root: Path, operation_id: str) -> Path:
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", operation_id, re.ASCII) is None:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "invalid transition operation id")
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    return repository / ".scratch" / "work-items-lifecycle-transitions" / f"{operation_id}.json"


def _transition_fsync_directory(path: Path) -> None:
    descriptor = None
    native_handle = None
    try:
        if os.name == "nt":
            import ctypes
            import ctypes.wintypes
            import msvcrt

            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            create_file = kernel32.CreateFileW
            create_file.argtypes = [
                ctypes.wintypes.LPCWSTR, ctypes.wintypes.DWORD, ctypes.wintypes.DWORD,
                ctypes.wintypes.LPVOID, ctypes.wintypes.DWORD, ctypes.wintypes.DWORD,
                ctypes.wintypes.HANDLE,
            ]
            create_file.restype = ctypes.wintypes.HANDLE
            native_handle = create_file(
                str(path), 0x40000000, 0x00000001 | 0x00000002 | 0x00000004,
                None, 3, 0x02000000 | 0x00200000, None,
            )
            if native_handle == ctypes.wintypes.HANDLE(-1).value:
                native_handle = None
                raise OSError(ctypes.get_last_error(), "cannot open transition directory")
            descriptor = msvcrt.open_osfhandle(native_handle, os.O_RDWR)
            native_handle = None
        else:
            descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0))
        if not stat.S_ISDIR(os.fstat(descriptor).st_mode):
            raise OSError(errno.ENOTDIR, "transition parent is not a directory")
        os.fsync(descriptor)
    except OSError as exc:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "transition directory cannot be durably synced") from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
        elif native_handle is not None:
            import ctypes
            ctypes.WinDLL("kernel32", use_last_error=True).CloseHandle(native_handle)


def _intent_path(root: Path, relative: str) -> Path:
    pure = Path(relative)
    if pure.is_absolute() or ".." in pure.parts:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "intent path is not repository-relative")
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    path = repository.joinpath(*pure.parts)
    return _require_lifecycle_mutation_path(
        repository, path, failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID"
    )



def _verify_bug_supersession_settlement(
    root: Path,
    receipt_path: Path,
    expected_bytes: bytes | None = None,
) -> dict:
    receipt_path = _require_lifecycle_mutation_path(
        root,
        receipt_path,
        failure_id="WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
    )
    payload, receipt_bytes = _ledger_location_proof_object(
        receipt_path,
        failure_id="WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
        unreadable="bug supersession receipt is unreadable",
    )
    if (
        not isinstance(payload, dict)
        or set(payload) != BUG_SUPERSESSION_RECEIPT_FIELDS
        or payload.get("schemaVersion") != 1
        or payload.get("owner") != BUG_SUPERSESSION_OWNER
        or payload.get("kind") != BUG_SUPERSESSION_KIND
        or payload.get("status") != "settled"
        or not isinstance(payload.get("links"), list)
        or any(
            not isinstance(payload.get(key), str)
            for key in BUG_SUPERSESSION_RECEIPT_FIELDS - {"schemaVersion", "links"}
        )
    ):
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "bug supersession receipt shape differs",
        )
    try:
        category, slug = _canonical_category(payload["sourceReference"])
        month = archive_month(payload["terminalInstant"])
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "bug supersession receipt identity differs",
        ) from exc
    repository = _work_items_root(root).parent
    expected_source = repository / "work-items" / "bugs" / f"{slug}.md"
    expected_archive = (
        repository
        / "work-items"
        / "bugs"
        / "archive"
        / month
        / f"{slug}.md"
    )
    expected_receipt = expected_archive.with_name(
        f"{slug}.supersession-receipt.json"
    )
    if (
        category.name != "bug"
        or payload["sourcePath"] != expected_source.relative_to(repository).as_posix()
        or payload["archivePath"] != expected_archive.relative_to(repository).as_posix()
        or receipt_path.resolve() != expected_receipt.resolve()
        or expected_source.exists()
        or not SHA256_RE.fullmatch(payload["archivedBugSha256"])
        or not SHA256_RE.fullmatch(payload["successorBindingSha256"])
        or not SHA256_RE.fullmatch(payload["successorRecordSha256"])
        or not SHA256_RE.fullmatch(payload["incomingLinksInventorySha256"])
        or not SHA256_RE.fullmatch(payload["readmeSha256"])
        or not SHA256_RE.fullmatch(payload["requestExpectedBugSha256"])
        or not SHA256_RE.fullmatch(payload["requestExpectedReadmeSha256"])
    ):
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "bug supersession receipt binding differs",
        )
    try:
        archived = _capture_file_snapshot(
            expected_archive,
            failure_id="WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
        )
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "archived bug identity differs",
        ) from exc
    try:
        fields = _parse_fields(archived.data.decode("utf-8"))
    except UnicodeError as exc:
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "archived bug is not UTF-8",
        ) from exc
    successor_reference = (
        f"{payload['successorRegistryReference']}#{payload['successorRecordReference']}"
    )
    if (
        _sha256_bytes(archived.data) != payload["archivedBugSha256"]
        or fields.get("status") != "superseded"
        or fields.get("terminal-at") != payload["terminalInstant"]
        or fields.get("successor") != successor_reference
        or fields.get("evidence") != payload["acceptanceEvidence"]
    ):
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "archived bug settlement differs",
        )
    link_paths: list[str] = []
    for row in payload["links"]:
        if (
            not isinstance(row, dict)
            or set(row) != {"path", "beforeSha256", "afterSha256"}
            or not isinstance(row.get("path"), str)
            or not isinstance(row.get("beforeSha256"), str)
            or not SHA256_RE.fullmatch(row["beforeSha256"])
            or not isinstance(row.get("afterSha256"), str)
            or not SHA256_RE.fullmatch(row["afterSha256"])
        ):
            raise LifecycleError(
                "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
                "bug supersession receipt link row differs",
            )
        link_paths.append(row["path"])
        path = _intent_path(root, row["path"])
        if _ledger_location_regular_sha256(
            path,
            failure_id="WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
        ) != row["afterSha256"]:
            raise LifecycleError(
                "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
                f"bug supersession settled link differs: {row['path']}",
            )
    readme = _work_items_root(root) / "README.md"
    if (
        link_paths != sorted(link_paths)
        or len(link_paths) != len(set(link_paths))
        or _ledger_location_regular_sha256(
            readme,
            failure_id="WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
        ) != payload["readmeSha256"]
        or (expected_bytes is not None and receipt_bytes != expected_bytes)
    ):
        raise LifecycleError(
            "WI-BUG-SUPERSESSION-SETTLEMENT-MISMATCH",
            "bug supersession settled bytes differ",
        )
    return payload


def _verify_fixed_bug_archive_settlement(
    root: Path, receipt_path: Path, expected_bytes: bytes | None = None,
) -> dict:
    failure_id = "WI-FIXED-BUG-SETTLEMENT-MISMATCH"
    receipt_path = _require_lifecycle_mutation_path(root, receipt_path, failure_id=failure_id)
    payload, receipt_bytes = _ledger_location_proof_object(
        receipt_path, failure_id=failure_id, unreadable="fixed bug receipt is unreadable",
    )
    if (
        not isinstance(payload, dict)
        or set(payload) != FIXED_BUG_ARCHIVE_RECEIPT_FIELDS
        or payload.get("schemaVersion") != 1
        or payload.get("owner") != FIXED_BUG_ARCHIVE_OWNER
        or payload.get("kind") != FIXED_BUG_ARCHIVE_KIND
        or payload.get("status") != "settled"
        or not isinstance(payload.get("links"), list)
        or any(not isinstance(payload.get(key), str)
               for key in FIXED_BUG_ARCHIVE_RECEIPT_FIELDS - {"schemaVersion", "links"})
    ):
        raise LifecycleError(failure_id, "fixed bug receipt shape differs")
    try:
        category, slug = _canonical_category(payload["sourceReference"])
        month = archive_month(payload["terminalInstant"])
    except LifecycleError as exc:
        raise LifecycleError(failure_id, "fixed bug receipt identity differs") from exc
    repository = _work_items_root(root).parent
    source = repository / "work-items" / "bugs" / f"{slug}.md"
    archive = repository / "work-items" / "bugs" / "archive" / month / f"{slug}.md"
    receipt = archive.with_name(f"{slug}.fixed-archive-receipt.json")
    if (
        category.name != "bug"
        or payload["sourcePath"] != source.relative_to(repository).as_posix()
        or payload["archivePath"] != archive.relative_to(repository).as_posix()
        or receipt_path.resolve() != receipt.resolve()
        or _category_locations(root, CATEGORIES["bug"], slug) != [archive]
        or any(not SHA256_RE.fullmatch(payload[key]) for key in (
            "sourceBeforeSha256", "archivedBugSha256", "readmeSha256"
        ))
    ):
        raise LifecycleError(failure_id, "fixed bug receipt binding differs")
    archived = _capture_file_snapshot(archive, failure_id=failure_id)
    try:
        fields = _parse_fields(archived.data.decode("utf-8"))
    except UnicodeError as exc:
        raise LifecycleError(failure_id, "archived bug is not UTF-8") from exc
    if (
        _sha256_bytes(archived.data) != payload["archivedBugSha256"]
        or fields.get("id") != slug
        or fields.get("status") != "fixed"
        or fields.get("terminal-at") != payload["terminalInstant"]
        or not fields.get("context")
        or not fields.get("resolution")
        or not fields.get("evidence")
    ):
        raise LifecycleError(failure_id, "archived fixed bug differs")
    paths: list[str] = []
    for row in payload["links"]:
        if (
            not isinstance(row, dict)
            or set(row) != {"path", "beforeSha256", "afterSha256"}
            or not isinstance(row.get("path"), str)
            or not isinstance(row.get("beforeSha256"), str)
            or not isinstance(row.get("afterSha256"), str)
            or not SHA256_RE.fullmatch(row["beforeSha256"])
            or not SHA256_RE.fullmatch(row["afterSha256"])
        ):
            raise LifecycleError(failure_id, "fixed bug receipt link row differs")
        paths.append(row["path"])
        consumer = _intent_path(root, row["path"])
        if _ledger_location_regular_sha256(consumer, failure_id=failure_id) != row["afterSha256"]:
            raise LifecycleError(failure_id, f"fixed bug settled link differs: {row['path']}")
    if (
        paths != sorted(paths) or len(paths) != len(set(paths))
        or _ledger_location_regular_sha256(
            _work_items_root(root) / "README.md", failure_id=failure_id,
        ) != payload["readmeSha256"]
        or (expected_bytes is not None and receipt_bytes != expected_bytes)
    ):
        raise LifecycleError(failure_id, "fixed bug settled bytes differ")
    return payload


def _bug_supersession_intent_links(root: Path, intent: dict) -> list[dict]:
    result: list[dict] = []
    for row in intent["links"]:
        before = _unb64(row["before"])
        after = _unb64(row["after"])
        if before is None or after is None:
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
                f"{_single_bug_transition_label(intent)} intent link image is absent",
            )
        result.append(
            {
                "path": _intent_path(root, row["path"]),
                "pathRelative": row["path"],
                "before": before,
                "after": after,
                "beforeSha256": row["beforeSha256"],
                "afterSha256": row["afterSha256"],
            }
        )
    return result


def _recover_single_bug_transition(
    root: Path,
    intent_path: Path,
    intent: dict,
    *,
    inject_failure_at: str | None = None,
) -> dict | None:
    label = _single_bug_transition_label(intent)
    source = _intent_path(root, intent["sourcePath"])
    archive = _intent_path(root, intent["archivePath"])
    receipt = _intent_path(root, intent["receiptPath"])
    source_before = _unb64(intent["sourceBefore"])
    source_after = _unb64(intent["sourceAfter"])
    receipt_before = _unb64(intent["receiptBefore"])
    receipt_after = _unb64(intent["receiptAfter"])
    if source_before is None or source_after is None or receipt_after is None:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            f"{label} intent image is absent",
        )
    links = _bug_supersession_intent_links(root, intent)
    rollback_id = _single_bug_failure_id(intent, "ROLLBACK")
    forward_id = _single_bug_failure_id(intent, "ROLLFORWARD")
    failpoint = "F" if intent["kind"] == FIXED_BUG_ARCHIVE_KIND else "B"
    failure_id = rollback_id
    current_source = _read_lifecycle_image(
        source,
        source_before,
        source_after,
        failure_id=failure_id,
    )
    source_exists = current_source is not None
    archive_exists = archive.is_file()
    if source_exists:
        if archive_exists or current_source not in {source_before, source_after}:
            raise LifecycleError(
                rollback_id,
                f"{label} rollback identity differs",
            )
        for row in links:
            if _read_lifecycle_image(
                row["path"],
                row["before"],
                row["after"],
                failure_id=failure_id,
            ) not in {
                row["before"], row["after"]
            }:
                raise LifecycleError(
                    rollback_id,
                    f"{label} rollback link differs: {row['pathRelative']}",
                )
        current_receipt = _read_lifecycle_image(
            receipt,
            receipt_before,
            receipt_after,
            failure_id=failure_id,
            require_single_link=True,
        )
        if current_receipt not in {receipt_before, receipt_after}:
            raise LifecycleError(
                rollback_id,
                f"{label} rollback receipt differs",
            )
        for row in links:
            _atomic_write(row["path"], row["before"])
        _atomic_write(source, source_before)
        if receipt_before is None:
            receipt.unlink(missing_ok=True)
        else:
            _atomic_write(receipt, receipt_before)
        intent_path.unlink()
        return None
    failure_id = forward_id
    if not archive_exists:
        raise LifecycleError(
            forward_id,
            f"{label} commit identity is absent",
        )
    if _read_lifecycle_image(archive, source_after, failure_id=failure_id) != source_after:
        raise LifecycleError(
            forward_id,
            f"{label} archive image differs",
        )
    for row in links:
        if _read_lifecycle_image(row["path"], row["after"], failure_id=failure_id) != row["after"]:
            raise LifecycleError(
                forward_id,
                f"{label} roll-forward link differs: {row['pathRelative']}",
            )
    current_receipt = _read_lifecycle_image(
        receipt,
        receipt_before,
        receipt_after,
        failure_id=failure_id,
        require_single_link=True,
    )
    if current_receipt not in {receipt_before, receipt_after}:
        raise LifecycleError(
                forward_id,
            f"{label} roll-forward receipt differs",
        )
    try:
        readme_sha256 = _safe_refresh_readme(root)
    except (LifecycleError, OSError) as exc:
        if intent["kind"] == FIXED_BUG_ARCHIVE_KIND:
            raise LifecycleError(forward_id, "fixed bug README refresh failed") from exc
        raise
    if readme_sha256 != intent["finalReadmeSha256"]:
        raise LifecycleError(
            forward_id,
            f"{label} README afterimage differs",
        )
    if inject_failure_at == f"{failpoint}4":
        raise LifecycleError(
            forward_id, f"injected {failpoint}4"
        )
    if current_receipt is None:
        _atomic_write(receipt, receipt_after)
        _transition_fsync_directory(receipt.parent)
    if inject_failure_at == f"{failpoint}5":
        raise LifecycleError(
            forward_id, f"injected {failpoint}5"
        )
    if intent["kind"] == FIXED_BUG_ARCHIVE_KIND:
        settled = _verify_fixed_bug_archive_settlement(root, receipt, receipt_after)
    else:
        settled = _verify_bug_supersession_settlement(root, receipt, receipt_after)
    if inject_failure_at == f"{failpoint}6":
        raise LifecycleError(
            forward_id, f"injected {failpoint}6"
        )
    intent_path.unlink()
    if inject_failure_at == f"{failpoint}7":
        raise LifecycleError(
            forward_id, f"injected {failpoint}7"
        )
    return settled


def _load_transition_intent(root: Path, path: Path) -> dict:
    try:
        snapshot = _capture_file_snapshot(
            path,
            failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            maximum_bytes=TRANSITION_INTENT_FILE_BYTE_CAP,
            require_single_link=True,
        )
        payload = json.loads(snapshot.data.decode("utf-8", errors="strict"))
    except LifecycleError:
        raise
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "transition intent is unreadable",
        ) from exc
    is_v1 = (
        isinstance(payload, dict)
        and set(payload) == TRANSITION_INTENT_FIELDS
        and payload.get("schemaVersion") == 1
        and payload.get("owner") == TRANSITION_OWNER
    )
    is_v2 = (
        isinstance(payload, dict)
        and set(payload) == TRANSFER_TRANSITION_INTENT_FIELDS
        and payload.get("schemaVersion") == 2
        and payload.get("owner") == TRANSFER_TRANSITION_OWNER
        and isinstance(payload.get("obligations"), list)
    )
    is_legacy_v2 = (
        isinstance(payload, dict)
        and set(payload) == LEGACY_TRANSFER_TRANSITION_INTENT_FIELDS
        and payload.get("schemaVersion") == 2
        and payload.get("owner") == TRANSFER_TRANSITION_OWNER
        and isinstance(payload.get("obligations"), list)
    )
    is_bug_supersession = (
        isinstance(payload, dict)
        and set(payload) == BUG_SUPERSESSION_INTENT_FIELDS
        and payload.get("schemaVersion") == 1
        and payload.get("owner") == BUG_SUPERSESSION_OWNER
        and payload.get("kind") == BUG_SUPERSESSION_KIND
        and isinstance(payload.get("links"), list)
    )
    is_fixed_bug_archive = (
        isinstance(payload, dict)
        and set(payload) == FIXED_BUG_ARCHIVE_INTENT_FIELDS
        and payload.get("schemaVersion") == 1
        and payload.get("owner") == FIXED_BUG_ARCHIVE_OWNER
        and payload.get("kind") == FIXED_BUG_ARCHIVE_KIND
        and isinstance(payload.get("links"), list)
    )
    is_ledger_h1_relocation = (
        isinstance(payload, dict)
        and set(payload) == LEDGER_H1_RELOCATION_INTENT_FIELDS
        and payload.get("schemaVersion") == 1
        and payload.get("owner") == LEDGER_H1_RELOCATION_OWNER
        and payload.get("kind") == LEDGER_H1_RELOCATION_KIND
        and isinstance(payload.get("members"), list)
    )
    is_successor_import = (
        isinstance(payload, dict)
        and set(payload) == SUCCESSOR_IMPORT_INTENT_FIELDS
        and payload.get("schemaVersion") == 1
        and payload.get("owner") == SUCCESSOR_IMPORT_OWNER
        and payload.get("kind") == SUCCESSOR_IMPORT_KIND
    )
    if is_successor_import:
        _validate_successor_import_intent(root, path, payload, snapshot.data)
        return payload
    if (
        not (
            is_v1
            or is_v2
            or is_legacy_v2
            or is_bug_supersession
            or is_fixed_bug_archive
            or is_ledger_h1_relocation
        )
        or payload.get("status") != "intent"
        or (
            not (is_bug_supersession or is_fixed_bug_archive or is_ledger_h1_relocation)
            and not isinstance(payload.get("bugs"), list)
        )
    ):
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "transition intent shape differs")
    if is_bug_supersession or is_fixed_bug_archive:
        label = _single_bug_transition_label(payload)
        for key in ("sourcePath", "archivePath", "receiptPath"):
            if not isinstance(payload[key], str):
                raise LifecycleError(
                    "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
                    f"{label} intent path differs",
                )
            _intent_path(root, payload[key])
        paths: list[str] = []
        for row in payload["links"]:
            if (
                not isinstance(row, dict)
                or set(row) != BUG_SUPERSESSION_LINK_INTENT_FIELDS
                or not isinstance(row.get("path"), str)
                or not isinstance(row.get("before"), str)
                or not isinstance(row.get("after"), str)
                or not isinstance(row.get("beforeSha256"), str)
                or not SHA256_RE.fullmatch(row["beforeSha256"])
                or not isinstance(row.get("afterSha256"), str)
                or not SHA256_RE.fullmatch(row["afterSha256"])
            ):
                raise LifecycleError(
                    "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
                    f"{label} intent link differs",
                )
            paths.append(row["path"])
            _intent_path(root, row["path"])
        if paths != sorted(paths) or len(paths) != len(set(paths)):
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
                f"{label} intent links are not sorted and unique",
            )
        return payload
    if is_ledger_h1_relocation:
        _validate_ledger_h1_relocation_intent_shape(root, payload, path)
        return payload
    for key in ("activePath", "archivePath", "successorPath"):
        if payload[key] is not None:
            _intent_path(root, payload[key])
    if is_v2:
        _validate_transfer_migration_receipt_bindings(
            root,
            payload["archivePath"],
            payload["migrationReceipts"],
            failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
        )
    elif payload["migrationReceiptPath"] is not None:
        _intent_path(root, payload["migrationReceiptPath"])
    return payload


def _read_lifecycle_image(
    path: Path,
    *known_images: bytes | None,
    failure_id: str,
    require_single_link: bool = False,
) -> bytes | None:
    """Capture an optional file within its known intent-image length envelope."""
    _lifecycle_reject_unreduced_reparse(
        path, failure_id=failure_id, message="lifecycle image crosses a link or reparse point"
    )
    try:
        path.lstat()
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise LifecycleError(failure_id, "lifecycle image cannot be inspected") from exc
    maximum_bytes = max(
        (len(image) for image in known_images if image is not None), default=0
    )
    return _capture_file_snapshot(
        path, failure_id=failure_id, maximum_bytes=maximum_bytes,
        require_single_link=require_single_link,
    ).data


def _ledger_location_proof_object(
    path: Path,
    *,
    failure_id: str,
    unreadable: str,
    maximum_bytes: int = LEDGER_LOCATION_PROOF_BYTE_CAP,
) -> tuple[dict, bytes]:
    def reject_duplicate_pairs(pairs: list[tuple[str, object]]) -> dict:
        value: dict[str, object] = {}
        for key, item in pairs:
            if key in value:
                raise LifecycleError(
                    failure_id, "ledger location proof repeats a JSON key"
                )
            value[key] = item
        return value

    try:
        raw = _capture_file_snapshot(
            path,
            failure_id=failure_id,
            maximum_bytes=maximum_bytes,
            require_single_link=True,
        ).data
        payload = json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=reject_duplicate_pairs,
        )
    except LifecycleError:
        raise
    except (OSError, ValueError, RecursionError) as exc:
        raise LifecycleError(failure_id, unreadable) from exc
    if not isinstance(payload, dict):
        raise LifecycleError(
            failure_id, "ledger location proof is not one JSON object"
        )
    return payload, raw


def _ledger_location_lexically_exists(path: Path) -> bool:
    try:
        path.lstat()
    except FileNotFoundError:
        return False
    except OSError as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE",
            "ledger location identity cannot be inspected",
        ) from exc
    return True


def _ledger_location_regular_sha256(
    path: Path, *, failure_id: str, maximum_bytes: int | None = None
) -> str:
    maximum_bytes = (
        LEDGER_LOCATION_PROOF_BYTE_CAP if maximum_bytes is None else maximum_bytes
    )
    if type(maximum_bytes) is not int or maximum_bytes < 0:
        raise LifecycleError(failure_id, "ledger location byte limit is invalid")
    _lifecycle_reject_unreduced_reparse(
        path,
        failure_id=failure_id,
        message="ledger location path crosses a link or reparse point",
    )
    parent_chain = _capture_path_parent_chain(path, failure_id)
    descriptor = -1
    try:
        observed = path.lstat()
        if (
            not stat.S_ISREG(observed.st_mode)
            or observed.st_size > maximum_bytes
            or _lifecycle_path_has_reparse(path)
        ):
            raise OSError("ledger location is not a bounded regular file")
        descriptor = _open_readonly_nofollow(path)
        with os.fdopen(descriptor, "rb", closefd=True) as stream:
            descriptor = -1  # The stream now owns the descriptor, including failure exits.
            before = os.fstat(stream.fileno())
            before_key = _lifecycle_file_snapshot_key(before)
            if before_key[:5] != _lifecycle_file_snapshot_key(observed)[:5]:
                raise OSError("ledger location descriptor differs from its pathname")
            digests = []
            # Match snapshot capture's content check without retaining either image.
            for pass_index in range(2):
                if pass_index:
                    stream.seek(0)
                digest = hashlib.sha256()
                total = 0
                while True:
                    chunk = stream.read(min(64 * 1024, maximum_bytes - total + 1))
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > maximum_bytes:
                        raise OSError("ledger location exceeds its byte limit")
                    digest.update(chunk)
                if (
                    total != before.st_size
                    or _lifecycle_file_snapshot_key(os.fstat(stream.fileno()))
                    != before_key
                ):
                    raise OSError("ledger location changed while hashing")
                digests.append(digest.hexdigest())
        current = path.lstat()
        if (
            digests[0] != digests[1]
            or _lifecycle_file_snapshot_key(observed)
            != _lifecycle_file_snapshot_key(current)
            or _lifecycle_path_has_reparse(path)
        ):
            raise OSError("ledger location identity or content changed")
    except OSError as exc:
        raise LifecycleError(failure_id, "ledger location digest cannot be captured") from exc
    finally:
        if descriptor >= 0:
            os.close(descriptor)
    _verify_captured_parent_chain(parent_chain, failure_id)
    return digests[0]


def _migration_receipt_bindings_at(
    root: Path,
    archive: Path,
    *,
    failure_id: str,
) -> tuple[dict[str, str], ...]:
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    receipt_root = archive / "ledger-migration-receipts"
    if not _ledger_location_lexically_exists(receipt_root):
        return ()
    _lifecycle_reject_unreduced_reparse(
        receipt_root,
        failure_id=failure_id,
        message="migration receipt root crosses a link or reparse point",
    )
    if not receipt_root.is_dir():
        raise LifecycleError(failure_id, "migration receipt root is not a directory")
    receipts = sorted(
        receipt_root.glob("*.json"),
        key=lambda path: path.relative_to(repository).as_posix().encode("utf-8"),
    )
    rows = tuple(
        {
            "path": receipt.relative_to(repository).as_posix(),
            "sha256": _ledger_location_regular_sha256(
                receipt,
                failure_id=failure_id,
            ),
        }
        for receipt in receipts
    )
    _validate_transfer_migration_receipt_bindings(
        root,
        archive.relative_to(repository).as_posix(),
        list(rows),
        failure_id=failure_id,
    )
    return rows


def _ledger_location_archive_relative(slug: str, terminal_instant: object) -> str:
    if not isinstance(terminal_instant, str):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "ledger location terminal instant has the wrong type",
        )
    try:
        month = archive_month(terminal_instant)
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "ledger location terminal instant is invalid",
        ) from exc
    return f"work-items/archive/{month}/{slug}"


def _validate_ledger_location_intent(
    root: Path,
    path: Path,
    payload: dict,
    *,
    slug: str,
    logical_work_item: str,
) -> None:
    try:
        loaded = _load_transition_intent(root, path)
    except (LifecycleError, TypeError, ValueError) as exc:
        if isinstance(exc, LifecycleError):
            raise
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "ledger location intent value type differs",
        ) from exc
    if loaded != payload:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "ledger location intent changed while acquired",
        )
    field_set_is_valid = set(payload) == TRANSITION_INTENT_FIELDS
    if payload.get("schemaVersion") == 2:
        field_set_is_valid = set(payload) in (
            TRANSFER_TRANSITION_INTENT_FIELDS,
            LEGACY_TRANSFER_TRANSITION_INTENT_FIELDS,
        )
    valid_owner = (
        payload.get("schemaVersion") == 1
        and payload.get("owner") == TRANSITION_OWNER
    ) or (
        payload.get("schemaVersion") == 2
        and payload.get("owner") == TRANSFER_TRANSITION_OWNER
        and isinstance(payload.get("obligations"), list)
    )
    operation_id = payload.get("operationId")
    successor_slug = payload.get("successorSlug")
    archive_relative = _ledger_location_archive_relative(
        slug, payload.get("terminalInstant")
    )
    if (
        not field_set_is_valid
        or not valid_owner
        or payload.get("status") != "intent"
        or payload.get("slug") != slug
        or payload.get("activePath") != logical_work_item
        or payload.get("archivePath") != archive_relative
        or not isinstance(successor_slug, str)
        or not is_valid_slug(successor_slug)
        or payload.get("successorPath")
        != f"work-items/backlog/{successor_slug}.md"
        or not isinstance(payload.get("expectedLedgerSha256"), str)
        or SHA256_RE.fullmatch(payload["expectedLedgerSha256"]) is None
        or not isinstance(operation_id, str)
    ):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "ledger location intent binding differs",
        )
    expected_path = _transition_intent_path(root, operation_id)
    if expected_path.absolute() != path.absolute():
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "ledger location intent path differs from its operation id",
        )


def _matching_ledger_location_intents(
    root: Path,
    repository: Path,
    *,
    slug: str,
    logical_work_item: str,
) -> list[tuple[dict, Path, bytes]]:
    transition_root = repository / ".scratch" / "work-items-lifecycle-transitions"
    if not _ledger_location_lexically_exists(transition_root):
        return []
    _lifecycle_reject_unreduced_reparse(
        transition_root,
        failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
        message="transition staging root is a link or reparse point",
    )
    if not transition_root.is_dir():
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "transition staging root is not a directory",
        )
    matches: list[tuple[dict, Path, bytes]] = []
    candidates = _bounded_transition_intent_inventory(
        transition_root,
        failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
        unreadable="transition staging root is unreadable",
    )
    loaded_bytes = 0
    for path in candidates:
        payload, raw = _ledger_location_proof_object(
            path,
            failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            unreadable="transition intent is unreadable",
            maximum_bytes=TRANSITION_INTENT_FILE_BYTE_CAP,
        )
        loaded_bytes += len(raw)
        if loaded_bytes > TRANSITION_INTENT_INVENTORY_BYTE_CAP:
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
                "transition intent cumulative byte limit exceeded",
            )
        if payload.get("slug") != slug:
            continue
        _validate_ledger_location_intent(
            root,
            path,
            payload,
            slug=slug,
            logical_work_item=logical_work_item,
        )
        matches.append((payload, path, raw))
    if len(matches) > 1:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "multiple ledger location intents match one work item",
        )
    return matches


def _validate_stable_ledger_settlement(
    root: Path,
    repository: Path,
    archive: Path,
    receipt_path: Path,
    *,
    slug: str,
) -> tuple[dict, bytes, str]:
    payload, raw = _ledger_location_proof_object(
        receipt_path,
        failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
        unreadable="settled receipt is unreadable",
    )
    schema_version = payload.get("schemaVersion")
    is_v1 = (
        schema_version == 1
        and set(payload) == TRANSITION_SETTLEMENT_FIELDS
        and payload.get("owner") == TRANSITION_OWNER
    )
    is_v2 = (
        schema_version == 2
        and set(payload) == TRANSFER_TRANSITION_SETTLEMENT_FIELDS
        and payload.get("owner") == TRANSFER_TRANSITION_OWNER
        and isinstance(payload.get("obligations"), list)
    )
    is_legacy_v2 = (
        schema_version == 2
        and set(payload) == LEGACY_TRANSFER_TRANSITION_SETTLEMENT_FIELDS
        and payload.get("owner") == TRANSFER_TRANSITION_OWNER
        and isinstance(payload.get("obligations"), list)
    )
    terminal_instant = payload.get("terminalInstant")
    try:
        archive_relative = _ledger_location_archive_relative(slug, terminal_instant)
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
            "settled receipt terminal instant is invalid",
        ) from exc
    successor_slug = payload.get("requestSuccessorSlug")
    operation_id = payload.get("operationId")
    required_sha_fields = (
        "successorSha256",
        "ledgerSha256",
        "statusSha256",
        "closureSha256",
        "bugDispositionReceiptSha256",
        "readmeSha256",
        "requestClosureSha256",
        "requestSuccessorSha256",
        "requestExpectedLedgerSha256",
        "requestExpectedReadmeSha256",
    )
    if (
        not (is_v1 or is_v2 or is_legacy_v2)
        or payload.get("status") != "settled"
        or payload.get("workItem") != slug
        or payload.get("requestTerminalInstant") != terminal_instant
        or payload.get("archivePath") != archive_relative
        or archive.relative_to(repository).as_posix() != archive_relative
        or not isinstance(successor_slug, str)
        or not is_valid_slug(successor_slug)
        or payload.get("successorPath")
        != f"work-items/backlog/{successor_slug}.md"
        or not isinstance(operation_id, str)
        or any(
            not isinstance(payload.get(key), str)
            or SHA256_RE.fullmatch(payload[key]) is None
            for key in required_sha_fields
        )
        or payload.get("ledgerSha256")
        != payload.get("requestExpectedLedgerSha256")
    ):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
            "settled receipt binding or shape differs",
        )
    try:
        _transition_intent_path(root, operation_id)
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
            "settled receipt operation id is invalid",
        ) from exc
    if schema_version == 2:
        obligations = payload["obligations"]
        obligation_fields = {
            "runId", "rawLineOrdinal", "rawLineSha256", "rawEventSha256",
            "projectedEventSha256", "obligationId", "predecessorOperationId",
        }
        if (
            not isinstance(payload.get("transferInputSha256"), str)
            or SHA256_RE.fullmatch(payload["transferInputSha256"]) is None
            or not isinstance(payload.get("archiveIdentity"), str)
            or SHA256_RE.fullmatch(payload["archiveIdentity"]) is None
            or not (
                payload.get("predecessorOperationId") is None
                or isinstance(payload.get("predecessorOperationId"), str)
            )
            or any(
                not isinstance(row, dict)
                or set(row) != obligation_fields
                or not isinstance(row.get("runId"), str)
                or type(row.get("rawLineOrdinal")) is not int
                or row["rawLineOrdinal"] < 1
                or any(
                    not isinstance(row.get(key), str)
                    or SHA256_RE.fullmatch(row[key]) is None
                    for key in (
                        "rawLineSha256", "rawEventSha256",
                        "projectedEventSha256", "obligationId",
                    )
                )
                or not (
                    row.get("predecessorOperationId") is None
                    or isinstance(row.get("predecessorOperationId"), str)
                )
                for row in obligations
            )
        ):
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
                "settled transfer receipt fields differ",
            )
    physical_hashes = {
        "ledgerSha256": _ledger_location_regular_sha256(
            archive / "agent-runs.jsonl",
            failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
            maximum_bytes=_validator_module().MAX_TRANSFER_LEDGER_BYTES,
        ),
        "statusSha256": _ledger_location_regular_sha256(
            archive / "status.md",
            failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
        ),
        "closureSha256": _ledger_location_regular_sha256(
            archive / "closure.md",
            failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
        ),
        "bugDispositionReceiptSha256": _ledger_location_regular_sha256(
            archive / BUG_DISPOSITIONS_RECEIPT,
            failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
        ),
    }
    physical_migration_receipts = _migration_receipt_bindings_at(
        root,
        archive,
        failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
    )
    if is_v2:
        expected_migration_receipts = _validate_transfer_migration_receipt_bindings(
            root,
            payload.get("archivePath"),
            payload.get("migrationReceipts"),
            failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
        )
        if physical_migration_receipts != expected_migration_receipts:
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
                "migration receipt set differs",
            )
    else:
        expected_migration_sha256 = payload.get("migrationReceiptSha256")
        if expected_migration_sha256 is None:
            if physical_migration_receipts:
                raise LifecycleError(
                    "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
                    "migration receipt cardinality differs",
                )
        elif (
            not isinstance(expected_migration_sha256, str)
            or SHA256_RE.fullmatch(expected_migration_sha256) is None
            or len(physical_migration_receipts) != 1
            or physical_migration_receipts[0]["sha256"]
            != expected_migration_sha256
        ):
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
                "migration receipt hash differs",
            )
    if any(payload.get(key) != value for key, value in physical_hashes.items()):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
            "settled archive hashes differ",
        )
    return payload, raw, physical_hashes["ledgerSha256"]


def _ledger_settlement_agrees_with_intent(receipt: dict, intent: dict) -> bool:
    pairs = {
        "schemaVersion": "schemaVersion",
        "owner": "owner",
        "operationId": "operationId",
        "workItem": "slug",
        "terminalInstant": "terminalInstant",
        "archivePath": "archivePath",
        "successorPath": "successorPath",
        "requestClosureSha256": "closureInputSha256",
        "requestSuccessorSlug": "successorSlug",
        "requestTerminalInstant": "terminalInstant",
        "requestExpectedLedgerSha256": "expectedLedgerSha256",
        "requestExpectedReadmeSha256": "expectedReadmeSha256",
    }
    if any(receipt.get(left) != intent.get(right) for left, right in pairs.items()):
        return False
    successor_data = _unb64(intent.get("successorData"))
    if successor_data is None or receipt.get("requestSuccessorSha256") != _sha256_bytes(
        successor_data
    ):
        return False
    for receipt_key, intent_key in (
        ("statusSha256", "statusAfter"),
        ("closureSha256", "closureAfter"),
        ("bugDispositionReceiptSha256", "bugReceiptAfter"),
    ):
        image = _unb64(intent.get(intent_key))
        if image is None or receipt.get(receipt_key) != _sha256_bytes(image):
            return False
    if receipt.get("schemaVersion") == 2:
        transfer_fields_agree = all(
            receipt.get(key) == intent.get(key)
            for key in (
                "transferInputSha256", "archiveIdentity",
                "predecessorOperationId", "obligations",
            )
        )
        if not transfer_fields_agree:
            return False
        if "migrationReceipts" in intent or "migrationReceipts" in receipt:
            return (
                "migrationReceipts" in intent
                and "migrationReceipts" in receipt
                and receipt["migrationReceipts"] == intent["migrationReceipts"]
            )
        return True
    return True


def resolve_work_item_ledger_location(
    root: Path, *, logical_work_item: str, logical_ledger_path: str
) -> WorkItemLedgerLocationV1:
    logical_parts = PurePosixPath(logical_work_item).parts
    if (
        len(logical_parts) != 3
        or logical_parts[:2] != ("work-items", "active")
        or logical_ledger_path != f"{logical_work_item}/agent-runs.jsonl"
    ):
        raise LifecycleError(
            "WI-LEDGER-COMPAT-EFFECTIVE-VIEW-BYPASS",
            "logical H1 ledger identity must be one canonical active participant",
        )
    slug = logical_parts[2]
    _validate_slug(slug)
    work_items = _work_items_root(root)
    repository = work_items.parent
    active = work_items / "active" / slug
    backlog = work_items / "backlog" / f"{slug}.md"
    archive_root = work_items / "archive"
    active_exists = _ledger_location_lexically_exists(active)
    backlog_exists = _ledger_location_lexically_exists(backlog)
    archives: list[Path] = []
    if _ledger_location_lexically_exists(archive_root):
        _lifecycle_reject_unreduced_reparse(
            archive_root,
            failure_id="WI-CATEGORY-DUAL-LOCATION",
            message="archive root crosses a link or reparse point",
        )
        if not archive_root.is_dir():
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION", "archive root is not a directory"
            )
        for month in sorted(archive_root.iterdir()):
            candidate = month / slug
            if _ledger_location_lexically_exists(candidate):
                archives.append(candidate)
    if backlog_exists or len(archives) > 1 or (active_exists and archives):
        raise LifecycleError(
            "WI-CATEGORY-DUAL-LOCATION",
            "H1 work item does not have one physical lifecycle location",
        )
    intents = _matching_ledger_location_intents(
        root,
        repository,
        slug=slug,
        logical_work_item=logical_work_item,
    )
    intent, intent_path, intent_raw = intents[0] if intents else (None, None, None)
    if active_exists:
        _lifecycle_reject_unreduced_reparse(
            active,
            failure_id="WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE",
            message="active H1 work item crosses a link or reparse point",
        )
        if not active.is_dir():
            raise LifecycleError(
                "WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE",
                "active H1 work item is not a directory",
            )
        ledger_sha256 = _ledger_location_regular_sha256(
            active / "agent-runs.jsonl",
            failure_id="WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE",
            maximum_bytes=_validator_module().MAX_TRANSFER_LEDGER_BYTES,
        )
        if intent is not None and intent.get("expectedLedgerSha256") != ledger_sha256:
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
                "active intent ledger digest differs",
            )
        return WorkItemLedgerLocationV1(
            logical_work_item,
            logical_ledger_path,
            logical_work_item,
            logical_ledger_path,
            "active-intent" if intent is not None else "active",
            ledger_sha256,
            intent.get("operationId") if intent is not None else None,
            intent_path.relative_to(repository).as_posix() if intent_path else None,
            _sha256_bytes(intent_raw) if intent_raw is not None else None,
        )
    if len(archives) != 1:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE",
            "H1 work item has no owner-proven physical ledger location",
        )
    archive = archives[0]
    _lifecycle_reject_unreduced_reparse(
        archive,
        failure_id="WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE",
        message="archived H1 work item crosses a link or reparse point",
    )
    if not archive.is_dir():
        raise LifecycleError(
            "WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE",
            "archived H1 work item is not a directory",
        )
    physical_work_item = archive.relative_to(repository).as_posix()
    physical_ledger_path = f"{physical_work_item}/agent-runs.jsonl"
    receipt_path = archive / "lifecycle-transition-receipt.json"
    if _ledger_location_lexically_exists(receipt_path):
        receipt, receipt_raw, ledger_sha256 = _validate_stable_ledger_settlement(
            root,
            repository,
            archive,
            receipt_path,
            slug=slug,
        )
        if intent is not None and not _ledger_settlement_agrees_with_intent(
            receipt, intent
        ):
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
                "settlement and durable intent disagree",
            )
        return WorkItemLedgerLocationV1(
            logical_work_item,
            logical_ledger_path,
            physical_work_item,
            physical_ledger_path,
            "settled-archive",
            ledger_sha256,
            receipt["operationId"],
            receipt_path.relative_to(repository).as_posix(),
            _sha256_bytes(receipt_raw),
        )
    if intent is None or intent_path is None or intent_raw is None:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE",
            "archived H1 ledger has no lifecycle relocation proof",
        )
    if intent.get("archivePath") != physical_work_item:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
            "moved intent archive path differs",
        )
    ledger_sha256 = _ledger_location_regular_sha256(
        archive / "agent-runs.jsonl",
        failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
        maximum_bytes=_validator_module().MAX_TRANSFER_LEDGER_BYTES,
    )
    status_after = _unb64(intent.get("statusAfter"))
    closure_after = _unb64(intent.get("closureAfter"))
    if (
        status_after is None
        or closure_after is None
        or intent.get("expectedLedgerSha256") != ledger_sha256
        or _ledger_location_regular_sha256(
            archive / "status.md",
            failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
        )
        != _sha256_bytes(status_after)
        or _ledger_location_regular_sha256(
            archive / "closure.md",
            failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
        )
        != _sha256_bytes(closure_after)
    ):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
            "moved intent after-images or ledger digest differ",
        )
    return WorkItemLedgerLocationV1(
        logical_work_item,
        logical_ledger_path,
        physical_work_item,
        physical_ledger_path,
        "moved-intent",
        ledger_sha256,
        intent["operationId"],
        intent_path.relative_to(repository).as_posix(),
        _sha256_bytes(intent_raw),
    )


def _transition_bug_plans(root: Path, intent: dict) -> tuple[BugDispositionPlan, ...]:
    plans = []
    for row in intent["bugs"]:
        if not isinstance(row, dict) or set(row) != {
            "id", "action", "source", "target", "before", "after", "statusBefore", "statusAfter"
        }:
            raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "transition bug image differs")
        plans.append(BugDispositionPlan(
            bug_id=row["id"], action=row["action"], source=_intent_path(root, row["source"]),
            target=_intent_path(root, row["target"]) if row["target"] is not None else None,
            before=_unb64(row["before"]) or b"", after=_unb64(row["after"]) or b"",
            status_before=row["statusBefore"], status_after=row["statusAfter"],
        ))
    return tuple(plans)


def _settlement_payload(root: Path, intent: dict, readme_sha256: str) -> dict:
    failure_id = "WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE"
    archive = _intent_path(root, intent["archivePath"])
    successor = _intent_path(root, intent["successorPath"])
    bug_receipt = archive / BUG_DISPOSITIONS_RECEIPT
    migration_receipt = None
    if (
        "migrationReceiptPath" in intent
        and intent["migrationReceiptPath"] is not None
    ):
        migration_receipt = archive / "ledger-migration-receipts" / Path(intent["migrationReceiptPath"]).name
    bug_receipt = _require_lifecycle_mutation_path(
        root, bug_receipt, failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE"
    )
    if migration_receipt is not None:
        migration_receipt = _require_lifecycle_mutation_path(
            root, migration_receipt, failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE"
        )
    payload = {
        "schemaVersion": intent["schemaVersion"],
        "owner": intent["owner"],
        "status": "settled",
        "operationId": intent["operationId"],
        "workItem": intent["slug"],
        "terminalInstant": intent["terminalInstant"],
        "archivePath": intent["archivePath"],
        "successorPath": intent["successorPath"],
        "successorSha256": _ledger_location_regular_sha256(successor, failure_id=failure_id),
        "ledgerSha256": _ledger_location_regular_sha256(
            archive / "agent-runs.jsonl",
            failure_id=failure_id,
            maximum_bytes=_validator_module().MAX_TRANSFER_LEDGER_BYTES,
        ),
        "statusSha256": _ledger_location_regular_sha256(
            archive / "status.md",
            failure_id=failure_id,
        ),
        "closureSha256": _ledger_location_regular_sha256(
            archive / "closure.md",
            failure_id=failure_id,
        ),
        "bugDispositionReceiptSha256": _ledger_location_regular_sha256(
            bug_receipt,
            failure_id=failure_id,
        ),
        "readmeSha256": readme_sha256,
        "requestClosureSha256": intent["closureInputSha256"],
        "requestSuccessorSlug": intent["successorSlug"],
        "requestSuccessorSha256": _sha256_bytes(_unb64(intent["successorData"]) or b""),
        "requestTerminalInstant": intent["terminalInstant"],
        "requestExpectedLedgerSha256": intent["expectedLedgerSha256"],
        "requestExpectedReadmeSha256": intent["expectedReadmeSha256"],
    }
    if "migrationReceipts" in intent:
        expected_migration_receipts = _validate_transfer_migration_receipt_bindings(
            root,
            intent["archivePath"],
            intent["migrationReceipts"],
            failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
        )
        physical_migration_receipts = _migration_receipt_bindings_at(
            root,
            archive,
            failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
        )
        if physical_migration_receipts != expected_migration_receipts:
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
                "migration receipt set differs from transition intent",
            )
        payload["migrationReceipts"] = [
            dict(row) for row in physical_migration_receipts
        ]
    else:
        payload["migrationReceiptSha256"] = (
            _ledger_location_regular_sha256(migration_receipt, failure_id=failure_id)
            if migration_receipt is not None
            else None
        )
    if intent["schemaVersion"] == 2:
        payload.update({
            "transferInputSha256": intent["transferInputSha256"],
            "archiveIdentity": intent["archiveIdentity"],
            "predecessorOperationId": intent["predecessorOperationId"],
            "obligations": intent["obligations"],
        })
    return payload


def _safe_refresh_readme(root: Path) -> str:
    readme = _work_items_root(root) / "README.md"
    _require_lifecycle_mutation_path(root, readme, failure_id="WI-README-STALE")
    digest = refresh_readme(root)
    readme = _require_lifecycle_mutation_path(root, readme, failure_id="WI-README-STALE")
    if _ledger_location_regular_sha256(readme, failure_id="WI-README-STALE") != digest:
        raise LifecycleError("WI-README-STALE", "README identity or digest changed")
    return digest


def _precompute_transition_readme_sha256(
    root: Path,
    active: Path,
    archive: Path,
    successor: Path,
    status_after: bytes,
    closure_after: bytes,
    successor_data: bytes,
    plans: tuple[BugDispositionPlan, ...],
) -> str:
    work_items = _work_items_root(root)
    static_guide = _static_guide(work_items / "README.md")
    with tempfile.TemporaryDirectory(prefix="work-items-transition-readme-") as directory:
        shadow_root = Path(directory)
        shadow_work_items = shadow_root / "work-items"
        shutil.copytree(work_items, shadow_work_items, symlinks=True)

        def shadow(path: Path) -> Path:
            return shadow_work_items / path.relative_to(work_items)

        shadow_active = shadow(active)
        shadow_archive = shadow(archive)
        _atomic_write(shadow_active / "status.md", status_after)
        _atomic_write(shadow_active / "closure.md", closure_after)
        for plan in plans:
            source = shadow(plan.source)
            if plan.action == "terminalize":
                assert plan.target is not None
                target = shadow(plan.target)
                _atomic_write(source, plan.after)
                target.parent.mkdir(parents=True, exist_ok=True)
                os.replace(source, target)
        shadow_archive.parent.mkdir(parents=True, exist_ok=True)
        os.replace(shadow_active, shadow_archive)
        _atomic_write(shadow(successor), successor_data)
        transaction_token = _CURRENT_LIFECYCLE_TRANSACTION.set(None)
        composer_token = _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.set(None)
        try:
            rendered = render_readme_bytes(
                shadow_root, static_guide_override=static_guide
            )
        finally:
            _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.reset(composer_token)
            _CURRENT_LIFECYCLE_TRANSACTION.reset(transaction_token)
        return _sha256_bytes(rendered)


def _verify_settlement(root: Path, receipt: Path, expected: dict | None = None) -> dict:
    failure_id = "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH"
    receipt = _require_lifecycle_mutation_path(
        root, receipt, failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH"
    )
    payload, _ = _ledger_location_proof_object(
        receipt, failure_id=failure_id, unreadable="settled receipt is unreadable"
    )
    valid_owner = False
    if isinstance(payload, dict):
        schema_version = payload.get("schemaVersion")
        valid_owner = (
            schema_version == 1
            and payload.get("owner") == TRANSITION_OWNER
            and set(payload) == TRANSITION_SETTLEMENT_FIELDS
        ) or (
            schema_version == 2
            and payload.get("owner") == TRANSFER_TRANSITION_OWNER
            and isinstance(payload.get("obligations"), list)
            and set(payload)
            in (
                TRANSFER_TRANSITION_SETTLEMENT_FIELDS,
                LEGACY_TRANSFER_TRANSITION_SETTLEMENT_FIELDS,
            )
        )
    if not isinstance(payload, dict) or payload.get("status") != "settled" or not valid_owner:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH", "settled receipt shape differs")
    archive = _intent_path(root, payload["archivePath"])
    successor = _intent_path(root, payload["successorPath"])
    readme_path = _require_lifecycle_mutation_path(
        root, _work_items_root(root) / "README.md",
        failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
    )
    bug_receipt_path = _require_lifecycle_mutation_path(
        root, archive / BUG_DISPOSITIONS_RECEIPT,
        failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
    )
    physical = {
        "successorSha256": _ledger_location_regular_sha256(successor, failure_id=failure_id),
        "ledgerSha256": _ledger_location_regular_sha256(
            archive / "agent-runs.jsonl",
            failure_id=failure_id,
            maximum_bytes=_validator_module().MAX_TRANSFER_LEDGER_BYTES,
        ),
        "statusSha256": _ledger_location_regular_sha256(
            archive / "status.md",
            failure_id=failure_id,
        ),
        "closureSha256": _ledger_location_regular_sha256(
            archive / "closure.md",
            failure_id=failure_id,
        ),
        "bugDispositionReceiptSha256": _ledger_location_regular_sha256(
            bug_receipt_path,
            failure_id=failure_id,
        ),
        "readmeSha256": _ledger_location_regular_sha256(readme_path, failure_id=failure_id),
    }
    migration_receipts = _migration_receipt_bindings_at(
        root,
        archive,
        failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
    )
    if "migrationReceipts" in payload:
        expected_migration_receipts = _validate_transfer_migration_receipt_bindings(
            root,
            payload["archivePath"],
            payload["migrationReceipts"],
            failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
        )
        if migration_receipts != expected_migration_receipts:
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
                "migration receipt set differs",
            )
        physical["migrationReceipts"] = [dict(row) for row in migration_receipts]
    else:
        expected_migration_sha = payload.get("migrationReceiptSha256")
        expected_migration_count = 0 if expected_migration_sha is None else 1
        if len(migration_receipts) != expected_migration_count:
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
                "migration receipt cardinality differs",
            )
        physical["migrationReceiptSha256"] = (
            migration_receipts[0]["sha256"] if migration_receipts else None
        )
    if any(payload.get(key) != value for key, value in physical.items()):
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH", "settled receipt hashes differ")
    if payload.get("schemaVersion") == 2:
        coverage_errors = _validator_module().validate_transfer_receipt_obligation_coverage(
            Path(root).resolve(), payload, archive
        )
        if coverage_errors:
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
                "; ".join(coverage_errors),
            )
    if expected is not None and payload != expected:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH", "settled receipt content differs")
    return payload


def _recover_transition(root: Path, intent_path: Path, *, inject_failure_at: str | None = None) -> dict | None:
    intent = _load_transition_intent(root, intent_path)
    if intent.get("kind") == LEDGER_H1_RELOCATION_KIND:
        return _recover_ledger_h1_artifact_set_relocation(
            root,
            intent_path,
            intent,
        )
    if intent.get("kind") == SUCCESSOR_IMPORT_KIND:
        return _recover_successor_import(root, intent_path, intent)
    if intent.get("kind") in {BUG_SUPERSESSION_KIND, FIXED_BUG_ARCHIVE_KIND}:
        return _recover_single_bug_transition(
            root,
            intent_path,
            intent,
            inject_failure_at=inject_failure_at,
        )
    rollback_failure_id = "WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE"
    forward_failure_id = "WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE"
    active = _intent_path(root, intent["activePath"])
    archive = _intent_path(root, intent["archivePath"])
    successor = _intent_path(root, intent["successorPath"])
    status_before = _unb64(intent["statusBefore"]) or b""
    status_after = _unb64(intent["statusAfter"]) or b""
    closure_before = _unb64(intent["closureBefore"])
    closure_after = _unb64(intent["closureAfter"]) or b""
    bug_receipt_before = _unb64(intent["bugReceiptBefore"])
    bug_receipt_after = _unb64(intent["bugReceiptAfter"]) or b""
    successor_data = _unb64(intent["successorData"]) or b""
    plans = _transition_bug_plans(root, intent)
    if active.is_dir():
        status = _require_lifecycle_mutation_path(
            root, active / "status.md",
            failure_id="WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE",
        )
        closure = _require_lifecycle_mutation_path(
            root, active / "closure.md",
            failure_id="WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE",
        )
        bug_receipt = _require_lifecycle_mutation_path(
            root, active / BUG_DISPOSITIONS_RECEIPT,
            failure_id="WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE",
        )
        current_status = _read_lifecycle_image(
            status,
            status_before,
            status_after,
            failure_id=rollback_failure_id,
        )
        current_closure = _read_lifecycle_image(
            closure,
            closure_before,
            closure_after,
            failure_id=rollback_failure_id,
        )
        if current_status not in {status_before, status_after} or current_closure not in {closure_before, closure_after}:
            raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE", "active before-image cannot be proven")
        for plan in plans:
            current = plan.source if plan.source.exists() else plan.target
            if current is None or _read_lifecycle_image(
                current,
                plan.before,
                plan.after,
                failure_id=rollback_failure_id,
            ) not in {plan.before, plan.after}:
                raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE", f"bug before-image differs: {plan.bug_id}")
            if plan.target is not None and plan.target.exists() and not plan.source.exists():
                plan.source.parent.mkdir(parents=True, exist_ok=True)
                os.replace(plan.target, plan.source)
            _atomic_write(plan.source, plan.before)
        current_bug_receipt = _read_lifecycle_image(
            bug_receipt,
            bug_receipt_before,
            bug_receipt_after,
            failure_id=rollback_failure_id,
            require_single_link=True,
        )
        if current_bug_receipt not in {bug_receipt_before, bug_receipt_after}:
            raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE", "bug receipt before-image differs")
        _atomic_write(status, status_before)
        if closure_before is None:
            _require_lifecycle_mutation_path(
                root, closure, failure_id="WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE"
            )
            closure.unlink(missing_ok=True)
        else:
            _atomic_write(closure, closure_before)
        if bug_receipt_before is None:
            _require_lifecycle_mutation_path(
                root, bug_receipt, failure_id="WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE"
            )
            bug_receipt.unlink(missing_ok=True)
        else:
            _atomic_write(bug_receipt, bug_receipt_before)
        if successor.exists():
            if _read_lifecycle_image(
                successor,
                successor_data,
                failure_id=rollback_failure_id,
            ) != successor_data:
                raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE", "unexpected successor bytes")
            successor.unlink()
        _require_lifecycle_mutation_path(
            root, intent_path, failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID"
        )
        intent_path.unlink()
        return None
    if not archive.is_dir():
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "intent has neither active nor archive identity")
    if _read_lifecycle_image(
        archive / "status.md",
        status_after,
        failure_id=forward_failure_id,
    ) != status_after or _read_lifecycle_image(
        archive / "closure.md",
        closure_after,
        failure_id=forward_failure_id,
    ) != closure_after:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE", "archive identity differs")
    if successor.exists():
        if _read_lifecycle_image(
            successor,
            successor_data,
            failure_id=forward_failure_id,
        ) != successor_data:
            raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE", "successor bytes differ")
    else:
        _atomic_write(successor, successor_data)
    if inject_failure_at == "T4":
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE", "injected T4")
    archived_bug_receipt = archive / BUG_DISPOSITIONS_RECEIPT
    archived_bug_receipt = _require_lifecycle_mutation_path(
        root, archived_bug_receipt,
        failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
    )
    if _read_lifecycle_image(
        archived_bug_receipt,
        bug_receipt_after,
        failure_id=forward_failure_id,
        require_single_link=True,
    ) != bug_receipt_after:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
            "pre-archive bug receipt is missing or changed",
        )
    readme_sha = _safe_refresh_readme(root)
    if readme_sha != intent["finalReadmeSha256"]:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
            "precomputed README digest differs after roll-forward",
        )
    if inject_failure_at == "T5":
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE", "injected T5")
    settlement = _settlement_payload(root, intent, readme_sha)
    receipt_path = archive / "lifecycle-transition-receipt.json"
    receipt_bytes = _migration_receipt_bytes(settlement)
    current_receipt = _read_lifecycle_image(
        receipt_path,
        receipt_bytes,
        failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH",
        require_single_link=True,
    )
    if current_receipt not in {None, receipt_bytes}:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH", "settled receipt differs")
    receipt_path = _require_lifecycle_mutation_path(
        root, receipt_path,
        failure_id="WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE",
    )
    _atomic_write(receipt_path, receipt_bytes)
    _transition_fsync_directory(receipt_path.parent)
    if inject_failure_at == "T6":
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE", "injected T6")
    _verify_settlement(root, receipt_path, settlement)
    if inject_failure_at == "T7":
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE", "injected T7")
    _require_lifecycle_mutation_path(
        root, intent_path, failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID"
    )
    intent_path.unlink(missing_ok=True)
    if inject_failure_at in {"T8", "T9"}:
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE", f"injected {inject_failure_at}")
    return settlement


def _iter_transition_intents(root: Path) -> Iterable[Path]:
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    directory = repository / ".scratch" / "work-items-lifecycle-transitions"
    if not directory.exists():
        return
    if not directory.is_dir() or _lifecycle_path_has_reparse(directory):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "transition staging root is unsafe",
        )
    yield from _bounded_transition_intent_inventory(
        directory,
        failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
        unreadable="transition staging root is unreadable",
    )


def _recover_all_transitions(root: Path) -> None:
    for intent_path in _iter_transition_intents(root):
        _recover_transition(root, intent_path)


def archive_with_successor(
    root: Path,
    slug: str,
    closure_data: bytes,
    terminal_instant: str,
    successor_slug: str,
    successor_data: bytes,
    operation_id: str,
    expected_ledger_sha256: str,
    expected_readme_sha256: str,
    *,
    obligation_transfer_data: bytes | None = None,
    inject_failure_at: str | None = None,
) -> dict:
    _validate_slug(slug)
    _validate_slug(successor_slug)
    expected_ledger_sha256 = _normalize_sha256_input(expected_ledger_sha256)
    expected_readme_sha256 = _normalize_sha256_input(expected_readme_sha256)
    month = archive_month(terminal_instant)
    _validate_closure(closure_data, terminal_instant)
    work_items = _work_items_root(root)
    archive = work_items / "archive" / month / slug
    settled_path = archive / "lifecycle-transition-receipt.json"
    settled_path = _require_lifecycle_mutation_path(
        root, settled_path, failure_id="WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH"
    )
    if settled_path.is_file():
        payload = _verify_settlement(root, settled_path)
        if (
            payload.get("operationId") != operation_id
            or payload.get("workItem") != slug
            or payload.get("requestClosureSha256") != _sha256_bytes(closure_data)
            or payload.get("requestSuccessorSlug") != successor_slug
            or payload.get("requestSuccessorSha256") != _sha256_bytes(successor_data)
            or payload.get("requestTerminalInstant") != terminal_instant
            or payload.get("requestExpectedLedgerSha256") != expected_ledger_sha256
            or payload.get("requestExpectedReadmeSha256") != expected_readme_sha256
            or payload.get("transferInputSha256") != (
                _sha256_bytes(obligation_transfer_data)
                if obligation_transfer_data is not None else None
            )
        ):
            raise LifecycleError("WI-LIFECYCLE-TRANSITION-SETTLEMENT-MISMATCH", "replay inputs differ")
        return payload
    intent_path = _transition_intent_path(root, operation_id)
    if intent_path.exists():
        recovered = _recover_transition(root, intent_path, inject_failure_at=inject_failure_at)
        if recovered is not None:
            return recovered
    active = _active_migration_item(root, slug)
    ledger = active / "agent-runs.jsonl"
    if _ledger_location_regular_sha256(
        ledger,
        failure_id="WI-LEDGER-MIGRATION-LEDGER-DRIFT",
        maximum_bytes=_validator_module().MAX_TRANSFER_LEDGER_BYTES,
    ) != expected_ledger_sha256:
        raise LifecycleError("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "transition ledger digest changed")
    readme = work_items / "README.md"
    readme = _require_lifecycle_mutation_path(root, readme, failure_id="WI-README-STALE")
    if _ledger_location_regular_sha256(
        readme,
        failure_id="WI-README-STALE",
    ) != expected_readme_sha256:
        raise LifecycleError("WI-README-STALE", "transition README digest changed")
    archive = _require_lifecycle_mutation_path(
        root, archive, failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID"
    )
    successor_preflight = _require_lifecycle_mutation_path(
        root, work_items / "backlog" / f"{successor_slug}.md",
        failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
    )
    if archive.exists() or successor_preflight.exists():
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", "archive or successor already exists")
    transfer_obligations: list[dict] | None = None
    archive_identity: str | None = None
    migration_receipt: Path | None = None
    transfer_migration_receipts: tuple[CapturedFileSnapshot, ...] = ()
    if obligation_transfer_data is None:
        _validate_item_before_close(active)
    else:
        (
            _transfer_payload,
            transfer_obligations,
            archive_identity,
            transfer_migration_receipts,
        ) = _prepare_obligation_transfer(
            root,
            active,
            archive,
            slug,
            successor_slug,
            successor_data,
            operation_id,
            expected_ledger_sha256,
            obligation_transfer_data,
        )
    _manifest, manifest_data, bug_plans = _prepare_bug_dispositions(root, active, slug, terminal_instant)
    if obligation_transfer_data is None:
        migration_receipts = sorted((active / "ledger-migration-receipts").glob("*.json"))
        if len(migration_receipts) != 1:
            raise LifecycleError("WI-LEDGER-MIGRATION-RECEIPT-MISMATCH", "one migration receipt is required")
        migration_receipt = _require_lifecycle_mutation_path(
            root, migration_receipts[0], failure_id="WI-LEDGER-MIGRATION-RECEIPT-MISMATCH"
        )
    archived_closure = _stamp_schema_marker(closure_data, "closure.md")
    status = active / "status.md"
    prior_status = status.read_bytes()
    status_after = _terminalize_status(prior_status)
    prior_closure = (active / "closure.md").read_bytes() if (active / "closure.md").exists() else None
    relative = lambda path: path.relative_to(Path(root).resolve()).as_posix()
    successor_path = work_items / "backlog" / f"{successor_slug}.md"
    final_readme_sha = _precompute_transition_readme_sha256(
        root, active, archive, successor_path, status_after, archived_closure,
        successor_data, bug_plans,
    )
    bug_receipt_path = active / BUG_DISPOSITIONS_RECEIPT
    bug_receipt_path = _require_lifecycle_mutation_path(
        root, bug_receipt_path, failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID"
    )
    if bug_receipt_path.exists():
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-INTENT-INVALID", "active bug receipt already exists")
    bug_receipt_after = _bug_disposition_receipt_bytes(
        root, slug, terminal_instant, manifest_data, archived_closure, bug_plans, final_readme_sha
    )
    intent = {
        "schemaVersion": 2 if obligation_transfer_data is not None else 1,
        "owner": TRANSFER_TRANSITION_OWNER if obligation_transfer_data is not None else TRANSITION_OWNER,
        "status": "intent",
        "operationId": operation_id, "slug": slug, "terminalInstant": terminal_instant,
        "activePath": relative(active), "archivePath": relative(archive),
        "successorPath": relative(successor_path),
        "expectedLedgerSha256": expected_ledger_sha256, "expectedReadmeSha256": expected_readme_sha256,
        "statusBefore": _b64(prior_status), "statusAfter": _b64(status_after),
        "closureBefore": _b64(prior_closure), "closureAfter": _b64(archived_closure),
        "successorData": _b64(successor_data), "manifestData": _b64(manifest_data),
        "closureInputSha256": _sha256_bytes(closure_data),
        "successorSlug": successor_slug,
        "finalReadmeSha256": final_readme_sha,
        "bugReceiptBefore": None,
        "bugReceiptAfter": _b64(bug_receipt_after),
        "bugs": [{
            "id": plan.bug_id, "action": plan.action, "source": relative(plan.source),
            "target": relative(plan.target) if plan.target is not None else None,
            "before": _b64(plan.before), "after": _b64(plan.after),
            "statusBefore": plan.status_before, "statusAfter": plan.status_after,
        } for plan in bug_plans],
    }
    if obligation_transfer_data is None:
        intent["migrationReceiptPath"] = (
            relative(migration_receipt) if migration_receipt is not None else None
        )
    else:
        predecessor_ids = {
            row["predecessorOperationId"] for row in (transfer_obligations or [])
            if row["predecessorOperationId"] is not None
        }
        migration_receipt_bindings = [
            {
                "path": relative(
                    archive
                    / "ledger-migration-receipts"
                    / snapshot.path.name
                ),
                "sha256": _sha256_bytes(snapshot.data),
            }
            for snapshot in transfer_migration_receipts
        ]
        migration_receipt_bindings.sort(
            key=lambda row: row["path"].encode("utf-8")
        )
        intent.update({
            "migrationReceipts": migration_receipt_bindings,
            "transferInputSha256": _sha256_bytes(obligation_transfer_data),
            "archiveIdentity": archive_identity,
            "predecessorOperationId": (
                next(iter(predecessor_ids)) if len(predecessor_ids) == 1 else None
            ),
            "obligations": transfer_obligations,
        })
    intent_path = _require_lifecycle_mutation_path(
        root, intent_path, failure_id="WI-LIFECYCLE-TRANSITION-INTENT-INVALID"
    )
    for snapshot in transfer_migration_receipts:
        _verify_captured_file(
            snapshot,
            "WI-LEDGER-MIGRATION-RECEIPT-MISMATCH",
        )
    _atomic_write(intent_path, _migration_receipt_bytes(intent))
    _transition_fsync_directory(intent_path.parent)
    if inject_failure_at == "T0":
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE", "injected T0")
    for plan in bug_plans:
        plan_source = _require_lifecycle_mutation_path(
            root, plan.source,
            failure_id="WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE",
        )
        plan_target = None
        if plan.target is not None:
            plan_target = _require_lifecycle_mutation_path(
                root, plan.target,
                failure_id="WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE",
            )
        if plan.action == "terminalize":
            _atomic_write(plan_source, plan.after)
            assert plan_target is not None
            plan_target.parent.mkdir(parents=True, exist_ok=True)
            os.replace(plan_source, plan_target)
    closure_path = _require_lifecycle_mutation_path(
        root, active / "closure.md",
        failure_id="WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE",
    )
    _atomic_write(closure_path, archived_closure)
    _atomic_write(status, status_after)
    if inject_failure_at == "T1":
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE", "injected T1")
    _atomic_write(bug_receipt_path, bug_receipt_after)
    _transition_fsync_directory(bug_receipt_path.parent)
    if inject_failure_at == "T2":
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLBACK-INDETERMINATE", "injected T2")
    archive.parent.mkdir(parents=True, exist_ok=True)
    os.replace(active, archive)
    if inject_failure_at == "T3":
        raise LifecycleError("WI-LIFECYCLE-TRANSITION-ROLLFORWARD-INDETERMINATE", "injected T3")
    return _recover_transition(root, intent_path, inject_failure_at=inject_failure_at)


def _validate_flat_terminal(category: Category, data: bytes) -> str:
    try:
        fields = _parse_fields(data.decode("utf-8"))
    except UnicodeDecodeError as exc:
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "terminal record must be UTF-8"
        ) from exc
    status = fields.get("status", "")
    if status not in category.terminal_statuses:
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
            f"{category.name} status {status!r} is not terminal",
        )
    admission = _admission_for(category.name)
    utc_field = admission.utc_field.casefold()
    evidence_fields = (
        admission.detail_field.casefold(),
        admission.evidence_field.casefold(),
    )
    missing = [name for name in (utc_field, *evidence_fields) if not fields.get(name)]
    if missing:
        raise LifecycleError(
            "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
            f"{category.name} terminal record missing: {', '.join(missing)}",
        )
    _strict_utc(fields[utc_field])
    return fields[utc_field]


def _normalization_fail(failure_id: str, message: str) -> LifecycleError:
    return LifecycleError(failure_id, message)


def _normalization_bound_source(
    root: Path, category: Category, relative: str, *, must_exist: bool = True
) -> Path:
    work_items = _work_items_root(
        root,
        root_failure_id="WI-IDENTITY-NORMALIZE-SOURCE",
    )
    relative_path = Path(relative)
    if (
        relative_path.is_absolute()
        or len(relative_path.parts) < 2
        or relative_path.parts[0] != "work-items"
    ):
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-SOURCE",
            "normalization source must be repository-relative under work-items",
        )
    within_work_items = Path(*relative_path.parts[1:]).as_posix()
    requested = work_items.resolve() / Path(within_work_items)
    try:
        resolved = _terminalization_bound_path(
            work_items, within_work_items, label="normalization source"
        )
    except LifecycleError as exc:
        raise _normalization_fail("WI-IDENTITY-NORMALIZE-SOURCE", str(exc)) from exc
    source = requested
    expected_parent = (work_items / category.current_root).resolve()
    if (
        category.current_kind != "flat"
        or source.parent.resolve() != expected_parent
        or source.resolve() != resolved
        or source.suffix != ".md"
        or (must_exist and not source.is_file())
    ):
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-SOURCE",
            "normalization source must be one mutable flat record in its category current root",
        )
    return source


def _normalization_scratch_path(root: Path, path: Path, *, label: str) -> Path:
    try:
        return _bound_repository_scratch_path(root, path, label=label, allow_absolute=True)
    except LifecycleError as exc:
        raise _normalization_fail("WI-IDENTITY-NORMALIZE-INVENTORY", str(exc)) from exc


def _normalization_exact_file(path: Path) -> bool:
    return path.parent.is_dir() and any(
        child.name == path.name and child.is_file() for child in path.parent.iterdir()
    )


def _normalization_current_files(work_items: Path) -> list[Path]:
    files: set[Path] = set((work_items / "backlog").glob("*.md"))
    files.update(path / "status.md" for path in (work_items / "active").glob("*") if path.is_dir())
    for category in CATEGORIES.values():
        if category.current_kind == "flat":
            files.update((work_items / category.current_root).glob("*.md"))
    return sorted(path for path in files if path.is_file())


def _normalization_authoritative_line_numbers(text: str) -> frozenset[int]:
    return frozenset(
        line_number for line_number, _line in _authoritative_markdown_lines(text)
    )


def _normalization_replace_id(text: str, old_slug: str, new_slug: str) -> tuple[str, int]:
    authoritative = _normalization_authoritative_line_numbers(text)
    lines = text.splitlines(keepends=True)
    count = 0
    for index, line in enumerate(lines, start=1):
        if index not in authoritative:
            continue
        body = line.rstrip("\r\n")
        ending = line[len(body) :]
        match = FIELD_RE.fullmatch(body)
        if not (
            match
            and match.group(1).strip().casefold() == "id"
            and match.group(2).strip() == old_slug
        ):
            continue
        value_start, value_end = match.span(2)
        raw_value = match.group(2)
        leading = len(raw_value) - len(raw_value.lstrip())
        trailing = len(raw_value) - len(raw_value.rstrip())
        replacement = raw_value[:leading] + new_slug
        if trailing:
            replacement += raw_value[len(raw_value) - trailing :]
        lines[index - 1] = body[:value_start] + replacement + body[value_end:] + ending
        count += 1
    return "".join(lines), count


def _normalization_replace_live_mentions(
    text: str, old_slug: str, new_slug: str
) -> tuple[str, int]:
    """Rewrite live current-record mentions but preserve fenced evidence bytes."""
    authoritative = _normalization_authoritative_line_numbers(text)
    lines = text.splitlines(keepends=True)
    count = 0
    for index, line in enumerate(lines, start=1):
        if index not in authoritative:
            continue
        count += line.count(old_slug)
        lines[index - 1] = line.replace(old_slug, new_slug)
    return "".join(lines), count


def _normalization_authoritative_markdown_links(
    text: str,
) -> Iterable[MarkdownLocalLink]:
    """Yield normalization links only from lifecycle-authoritative Markdown lines."""
    authoritative = _normalization_authoritative_line_numbers(text)
    for link in _markdown_local_links(text):
        line_number = text.count("\n", 0, link.href_start) + 1
        if line_number in authoritative:
            yield link


def _normalization_snapshot(
    root: Path,
    category: Category,
    source: Path,
    target_slug: str,
) -> tuple[dict, dict[Path, bytes]]:
    work_items = _work_items_root(root)
    old_slug = source.stem
    target = work_items / category.current_root / f"{target_slug}.md"
    planned: dict[Path, bytes] = {}
    kinds: dict[Path, set[str]] = {}

    current_files = frozenset(_normalization_current_files(work_items))
    markdown_files = sorted(
        path for path in work_items.rglob("*.md") if path.name != "README.md"
    )
    for path in markdown_files:
        try:
            before = path.read_bytes()
            text = before.decode("utf-8")
        except (OSError, UnicodeError) as exc:
            raise _normalization_fail(
                "WI-IDENTITY-NORMALIZE-INVENTORY",
                f"cannot classify Markdown consumer: {path}",
            ) from exc

        physical_replacements: list[tuple[int, int, str]] = []
        for link in _normalization_authoritative_markdown_links(text):
            href_parts = _local_markdown_href_parts(link.href)
            if href_parts is None:
                continue
            filesystem_href, suffix = href_parts
            if (path.parent / filesystem_href).resolve() != source.resolve():
                continue
            if path not in current_files:
                raise _normalization_fail(
                    "WI-IDENTITY-NORMALIZE-INVENTORY",
                    f"physical consumer is not mutable current state: {path}",
                )
            new_href = Path(os.path.relpath(target, path.parent)).as_posix() + suffix
            physical_replacements.append((link.href_start, link.href_end, new_href))
        if physical_replacements:
            for start, end, value in reversed(physical_replacements):
                text = text[:start] + value + text[end:]
            kinds.setdefault(path, set()).add("physical-link")

        if path not in current_files:
            continue
        after = text
        if path == source:
            after, count = _normalization_replace_id(after, old_slug, target_slug)
            if count != 1:
                raise _normalization_fail(
                    "WI-IDENTITY-NORMALIZE-INVENTORY",
                    "source must contain exactly one authoritative id matching its physical slug",
                )
            kinds.setdefault(path, set()).add("authoritative-id")
        after, live_count = _normalization_replace_live_mentions(
            after, old_slug, target_slug
        )
        if live_count:
            kinds.setdefault(path, set()).add("live-reference")
        if after.encode("utf-8") != before:
            planned[path] = after.encode("utf-8")

    if source not in planned:
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-INVENTORY", "normalization source produced no identity change"
        )
    rows = []
    for path in sorted(planned):
        before = path.read_bytes()
        after = planned[path]
        rows.append(
            {
                "path": path.relative_to(work_items).as_posix(),
                "kinds": sorted(kinds[path]),
                "beforeSha256": hashlib.sha256(before).hexdigest(),
                "afterSha256": hashlib.sha256(after).hexdigest(),
            }
        )
    inventory = {
        "schemaVersion": CURRENT_IDENTITY_NORMALIZATION_SCHEMA_VERSION,
        "owner": CURRENT_IDENTITY_NORMALIZATION_OWNER,
        "workItemsRoot": str(work_items.resolve()),
        "category": category.name,
        "source": source.relative_to(work_items.parent).as_posix(),
        "targetSlug": target_slug,
        "oldIdentity": f"{category.name}:{old_slug}",
        "newIdentity": f"{category.name}:{target_slug}",
        "rows": rows,
    }
    return inventory, planned


def write_current_identity_normalization_inventory(
    root: Path,
    category_name: str,
    source_relative: str,
    target_slug: str,
    inventory_path: Path,
) -> dict:
    category = CATEGORIES.get(CATEGORY_ALIASES.get(category_name, category_name))
    if category is None:
        raise LifecycleError("WI-REFERENCE-INVALID", f"unknown category: {category_name!r}")
    _validate_slug(target_slug)
    source = _normalization_bound_source(root, category, source_relative)
    if is_valid_slug(source.stem):
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-SOURCE", "source identity is already canonical"
        )
    fields = _parse_fields(source.read_text(encoding="utf-8"))
    if fields.get("status", "") not in category.current_statuses:
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-SOURCE", "source does not carry a current admitted status"
        )
    inventory, _planned = _normalization_snapshot(root, category, source, target_slug)
    destination = _normalization_scratch_path(root, inventory_path, label="normalization inventory")
    _atomic_write(destination, (json.dumps(inventory, indent=2, sort_keys=True) + "\n").encode())
    return inventory


def _normalization_expected_receipt_rows(
    root: Path,
    category: Category,
    inventory: object,
    source: Path,
    target: Path,
) -> list[dict[str, str]]:
    """Derive the one complete receipt row sequence from the canonical inventory."""
    work_items = _work_items_root(root)
    source_repo_relative = source.relative_to(work_items.parent).as_posix()
    source_work_items_relative = source.relative_to(work_items).as_posix()
    target_work_items_relative = target.relative_to(work_items).as_posix()
    if (
        not isinstance(inventory, dict)
        or inventory.get("schemaVersion")
        != CURRENT_IDENTITY_NORMALIZATION_SCHEMA_VERSION
        or inventory.get("owner") != CURRENT_IDENTITY_NORMALIZATION_OWNER
        or inventory.get("workItemsRoot") != str(work_items.resolve())
        or inventory.get("category") != category.name
        or inventory.get("source") != source_repo_relative
        or inventory.get("targetSlug") != target.stem
        or not isinstance(inventory.get("rows"), list)
    ):
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-RECOVERY",
            "normalization inventory binding differs during replay",
        )

    expected: list[dict[str, str]] = []
    before_paths: set[str] = set()
    after_paths: set[str] = set()
    digest_re = re.compile(r"^[0-9a-f]{64}$")
    for row in inventory["rows"]:
        if (
            not isinstance(row, dict)
            or set(row) != {"path", "kinds", "beforeSha256", "afterSha256"}
            or not isinstance(row.get("path"), str)
            or not isinstance(row.get("kinds"), list)
            or not all(isinstance(kind, str) for kind in row["kinds"])
            or not isinstance(row.get("beforeSha256"), str)
            or not digest_re.fullmatch(row["beforeSha256"])
            or not isinstance(row.get("afterSha256"), str)
            or not digest_re.fullmatch(row["afterSha256"])
        ):
            raise _normalization_fail(
                "WI-IDENTITY-NORMALIZE-RECOVERY",
                "normalization inventory row is invalid during replay",
            )
        before_path = row["path"]
        try:
            _terminalization_bound_path(
                work_items, before_path, label="normalization receipt preimage"
            )
        except LifecycleError as exc:
            raise _normalization_fail(
                "WI-IDENTITY-NORMALIZE-RECOVERY", str(exc)
            ) from exc
        after_path = (
            target_work_items_relative
            if before_path == source_work_items_relative
            else before_path
        )
        if before_path in before_paths or after_path in after_paths:
            raise _normalization_fail(
                "WI-IDENTITY-NORMALIZE-RECOVERY",
                "normalization inventory rows are duplicated or collide",
            )
        before_paths.add(before_path)
        after_paths.add(after_path)
        expected.append(
            {
                "beforePath": before_path,
                "afterPath": after_path,
                "beforeSha256": row["beforeSha256"],
                "afterSha256": row["afterSha256"],
            }
        )
    if source_work_items_relative not in before_paths:
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-RECOVERY",
            "normalization inventory omits the authoritative source row",
        )
    return expected


def _normalization_replay(
    root: Path,
    category: Category,
    inventory_bytes: bytes,
    receipt: Path,
    source: Path,
    target: Path,
) -> bool:
    if not receipt.is_file() or _normalization_exact_file(source) or not _normalization_exact_file(target):
        return False
    try:
        payload = json.loads(receipt.read_text(encoding="utf-8"))
        inventory = json.loads(inventory_bytes.decode("utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise _normalization_fail("WI-IDENTITY-NORMALIZE-RECOVERY", "invalid normalization receipt") from exc
    work_items = _work_items_root(root)
    if (
        not isinstance(payload, dict)
        or payload.get("schemaVersion") != CURRENT_IDENTITY_NORMALIZATION_SCHEMA_VERSION
        or payload.get("owner") != CURRENT_IDENTITY_NORMALIZATION_OWNER
        or payload.get("inventorySha256") != hashlib.sha256(inventory_bytes).hexdigest()
        or payload.get("source") != source.relative_to(work_items.parent).as_posix()
        or payload.get("target") != target.relative_to(work_items).as_posix()
        or not isinstance(payload.get("rows"), list)
    ):
        raise _normalization_fail("WI-IDENTITY-NORMALIZE-RECOVERY", "normalization receipt binding differs")
    expected_rows = _normalization_expected_receipt_rows(
        root, category, inventory, source, target
    )
    if payload["rows"] != expected_rows:
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-RECOVERY",
            "normalization receipt row set is incomplete, duplicated, or tampered",
        )
    for row in expected_rows:
        path = _terminalization_bound_path(work_items, row["afterPath"], label="normalization replay")
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != row.get("afterSha256"):
            raise _normalization_fail("WI-IDENTITY-NORMALIZE-RECOVERY", "normalization settled bytes differ")
    readme = work_items / "README.md"
    if not readme.is_file() or hashlib.sha256(readme.read_bytes()).hexdigest() != payload.get("readmeSha256"):
        raise _normalization_fail("WI-IDENTITY-NORMALIZE-RECOVERY", "normalization README differs")
    return True


def normalize_current_identity(
    root: Path,
    category_name: str,
    source_relative: str,
    target_slug: str,
    inventory_path: Path,
    receipt_path: Path,
    *,
    inject_failure_at: str | None = None,
) -> tuple[Path, bool]:
    category = CATEGORIES.get(CATEGORY_ALIASES.get(category_name, category_name))
    if category is None:
        raise LifecycleError("WI-REFERENCE-INVALID", f"unknown category: {category_name!r}")
    _validate_slug(target_slug)
    work_items = _work_items_root(root)
    source = _normalization_bound_source(root, category, source_relative, must_exist=False)
    target = work_items / category.current_root / f"{target_slug}.md"
    inventory_file = _normalization_scratch_path(root, inventory_path, label="normalization inventory")
    receipt = _normalization_scratch_path(root, receipt_path, label="normalization receipt")
    try:
        inventory_bytes = inventory_file.read_bytes()
        inventory = json.loads(inventory_bytes.decode("utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise _normalization_fail("WI-IDENTITY-NORMALIZE-INVENTORY", "invalid normalization inventory") from exc
    if not _normalization_exact_file(source):
        if _normalization_replay(
            root, category, inventory_bytes, receipt, source, target
        ):
            return target, True
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-RECOVERY", "source is absent without a complete settled receipt"
        )
    if receipt.exists():
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-RECOVERY",
            "receipt exists while legacy source is still present",
        )
    if is_valid_slug(source.stem):
        raise _normalization_fail("WI-IDENTITY-NORMALIZE-SOURCE", "source identity is already canonical")
    locations = _category_locations(root, category, source.stem)
    if locations != [source]:
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", "source identity is not physically unique")
    fields = _parse_fields(source.read_text(encoding="utf-8"))
    if fields.get("status", "") not in category.current_statuses:
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-SOURCE", "source does not carry a current admitted status"
        )
    target_locations = _category_locations(root, category, target_slug)
    if _normalization_exact_file(target) or any(
        not (location.is_file() and os.path.samefile(location, source))
        for location in target_locations
    ):
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", "normalization target already exists")
    expected, planned = _normalization_snapshot(root, category, source, target_slug)
    if inventory != expected:
        raise _normalization_fail(
            "WI-IDENTITY-NORMALIZE-INVENTORY", "inventory is incomplete, stale, or differently classified"
        )
    readme = work_items / "README.md"
    readme_before = readme.read_bytes() if readme.is_file() else None
    preimages = {path: path.read_bytes() for path in planned}
    inventory_sha = hashlib.sha256(inventory_bytes).hexdigest()
    moved = False
    move_temp: Path | None = None
    try:
        for path in sorted(planned):
            _atomic_write(path, planned[path])
        if inject_failure_at == "after-rewrites":
            raise RuntimeError("injected normalization failure after rewrites")
        temp_dir = Path(tempfile.mkdtemp(prefix=f".{target_slug}.normalize.", dir=source.parent))
        move_temp = temp_dir / source.name
        os.replace(source, move_temp)
        os.replace(move_temp, target)
        temp_dir.rmdir()
        move_temp = None
        moved = True
        if inject_failure_at == "after-move":
            raise RuntimeError("injected normalization failure after move")
        readme_sha = refresh_readme(root)
        if inject_failure_at == "after-readme":
            raise RuntimeError("injected normalization failure after README")
        resolved = resolve_category(root, f"{category.name}:{target_slug}")
        if resolved != target.resolve() or _normalization_exact_file(source) or not _normalization_exact_file(target):
            raise RuntimeError("normalization final identity check failed")
        for path, after in planned.items():
            final_path = target if path == source else path
            if (
                not final_path.is_file()
                or hashlib.sha256(final_path.read_bytes()).hexdigest()
                != hashlib.sha256(after).hexdigest()
            ):
                raise RuntimeError(
                    f"normalization final byte check failed: {final_path}"
                )
        audit(root)
        rows = _normalization_expected_receipt_rows(
            root, category, inventory, source, target
        )
        payload = {
            "schemaVersion": CURRENT_IDENTITY_NORMALIZATION_SCHEMA_VERSION,
            "owner": CURRENT_IDENTITY_NORMALIZATION_OWNER,
            "inventorySha256": inventory_sha,
            "source": source_relative,
            "target": target.relative_to(work_items).as_posix(),
            "readmeSha256": readme_sha,
            "rows": rows,
        }
        _atomic_write(receipt, (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode())
        if not _normalization_replay(
            root, category, inventory_bytes, receipt, source, target
        ):
            raise RuntimeError("normalization settled receipt verification failed")
        return target, False
    except BaseException as exc:
        try:
            if move_temp is not None and move_temp.exists():
                os.replace(move_temp, source)
                move_temp.parent.rmdir()
            elif moved and _normalization_exact_file(target) and not _normalization_exact_file(source):
                temp_dir = Path(tempfile.mkdtemp(prefix=f".{source.stem}.rollback.", dir=source.parent))
                rollback_temp = temp_dir / target.name
                os.replace(target, rollback_temp)
                os.replace(rollback_temp, source)
                temp_dir.rmdir()
            for path, before in preimages.items():
                _atomic_write(path, before)
            if readme_before is None:
                if readme.exists():
                    readme.unlink()
            else:
                _atomic_write(readme, readme_before)
            if receipt.exists():
                receipt.unlink()
        except BaseException as rollback_exc:
            raise _normalization_fail(
                "WI-IDENTITY-NORMALIZE-ROLLBACK", f"rollback failed: {rollback_exc}"
            ) from exc
        raise _normalization_fail("WI-IDENTITY-NORMALIZE-ROLLBACK", str(exc)) from exc


CATEGORY_ADMISSION_TABLE = (
    CategoryAdmission(
        "work-item",
        "mutate-work-item:_category_locations",
        "mutate-work-item:_validate_closure",
        "closure.md:Closed",
        "work_item_terminal_evidence_missing",
        "Closed",
        "Outcome",
        "Evidence",
    ),
    CategoryAdmission(
        "bug",
        "mutate-work-item:_category_locations",
        "mutate-work-item:_validate_flat_terminal",
        "bug:Terminal-at",
        "bug_terminal_evidence_missing",
        "Terminal-at",
        "Resolution",
        "Evidence",
    ),
    CategoryAdmission(
        "decision",
        "mutate-work-item:_category_locations",
        "mutate-work-item:_validate_flat_terminal",
        "decision:Terminal-at",
        "decision_terminal_evidence_missing",
        "Terminal-at",
        "Rationale",
        "Evidence",
    ),
    CategoryAdmission(
        "lesson",
        "mutate-work-item:_category_locations",
        "mutate-work-item:_validate_flat_terminal",
        "lesson:Terminal-at",
        "lesson_terminal_evidence_missing",
        "Terminal-at",
        "Disposition",
        "Evidence",
    ),
    CategoryAdmission(
        "roadmap",
        "mutate-work-item:_category_locations",
        "mutate-work-item:_validate_flat_terminal",
        "roadmap:Terminal-at",
        "roadmap_terminal_evidence_missing",
        "Terminal-at",
        "Disposition",
        "Evidence",
    ),
    CategoryAdmission(
        "epic",
        "mutate-work-item:_category_locations",
        "mutate-work-item:_validate_flat_terminal",
        "epic:Closed",
        "epic_terminal_evidence_missing",
        "Closed",
        "Outcome",
        "Evidence",
    ),
)


def _admission_for(category_name: str) -> CategoryAdmission:
    rows = [row for row in CATEGORY_ADMISSION_TABLE if row.category == category_name]
    if len(CATEGORY_ADMISSION_TABLE) != 6 or len(rows) != 1:
        raise LifecycleError(
            "CATEGORY-MIGRATION-ADMISSION-GATE",
            f"category admission table is incomplete or duplicated: {category_name}",
        )
    row = rows[0]
    if not all(
        (
            row.category,
            row.current_reader,
            row.terminal_validator,
            row.utc_field_owner,
            row.negative_fixture,
            row.utc_field,
            row.detail_field,
            row.evidence_field,
        )
    ):
        raise LifecycleError(
            "CATEGORY-MIGRATION-ADMISSION-GATE",
            f"category admission row has a missing cell: {category_name}",
        )
    return row


def _move_terminal_category(root: Path, reference: str) -> Path:
    category, slug = _canonical_category(reference)
    _admission_for(category.name)
    locations = _category_locations(root, category, slug)
    if len(locations) > 1:
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", f"duplicate slug: {reference}")
    if len(locations) != 1:
        raise LifecycleError("WI-INVALID-TARGET", f"missing category record: {reference}")
    source = locations[0]
    if category.name == "work-item":
        closure = source / "closure.md"
        if not closure.is_file():
            raise LifecycleError(
                "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "work-item lacks closure.md"
            )
        if "archive" in source.parts:
            _archived_work_item_entry(source)
            refresh_readme(root)
            return source
        fields = _parse_fields(closure.read_text(encoding="utf-8"))
        instant = fields.get("closed", "")
        closure_data = closure.read_bytes()
        _validate_closure(closure_data, instant)
        terminal_closure = _stamp_schema_marker(closure_data, "closure.md")
        target = _work_items_root(root) / "archive" / archive_month(instant) / slug
        if not source.is_dir() or source.parent.name != "active":
            raise LifecycleError("WI-INVALID-TARGET", "work-item migration requires active/")
        _validate_item_before_close(source)
        status = source / "status.md"
        terminal_status = _terminalize_status(status.read_bytes())
    else:
        instant = _validate_flat_terminal(category, source.read_bytes())
        target = (
            _work_items_root(root)
            / category.current_root
            / "archive"
            / archive_month(instant)
            / source.name
        )
        if "archive" in source.parts:
            if source != target:
                raise LifecycleError(
                    "WI-CATEGORY-ARCHIVE-MONTH-MISMATCH",
                    f"{reference} is not in archive/{archive_month(instant)}",
                )
            refresh_readme(root)
            return source
    _preflight_readme_markers(root)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", f"archive target exists: {target}")
    if category.name == "work-item":
        prior_status = status.read_bytes()
        prior_closure = closure.read_bytes()
        _atomic_write(status, terminal_status)
        _atomic_write(closure, terminal_closure)
    try:
        os.replace(source, target)
    except BaseException:
        if category.name == "work-item":
            _atomic_write(status, prior_status)
            _atomic_write(closure, prior_closure)
        raise
    try:
        refresh_readme(root)
    except LifecycleError as exc:
        raise LifecycleError("WI-README-STALE", str(exc)) from exc
    return target


def _v0_archive_manifest_row(root: Path, name: str) -> dict | None:
    """Return a validated frozen V0 row, including external archive evidence."""
    _preflight_current_decision_v0(root)
    manifest = _work_items_root(root) / DECISION_V0_MANIFEST
    if not manifest.is_file():
        return None
    payload = json.loads(manifest.read_text(encoding="utf-8"))
    return next((row for row in payload["entries"] if row["path"] == name), None)


def _v0_archive_input(inventory: dict, reference: str) -> dict:
    required = {
        "reference", "expectedSourceSha256", "archivedAt", "rationale",
        "evidence", "incomingLinks",
    }
    if set(inventory) != required or inventory["reference"] != reference:
        raise LifecycleError("WI-DECISION-V0-ARCHIVE-EVIDENCE", "V0 archive input has invalid shape")
    if (
        not isinstance(inventory["expectedSourceSha256"], str)
        or re.fullmatch(r"[0-9A-F]{64}", inventory["expectedSourceSha256"]) is None
        or not isinstance(inventory["archivedAt"], str)
        or any(
            not isinstance(inventory[field], str) or not inventory[field].strip()
            for field in ("rationale", "evidence")
        )
        or not isinstance(inventory["incomingLinks"], list)
    ):
        raise LifecycleError("WI-DECISION-V0-ARCHIVE-EVIDENCE", "V0 archive input is incomplete")
    try:
        _strict_utc(inventory["archivedAt"])
    except LifecycleError as exc:
        raise LifecycleError("WI-DECISION-V0-ARCHIVE-EVIDENCE", "V0 archive instant is invalid") from exc
    return inventory


def _migrate_v0_decision(root: Path, reference: str, inventory: dict, source: Path | None) -> Path:
    category, slug = _canonical_category(reference)
    assert category.name == "decision"
    work_items = _work_items_root(root)
    manifest = work_items / DECISION_V0_MANIFEST
    row = _v0_archive_manifest_row(root, f"{slug}.md")
    if row is None:
        raise LifecycleError("WI-DECISION-V0-UNADMITTED", "V0 archive source has no admitted manifest row")
    evidence_input = _v0_archive_input(inventory, reference)
    archive = work_items / "decisions" / "archive" / archive_month(evidence_input["archivedAt"]) / f"{slug}.md"
    if source is None:
        evidence = row.get("archiveEvidence")
        if (
            row["state"] != "retired" or not isinstance(evidence, dict)
            or evidence["archivePath"] != archive.relative_to(work_items).as_posix()
            or evidence["archivedAt"] != evidence_input["archivedAt"]
            or evidence["rationale"] != evidence_input["rationale"]
            or evidence["evidence"] != evidence_input["evidence"]
            or row["sha256"] != evidence_input["expectedSourceSha256"]
            or _category_locations(root, category, slug) != [archive]
        ):
            raise LifecycleError("WI-DECISION-V0-ARCHIVE-EVIDENCE", "V0 archive replay differs")
        return archive
    if row["state"] != "admitted":
        raise LifecycleError("WI-DECISION-V0-UNADMITTED", "V0 source is not admitted")
    current = _preflight_current_decision_v0(root).get(source.name)
    if current is None or current.raw_status not in category.terminal_statuses:
        raise LifecycleError("WI-CATEGORY-TERMINAL-EVIDENCE-MISSING", "V0 decision is not terminal")
    source = _require_lifecycle_mutation_path(root, source, failure_id="WI-DECISION-V0-ARCHIVE-EVIDENCE")
    archive = _require_lifecycle_mutation_path(root, archive, failure_id="WI-DECISION-V0-ARCHIVE-EVIDENCE")
    manifest = _require_lifecycle_mutation_path(root, manifest, failure_id="WI-DECISION-V0-ARCHIVE-EVIDENCE")
    if _category_locations(root, category, slug) != [source] or os.path.lexists(archive):
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", "V0 archive target is not uniquely absent")
    source_before = _capture_file_snapshot(source, failure_id="WI-DECISION-V0-HASH-MISMATCH").data
    if _sha256_bytes(source_before).upper() != row["sha256"] or row["sha256"] != evidence_input["expectedSourceSha256"]:
        raise LifecycleError("WI-DECISION-V0-HASH-MISMATCH", "V0 source hash differs from admission")
    manifest_before = _capture_file_snapshot(manifest, failure_id="WI-DECISION-V0-MANIFEST-INVALID").data
    payload = json.loads(manifest_before.decode("utf-8"))
    if payload["schemaVersion"] == 1 and any(
        entry["state"] == "retired" for entry in payload["entries"]
    ):
        raise LifecycleError("WI-DECISION-V0-MANIFEST-INVALID", "V1 retirement cannot be backfilled")
    references = _incoming_link_result(
        root, {source}, reference, strict_consumer_reads=True
    )["references"]
    if evidence_input["incomingLinks"] != references:
        raise LifecycleError("WI-LEGACY-LINK-UNMAPPED", "V0 incoming-link inventory is stale")
    links = _physical_archive_link_plans(
        root, source, archive, references, failure_id="WI-LEGACY-LINK-UNMAPPED"
    )
    _preflight_readme_markers(root)
    readme = work_items / "README.md"
    readme_before = readme.read_bytes() if readme.is_file() else None
    payload["schemaVersion"] = 2
    updated_row = next(entry for entry in payload["entries"] if entry["path"] == source.name)
    updated_row["state"] = "retired"
    updated_row["archiveEvidence"] = {
        "archivePath": archive.relative_to(work_items).as_posix(),
        "archivedAt": evidence_input["archivedAt"],
        "rationale": evidence_input["rationale"],
        "evidence": evidence_input["evidence"],
    }
    manifest_after = (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    archive_parent_existed = archive.parent.is_dir()
    archive_root_existed = archive.parent.parent.is_dir()
    readme_attempted = False
    try:
        archive.parent.mkdir(parents=True, exist_ok=True)
        os.replace(source, archive)
        _atomic_write(manifest, manifest_after)
        for link in links:
            _atomic_write(link["path"], link["after"])
        readme_attempted = True
        refresh_readme(root)
        if archive.read_bytes() != source_before or manifest.read_bytes() != manifest_after:
            raise LifecycleError("WI-DECISION-V0-ARCHIVE-EVIDENCE", "V0 archive readback differs")
        if any(link["path"].read_bytes() != link["after"] for link in links):
            raise LifecycleError("WI-LEGACY-LINK-UNMAPPED", "V0 link readback differs")
        _preflight_current_decision_v0(root)
        return archive
    except Exception as exc:
        try:
            for link in reversed(links):
                observed = link["path"].read_bytes()
                if observed == link["after"]:
                    _atomic_write(link["path"], link["before"])
                elif observed != link["before"]:
                    raise ValueError("V0 link rollback preimage changed")
            observed_manifest = manifest.read_bytes()
            if observed_manifest == manifest_after:
                _atomic_write(manifest, manifest_before)
            elif observed_manifest != manifest_before:
                raise ValueError("V0 manifest rollback preimage changed")
            if readme_before is None:
                if readme_attempted and readme.exists():
                    readme.unlink()
            elif readme.read_bytes() != readme_before:
                _atomic_write(readme, readme_before)
            if archive.is_file() and not source.exists() and archive.read_bytes() == source_before:
                os.replace(archive, source)
            elif archive.exists() or not source.is_file() or source.read_bytes() != source_before:
                raise ValueError("V0 source rollback location changed")
            for directory, existed in (
                (archive.parent, archive_parent_existed),
                (archive.parent.parent, archive_root_existed),
            ):
                if not existed and directory.is_dir():
                    if any(directory.iterdir()):
                        raise ValueError("new V0 archive parent gained content")
                    directory.rmdir()
        except Exception as rollback_exc:
            raise LifecycleError(
                "WI-DECISION-V0-ROLLBACK-FAILED", "V0 archive compensation failed"
            ) from rollback_exc
        raise


def migrate_legacy(
    root: Path, reference: str, *, incoming_links_inventory: Path | None
) -> Path:
    category, _slug = _canonical_category(reference)
    _admission_for(category.name)
    if incoming_links_inventory is None or not incoming_links_inventory.is_file():
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED",
            f"legacy move requires an incoming-link inventory: {reference}",
        )
    try:
        inventory = json.loads(incoming_links_inventory.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise LifecycleError("WI-LEGACY-LINK-UNMAPPED", "invalid incoming-link inventory") from exc
    if not isinstance(inventory, dict) or inventory.get("reference") != reference:
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED", "incoming-link inventory is not target-bound"
        )
    if category.name == "decision":
        locations = _category_locations(root, category, _slug)
        if len(locations) > 1:
            raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", f"duplicate slug: {reference}")
        current = _work_items_root(root) / "decisions" / f"{_slug}.md"
        admitted = _preflight_current_decision_v0(root)
        if locations == [current] and current.name in admitted:
            return _migrate_v0_decision(root, reference, inventory, current)
        row = _v0_archive_manifest_row(root, current.name)
        if locations and row is not None and row.get("archiveEvidence") is not None:
            return _migrate_v0_decision(root, reference, inventory, None)
    return _move_terminal_category(root, reference)


@dataclass(frozen=True)
class PayloadDigestLimits:
    max_files: int
    max_entries: int
    max_bytes: int

    def __post_init__(self) -> None:
        for value in (self.max_files, self.max_entries, self.max_bytes):
            if type(value) is not int or value < 0:
                raise ValueError("payload digest limits must be non-negative integers")


_POINTER_LITERAL_IDENTIFIER_CHARS = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-/"
)


def _pointer_names_retained_root(
    pointer_text: str, root_name: str, manifest_path: str
) -> bool:
    """Accept only a literal retained root name or its manifest-authorized path."""

    for reference in (root_name, manifest_path):
        start = pointer_text.find(reference)
        while start >= 0:
            end = start + len(reference)
            left_is_literal = (
                start > 0 and pointer_text[start - 1] in _POINTER_LITERAL_IDENTIFIER_CHARS
            )
            right_is_literal = (
                end < len(pointer_text)
                and pointer_text[end] in _POINTER_LITERAL_IDENTIFIER_CHARS
            )
            if not left_is_literal and not right_is_literal:
                return True
            start = pointer_text.find(reference, start + 1)
    return False


def _payload_stream_regular_file(path: Path, expected: os.stat_result, digest, classifier) -> None:
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload file cannot be opened") from exc
    try:
        opened = os.fstat(descriptor)
        if not classifier._same_open_identity(opened, expected) or not stat.S_ISREG(opened.st_mode):
            raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload file identity changed while opening")
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            digest.update(block)
        final = os.fstat(descriptor)
        if not classifier._same_open_identity(final, opened):
            raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload file identity changed while reading")
    except OSError as exc:
        raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload file cannot be read") from exc
    finally:
        os.close(descriptor)


def _payload_limited_tree_entries(path: Path, limits: PayloadDigestLimits) -> list[Path]:
    """Walk at most one entry beyond the retention ceiling without preloading directories."""

    entries: list[Path] = []
    directories = [path]
    while directories:
        directory = directories.pop()
        try:
            with os.scandir(directory) as iterator:
                for entry in iterator:
                    if len(entries) >= limits.max_entries:
                        raise LifecycleError(
                            "WI-CATEGORY-MIGRATION-PAYLOAD",
                            "payload exceeds retention entry limit",
                        )
                    candidate = Path(entry.path)
                    info = entry.stat(follow_symlinks=False)
                    if entry.is_symlink() or bool(
                        getattr(info, "st_file_attributes", 0)
                        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
                    ):
                        raise LifecycleError(
                            "WI-CATEGORY-MIGRATION-PAYLOAD",
                            "payload tree entry is not ordinary",
                        )
                    if stat.S_ISDIR(info.st_mode):
                        directories.append(candidate)
                    elif not stat.S_ISREG(info.st_mode):
                        raise LifecycleError(
                            "WI-CATEGORY-MIGRATION-PAYLOAD",
                            "unsupported tree entry",
                        )
                    entries.append(candidate)
        except OSError as exc:
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD", "payload tree cannot be enumerated"
            ) from exc
    entries.sort(key=lambda item: item.relative_to(path).as_posix())
    return entries


def _payload_digest(path: Path, *, limits: PayloadDigestLimits | None = None) -> tuple[str, str]:
    if path.is_symlink():
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-PAYLOAD",
            f"symbolic-link payload is not admitted: {path}",
        )
    if path.is_file():
        if limits is None:
            return (
                MIGRATION_DIGEST_ALGORITHMS["file"],
                hashlib.sha256(path.read_bytes()).hexdigest(),
            )
        try:
            expected = path.lstat()
        except OSError as exc:
            raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload file is unavailable") from exc
        if _lifecycle_path_has_reparse(path) or not stat.S_ISREG(expected.st_mode):
            raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload file is not ordinary")
        if limits.max_entries < 1 or limits.max_files < 1 or expected.st_size > limits.max_bytes:
            raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload exceeds retention limits")
        digest = hashlib.sha256()
        _payload_stream_regular_file(path, expected, digest, _scratch_classifier_module())
        return (
            MIGRATION_DIGEST_ALGORITHMS["file"],
            digest.hexdigest(),
        )
    if not path.is_dir():
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-PAYLOAD",
            f"payload is not a file or directory: {path}",
        )
    digest = hashlib.sha256()
    digest.update(b"sha256-tree-entries-v1\0")
    if limits is None:
        entries = sorted(path.rglob("*"), key=lambda item: item.relative_to(path).as_posix())
        classifier = None
    else:
        entries = _payload_limited_tree_entries(path, limits)
        classifier = _scratch_classifier_module()
    file_count = 0
    total_bytes = 0
    for entry in entries:
        if entry.is_symlink():
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD",
                f"symbolic-link tree entry is not admitted: {entry}",
            )
        relative = entry.relative_to(path).as_posix().encode("utf-8")
        if entry.is_dir():
            if limits is not None and _lifecycle_path_has_reparse(entry):
                raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload tree entry is not ordinary")
            digest.update(b"D")
            digest.update(len(relative).to_bytes(8, "big"))
            digest.update(relative)
        elif entry.is_file():
            if limits is None:
                data = entry.read_bytes()
                size = len(data)
            else:
                try:
                    expected = entry.lstat()
                except OSError as exc:
                    raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload tree entry is unavailable") from exc
                if _lifecycle_path_has_reparse(entry) or not stat.S_ISREG(expected.st_mode):
                    raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload tree entry is not ordinary")
                file_count += 1
                total_bytes += expected.st_size
                if file_count > limits.max_files or total_bytes > limits.max_bytes:
                    raise LifecycleError("WI-CATEGORY-MIGRATION-PAYLOAD", "payload exceeds retention file or byte limit")
                data = None
                size = expected.st_size
            digest.update(b"F")
            digest.update(len(relative).to_bytes(8, "big"))
            digest.update(relative)
            digest.update(size.to_bytes(8, "big"))
            if data is None:
                assert limits is not None and classifier is not None
                _payload_stream_regular_file(entry, expected, digest, classifier)
            else:
                digest.update(data)
        else:
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD",
                f"unsupported tree entry: {entry}",
            )
    return MIGRATION_DIGEST_ALGORITHMS["directory"], digest.hexdigest()


def _selected_migration_records(root: Path) -> list[tuple[Category, str, Path]]:
    work_items = _work_items_root(root)
    selected: list[tuple[Category, str, Path]] = []
    active = work_items / "active"
    if active.is_dir():
        for item in sorted(path for path in active.iterdir() if path.is_dir()):
            status = item / "status.md"
            fields = (
                _parse_fields(status.read_text(encoding="utf-8", errors="replace"))
                if status.is_file()
                else {}
            )
            if (item / "closure.md").is_file() or fields.get("status") in CATEGORIES[
                "work-item"
            ].terminal_statuses:
                selected.append((CATEGORIES["work-item"], item.name, item))
    for category in CATEGORIES.values():
        if category.current_kind != "flat":
            continue
        current = work_items / category.current_root
        if not current.is_dir():
            continue
        for path in sorted(current.glob("*.md")):
            fields = _parse_fields(path.read_text(encoding="utf-8", errors="replace"))
            if fields.get("status") in category.terminal_statuses:
                selected.append((category, path.stem, path))
    return sorted(selected, key=lambda item: (item[0].name, item[1]))


def _planned_migration_target(
    root: Path,
    category: Category,
    slug: str,
    source: Path,
) -> tuple[str, Path]:
    locations = _category_locations(root, category, slug)
    if locations != [source]:
        failure = "WI-CATEGORY-DUAL-LOCATION" if len(locations) > 1 else "WI-INVALID-TARGET"
        raise LifecycleError(
            failure,
            f"{category.name}:{slug} does not resolve to its selected source",
        )
    return _validated_migration_payload_target(root, category, slug, source)


def _validated_migration_payload_target(
    root: Path,
    category: Category,
    slug: str,
    payload: Path,
) -> tuple[str, Path]:
    if category.name == "work-item":
        closure = payload / "closure.md"
        if not closure.is_file():
            raise LifecycleError(
                "WI-CATEGORY-TERMINAL-EVIDENCE-MISSING",
                f"work-item:{slug} lacks closure.md",
            )
        fields = _parse_fields(closure.read_text(encoding="utf-8"))
        instant = fields.get("closed", "")
        _validate_closure(closure.read_bytes(), instant)
        _validate_item_before_close(payload)
        target = _work_items_root(root) / "archive" / archive_month(instant) / slug
    else:
        instant = _validate_flat_terminal(category, payload.read_bytes())
        target = (
            _work_items_root(root)
            / category.current_root
            / "archive"
            / archive_month(instant)
            / f"{slug}.md"
        )
    return instant, target


MARKDOWN_LINK_RE = re.compile(
    r"\[(?P<label>[^\]\r\n]+)\]\(\s*(?:<(?P<angle>[^<>()\s\r\n]+)>|(?P<bare>[^()\s\r\n]+))\s*\)"
)


@dataclass(frozen=True)
class MarkdownLocalLink:
    label: str
    href: str
    href_start: int
    href_end: int


def _markdown_local_links(text: str) -> Iterable[MarkdownLocalLink]:
    """Yield only complete, closed, local Markdown link destinations."""
    for match in MARKDOWN_LINK_RE.finditer(text):
        href = match.group("angle") or match.group("bare")
        yield MarkdownLocalLink(
            label=match.group("label"),
            href=href,
            href_start=match.start("angle") if match.group("angle") is not None else match.start("bare"),
            href_end=match.end("angle") if match.group("angle") is not None else match.end("bare"),
        )


URI_SCHEME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*:")


def _local_markdown_href_parts(href: str) -> tuple[str, str] | None:
    """Split one local href into filesystem identity and preserved suffix."""
    if (
        not href
        or href.startswith(("#", "/", "\\"))
        or URI_SCHEME_RE.match(href)
    ):
        return None
    suffix_offsets = [offset for marker in ("#", "?") if (offset := href.find(marker)) >= 0]
    split_at = min(suffix_offsets) if suffix_offsets else len(href)
    filesystem_identity = href[:split_at]
    if not filesystem_identity:
        return None
    return filesystem_identity, href[split_at:]


def _markdown_href_resolves(base: Path, href: str, expected: Path) -> bool:
    parts = _local_markdown_href_parts(href)
    return parts is not None and (base / parts[0]).resolve() == expected.resolve()


def _incoming_link_result(
    root: Path,
    owned_paths: Iterable[Path],
    reference: str,
    *,
    literal_path_references: Iterable[str] = (),
    mutable_consumers_only: bool = False,
    scan_markdown_links: bool = True,
    strict_consumer_reads: bool = False,
) -> dict:
    work_items = _work_items_root(root)
    physical: list[dict[str, str]] = []
    logical: list[dict[str, str]] = []
    owned_resolved = frozenset(path.resolve() for path in owned_paths)
    if not owned_resolved:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            f"incoming-link scan has no owned paths for {reference}",
        )
    literal_paths = tuple(sorted(set(literal_path_references)))
    if any(not path or path.startswith(("/", "\\")) for path in literal_paths):
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            f"incoming-link scan has invalid literal path for {reference}",
        )
    literal_patterns = tuple(
        (
            literal_path,
            re.compile(
                r"(?<![A-Za-z0-9_.\\/-]){}(?![A-Za-z0-9_.\\/-])".format(
                    re.escape(literal_path).replace("/", r"[\\/]"),
                )
            ),
        )
        for literal_path in literal_paths
    )

    def belongs_to_owned(path: Path) -> bool:
        return any(
            path == owned or owned in path.parents
            for owned in owned_resolved
        )

    for consumer in sorted(path for path in work_items.rglob("*") if path.is_file()):
        if consumer.name in {"README.md", "index.md"}:
            continue
        consumer_resolved = consumer.resolve()
        if belongs_to_owned(consumer_resolved):
            continue
        consumer_rel = consumer.relative_to(work_items).as_posix()
        if mutable_consumers_only and "archive" in Path(consumer_rel).parts:
            continue
        try:
            consumer_bytes = consumer.read_bytes()
            text = consumer_bytes.decode("utf-8")
        except (OSError, UnicodeError) as exc:
            if strict_consumer_reads:
                raise LifecycleError(
                    "WI-CATEGORY-MIGRATION-INVENTORY",
                    f"cannot classify live incoming-link consumer: {consumer_rel}",
                ) from exc
            continue
        if reference in text:
            logical.append(
                {"consumer": consumer_rel, "kind": "logical", "value": reference}
            )
        if scan_markdown_links:
            for link in _markdown_local_links(text):
                raw = link.href
                href_parts = _local_markdown_href_parts(raw)
                if href_parts is None:
                    continue
                candidate = (consumer.parent / href_parts[0]).resolve()
                if belongs_to_owned(candidate):
                    physical.append(
                        {
                            "consumer": consumer_rel,
                            "kind": "physical",
                            "value": raw,
                        }
                    )
        for literal_path, literal_pattern in literal_patterns:
            if literal_pattern.search(text):
                physical.append(
                    {
                        "consumer": consumer_rel,
                        "kind": "physical",
                        "value": literal_path,
                    }
                )
    references = sorted(
        physical + logical,
        key=lambda item: (item["consumer"], item["kind"], item["value"]),
    )
    if physical:
        result = "unmapped"
    elif logical:
        result = "logical-only"
    else:
        result = "clear"
    return {"result": result, "references": references}


def _validate_incoming_link_snapshot(reference: str, snapshot: dict, *, label: str) -> None:
    if not isinstance(snapshot, dict):
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED",
            f"{label} incoming-link inventory is invalid for {reference}",
        )
    result = snapshot.get("result")
    links = snapshot.get("references")
    if result not in {"clear", "logical-only"} or not isinstance(links, list):
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED",
            f"{label} incoming links are not logical-only for {reference}",
        )
    expected_result = "logical-only" if links else "clear"
    if result != expected_result:
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED",
            f"{label} incoming-link result differs from its rows for {reference}",
        )
    seen: set[tuple[str, str, str]] = set()
    for link in links:
        if (
            not isinstance(link, dict)
            or not isinstance(link.get("consumer"), str)
            or link.get("kind") != "logical"
            or link.get("value") != reference
        ):
            raise LifecycleError(
                "WI-LEGACY-LINK-UNMAPPED",
                f"{label} incoming link is not category-qualified logical for {reference}",
            )
        identity = (link["consumer"], link["kind"], link["value"])
        if identity in seen:
            raise LifecycleError(
                "WI-LEGACY-LINK-UNMAPPED",
                f"{label} incoming-link inventory repeats a row for {reference}",
            )
        seen.add(identity)


def _validate_incoming_link_compatibility(
    root: Path,
    reference: str,
    planned: dict,
    current: dict,
    *,
    resolved_location: Path,
) -> None:
    for label, snapshot in (("planned", planned), ("current", current)):
        _validate_incoming_link_snapshot(reference, snapshot, label=label)
    try:
        resolved = resolve_category(root, reference)
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED",
            f"logical reference does not resolve uniquely: {reference}",
        ) from exc
    if resolved != resolved_location.resolve():
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED",
            f"logical reference resolves outside the migration payload: {reference}",
        )


def build_migration_inventory(root: Path) -> dict:
    work_items = _work_items_root(root)
    rows: list[dict] = []
    for category, slug, source in _selected_migration_records(root):
        reference = f"{category.name}:{slug}"
        algorithm, input_hash = _payload_digest(source)
        admission_row = _admission_for(category.name)
        row = {
            "reference": reference,
            "category": category.name,
            "source": source.relative_to(work_items).as_posix(),
            "target": None,
            "terminalInstant": None,
            "inputSha256": input_hash,
            "digestAlgorithm": algorithm,
            "incomingLinks": None,
            "admission": {
                "result": "admitted",
                "reader": admission_row.current_reader,
                "validator": admission_row.terminal_validator,
                "utcOwner": admission_row.utc_field_owner,
                "negativeFixture": admission_row.negative_fixture,
            },
        }
        try:
            instant, target = _planned_migration_target(
                root, category, slug, source
            )
            row["terminalInstant"] = instant
            row["target"] = target.relative_to(work_items).as_posix()
        except LifecycleError as exc:
            row["admission"] = {
                "result": "denied",
                "failureId": exc.failure_id,
                "reason": str(exc),
            }
        owned_paths = {source}
        if row["target"] is not None:
            owned_paths.add(work_items / Path(row["target"]))
        row["incomingLinks"] = _incoming_link_result(
            root,
            owned_paths,
            reference,
        )
        rows.append(row)
    return {
        "schemaVersion": MIGRATION_SCHEMA_VERSION,
        "owner": MIGRATION_OWNER,
        "workItemsRoot": str(work_items.resolve()),
        "digestAlgorithms": dict(MIGRATION_DIGEST_ALGORITHMS),
        "rows": rows,
    }


def write_migration_inventory(root: Path, output: Path) -> dict:
    _static_guide(
        _work_items_root(root) / "README.md",
        allow_marker_bootstrap=True,
    )
    inventory = build_migration_inventory(root)
    _atomic_write(
        output,
        (json.dumps(inventory, indent=2, sort_keys=True) + "\n").encode("utf-8"),
    )
    for row in inventory["rows"]:
        admission = row["admission"]
        if admission.get("result") != "admitted":
            raise LifecycleError(
                admission.get("failureId", "CATEGORY-MIGRATION-ADMISSION-GATE"),
                admission.get("reason", f"unadmitted row: {row['reference']}"),
            )
        if row["incomingLinks"].get("result") == "unmapped":
            raise LifecycleError(
                "WI-LEGACY-LINK-UNMAPPED",
                f"physical incoming links remain for {row['reference']}",
            )
    return inventory


def _reject_duplicate_json_pairs(pairs: list[tuple[str, object]]) -> dict:
    value: dict[str, object] = {}
    for key, item in pairs:
        if key in value:
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-INVENTORY",
                f"migration inventory repeats JSON key: {key}",
            )
        value[key] = item
    return value


def _capture_path_parent_chain(
    path: Path,
    failure_id: str,
) -> CapturedPathParentChain:
    parent = _lifecycle_unresolved_absolute(path).parent
    cursor = Path(parent.anchor)
    participants = []
    try:
        root_info = cursor.lstat()
        if stat.S_ISLNK(root_info.st_mode) or bool(
            getattr(root_info, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        ):
            raise OSError("path root is a link or reparse point")
        participants.append((cursor, _lifecycle_file_identity(root_info)))
        for part in parent.parts[1:]:
            if part in {"", "."}:
                continue
            if part == "..":
                cursor = cursor.parent
                continue
            cursor /= part
            info = cursor.lstat()
            if not stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode) or bool(
                getattr(info, "st_file_attributes", 0)
                & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
            ):
                raise OSError("path parent is not a regular non-reparse directory")
            participants.append((cursor, _lifecycle_file_identity(info)))
    except OSError as exc:
        raise LifecycleError(failure_id, "file parent chain cannot be captured") from exc
    return CapturedPathParentChain(tuple(participants))


def _verify_captured_parent_chain(
    chain: CapturedPathParentChain,
    failure_id: str,
) -> None:
    try:
        for path, identity in chain.participants:
            info = path.lstat()
            if (
                not stat.S_ISDIR(info.st_mode)
                or stat.S_ISLNK(info.st_mode)
                or bool(
                    getattr(info, "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
                )
                or _lifecycle_file_identity(info) != identity
            ):
                raise OSError("captured parent identity changed")
    except OSError as exc:
        raise LifecycleError(failure_id, "captured file parent chain changed") from exc


def _open_readonly_nofollow(path: Path) -> int:
    if os.name != "nt":
        nofollow = getattr(os, "O_NOFOLLOW", 0)
        nonblock = getattr(os, "O_NONBLOCK", 0)
        if not nofollow or not nonblock:
            raise OSError(errno.ENOTSUP, "nonblocking no-follow open is unavailable")
        # A regular pathname may become a FIFO before open; inspect without blocking.
        return os.open(path, os.O_RDONLY | nofollow | nonblock)

    import ctypes
    import ctypes.wintypes
    import msvcrt

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    create_file = kernel32.CreateFileW
    create_file.argtypes = [
        ctypes.wintypes.LPCWSTR,
        ctypes.wintypes.DWORD,
        ctypes.wintypes.DWORD,
        ctypes.wintypes.LPVOID,
        ctypes.wintypes.DWORD,
        ctypes.wintypes.DWORD,
        ctypes.wintypes.HANDLE,
    ]
    create_file.restype = ctypes.wintypes.HANDLE
    native_handle = create_file(
        str(path),
        0x80000000,  # GENERIC_READ
        0x00000001 | 0x00000002 | 0x00000004,
        None,
        3,  # OPEN_EXISTING
        0x00200000,  # FILE_FLAG_OPEN_REPARSE_POINT
        None,
    )
    if native_handle == ctypes.wintypes.HANDLE(-1).value:
        raise OSError(ctypes.get_last_error(), "cannot open file without following links")
    try:
        return msvcrt.open_osfhandle(
            native_handle,
            os.O_RDONLY | getattr(os, "O_BINARY", 0),
        )
    except BaseException:
        kernel32.CloseHandle(native_handle)
        raise


def _capture_file_snapshot(
    path: Path,
    *,
    failure_id: str,
    maximum_bytes: int = 4 * 1024 * 1024,
    require_single_link: bool = False,
) -> CapturedFileSnapshot:
    parent_chain = _capture_path_parent_chain(path, failure_id)
    descriptor = -1
    try:
        observed = path.lstat()
        if (
            not stat.S_ISREG(observed.st_mode)
            or stat.S_ISLNK(observed.st_mode)
            or (require_single_link and observed.st_nlink != 1)
            or observed.st_size > maximum_bytes
            or bool(
                getattr(observed, "st_file_attributes", 0)
                & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
            )
            or _lifecycle_path_has_reparse(path)
        ):
            raise OSError("snapshot is not a bounded owned regular file")
        descriptor = _open_readonly_nofollow(path)
        with os.fdopen(descriptor, "rb", closefd=True) as stream:
            descriptor = -1
            before = os.fstat(stream.fileno())
            if (
                not stat.S_ISREG(before.st_mode)
                or (require_single_link and before.st_nlink != 1)
                or bool(
                    getattr(before, "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
                )
                or _lifecycle_file_snapshot_key(before)[:5]
                != _lifecycle_file_snapshot_key(observed)[:5]
            ):
                raise OSError("snapshot descriptor differs from its pathname")
            data = stream.read(maximum_bytes + 1)
            middle = os.fstat(stream.fileno())
            stream.seek(0)
            verified = stream.read(maximum_bytes + 1)
            after = os.fstat(stream.fileno())
        current = path.lstat()
    except OSError as exc:
        raise LifecycleError(
            failure_id, "file snapshot identity cannot be captured"
        ) from exc
    finally:
        if descriptor >= 0:
            os.close(descriptor)
    identity = _lifecycle_file_identity(before)
    before_key = _lifecycle_file_snapshot_key(before)
    if (
        len(data) > maximum_bytes
        or len(data) != before.st_size
        or data != verified
        or before_key != _lifecycle_file_snapshot_key(middle)
        or before_key != _lifecycle_file_snapshot_key(after)
        or _lifecycle_file_snapshot_key(observed)
        != _lifecycle_file_snapshot_key(current)
        or _lifecycle_file_identity(current) != identity
        or stat.S_ISLNK(current.st_mode)
        or (require_single_link and current.st_nlink != 1)
        or bool(
            getattr(current, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        )
        or _lifecycle_path_has_reparse(path)
    ):
        raise LifecycleError(failure_id, "file snapshot changed during capture")
    _verify_captured_parent_chain(parent_chain, failure_id)
    return CapturedFileSnapshot(
        path, identity, len(data), data, parent_chain, require_single_link
    )


def _verify_captured_file(snapshot: CapturedFileSnapshot, failure_id: str) -> None:
    _verify_captured_parent_chain(snapshot.parent_chain, failure_id)
    descriptor = -1
    try:
        observed = snapshot.path.lstat()
        descriptor = _open_readonly_nofollow(snapshot.path)
        with os.fdopen(descriptor, "rb", closefd=True) as stream:
            descriptor = -1
            before = os.fstat(stream.fileno())
            if _lifecycle_file_snapshot_key(before)[:5] != (
                _lifecycle_file_snapshot_key(observed)[:5]
            ):
                raise OSError("captured descriptor differs from its pathname")
            data = stream.read(snapshot.length + 1)
            middle = os.fstat(stream.fileno())
            stream.seek(0)
            verified = stream.read(snapshot.length + 1)
            after = os.fstat(stream.fileno())
        current = snapshot.path.lstat()
    except OSError as exc:
        raise LifecycleError(
            failure_id, "captured file path is no longer available"
        ) from exc
    finally:
        if descriptor >= 0:
            os.close(descriptor)
    before_key = _lifecycle_file_snapshot_key(before)
    if (
        _lifecycle_path_has_reparse(snapshot.path)
        or not stat.S_ISREG(observed.st_mode)
        or not stat.S_ISREG(before.st_mode)
        or stat.S_ISLNK(observed.st_mode)
        or stat.S_ISLNK(current.st_mode)
        or (
            snapshot.require_single_link
            and any(
                info.st_nlink != 1
                for info in (observed, before, middle, after, current)
            )
        )
        or bool(
            getattr(observed, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        )
        or bool(
            getattr(current, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        )
        or bool(
            getattr(before, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        )
        or before_key != _lifecycle_file_snapshot_key(middle)
        or before_key != _lifecycle_file_snapshot_key(after)
        or _lifecycle_file_snapshot_key(observed)
        != _lifecycle_file_snapshot_key(current)
        or _lifecycle_file_identity(before) != snapshot.identity
        or _lifecycle_file_identity(current) != snapshot.identity
        or before.st_size != snapshot.length
        or data != verified
        or data != snapshot.data
    ):
        raise LifecycleError(
            failure_id, "captured file path identity or content changed"
        )


def _parse_migration_inventory_bytes(
    root: Path,
    snapshot: bytes,
    *,
    strict_shape: bool = False,
) -> dict:
    try:
        inventory = json.loads(
            snapshot.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_json_pairs,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            "migration inventory is not strict UTF-8 JSON",
        ) from exc
    work_items = _work_items_root(root)
    if (
        not isinstance(inventory, dict)
        or (
            strict_shape
            and set(inventory)
            != {
                "digestAlgorithms",
                "owner",
                "rows",
                "schemaVersion",
                "workItemsRoot",
            }
        )
        or inventory.get("schemaVersion") != MIGRATION_SCHEMA_VERSION
        or inventory.get("owner") != MIGRATION_OWNER
        or inventory.get("workItemsRoot") != str(work_items.resolve())
        or inventory.get("digestAlgorithms") != MIGRATION_DIGEST_ALGORITHMS
        or not isinstance(inventory.get("rows"), list)
    ):
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            "migration inventory schema or target binding differs",
        )
    allowed_row_fields = {
        "admission",
        "category",
        "digestAlgorithm",
        "incomingLinks",
        "inputSha256",
        "reference",
        "source",
        "target",
        "terminalInstant",
    }
    allowed_admission_fields = {
        "negativeFixture",
        "reader",
        "result",
        "utcOwner",
        "validator",
    }
    if strict_shape:
        for row in inventory["rows"]:
            if (
                not isinstance(row, dict)
                or set(row) != allowed_row_fields
                or not isinstance(row.get("admission"), dict)
                or set(row["admission"]) != allowed_admission_fields
                or not isinstance(row.get("incomingLinks"), dict)
                or not set(row["incomingLinks"]).issubset(
                    {"physicalRelocation", "references", "result"}
                )
            ):
                raise LifecycleError(
                    "WI-CATEGORY-MIGRATION-INVENTORY",
                    "migration inventory row shape differs",
                )
    return inventory


def _load_migration_inventory(root: Path, inventory_path: Path) -> dict:
    snapshot = _capture_file_snapshot(
        inventory_path,
        failure_id="WI-CATEGORY-MIGRATION-INVENTORY",
    )
    return _parse_migration_inventory_bytes(root, snapshot.data)


def _terminalization_fail(message: str) -> LifecycleError:
    return LifecycleError(V1_TERMINALIZATION_FAILURE, message)


def _terminalization_has_reparse(path: Path) -> bool:
    try:
        attributes = getattr(path.lstat(), "st_file_attributes", 0)
    except OSError as exc:
        raise _terminalization_fail(f"cannot inspect terminalization path: {path}") from exc
    return path.is_symlink() or bool(
        attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
    )


def _terminalization_bound_path(
    work_items: Path,
    relative: str,
    *,
    label: str,
) -> Path:
    if not isinstance(relative, str) or not relative:
        raise _terminalization_fail(f"{label} path is missing")
    relative_path = Path(relative)
    if relative_path.is_absolute() or ".." in relative_path.parts:
        raise _terminalization_fail(f"{label} path escapes work-items: {relative!r}")
    root = work_items.resolve()
    cursor = work_items
    if _terminalization_has_reparse(cursor):
        raise _terminalization_fail(f"work-items root is a link or reparse point: {cursor}")
    for part in relative_path.parts:
        cursor = cursor / part
        if cursor.exists() or cursor.is_symlink():
            if _terminalization_has_reparse(cursor):
                raise _terminalization_fail(
                    f"{label} path contains a link or reparse point: {cursor}"
                )
    resolved = cursor.resolve()
    if resolved != root and root not in resolved.parents:
        raise _terminalization_fail(f"{label} path escapes work-items: {relative!r}")
    return resolved


def _bound_repository_scratch_path(
    root: Path,
    path: str | Path,
    *,
    label: str,
    allow_absolute: bool,
) -> Path:
    candidate = Path(path) if isinstance(path, (str, Path)) else Path()
    if not candidate.parts or ".." in candidate.parts:
        raise _terminalization_fail(f"{label} path is unsafe")
    repo_root = _work_items_root(root).parent.resolve()
    if candidate.is_absolute():
        if not allow_absolute:
            raise _terminalization_fail(f"{label} path must be repository-relative")
        try:
            relative = candidate.relative_to(repo_root)
        except ValueError as exc:
            raise _terminalization_fail(f"{label} path escapes the repository") from exc
    else:
        relative = candidate
    if len(relative.parts) < 2 or relative.parts[0] != ".scratch":
        raise _terminalization_fail(f"{label} must be a file under repository .scratch")
    if _terminalization_has_reparse(repo_root):
        raise _terminalization_fail(f"repository root is a link or reparse point: {repo_root}")
    cursor = repo_root
    for part in relative.parts:
        cursor = cursor / part
        if (cursor.exists() or cursor.is_symlink()) and _terminalization_has_reparse(cursor):
            raise _terminalization_fail(
                f"{label} path contains a link or reparse point: {cursor}"
            )
    resolved = cursor.resolve()
    scratch = (repo_root / ".scratch").resolve()
    if resolved == scratch or scratch not in resolved.parents:
        raise _terminalization_fail(f"{label} escapes repository .scratch")
    return resolved


def _bound_physical_receipt(root: Path, relative: str) -> Path:
    return _bound_repository_scratch_path(
        root,
        relative,
        label="physical-relocation receipt",
        allow_absolute=False,
    )


def _physical_relocation_admission(
    root: Path,
    reference: str,
    incoming: object,
    *,
    receipt_path: Path | None = None,
) -> tuple[list[dict], dict | None]:
    if not isinstance(incoming, dict) or not isinstance(incoming.get("references"), list):
        raise _terminalization_fail(f"incoming-link inventory is invalid for {reference}")
    links = incoming["references"]
    physical: list[dict] = []
    logical: list[dict] = []
    for link in links:
        if (
            not isinstance(link, dict)
            or not isinstance(link.get("consumer"), str)
            or not isinstance(link.get("value"), str)
        ):
            raise _terminalization_fail(f"incoming-link row is invalid for {reference}")
        if link.get("kind") == "physical":
            physical.append(link)
        elif link.get("kind") == "logical" and link["value"] == reference:
            logical.append(link)
        else:
            raise _terminalization_fail(f"incoming-link kind or identity differs for {reference}")
    if not physical:
        expected_result = "logical-only" if logical else "clear"
        if incoming.get("result") != expected_result or "physicalRelocation" in incoming:
            raise _terminalization_fail(
                f"incoming-link result differs from its rows for {reference}"
            )
        return links, None
    if len(physical) != 1 or logical or incoming.get("result") != "physical-relocation":
        raise _terminalization_fail(
            f"physical relocation requires one exact incoming link for {reference}"
        )
    admission = incoming.get("physicalRelocation")
    required = {
        "source",
        "label",
        "href",
        "expectedIdentity",
        "sourceSha256",
        "targetSha256",
        "receipt",
    }
    if not isinstance(admission, dict) or set(admission) != required:
        raise _terminalization_fail(
            f"physical-relocation admission shape differs for {reference}"
        )
    source_relative = admission.get("source")
    source_parts = Path(source_relative).parts if isinstance(source_relative, str) else ()
    if (
        source_relative != physical[0]["consumer"]
        or admission.get("href") != physical[0]["value"]
        or admission.get("expectedIdentity") != reference
        or not isinstance(admission.get("label"), str)
        or not admission["label"]
        or not re.fullmatch(r"[0-9a-f]{64}", str(admission.get("sourceSha256", "")))
        or not re.fullmatch(r"[0-9a-f]{64}", str(admission.get("targetSha256", "")))
        or len(source_parts) < 4
        or source_parts[-3] != "archive"
        or not re.fullmatch(r"\d{4}-\d{2}", source_parts[-2])
    ):
        raise _terminalization_fail(
            f"physical-relocation tuple differs for {reference}"
        )
    bound_receipt = _bound_physical_receipt(root, admission["receipt"])
    if receipt_path is not None and bound_receipt != receipt_path.resolve():
        raise _terminalization_fail(
            f"physical-relocation receipt binding differs for {reference}"
        )
    return links, admission


def _plan_v1_link_relocations(
    root: Path,
    planned: list[dict],
    terminal_at: str,
    receipt_path: Path,
) -> tuple[list[dict], list[dict]]:
    work_items = _work_items_root(root)
    admissions: list[tuple[dict, dict]] = []
    for item in planned:
        _links, admission = _physical_relocation_admission(
            root,
            item["reference"],
            item["incomingLinks"],
            receipt_path=receipt_path,
        )
        if admission is not None:
            admissions.append((item, admission))
    if len(admissions) > 1:
        raise _terminalization_fail("only one exact physical relocation is admitted")
    consumer_plans: list[dict] = []
    receipt_links: list[dict] = []
    for item, admission in admissions:
        consumer_relative = admission["source"]
        consumer = _terminalization_bound_path(
            work_items, consumer_relative, label="physical-link consumer"
        )
        if consumer.suffix.casefold() != ".md" or not consumer.is_file():
            raise _terminalization_fail(
                f"physical-link consumer is not a Markdown file: {consumer_relative}"
            )
        if consumer == item["source"]:
            raise _terminalization_fail(
                f"physical-link consumer is also moving: {consumer_relative}"
            )
        before = consumer.read_bytes()
        before_sha256 = hashlib.sha256(before).hexdigest()
        if admission["sourceSha256"] != before_sha256:
            raise _terminalization_fail(
                f"physical-link consumer hash changed: {consumer_relative}"
            )
        if admission["targetSha256"] != item["beforeSha256"]:
            raise _terminalization_fail(
                f"physical-link target hash changed: {item['reference']}"
            )
        try:
            text = before.decode("utf-8")
        except UnicodeError as exc:
            raise _terminalization_fail(
                f"physical-link consumer is not UTF-8 Markdown: {consumer_relative}"
            ) from exc

        matches = [
            link
            for link in _markdown_local_links(text)
            if link.label == admission["label"] and link.href == admission["href"]
        ]
        if len(matches) != 1:
            raise _terminalization_fail(
                f"physical Markdown tuple is missing or duplicated: {consumer_relative}"
            )
        href_parts = _local_markdown_href_parts(admission["href"])
        if href_parts is None or not _markdown_href_resolves(
            consumer.parent, admission["href"], item["source"]
        ):
            raise _terminalization_fail(
                f"physical Markdown href resolves outside expected identity: {consumer_relative}"
            )
        new_path = Path(os.path.relpath(item["target"], consumer.parent)).as_posix()
        new_href = new_path + href_parts[1]
        if not _markdown_href_resolves(consumer.parent, new_href, item["target"]):
            raise _terminalization_fail(
                f"relocated href does not resolve to target: {consumer_relative}"
            )
        after_text = (
            text[:matches[0].href_start]
            + new_href
            + text[matches[0].href_end:]
        )
        after = after_text.encode("utf-8")
        after_sha256 = hashlib.sha256(after).hexdigest()
        consumer_plans.append(
            {
                "consumer": consumer,
                "consumerRelative": consumer_relative,
                "before": before,
                "beforeSha256": before_sha256,
                "after": after,
                "afterSha256": after_sha256,
            }
        )
        receipt_links.append(
            {
                "source": consumer_relative,
                "label": admission["label"],
                "oldHref": admission["href"],
                "newHref": new_href,
                "expectedIdentity": item["reference"],
                "finalTarget": item["targetRelative"],
                "sourceBeforeSha256": before_sha256,
                "sourceAfterSha256": None,
                "targetBeforeSha256": item["afterSha256"],
                "targetAfterSha256": None,
                "terminalAt": terminal_at,
            }
        )
    return consumer_plans, receipt_links


def _expected_physical_relocation_receipt(
    root: Path,
    reference: str,
    admission: dict,
    source: Path,
    target: Path,
    target_before_sha256: str,
    terminal_at: str,
    *,
    settled: bool,
) -> dict:
    """Derive the one receipt relation allowed by an admitted physical link."""
    work_items = _work_items_root(root)
    consumer_relative = admission["source"]
    consumer = _terminalization_bound_path(
        work_items, consumer_relative, label="physical-link consumer"
    )
    if not consumer.is_file():
        raise _terminalization_fail(
            f"physical-link consumer is missing: {consumer_relative}"
        )
    href_parts = _local_markdown_href_parts(admission["href"])
    if href_parts is None:
        raise _terminalization_fail(
            f"physical Markdown href is not local: {consumer_relative}"
        )
    expected_href = Path(os.path.relpath(target, consumer.parent)).as_posix() + href_parts[1]
    current_href = expected_href if settled else admission["href"]
    resolved_target = target if settled else source
    try:
        current = consumer.read_bytes()
        text = current.decode("utf-8")
    except (OSError, UnicodeError) as exc:
        raise _terminalization_fail(
            f"physical-link consumer is not UTF-8 Markdown: {consumer_relative}"
        ) from exc
    matches = [
        link
        for link in _markdown_local_links(text)
        if link.label == admission["label"]
        and link.href == current_href
        and _markdown_href_resolves(consumer.parent, link.href, resolved_target)
    ]
    if len(matches) != 1:
        raise _terminalization_fail(
            f"physical Markdown tuple is missing or duplicated: {consumer_relative}"
        )
    if settled:
        link = matches[0]
        source_before = hashlib.sha256(
            (
                text[:link.href_start]
                + admission["href"]
                + text[link.href_end:]
            ).encode("utf-8")
        ).hexdigest()
        source_after: str | None = hashlib.sha256(current).hexdigest()
        target_after: str | None = hashlib.sha256(target.read_bytes()).hexdigest()
    else:
        source_before = hashlib.sha256(current).hexdigest()
        source_after = None
        target_after = None
    payload = target if settled else source
    if (
        source_before != admission["sourceSha256"]
        or hashlib.sha256(payload.read_bytes()).hexdigest() != target_before_sha256
        or (settled and target_after != target_before_sha256)
    ):
        raise _terminalization_fail(
            f"physical-relocation evidence differs for {reference}"
        )
    return {
        "source": consumer_relative,
        "label": admission["label"],
        "oldHref": admission["href"],
        "newHref": expected_href,
        "expectedIdentity": reference,
        "finalTarget": target.relative_to(work_items).as_posix(),
        "sourceBeforeSha256": source_before,
        "sourceAfterSha256": source_after,
        "targetBeforeSha256": target_before_sha256,
        "targetAfterSha256": target_after,
        "terminalAt": terminal_at,
    }


def _terminalization_receipt_path(root: Path, path: Path) -> Path:
    return _bound_repository_scratch_path(
        root,
        path,
        label="terminalization receipt",
        allow_absolute=True,
    )


def _terminalization_replay(
    root: Path,
    inventory: dict,
    inventory_sha256: str,
    terminal_at: str,
    authorization_marker: str,
    receipt_path: Path,
) -> tuple[int, bool] | None:
    if not receipt_path.exists():
        return None
    if not receipt_path.is_file():
        raise _terminalization_fail(
            f"terminalization receipt is not a file: {receipt_path}"
        )
    try:
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise _terminalization_fail(
            f"existing terminalization receipt is invalid: {receipt_path}"
        ) from exc
    work_items = _work_items_root(root)
    expected_header = {
        "schemaVersion": V1_TERMINALIZATION_SCHEMA_VERSION,
        "owner": V1_TERMINALIZATION_OWNER,
        "workItemsRoot": str(work_items.resolve()),
        "inventorySha256": inventory_sha256,
        "terminalAt": terminal_at,
        "authorizationMarker": authorization_marker,
        "rowCount": len(inventory["rows"]),
        "linkCount": sum(
            1
            for inventory_row in inventory["rows"]
            if isinstance(inventory_row, dict)
            for link in (inventory_row.get("incomingLinks") or {}).get("references", [])
            if isinstance(link, dict) and link.get("kind") == "physical"
        ),
    }
    if not isinstance(receipt, dict) or any(
        receipt.get(key) != value for key, value in expected_header.items()
    ):
        raise _terminalization_fail(
            "existing terminalization receipt does not match this exact operation"
        )
    receipt_rows = receipt.get("rows")
    if not isinstance(receipt_rows, list) or len(receipt_rows) != len(
        inventory["rows"]
    ):
        raise _terminalization_fail(
            "existing terminalization receipt row set differs"
        )
    inventory_references = sorted(
        row.get("reference") for row in inventory["rows"] if isinstance(row, dict)
    )
    receipt_references = sorted(
        row.get("reference") for row in receipt_rows if isinstance(row, dict)
    )
    if inventory_references != receipt_references:
        raise _terminalization_fail(
            "existing terminalization receipt references differ"
        )
    inventory_by_reference = {
        row.get("reference"): row for row in inventory["rows"] if isinstance(row, dict)
    }
    receipt_pairs: set[tuple[str, str]] = set()
    for row in receipt_rows:
        if not isinstance(row, dict):
            raise _terminalization_fail(
                "existing terminalization receipt contains an invalid row"
            )
        inventory_row = inventory_by_reference.get(row.get("reference"))
        if not isinstance(inventory_row, dict):
            raise _terminalization_fail(
                f"terminalization receipt has no inventory row: {row.get('reference')}"
            )
        source = _terminalization_bound_path(
            work_items, row.get("source"), label="receipt source"
        )
        target = _terminalization_bound_path(
            work_items, row.get("target"), label="receipt target"
        )
        category, slug = _canonical_category(row["reference"])
        expected_target = (
            work_items
            / category.current_root
            / "archive"
            / archive_month(terminal_at)
            / f"{slug}.md"
        ).resolve()
        source_exists = source.is_file()
        target_exists = target.is_file()
        payload = source if source_exists else target
        if (
            row.get("source") != inventory_row.get("source")
            or row.get("beforeSha256") != inventory_row.get("inputSha256")
            or source_exists == target_exists
            or target != expected_target
            or row.get("afterSha256")
            != hashlib.sha256(payload.read_bytes()).hexdigest()
            or _category_locations(root, category, slug) != [payload]
        ):
            raise _terminalization_fail(
                f"terminalized payload differs from receipt: {row.get('reference')}"
            )
        receipt_pairs.add((row["source"], row["target"]))
    receipt_link_rows = [
        (receipt_row, receipt_row["physicalRelocation"])
        for receipt_row in receipt_rows
        if isinstance(receipt_row, dict)
        and isinstance(receipt_row.get("physicalRelocation"), dict)
    ]
    if len(receipt_link_rows) != expected_header["linkCount"]:
        raise _terminalization_fail("existing terminalization receipt link set differs")
    seen_link_rows: set[tuple[str, str, str, str]] = set()
    for owner_row, link in receipt_link_rows:
        if not isinstance(link, dict) or link.get("terminalAt") != terminal_at:
            raise _terminalization_fail("existing terminalization receipt link row is invalid")
        consumer = _terminalization_bound_path(
            work_items, link.get("source"), label="receipt link consumer"
        )
        new_target = _terminalization_bound_path(
            work_items, link.get("finalTarget"), label="receipt new target"
        )
        before_sha256 = link.get("sourceBeforeSha256")
        after_sha256 = link.get("sourceAfterSha256")
        target_before_sha256 = link.get("targetBeforeSha256")
        target_after_sha256 = link.get("targetAfterSha256")
        old_href = link.get("oldHref")
        new_href = link.get("newHref")
        label = link.get("label")
        identity = link.get("expectedIdentity")
        old_target_relative = next(
            (
                old
                for old, new in receipt_pairs
                if new == link.get("finalTarget")
            ),
            None,
        )
        old_target = (
            _terminalization_bound_path(
                work_items, old_target_relative, label="receipt old target"
            )
            if old_target_relative is not None
            else None
        )
        pending = old_target is not None and old_target.is_file() and not new_target.exists()
        settled = old_target is not None and not old_target.exists() and new_target.is_file()
        if (
            old_target is None
            or not isinstance(before_sha256, str)
            or not re.fullmatch(r"[0-9a-f]{64}", before_sha256)
            or not isinstance(target_before_sha256, str)
            or not re.fullmatch(r"[0-9a-f]{64}", target_before_sha256)
            or (pending and (after_sha256 is not None or target_after_sha256 is not None))
            or (
                settled
                and (
                    not isinstance(after_sha256, str)
                    or not re.fullmatch(r"[0-9a-f]{64}", after_sha256)
                    or not isinstance(target_after_sha256, str)
                    or not re.fullmatch(r"[0-9a-f]{64}", target_after_sha256)
                    or hashlib.sha256(new_target.read_bytes()).hexdigest()
                    != target_after_sha256
                )
            )
            or not isinstance(old_href, str)
            or not isinstance(new_href, str)
            or not isinstance(label, str)
            or not isinstance(identity, str)
            or not (pending or settled)
            or not consumer.is_file()
            or hashlib.sha256(consumer.read_bytes()).hexdigest()
            != (before_sha256 if pending else after_sha256)
        ):
            raise _terminalization_fail(
                f"terminalized link differs from receipt: {link.get('source')}"
            )
        key = (link["source"], old_href, new_href, link["finalTarget"])
        if key in seen_link_rows:
            raise _terminalization_fail("terminalization receipt repeats a physical link")
        seen_link_rows.add(key)
        try:
            text = consumer.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            raise _terminalization_fail(
                f"terminalized link consumer is unreadable: {link.get('source')}"
            ) from exc
        expected_href = old_href if pending else new_href
        expected_target = old_target if pending else new_target
        resolved_matches = [
            link
            for link in _markdown_local_links(text)
            if link.label == label
            and link.href == expected_href
            and _markdown_href_resolves(consumer.parent, link.href, expected_target)
        ]
        if len(resolved_matches) != 1:
            raise _terminalization_fail(
                f"terminalized Markdown href is missing: {link.get('source')}"
            )
        owner_reference = owner_row["reference"]
        owner_inventory_row = inventory_by_reference[owner_reference]
        _links, admission = _physical_relocation_admission(
            root,
            owner_reference,
            owner_inventory_row.get("incomingLinks"),
            receipt_path=receipt_path,
        )
        if admission is None or link != _expected_physical_relocation_receipt(
            root,
            owner_reference,
            admission,
            old_target,
            new_target,
            owner_row["afterSha256"],
            terminal_at,
            settled=settled,
        ):
            raise _terminalization_fail(
                f"terminalized physical-relocation receipt differs: {link.get('source')}"
            )
    return len(receipt_rows), True


def _preflight_v1_terminalization_rows(
    root: Path,
    inventory: dict,
    terminal_at: str,
    receipt_path: Path,
) -> tuple[list[dict], list[dict], list[dict]]:
    _strict_utc(terminal_at)
    work_items = _work_items_root(root)
    planned: list[dict] = []
    seen_sources: set[Path] = set()
    seen_targets: set[Path] = set()
    for row in inventory["rows"]:
        if not isinstance(row, dict):
            raise _terminalization_fail("terminalization inventory row is not an object")
        category_name = row.get("category")
        try:
            category, slug = _canonical_category(row.get("reference", ""))
        except LifecycleError as exc:
            raise _terminalization_fail(str(exc)) from exc
        if category.current_kind != "flat":
            raise _terminalization_fail(
                f"unsupported V1 terminalization category: {category_name!r}"
            )
        admission_row = _admission_for(category.name)
        if category.name != category_name:
            raise _terminalization_fail(
                f"category tuple differs for {row.get('reference')}"
            )
        admission = row.get("admission")
        if (
            not isinstance(admission, dict)
            or admission.get("result") != "denied"
            or admission.get("failureId") != V1_TERMINALIZATION_FAILURE
        ):
            raise _terminalization_fail(
                f"row is not denied solely for missing terminal evidence: "
                f"{row.get('reference')}"
            )
        incoming = row.get("incomingLinks")
        _incoming_rows, physical_relocation = _physical_relocation_admission(
            root,
            row["reference"],
            incoming,
            receipt_path=receipt_path,
        )
        if row.get("target") is not None or row.get("terminalInstant") is not None:
            raise _terminalization_fail(
                f"denied row already has a target or terminal instant: "
                f"{row.get('reference')}"
            )
        source = _terminalization_bound_path(
            work_items, row.get("source"), label="terminalization source"
        )
        expected_source = (
            work_items / category.current_root / f"{slug}.md"
        ).resolve()
        if source != expected_source or source in seen_sources:
            raise _terminalization_fail(
                f"source binding is ambiguous for {row.get('reference')}"
            )
        seen_sources.add(source)
        try:
            locations = _category_locations(root, category, slug)
        except OSError as exc:
            raise _terminalization_fail(
                f"cannot resolve locations for {row.get('reference')}"
            ) from exc
        if locations != [source] or not source.is_file():
            raise _terminalization_fail(
                f"current location is ambiguous for {row.get('reference')}"
            )
        target_relative = (
            Path(category.current_root)
            / "archive"
            / archive_month(terminal_at)
            / source.name
        ).as_posix()
        target = _terminalization_bound_path(
            work_items, target_relative, label="terminalization target"
        )
        if target in seen_targets or target.exists():
            raise _terminalization_fail(
                f"terminalization target is ambiguous for {row.get('reference')}"
            )
        seen_targets.add(target)
        if row.get("digestAlgorithm") != MIGRATION_DIGEST_ALGORITHMS["file"]:
            raise _terminalization_fail(
                f"unsupported digest algorithm for {row.get('reference')}"
            )
        before = source.read_bytes()
        before_sha256 = hashlib.sha256(before).hexdigest()
        if row.get("inputSha256") != before_sha256:
            raise _terminalization_fail(
                f"input payload hash changed for {row.get('reference')}"
            )
        try:
            text = before.decode("utf-8")
        except UnicodeError as exc:
            raise _terminalization_fail(
                f"terminal record is not UTF-8: {row.get('reference')}"
            ) from exc
        fields = _parse_fields(text)
        status = fields.get("status", "")
        if status not in category.terminal_statuses:
            raise _terminalization_fail(
                f"current status is not terminal for {row.get('reference')}: "
                f"{status!r}"
            )
        detail_field = admission_row.detail_field
        conflicting = tuple(
            dict.fromkeys(
                _terminalization_authoritative_field_occurrences(
                    text, admission_row.utc_field
                )
            )
        )
        if conflicting:
            raise _terminalization_fail(
                f"authoritative terminal field already exists for "
                f"{row.get('reference')}: {', '.join(conflicting)}"
            )
        current_links = _incoming_link_result(
            root,
            {source},
            row["reference"],
        )
        expected_current_links = (
            {
                "result": "unmapped",
                "references": incoming["references"],
            }
            if physical_relocation is not None
            else incoming
        )
        if current_links != expected_current_links:
            raise _terminalization_fail(
                f"incoming-link inventory changed for {row.get('reference')}"
            )
        separator = b"\n" if before.endswith(b"\n") else b"\n\n"
        proof = (
            "Historical terminal time is unknown; preserved pre-V1 input "
            f"SHA-256 `{before_sha256}`; original terminal status `{status}`; "
            "explicit operator-authorized V1 migration."
        )
        appended_lines = [f"{admission_row.utc_field}: {terminal_at}"]
        if not fields.get(detail_field.casefold()):
            appended_lines.append(
                f"{detail_field}: Pre-V1 terminal status `{status}` is preserved "
                "during operator-authorized V1 physical migration."
            )
        if not fields.get(admission_row.evidence_field.casefold()):
            appended_lines.append(f"{admission_row.evidence_field}: {proof}")
        appended_lines.append(f"V1-Migration-Evidence: {proof}")
        appended = ("\n".join(appended_lines) + "\n").encode("utf-8")
        after = before + separator + appended
        planned.append(
            {
                "reference": row["reference"],
                "sourceRelative": row["source"],
                "source": source,
                "targetRelative": target_relative,
                "target": target,
                "category": category,
                "slug": slug,
                "incomingLinks": incoming,
                "status": status,
                "before": before,
                "beforeSha256": before_sha256,
                "after": after,
                "afterSha256": hashlib.sha256(after).hexdigest(),
            }
        )
    planned = sorted(planned, key=lambda item: item["reference"])
    source_set = {item["source"] for item in planned}
    target_set = {item["target"] for item in planned}
    if source_set & target_set:
        raise _terminalization_fail("terminalization source and target sets overlap")
    consumers, receipt_links = _plan_v1_link_relocations(
        root, planned, terminal_at, receipt_path
    )
    return planned, consumers, receipt_links


def terminalize_v1_inventory(
    root: Path,
    inventory_path: Path,
    *,
    terminal_at: str,
    authorization_marker: str,
    receipt_path: Path,
    inject_failure_after: int | None = None,
) -> tuple[int, bool]:
    """Add V1 evidence and preserve exact relocation admission; never move records."""
    if authorization_marker != V1_TERMINALIZATION_AUTHORIZATION:
        raise _terminalization_fail(
            "explicit operator-authorized V1 terminalization marker is required"
        )
    _strict_utc(terminal_at)
    receipt = _terminalization_receipt_path(root, receipt_path)
    try:
        inventory_bytes = inventory_path.read_bytes()
        inventory = _load_migration_inventory(root, inventory_path)
    except LifecycleError as exc:
        raise _terminalization_fail(str(exc)) from exc
    except OSError as exc:
        raise _terminalization_fail(
            f"cannot read terminalization inventory: {inventory_path}"
        ) from exc
    inventory_sha256 = hashlib.sha256(inventory_bytes).hexdigest()
    replay = _terminalization_replay(
        root,
        inventory,
        inventory_sha256,
        terminal_at,
        authorization_marker,
        receipt,
    )
    if replay is not None:
        return replay
    planned, consumers, receipt_links = _preflight_v1_terminalization_rows(
        root, inventory, terminal_at, receipt
    )
    links_by_identity = {
        link["expectedIdentity"]: link for link in receipt_links
    }
    receipt_payload = {
        "schemaVersion": V1_TERMINALIZATION_SCHEMA_VERSION,
        "owner": V1_TERMINALIZATION_OWNER,
        "workItemsRoot": str(_work_items_root(root).resolve()),
        "inventorySha256": inventory_sha256,
        "terminalAt": terminal_at,
        "authorizationMarker": authorization_marker,
        "rowCount": len(planned),
        "linkCount": len(receipt_links),
        "rows": [
            {
                "reference": item["reference"],
                "source": item["sourceRelative"],
                "target": item["targetRelative"],
                "terminalAt": terminal_at,
                "originalStatus": item["status"],
                "beforeSha256": item["beforeSha256"],
                "afterSha256": item["afterSha256"],
                **(
                    {"physicalRelocation": links_by_identity[item["reference"]]}
                    if item["reference"] in links_by_identity
                    else {}
                ),
            }
            for item in planned
        ],
    }
    receipt_bytes = (
        json.dumps(receipt_payload, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    mutated_items: list[dict] = []
    try:
        for index, item in enumerate(planned, start=1):
            if item["source"].read_bytes() != item["before"]:
                raise _terminalization_fail(
                    f"payload changed after preflight: {item['reference']}"
                )
            _atomic_write(item["source"], item["after"])
            mutated_items.append(item)
            if inject_failure_after == index:
                raise _terminalization_fail(
                    f"injected terminalization failure after row {index}"
                )
        _atomic_write(receipt, receipt_bytes)
        for consumer in consumers:
            if consumer["consumer"].read_bytes() != consumer["before"]:
                raise _terminalization_fail(
                    f"terminalization rewrote consumer: {consumer['consumerRelative']}"
                )
        for item in planned:
            if (
                not item["source"].is_file()
                or item["target"].exists()
                or item["source"].read_bytes() != item["after"]
                or _category_locations(root, item["category"], item["slug"])
                != [item["source"]]
            ):
                raise _terminalization_fail(
                    f"terminalization identity check failed: {item['reference']}"
                )
    except Exception as exc:
        rollback_failures: list[str] = []
        for item in reversed(mutated_items):
            try:
                _atomic_write(item["source"], item["before"])
            except Exception as rollback_exc:
                rollback_failures.append(
                    f"{item['reference']}: {rollback_exc}"
                )
        if receipt.exists():
            try:
                receipt.unlink()
            except OSError as rollback_exc:
                rollback_failures.append(f"receipt: {rollback_exc}")
        if rollback_failures:
            raise _terminalization_fail(
                "terminalization rollback failed: " + "; ".join(rollback_failures)
            ) from exc
        if isinstance(exc, LifecycleError):
            raise
        raise _terminalization_fail(
            f"terminalization transaction failed: {exc}"
        ) from exc
    return len(planned), False


def _bound_inventory_path(work_items: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY", "inventory path is missing"
        )
    unresolved_root = _lifecycle_unresolved_absolute(work_items)
    unresolved_path = unresolved_root / Path(relative)
    _lifecycle_reject_unreduced_reparse(
        unresolved_root,
        failure_id="WI-CATEGORY-MIGRATION-INVENTORY",
        message="work-items root or parent contains a link or reparse point",
    )
    _lifecycle_reject_unreduced_reparse(
        unresolved_path,
        failure_id="WI-CATEGORY-MIGRATION-INVENTORY",
        message=f"inventory path contains a link or reparse point: {relative}",
    )
    root = Path(os.path.abspath(unresolved_root))
    path = Path(os.path.abspath(unresolved_path))
    if path != root and root not in path.parents:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            f"inventory path escapes work-items: {relative}",
        )
    return path


def _terminalization_receipt_for_migration(
    root: Path,
    inventory_path: Path,
    inventory: dict,
) -> tuple[Path, bytes, dict]:
    admissions = [
        row["incomingLinks"]["physicalRelocation"]
        for row in inventory["rows"]
        if isinstance(row, dict)
        and isinstance(row.get("incomingLinks"), dict)
        and isinstance(row["incomingLinks"].get("physicalRelocation"), dict)
    ]
    if len(admissions) != 1:
        raise LifecycleError(
            "WI-LEGACY-LINK-UNMAPPED",
            "migration requires exactly one physical-relocation admission",
        )
    receipt_path = _bound_physical_receipt(root, admissions[0].get("receipt"))
    try:
        receipt_bytes = receipt_path.read_bytes()
        receipt = json.loads(receipt_bytes.decode("utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            f"physical-relocation receipt is invalid: {receipt_path}",
        ) from exc
    inventory_sha256 = hashlib.sha256(inventory_path.read_bytes()).hexdigest()
    work_items = _work_items_root(root)
    if (
        not isinstance(receipt, dict)
        or receipt.get("schemaVersion") != V1_TERMINALIZATION_SCHEMA_VERSION
        or receipt.get("owner") != V1_TERMINALIZATION_OWNER
        or receipt.get("workItemsRoot") != str(work_items.resolve())
        or receipt.get("inventorySha256") != inventory_sha256
        or receipt.get("authorizationMarker") != V1_TERMINALIZATION_AUTHORIZATION
        or receipt.get("rowCount") != len(inventory["rows"])
        or receipt.get("linkCount") != 1
        or not isinstance(receipt.get("rows"), list)
        or len(receipt["rows"]) != len(inventory["rows"])
        or not isinstance(receipt.get("terminalAt"), str)
    ):
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY",
            "physical-relocation receipt binding differs",
        )
    _strict_utc(receipt["terminalAt"])
    return receipt_path, receipt_bytes, receipt


def _preflight_terminalized_inventory_rows(
    root: Path,
    inventory_path: Path,
    inventory: dict,
) -> tuple[list[dict], list[dict], Path, bytes, dict]:
    work_items = _work_items_root(root)
    receipt_path, receipt_bytes, receipt = _terminalization_receipt_for_migration(
        root, inventory_path, inventory
    )
    replay = _terminalization_replay(
        root,
        inventory,
        hashlib.sha256(inventory_path.read_bytes()).hexdigest(),
        receipt["terminalAt"],
        V1_TERMINALIZATION_AUTHORIZATION,
        receipt_path,
    )
    if replay is None:
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY", "terminalization receipt is missing"
        )
    receipt_rows = {row.get("reference"): row for row in receipt["rows"] if isinstance(row, dict)}
    if len(receipt_rows) != len(inventory["rows"]):
        raise LifecycleError(
            "WI-CATEGORY-MIGRATION-INVENTORY", "terminalization receipt repeats a row"
        )
    plans: list[dict] = []
    consumers: list[dict] = []
    seen_sources: set[Path] = set()
    seen_targets: set[Path] = set()
    for row in inventory["rows"]:
        reference = row.get("reference") if isinstance(row, dict) else None
        receipt_row = receipt_rows.get(reference)
        admission = row.get("admission") if isinstance(row, dict) else None
        if (
            not isinstance(row, dict)
            or not isinstance(receipt_row, dict)
            or not isinstance(admission, dict)
            or admission.get("result") != "denied"
            or admission.get("failureId") != V1_TERMINALIZATION_FAILURE
        ):
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-INVENTORY",
                f"terminalized inventory row is invalid: {reference}",
            )
        category, slug = _canonical_category(reference)
        if row.get("category") != category.name:
            raise LifecycleError(
                "CATEGORY-MIGRATION-ADMISSION-GATE",
                f"category tuple differs for {reference}",
            )
        source = _bound_inventory_path(work_items, row.get("source"))
        target = _bound_inventory_path(work_items, receipt_row.get("target"))
        if source in seen_sources or target in seen_targets:
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION", "terminalized inventory repeats a source or target"
            )
        seen_sources.add(source)
        seen_targets.add(target)
        source_exists = source.is_file()
        target_exists = target.is_file()
        if source_exists == target_exists:
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION", f"terminalized location differs for {reference}"
            )
        payload = source if source_exists else target
        payload_sha256 = hashlib.sha256(payload.read_bytes()).hexdigest()
        if (
            receipt_row.get("source") != row.get("source")
            or receipt_row.get("beforeSha256") != row.get("inputSha256")
            or receipt_row.get("afterSha256") != payload_sha256
            or receipt_row.get("terminalAt") != receipt["terminalAt"]
        ):
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD", f"terminalized payload changed for {reference}"
            )
        instant, expected_target = _validated_migration_payload_target(
            root, category, slug, payload
        )
        if instant != receipt["terminalAt"] or target != expected_target.resolve():
            raise LifecycleError(
                "WI-CATEGORY-ARCHIVE-MONTH-MISMATCH", f"terminalized target differs for {reference}"
            )
        if _category_locations(root, category, slug) != [payload]:
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION", f"terminalized identity differs for {reference}"
            )
        incoming = row.get("incomingLinks")
        _links, physical = _physical_relocation_admission(
            root, reference, incoming, receipt_path=receipt_path
        )
        plan = {
            "row": row,
            "reference": reference,
            "category": category,
            "slug": slug,
            "source": source,
            "target": target,
            "pending": source_exists,
            "beforeSha256": receipt_row["afterSha256"],
            "receiptRow": receipt_row,
        }
        if physical is None:
            current_links = _incoming_link_result(root, {source, target}, reference)
            _validate_incoming_link_compatibility(
                root,
                reference,
                incoming,
                current_links,
                resolved_location=payload,
            )
        elif source_exists:
            planned_consumers, planned_links = _plan_v1_link_relocations(
                root,
                [
                    {
                        "reference": reference,
                        "sourceRelative": row["source"],
                        "source": source,
                        "targetRelative": receipt_row["target"],
                        "target": target,
                        "incomingLinks": incoming,
                        "beforeSha256": row["inputSha256"],
                        "afterSha256": receipt_row["afterSha256"],
                    }
                ],
                receipt["terminalAt"],
                receipt_path,
            )
            if planned_links != [receipt_row.get("physicalRelocation")]:
                raise LifecycleError(
                    "WI-LEGACY-LINK-UNMAPPED",
                    f"physical-relocation receipt differs for {reference}",
                )
            consumers.extend(planned_consumers)
        plans.append(plan)
    source_set = {plan["source"] for plan in plans}
    target_set = {plan["target"] for plan in plans}
    if source_set & target_set:
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", "source and target sets overlap")
    return sorted(plans, key=lambda plan: plan["reference"]), consumers, receipt_path, receipt_bytes, receipt


def _preflight_inventory_rows(
    root: Path,
    inventory: dict,
) -> list[tuple[dict, Path, Path, bool]]:
    work_items = _work_items_root(root)
    planned: list[tuple[dict, Path, Path, bool]] = []
    seen_sources: set[Path] = set()
    seen_targets: set[Path] = set()
    for row in inventory["rows"]:
        if not isinstance(row, dict):
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-INVENTORY", "inventory row is not an object"
            )
        admission = row.get("admission")
        if not isinstance(admission, dict) or admission.get("result") != "admitted":
            raise LifecycleError(
                (admission or {}).get(
                    "failureId", "CATEGORY-MIGRATION-ADMISSION-GATE"
                ),
                (admission or {}).get("reason", "inventory row is not admitted"),
            )
        incoming = row.get("incomingLinks")
        if not isinstance(incoming, dict) or incoming.get("result") not in {
            "clear",
            "logical-only",
        }:
            raise LifecycleError(
                "WI-LEGACY-LINK-UNMAPPED",
                f"incoming links are not mapped for {row.get('reference')}",
            )
        category, slug = _canonical_category(row.get("reference", ""))
        if row.get("category") != category.name:
            raise LifecycleError(
                "CATEGORY-MIGRATION-ADMISSION-GATE",
                f"category tuple differs for {row.get('reference')}",
            )
        source = _bound_inventory_path(work_items, row.get("source"))
        target = _bound_inventory_path(work_items, row.get("target"))
        if source in seen_sources or target in seen_targets:
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION", "inventory repeats a source or target"
            )
        seen_sources.add(source)
        seen_targets.add(target)
        source_exists = source.exists()
        target_exists = target.exists()
        if source_exists == target_exists:
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION",
                f"pre-migration location differs for {row.get('reference')}",
            )
        payload = source if source_exists else target
        locations = _category_locations(root, category, slug)
        if locations != [payload]:
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION",
                f"resolved location differs for {row.get('reference')}",
            )
        algorithm, digest = _payload_digest(payload)
        if (
            row.get("digestAlgorithm") != algorithm
            or row.get("inputSha256") != digest
        ):
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD",
                f"migration payload changed for {row.get('reference')}",
            )
        instant, expected_target = _validated_migration_payload_target(
            root, category, slug, payload
        )
        if (
            row.get("terminalInstant") != instant
            or target != expected_target.resolve()
        ):
            raise LifecycleError(
                "WI-CATEGORY-ARCHIVE-MONTH-MISMATCH",
                f"planned target differs for {row.get('reference')}",
            )
        current_links = _incoming_link_result(
            root,
            {source, target},
            row["reference"],
        )
        _validate_incoming_link_compatibility(
            root,
            row["reference"],
            incoming,
            current_links,
            resolved_location=payload,
        )
        planned.append((row, source, target, source_exists))
    source_set = {source for _row, source, _target, _pending in planned}
    target_set = {target for _row, _source, target, _pending in planned}
    if source_set & target_set:
        raise LifecycleError(
            "WI-CATEGORY-DUAL-LOCATION", "source and target sets overlap"
        )
    return sorted(planned, key=lambda item: item[0]["reference"])


def apply_migration_inventory(
    root: Path,
    inventory_path: Path,
    *,
    render_readme: bool,
    byte_check: bool,
) -> tuple[int, str | None]:
    inventory = _load_migration_inventory(root, inventory_path)
    has_physical_relocation = any(
        isinstance(row, dict)
        and isinstance(row.get("incomingLinks"), dict)
        and isinstance(row["incomingLinks"].get("physicalRelocation"), dict)
        for row in inventory["rows"]
    )
    if has_physical_relocation:
        plans, consumers, receipt_path, receipt_before, receipt_payload = (
            _preflight_terminalized_inventory_rows(root, inventory_path, inventory)
        )
        work_items = _work_items_root(root)
        readme = work_items / "README.md"
        readme_before = readme.read_bytes() if readme.is_file() else None
        written_consumers: list[dict] = []
        moved: list[dict] = []
        created_directories: set[Path] = set()
        try:
            for consumer in consumers:
                if consumer["consumer"].read_bytes() != consumer["before"]:
                    raise LifecycleError(
                        "WI-LEGACY-LINK-UNMAPPED",
                        f"consumer changed after preflight: {consumer['consumerRelative']}",
                    )
                _atomic_write(consumer["consumer"], consumer["after"])
                written_consumers.append(consumer)
            for plan in plans:
                if not plan["pending"]:
                    continue
                if (
                    not plan["source"].is_file()
                    or plan["target"].exists()
                    or hashlib.sha256(plan["source"].read_bytes()).hexdigest()
                    != plan["beforeSha256"]
                ):
                    raise LifecycleError(
                        "WI-CATEGORY-MIGRATION-PAYLOAD",
                        f"payload changed after preflight: {plan['reference']}",
                    )
                cursor = plan["target"].parent
                while cursor != work_items and not cursor.exists():
                    created_directories.add(cursor)
                    cursor = cursor.parent
                plan["target"].parent.mkdir(parents=True, exist_ok=True)
                os.replace(plan["source"], plan["target"])
                moved.append(plan)
            readme_hash: str | None = None
            if render_readme:
                readme_hash = refresh_readme(root, allow_marker_bootstrap=True)
            if byte_check and (
                not readme.is_file() or readme.read_bytes() != render_readme_bytes(root)
            ):
                raise LifecycleError(
                    "WI-README-STALE", "README differs from an immediate fresh render"
                )
            for plan in plans:
                if (
                    plan["source"].exists()
                    or not plan["target"].is_file()
                    or hashlib.sha256(plan["target"].read_bytes()).hexdigest()
                    != plan["beforeSha256"]
                    or _category_locations(root, plan["category"], plan["slug"])
                    != [plan["target"]]
                ):
                    raise LifecycleError(
                        "WI-CATEGORY-DUAL-LOCATION",
                        f"migration identity check failed: {plan['reference']}",
                    )
            consumers_by_source = {
                consumer["consumerRelative"]: consumer for consumer in consumers
            }
            for row in receipt_payload["rows"]:
                evidence = row.get("physicalRelocation")
                if not isinstance(evidence, dict):
                    continue
                consumer = consumers_by_source.get(evidence.get("source"))
                if consumer is None:
                    if not isinstance(evidence.get("sourceAfterSha256"), str):
                        raise LifecycleError(
                            "WI-LEGACY-LINK-UNMAPPED",
                            "settled physical relocation lacks receipt evidence",
                        )
                    continue
                if (
                    consumer["consumer"].read_bytes() != consumer["after"]
                    or not _markdown_href_resolves(
                        consumer["consumer"].parent,
                        evidence["newHref"],
                        _bound_inventory_path(work_items, evidence["finalTarget"]),
                    )
                ):
                    raise LifecycleError(
                        "WI-LEGACY-LINK-UNMAPPED",
                        "migrated Markdown href does not resolve to final target",
                    )
                evidence["sourceAfterSha256"] = consumer["afterSha256"]
                final_target = _bound_inventory_path(work_items, evidence["finalTarget"])
                evidence["targetAfterSha256"] = hashlib.sha256(
                    final_target.read_bytes()
                ).hexdigest()
            _atomic_write(
                receipt_path,
                (json.dumps(receipt_payload, indent=2, sort_keys=True) + "\n").encode(
                    "utf-8"
                ),
            )
            return len(plans), readme_hash
        except Exception as exc:
            rollback_failures: list[str] = []
            for plan in reversed(moved):
                try:
                    if plan["target"].exists() and not plan["source"].exists():
                        plan["source"].parent.mkdir(parents=True, exist_ok=True)
                        os.replace(plan["target"], plan["source"])
                except Exception as rollback_exc:
                    rollback_failures.append(
                        f"{plan['reference']}: {rollback_exc}"
                    )
            for consumer in reversed(written_consumers):
                try:
                    _atomic_write(consumer["consumer"], consumer["before"])
                except Exception as rollback_exc:
                    rollback_failures.append(
                        f"{consumer['consumerRelative']}: {rollback_exc}"
                    )
            try:
                _restore_readme_snapshot(readme, readme_before)
            except Exception as rollback_exc:
                rollback_failures.append(f"README: {rollback_exc}")
            try:
                _atomic_write(receipt_path, receipt_before)
            except Exception as rollback_exc:
                rollback_failures.append(f"receipt: {rollback_exc}")
            for directory in sorted(
                created_directories, key=lambda path: len(path.parts), reverse=True
            ):
                try:
                    if directory.is_dir() and not any(directory.iterdir()):
                        directory.rmdir()
                except OSError as rollback_exc:
                    rollback_failures.append(f"directory {directory}: {rollback_exc}")
            if rollback_failures:
                raise LifecycleError(
                    "WI-CATEGORY-MIGRATION-INVENTORY",
                    "physical-relocation rollback failed: " + "; ".join(rollback_failures),
                ) from exc
            if isinstance(exc, LifecycleError):
                raise
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-INVENTORY",
                f"physical-relocation transaction failed: {exc}",
            ) from exc
    planned = _preflight_inventory_rows(root, inventory)
    for _row, source, target, pending in planned:
        if not pending:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        os.replace(source, target)
    readme_hash: str | None = None
    if render_readme:
        readme_hash = refresh_readme(root, allow_marker_bootstrap=True)
    if byte_check:
        readme = _work_items_root(root) / "README.md"
        if not readme.is_file() or readme.read_bytes() != render_readme_bytes(root):
            raise LifecycleError(
                "WI-README-STALE", "README differs from an immediate fresh render"
            )
    for _row, source, target, _pending in planned:
        if source.exists() or not target.exists():
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION",
                "source-target disjointness failed after migration",
            )
    return len(planned), readme_hash


def _partial_recovery_fail(failure_id: str, message: str) -> LifecycleError:
    return LifecycleError(failure_id, f"partial-migration-recovery: {message}")


def _partial_recovery_sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def _partial_recovery_bound_scratch_file(
    root: Path,
    path: Path,
    *,
    label: str,
) -> Path:
    unresolved_root = _lifecycle_unresolved_absolute(root)
    repository_root = (
        unresolved_root.parent
        if unresolved_root.name == "work-items"
        else unresolved_root
    )
    candidate = path if path.is_absolute() else repository_root / path
    _lifecycle_reject_unreduced_reparse(
        unresolved_root,
        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
        message=f"{label} root or parent contains a link or reparse point",
    )
    _lifecycle_reject_unreduced_reparse(
        repository_root / "work-items",
        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
        message=f"{label} work-items root contains a link or reparse point",
    )
    _lifecycle_reject_unreduced_reparse(
        candidate,
        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
        message=f"{label} contains a link or reparse point",
    )
    repository_root = Path(os.path.abspath(repository_root))
    candidate = Path(os.path.abspath(candidate))
    try:
        relative = candidate.relative_to(repository_root)
    except ValueError as exc:
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
            f"{label} escapes the repository",
        ) from exc
    if len(relative.parts) < 2 or relative.parts[0] != ".scratch":
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
            f"{label} must be a file under repository .scratch",
        )
    return repository_root / relative


def _partial_recovery_expected_paths(
    work_items: Path,
    reference: str,
) -> tuple[str, str, Path, Path]:
    category, slug = _canonical_category(reference)
    if category.name == "work-item":
        source_relative = f"active/{slug}"
        target_relative = f"archive/2026-08/{slug}"
    elif category.name == "bug":
        source_relative = f"bugs/{slug}.md"
        target_relative = f"bugs/archive/2026-08/{slug}.md"
    else:
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-COVERAGE",
            f"unsupported incident reference: {reference}",
        )
    return (
        source_relative,
        target_relative,
        _bound_inventory_path(work_items, source_relative),
        _bound_inventory_path(work_items, target_relative),
    )


def _partial_recovery_validate_target_path(path: Path, failure_id: str) -> None:
    cursor = path
    while True:
        if (cursor.exists() or cursor.is_symlink()) and _lifecycle_path_has_reparse(cursor):
            raise _partial_recovery_fail(failure_id, "target path contains a reparse point")
        if cursor.parent == cursor:
            break
        cursor = cursor.parent


def _partial_recovery_preflight(
    root: Path,
    inventory: dict,
) -> tuple[list[dict], list[dict]]:
    work_items = _work_items_root(root)
    rows = inventory["rows"]
    expected_references = set(PARTIAL_MIGRATION_RECOVERY_TARGETS) | set(
        PARTIAL_MIGRATION_RECOVERY_UNCHANGED_ROWS
    )
    references = [row.get("reference") for row in rows]
    if len(rows) != 4 or len(set(references)) != 4 or set(references) != expected_references:
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-COVERAGE",
            "inventory candidate set is not the exact admitted four-row incident",
        )
    status_plans: list[dict] = []
    unchanged_plans: list[dict] = []
    for row in sorted(rows, key=lambda item: item["reference"]):
        reference = row["reference"]
        source_relative, target_relative, source, target = (
            _partial_recovery_expected_paths(work_items, reference)
        )
        category, _slug = _canonical_category(reference)
        expected_digest = (
            PARTIAL_MIGRATION_RECOVERY_TARGETS[reference].inventory_tree_preimage
            if reference in PARTIAL_MIGRATION_RECOVERY_TARGETS
            else PARTIAL_MIGRATION_RECOVERY_UNCHANGED_ROWS[reference]
        )
        if (
            row.get("category") != category.name
            or row.get("source") != source_relative
            or row.get("target") != target_relative
            or str(row.get("inputSha256", "")).upper() != expected_digest.upper()
            or row.get("admission", {}).get("result") != "admitted"
            or not isinstance(row.get("terminalInstant"), str)
            or archive_month(row["terminalInstant"]) != "2026-08"
            or source.exists()
            or not target.exists()
        ):
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-COVERAGE",
                f"inventory row or source/target relation differs: {reference}",
            )
        _partial_recovery_validate_target_path(
            target,
            "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
        )
        algorithm, current_digest = _payload_digest(target)
        if algorithm != row.get("digestAlgorithm"):
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
                f"target digest algorithm differs: {reference}",
            )
        if reference not in PARTIAL_MIGRATION_RECOVERY_TARGETS:
            if current_digest.upper() != expected_digest.upper():
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
                    f"unchanged target bytes differ: {reference}",
                )
            _validate_flat_terminal(category, target.read_bytes())
            unchanged_plans.append(
                {
                    "reference": reference,
                    "row": row,
                    "source": source,
                    "target": target,
                    "digest": current_digest.upper(),
                }
            )
            continue
        contract = PARTIAL_MIGRATION_RECOVERY_TARGETS[reference]
        status_path = target / "status.md"
        closure_path = target / "closure.md"
        if not status_path.is_file() or not closure_path.is_file():
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-CLOSURE",
                f"status or closure is missing: {reference}",
            )
        _partial_recovery_validate_target_path(
            status_path,
            "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
        )
        _partial_recovery_validate_target_path(
            closure_path,
            "WI-PARTIAL-MIGRATION-RECOVERY-CLOSURE",
        )
        status_snapshot = _capture_file_snapshot(
            status_path,
            failure_id="WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
        )
        closure_snapshot = _capture_file_snapshot(
            closure_path,
            failure_id="WI-PARTIAL-MIGRATION-RECOVERY-CLOSURE",
        )
        status_before = status_snapshot.data
        closure_before = closure_snapshot.data
        if _partial_recovery_sha256(closure_before) != contract.closure_sha256.upper():
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-CLOSURE",
                f"closure hash differs: {reference}",
            )
        occurrences = _schema_marker_occurrences(closure_before, "closure.md")
        if len(occurrences) != 1 or occurrences[0] != (
            WORK_ITEM_SCHEMA_MARKER,
            WORK_ITEM_SCHEMA_KEY,
            WORK_ITEM_SCHEMA_VALUE,
        ):
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-CLOSURE",
                f"closure lifecycle marker differs: {reference}",
            )
        _validate_closure(closure_before, row["terminalInstant"])
        status_digest = _partial_recovery_sha256(status_before)
        if status_digest == contract.status_preimage.upper():
            if current_digest.upper() != contract.inventory_tree_preimage.upper():
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
                    f"target tree preimage differs: {reference}",
                )
            status_after = _terminalize_status(status_before)
            if _partial_recovery_sha256(status_after) != contract.status_afterimage.upper():
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
                    f"canonical status projection differs: {reference}",
                )
            pending = True
        elif status_digest == contract.status_afterimage.upper():
            if current_digest.upper() != contract.projected_tree_afterimage.upper():
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
                    f"target tree afterimage differs: {reference}",
                )
            _require_canonical_schema_marker(
                _schema_marker_occurrences(status_before, "status.md"),
                "status.md",
            )
            status_after = status_before
            pending = False
        else:
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
                f"status is neither admitted preimage nor deterministic afterimage: {reference}",
            )
        status_plans.append(
            {
                "reference": reference,
                "row": row,
                "source": source,
                "target": target,
                "status": status_path,
                "closure": closure_path,
                "status_before": status_before,
                "status_after": status_after,
                "closure_before": closure_before,
                "status_snapshot": status_snapshot,
                "closure_snapshot": closure_snapshot,
                "pending": pending,
                "contract": contract,
            }
        )
    return status_plans, unchanged_plans


def _partial_recovery_receipt_bytes(
    inventory_sha256: str,
    readme_before_sha256: str,
    readme_after_sha256: str,
    status_plans: list[dict],
    unchanged_plans: list[dict],
) -> bytes:
    rows = []
    for plan in sorted(status_plans, key=lambda item: item["reference"]):
        contract = plan["contract"]
        rows.append(
            {
                "action": "terminalize-status",
                "closureSha256": contract.closure_sha256.upper(),
                "finalTreeSha256": contract.projected_tree_afterimage.upper(),
                "inputTreeSha256": contract.inventory_tree_preimage.upper(),
                "reference": plan["reference"],
                "source": plan["row"]["source"],
                "statusAfterSha256": contract.status_afterimage.upper(),
                "statusBeforeSha256": contract.status_preimage.upper(),
                "target": plan["row"]["target"],
            }
        )
    for plan in sorted(unchanged_plans, key=lambda item: item["reference"]):
        rows.append(
            {
                "action": "none",
                "finalTreeSha256": plan["digest"].upper(),
                "inputTreeSha256": plan["digest"].upper(),
                "reference": plan["reference"],
                "source": plan["row"]["source"],
                "target": plan["row"]["target"],
            }
        )
    payload = {
        "audit": "PASS",
        "inventoryRowCount": 4,
        "inventorySha256": inventory_sha256.upper(),
        "operationId": "recover-partial-migration-v1:909A56",
        "owner": "work-items-lifecycle-v1-partial-migration-recovery",
        "readmeAfterSha256": readme_after_sha256.upper(),
        "readmeBeforeSha256": readme_before_sha256.upper(),
        "rows": sorted(rows, key=lambda row: row["reference"]),
        "schemaVersion": 1,
    }
    return (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _partial_recovery_fsync_directory(path: Path) -> None:
    _lifecycle_reject_unreduced_reparse(
        path,
        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CREATE-UNSUPPORTED",
        message="recovery receipt parent contains a link or reparse point",
    )
    descriptor = None
    native_handle = None
    try:
        if os.name == "nt":
            import ctypes
            import ctypes.wintypes
            import msvcrt

            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            create_file = kernel32.CreateFileW
            create_file.argtypes = [
                ctypes.wintypes.LPCWSTR,
                ctypes.wintypes.DWORD,
                ctypes.wintypes.DWORD,
                ctypes.wintypes.LPVOID,
                ctypes.wintypes.DWORD,
                ctypes.wintypes.DWORD,
                ctypes.wintypes.HANDLE,
            ]
            create_file.restype = ctypes.wintypes.HANDLE
            native_handle = create_file(
                str(path),
                0x40000000,  # GENERIC_WRITE
                0x00000001 | 0x00000002 | 0x00000004,
                None,
                3,  # OPEN_EXISTING
                0x02000000 | 0x00200000,
                None,
            )
            if native_handle == ctypes.wintypes.HANDLE(-1).value:
                native_handle = None
                raise OSError(ctypes.get_last_error(), "cannot open receipt directory")
            descriptor = msvcrt.open_osfhandle(native_handle, os.O_RDWR)
            native_handle = None
        else:
            flags = os.O_RDONLY
            flags |= getattr(os, "O_DIRECTORY", 0)
            flags |= getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(path, flags)
        if not stat.S_ISDIR(os.fstat(descriptor).st_mode):
            raise OSError(errno.ENOTDIR, "receipt parent is not a directory")
        os.fsync(descriptor)
    except OSError as exc:
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CREATE-UNSUPPORTED",
            "filesystem cannot durably settle the recovery receipt directory",
        ) from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
        elif native_handle is not None:
            import ctypes

            ctypes.WinDLL("kernel32", use_last_error=True).CloseHandle(native_handle)


def _partial_recovery_exact_receipt_snapshot(
    path: Path,
    data: bytes,
) -> CapturedFileSnapshot | None:
    failure_id = "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT"
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise _partial_recovery_fail(
            failure_id,
            "final recovery receipt identity is ambiguous",
        ) from exc
    if (
        not stat.S_ISREG(info.st_mode)
        or stat.S_ISLNK(info.st_mode)
        or bool(
            getattr(info, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        )
    ):
        raise _partial_recovery_fail(
            failure_id,
            "final recovery receipt is a link, reparse point, or non-regular file",
        )
    try:
        snapshot = _capture_file_snapshot(path, failure_id=failure_id)
    except LifecycleError as exc:
        raise _partial_recovery_fail(
            failure_id,
            "final recovery receipt identity cannot be proven",
        ) from exc
    if snapshot.data != data:
        raise _partial_recovery_fail(failure_id, "final recovery receipt differs")
    return snapshot


def _partial_recovery_settle_receipt(path: Path, data: bytes) -> bool:
    if _partial_recovery_exact_receipt_snapshot(path, data) is not None:
        return False
    pending = path.with_name(f".{path.name}.pending-v1")
    pending_created = False
    linked_here = False
    linked_identity = None
    if pending.exists():
        pending_snapshot = _capture_file_snapshot(
            pending,
            failure_id="WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
        )
        if pending_snapshot.data == data:
            pass
        elif (
            pending_snapshot.length < len(data)
            and data.startswith(pending_snapshot.data)
        ):
            _verify_captured_file(
                pending_snapshot,
                "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
            )
            pending.unlink()
            _atomic_write(pending, data)
            pending_created = True
        else:
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
                "pending recovery receipt differs",
            )
    else:
        _atomic_write(pending, data)
        pending_created = True
    pending_snapshot = _capture_file_snapshot(
        pending,
        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
    )
    if pending_snapshot.data != data:
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
            "prepared pending recovery receipt differs",
        )
    final_snapshot = None
    try:
        try:
            os.link(pending, path)
            linked_here = True
            final_snapshot = _partial_recovery_exact_receipt_snapshot(path, data)
            if final_snapshot is None or final_snapshot.identity != pending_snapshot.identity:
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
                    "created final recovery receipt identity differs from pending",
                )
            linked_identity = final_snapshot.identity
        except FileExistsError:
            final_snapshot = _partial_recovery_exact_receipt_snapshot(path, data)
            if final_snapshot is None:
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
                    "concurrent final recovery receipt disappeared",
                )
        except OSError as exc:
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CREATE-UNSUPPORTED",
                "filesystem cannot atomically create the final receipt",
            ) from exc
        _partial_recovery_fsync_directory(path.parent)
        verified_final = _partial_recovery_exact_receipt_snapshot(path, data)
        if (
            final_snapshot is None
            or verified_final is None
            or verified_final.identity != final_snapshot.identity
        ):
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
                "final recovery receipt reread identity differs",
            )
        try:
            pending.unlink()
        except FileNotFoundError:
            pass
        return True
    except BaseException as exc:
        composer = _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.get()
        if composer is not None:
            composer.capture_primary(exc)
        if linked_here:
            try:
                current = path.lstat()
                if (
                    linked_identity is None
                    or _lifecycle_file_identity(current) != linked_identity
                    or stat.S_ISLNK(current.st_mode)
                    or bool(
                        getattr(current, "st_file_attributes", 0)
                        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
                    )
                    or _capture_file_snapshot(
                        path,
                        failure_id=(
                            "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT"
                        ),
                    ).data
                    != data
                ):
                    raise OSError("final recovery receipt identity changed")
            except (OSError, LifecycleError) as cleanup_exc:
                if composer is not None:
                    composer.record_cleanup(
                        phase="receipt-final",
                        failure_id=(
                            "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT"
                        ),
                        resource=f".scratch/{path.name}",
                        diagnostic="final receipt ownership changed during cleanup",
                        cause=cleanup_exc,
                    )
        if pending_created:
            try:
                current_pending = pending.lstat()
                if (
                    _lifecycle_file_identity(current_pending)
                    != pending_snapshot.identity
                    or stat.S_ISLNK(current_pending.st_mode)
                    or bool(
                        getattr(current_pending, "st_file_attributes", 0)
                        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
                    )
                    or pending.read_bytes() != data
                ):
                    raise OSError("pending recovery receipt identity changed")
                pending.unlink()
            except FileNotFoundError:
                pass
            except OSError as cleanup_exc:
                if composer is not None:
                    composer.record_cleanup(
                        phase="receipt-pending",
                        failure_id=(
                            "WI-PARTIAL-MIGRATION-RECOVERY-CLEANUP-FAILED"
                        ),
                        resource=f".scratch/{pending.name}",
                        diagnostic="pending receipt cleanup failed",
                        cause=cleanup_exc,
                    )
        raise


def _partial_recovery_verify_owned_parent_chains(
    status_plans: list[dict],
    readme_snapshot: CapturedFileSnapshot,
) -> None:
    failure_id = "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT"
    for plan in status_plans:
        _verify_captured_parent_chain(plan["status_snapshot"].parent_chain, failure_id)
        _verify_captured_parent_chain(plan["closure_snapshot"].parent_chain, failure_id)
    _verify_captured_parent_chain(readme_snapshot.parent_chain, failure_id)


def recover_partial_migration_v1(
    root: Path,
    inventory_path: Path,
    *,
    expected_inventory_sha256: str,
    expected_readme_sha256: str,
    target_status_preimages: dict[str, str],
    receipt_path: Path,
    apply_admitted: bool,
    render_readme: bool,
    byte_check: bool,
    inject_failure_at: str | None = None,
) -> PartialRecoveryResult:
    transaction = _CURRENT_LIFECYCLE_TRANSACTION.get()
    if transaction is None:
        raise _partial_recovery_fail(
            "WI-LIFECYCLE-LOCK-IDENTITY",
            "recovery core requires the common lifecycle transaction",
        )
    if not (apply_admitted and render_readme and byte_check):
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-COVERAGE",
            "recovery requires --apply-admitted, --render-readme, and --byte-check",
        )
    expected_statuses = {
        reference: contract.status_preimage.upper()
        for reference, contract in PARTIAL_MIGRATION_RECOVERY_TARGETS.items()
    }
    supplied_statuses = {
        str(reference): str(digest).upper()
        for reference, digest in target_status_preimages.items()
    }
    if (
        expected_inventory_sha256.upper()
        != PARTIAL_MIGRATION_RECOVERY_INVENTORY_SHA256.upper()
        or expected_readme_sha256.upper()
        != PARTIAL_MIGRATION_RECOVERY_README_PREIMAGE_SHA256.upper()
        or supplied_statuses != expected_statuses
    ):
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-COVERAGE",
            "CLI bindings differ from the exact admitted incident",
        )
    inventory_path = _partial_recovery_bound_scratch_file(
        root,
        inventory_path,
        label="inventory",
    )
    receipt_path = _partial_recovery_bound_scratch_file(
        root,
        receipt_path,
        label="receipt",
    )
    transaction.verify()
    captured_inventory = _capture_file_snapshot(
        inventory_path,
        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
    )
    inventory_sha256 = _partial_recovery_sha256(captured_inventory.data)
    if inventory_sha256 != PARTIAL_MIGRATION_RECOVERY_INVENTORY_SHA256.upper():
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
            "captured inventory SHA-256 differs",
        )
    inventory = _parse_migration_inventory_bytes(
        root,
        captured_inventory.data,
        strict_shape=True,
    )
    status_plans, unchanged_plans = _partial_recovery_preflight(root, inventory)
    readme = _work_items_root(root) / "README.md"
    if not readme.is_file() or _lifecycle_path_has_reparse(readme):
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-README-PREIMAGE",
            "README is missing or noncanonical",
        )
    readme_snapshot = _capture_file_snapshot(
        readme,
        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-README-PREIMAGE",
    )
    readme_before = readme_snapshot.data
    readme_before_sha256 = _partial_recovery_sha256(readme_before)
    any_pending = any(plan["pending"] for plan in status_plans)
    if any_pending and readme_before_sha256 != expected_readme_sha256.upper():
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-README-PREIMAGE",
            "README does not equal the explicit preimage",
        )
    if any_pending:
        try:
            receipt_path.lstat()
        except FileNotFoundError:
            pass
        except OSError as exc:
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
                "final receipt identity is ambiguous while status rows remain pending",
            ) from exc
        else:
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
                "a final receipt exists while status rows remain pending",
            )

    written_statuses: list[dict] = []
    readme_written = False
    final_receipt_created = False
    receipt_bytes: bytes | None = None
    try:
        _partial_recovery_verify_owned_parent_chains(status_plans, readme_snapshot)
        for index, plan in enumerate(status_plans, start=1):
            if not plan["pending"]:
                continue
            transaction.verify()
            _verify_captured_file(
                captured_inventory,
                "WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
            )
            _verify_captured_file(
                plan["status_snapshot"],
                "WI-PARTIAL-MIGRATION-RECOVERY-PREIMAGE",
            )
            _verify_captured_file(
                plan["closure_snapshot"],
                "WI-PARTIAL-MIGRATION-RECOVERY-CLOSURE",
            )
            current_status = plan["status"].read_bytes()
            current_closure = plan["closure"].read_bytes()
            _algorithm, current_tree = _payload_digest(plan["target"])
            if (
                current_status != plan["status_before"]
                or current_closure != plan["closure_before"]
                or current_tree.upper()
                != plan["contract"].inventory_tree_preimage.upper()
            ):
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT",
                    f"target changed after preflight: {plan['reference']}",
                )
            _verify_captured_parent_chain(
                plan["status_snapshot"].parent_chain,
                "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT",
            )
            _verify_captured_parent_chain(
                plan["closure_snapshot"].parent_chain,
                "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT",
            )
            _atomic_write(plan["status"], plan["status_after"])
            written_statuses.append(plan)
            _verify_captured_file(
                plan["closure_snapshot"],
                "WI-PARTIAL-MIGRATION-RECOVERY-CLOSURE",
            )
            _algorithm, after_tree = _payload_digest(plan["target"])
            if (
                plan["status"].read_bytes() != plan["status_after"]
                or plan["closure"].read_bytes() != plan["closure_before"]
                or after_tree.upper()
                != plan["contract"].projected_tree_afterimage.upper()
            ):
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT",
                    f"target afterimage differs: {plan['reference']}",
                )
            if inject_failure_at == f"after-status-{index}":
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-TEST-FAILPOINT",
                    inject_failure_at,
                )

        transaction.verify()
        _verify_captured_file(
            captured_inventory,
            "WI-PARTIAL-MIGRATION-RECOVERY-INVENTORY",
        )
        _verify_captured_file(
            readme_snapshot,
            "WI-PARTIAL-MIGRATION-RECOVERY-README-PREIMAGE",
        )
        final_readme = render_readme_bytes(root)
        final_readme_sha256 = _partial_recovery_sha256(final_readme)
        current_readme = readme.read_bytes()
        if current_readme != final_readme and current_readme == readme_before:
            _partial_recovery_verify_owned_parent_chains(status_plans, readme_snapshot)
            _atomic_write(readme, final_readme)
            readme_written = True
        elif current_readme != final_readme:
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT",
                "README changed after preflight",
            )
        if readme.read_bytes() != render_readme_bytes(root):
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT",
                "README differs from a fresh render",
            )
        if inject_failure_at == "after-readme":
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-TEST-FAILPOINT",
                inject_failure_at,
            )
        _partial_recovery_verify_owned_parent_chains(status_plans, readme_snapshot)
        for plan in status_plans:
            _verify_captured_file(
                plan["closure_snapshot"],
                "WI-PARTIAL-MIGRATION-RECOVERY-CLOSURE",
            )
            _algorithm, digest = _payload_digest(plan["target"])
            if (
                _partial_recovery_sha256(plan["status"].read_bytes())
                != plan["contract"].status_afterimage.upper()
                or _partial_recovery_sha256(plan["closure"].read_bytes())
                != plan["contract"].closure_sha256.upper()
                or digest.upper()
                != plan["contract"].projected_tree_afterimage.upper()
            ):
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT",
                    f"final target verification differs: {plan['reference']}",
                )
        for plan in unchanged_plans:
            _algorithm, digest = _payload_digest(plan["target"])
            if digest.upper() != plan["digest"].upper():
                raise _partial_recovery_fail(
                    "WI-PARTIAL-MIGRATION-RECOVERY-CONCURRENT-DRIFT",
                    f"unchanged target drifted: {plan['reference']}",
                )
        audit(root)
        receipt_bytes = _partial_recovery_receipt_bytes(
            inventory_sha256,
            expected_readme_sha256,
            final_readme_sha256,
            status_plans,
            unchanged_plans,
        )
        _partial_recovery_exact_receipt_snapshot(receipt_path, receipt_bytes)
        transaction.verify()
        final_receipt_created = _partial_recovery_settle_receipt(
            receipt_path,
            receipt_bytes,
        )
        transaction.verify()
        committed_receipt = _partial_recovery_exact_receipt_snapshot(
            receipt_path,
            receipt_bytes,
        )
        if committed_receipt is None:
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-RECEIPT-CONFLICT",
                "committed receipt is absent",
            )
        _partial_recovery_verify_owned_parent_chains(status_plans, readme_snapshot)
        return PartialRecoveryCommittedCandidate(
            PartialRecoveryResult(
                receipt_sha256=_partial_recovery_sha256(receipt_bytes),
                audit="PASS",
                replay=not any_pending and not final_receipt_created,
            )
        )
    except BaseException as exc:
        composer = _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.get()
        if composer is not None:
            composer.capture_primary(exc)
        exact_final_receipt = False
        if receipt_bytes is not None:
            try:
                exact_final_receipt = (
                    _partial_recovery_exact_receipt_snapshot(
                        receipt_path,
                        receipt_bytes,
                    )
                    is not None
                )
            except LifecycleError:
                exact_final_receipt = False
        if final_receipt_created or exact_final_receipt:
            raise
        rollback_failed = False
        rollback_parents_valid = True
        if written_statuses or readme_written:
            try:
                _partial_recovery_verify_owned_parent_chains(
                    status_plans,
                    readme_snapshot,
                )
            except BaseException as rollback_exc:
                rollback_parents_valid = False
                rollback_failed = True
                if composer is not None:
                    composer.record_cleanup(
                        phase="rollback-parent-chain",
                        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                        resource="work-items",
                        diagnostic="rollback parent-chain verification failed",
                        cause=rollback_exc,
                    )
        if readme_written and rollback_parents_valid:
            try:
                _verify_captured_parent_chain(
                    readme_snapshot.parent_chain,
                    "WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                )
                if readme.read_bytes() == final_readme:
                    _verify_captured_parent_chain(
                        readme_snapshot.parent_chain,
                        "WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                    )
                    _atomic_write(readme, readme_before)
                else:
                    raise OSError("README afterimage changed")
            except BaseException as rollback_exc:
                rollback_failed = True
                if composer is not None:
                    composer.record_cleanup(
                        phase="rollback-readme",
                        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                        resource="work-items/README.md",
                        diagnostic="README rollback failed",
                        cause=rollback_exc,
                    )
        for plan in reversed(written_statuses) if rollback_parents_valid else ():
            try:
                _verify_captured_parent_chain(
                    plan["status_snapshot"].parent_chain,
                    "WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                )
                _verify_captured_parent_chain(
                    plan["closure_snapshot"].parent_chain,
                    "WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                )
                if plan["status"].read_bytes() == plan["status_after"]:
                    _verify_captured_parent_chain(
                        plan["status_snapshot"].parent_chain,
                        "WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                    )
                    _atomic_write(plan["status"], plan["status_before"])
                else:
                    raise OSError("status afterimage changed")
            except BaseException as rollback_exc:
                rollback_failed = True
                if composer is not None:
                    composer.record_cleanup(
                        phase=f"rollback-status:{plan['reference']}",
                        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                        resource=str(plan["row"]["target"]) + "/status.md",
                        diagnostic=f"status rollback failed for {plan['reference']}",
                        cause=rollback_exc,
                    )
        if rollback_parents_valid and (written_statuses or readme_written):
            try:
                _partial_recovery_verify_owned_parent_chains(
                    status_plans,
                    readme_snapshot,
                )
            except BaseException as rollback_exc:
                rollback_failed = True
                if composer is not None:
                    composer.record_cleanup(
                        phase="rollback-postcheck",
                        failure_id="WI-PARTIAL-MIGRATION-RECOVERY-ROLLBACK-FAILED",
                        resource="work-items",
                        diagnostic="rollback postcheck failed",
                        cause=rollback_exc,
                    )
        if composer is not None and (written_statuses or readme_written):
            composer.set_rollback("incomplete" if rollback_failed else "completed")
        raise


def verify_migration_inventory(root: Path, inventory_path: Path) -> int:
    inventory = _load_migration_inventory(root, inventory_path)
    work_items = _work_items_root(root)
    if any(
        isinstance(row, dict)
        and isinstance(row.get("incomingLinks"), dict)
        and isinstance(row["incomingLinks"].get("physicalRelocation"), dict)
        for row in inventory["rows"]
    ):
        plans, _consumers, _receipt_path, _receipt_bytes, _receipt = (
            _preflight_terminalized_inventory_rows(root, inventory_path, inventory)
        )
        for plan in plans:
            if (
                plan["pending"]
                or not plan["target"].is_file()
                or plan["source"].exists()
                or hashlib.sha256(plan["target"].read_bytes()).hexdigest()
                != plan["beforeSha256"]
                or _category_locations(root, plan["category"], plan["slug"])
                != [plan["target"]]
            ):
                raise LifecycleError(
                    "WI-CATEGORY-DUAL-LOCATION",
                    f"settled physical relocation differs for {plan['reference']}",
                )
        check_readme(root)
        return len(plans)
    for row in inventory["rows"]:
        source = _bound_inventory_path(work_items, row.get("source"))
        target = _bound_inventory_path(work_items, row.get("target"))
        if source.exists() or not target.exists():
            raise LifecycleError(
                "WI-CATEGORY-DUAL-LOCATION",
                f"source/target state differs for {row.get('reference')}",
            )
        algorithm, digest = _payload_digest(target)
        if (
            algorithm != row.get("digestAlgorithm")
            or digest != row.get("inputSha256")
        ):
            raise LifecycleError(
                "WI-CATEGORY-MIGRATION-PAYLOAD",
                f"target payload hash differs for {row.get('reference')}",
            )
        category, _slug = _canonical_category(row.get("reference", ""))
        if row.get("category") != category.name:
            raise LifecycleError(
                "CATEGORY-MIGRATION-ADMISSION-GATE",
                f"category tuple differs for {row.get('reference')}",
            )
        instant = row.get("terminalInstant")
        if target.parent.name != archive_month(instant):
            raise LifecycleError(
                "WI-CATEGORY-ARCHIVE-MONTH-MISMATCH",
                f"target month differs for {row.get('reference')}",
            )
        if resolve_category(root, row["reference"]) != target:
            raise LifecycleError(
                "WI-LEGACY-LINK-UNMAPPED",
                f"logical reference does not resolve to target: {row['reference']}",
            )
        current_links = _incoming_link_result(
            root,
            {source, target},
            row["reference"],
        )
        _validate_incoming_link_compatibility(
            root,
            row["reference"],
            row.get("incomingLinks"),
            current_links,
            resolved_location=target,
        )
    check_readme(root)
    return len(inventory["rows"])


def reopen_category_record(
    root: Path,
    archived_reference: str,
    successor_slug: str,
    current_data: bytes,
) -> Path:
    category, archived_slug = _canonical_category(archived_reference)
    _admission_for(category.name)
    if category.name == "work-item":
        return reopen_item(root, archived_slug, successor_slug, current_data)
    archived = resolve_category(root, archived_reference)
    if "archive" not in archived.parts:
        raise LifecycleError("WI-INVALID-TARGET", "reopen source must be archived")
    evidenced_v0 = False
    if category.name == "decision":
        row = _v0_archive_manifest_row(root, archived.name)
        evidence = row.get("archiveEvidence") if row is not None else None
        if isinstance(evidence, dict):
            expected = _work_items_root(root) / Path(evidence["archivePath"])
            if archived != expected.resolve():
                raise LifecycleError("WI-DECISION-V0-ARCHIVE-EVIDENCE", "V0 reopen archive path differs")
            record = _validate_current_decision_record(archived, archived_slug)
            if record.format != DECISION_FORMAT_V0 or record.raw_status not in category.terminal_statuses:
                raise LifecycleError("WI-DECISION-V0-ARCHIVE-EVIDENCE", "V0 reopen source is not terminal")
            evidenced_v0 = True
    if not evidenced_v0:
        _validate_flat_terminal(category, archived.read_bytes())
    _validate_slug(successor_slug)
    if _category_locations(root, category, successor_slug):
        raise LifecycleError("WI-CATEGORY-DUAL-LOCATION", "successor slug already exists")
    try:
        text = current_data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise LifecycleError("WI-CATEGORY-STATUS-INVALID", "successor must be UTF-8") from exc
    fields = _parse_fields(text)
    if fields.get("status") not in category.current_statuses:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID",
            f"{category.name} successor status must be current",
        )
    if fields.get("reopens") != archived_slug:
        raise LifecycleError(
            "WI-CATEGORY-STATUS-INVALID",
            f"successor must declare Reopens: {archived_slug}",
        )
    _preflight_readme(root)
    target = _work_items_root(root) / category.current_root / f"{successor_slug}.md"
    _atomic_write(target, current_data)
    try:
        refresh_readme(root)
    except LifecycleError as exc:
        raise LifecycleError("WI-README-STALE", str(exc)) from exc
    return target


def _fixture_status(item: dict) -> str:
    return (
        "---\n"
        "template: staged\n"
        f"status: {item['status']}\n"
        "started: 2026-07-31T00:00:00Z\n"
        f"updated: {item['updated']}\n"
        "---\n\n"
        f"Task: {item['task']}\n"
        f"Current step: {item.get('currentStep', 'Continue.')}\n"
        "Last result: Fixture materialized.\n"
        f"Next action: {item.get('nextAction', 'Continue.')}\n"
        "Scope boundary: Trial fixture only.\n"
        "Owner: toolchain-engineer\n"
        "Integration owner: toolchain-engineer\n"
        "Evidence gate: five-item trial\n"
        + (f"Blocker: {item['blocker']}\n" if item.get("blocker") else "")
        + (f"Roadmap: {item['roadmap']}\n" if item.get("roadmap") else "")
        + (f"Epic: {item['epic']}\n" if item.get("epic") else "")
    )


def _trial_expected_files(fixture: dict) -> set[str]:
    expected = {
        "work-items/README.md",
    }
    supporting_epics = fixture.get("supportingEpics", [])
    if not isinstance(supporting_epics, list):
        raise LifecycleError("WI-TRIAL-FIXTURE", "supportingEpics must be a list")
    for epic in supporting_epics:
        if not isinstance(epic, dict) or not isinstance(epic.get("slug"), str):
            raise LifecycleError("WI-TRIAL-FIXTURE", "supporting epic requires a slug")
        _validate_slug(epic["slug"])
        expected.add(f"work-items/epics/{epic['slug']}.md")

    items = fixture.get("items")
    if not isinstance(items, list) or len(items) != 5:
        raise LifecycleError("WI-TRIAL-FIXTURE", "fixture must contain exactly five items")
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get("slug"), str):
            raise LifecycleError("WI-TRIAL-FIXTURE", "trial item requires a slug")
        slug = item["slug"]
        _validate_slug(slug)
        kind = item.get("kind")
        if kind in {"active", "blocked"}:
            expected.add(f"work-items/active/{slug}/status.md")
        elif kind == "backlog":
            expected.add(f"work-items/backlog/{slug}.md")
        elif kind == "roadmap":
            expected.add(f"work-items/roadmaps/{slug}.md")
        elif kind == "archived":
            closed = item.get("closed")
            if not isinstance(closed, str):
                raise LifecycleError("WI-TRIAL-FIXTURE", "archived item requires Closed")
            expected.add(
                f"work-items/archive/{archive_month(closed)}/{slug}/closure.md"
            )
        else:
            raise LifecycleError("WI-TRIAL-FIXTURE", f"unknown trial kind: {kind}")
    return expected


def _trial_expected_directories(files: set[str]) -> set[str]:
    directories: set[str] = set()
    for value in files:
        parent = Path(value).parent
        while parent != Path("."):
            directories.add(parent.as_posix())
            parent = parent.parent
    return directories


def _trial_tree(root: Path) -> tuple[dict[str, str], set[str]]:
    files: dict[str, str] = {}
    directories: set[str] = set()
    for path in root.rglob("*"):
        relative = path.relative_to(root).as_posix()
        if relative in {".scratch", LIFECYCLE_LOCK_RELATIVE.as_posix()}:
            continue
        if path.is_symlink():
            raise LifecycleError(
                "WI-TRIAL-NOT-OWNED",
                f"trial root contains an unowned symbolic link: {relative}",
            )
        if path.is_dir():
            directories.add(relative)
        elif path.is_file():
            if relative == TRIAL_MARKER:
                continue
            files[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
        else:
            raise LifecycleError(
                "WI-TRIAL-NOT-OWNED",
                f"trial root contains an unsupported entry: {relative}",
            )
    return files, directories


def _trial_root_has_payload(root: Path) -> bool:
    if not root.exists():
        return False
    for path in root.iterdir():
        if path.name != ".scratch":
            return True
        if _lifecycle_path_has_reparse(path) or not path.is_dir():
            return True
        for child in path.iterdir():
            if child.name != LIFECYCLE_LOCK_RELATIVE.name:
                return True
    return False


def _prove_completed_trial(
    root: Path,
    fixture_bytes: bytes,
    expected_files: set[str],
) -> None:
    marker_path = root / TRIAL_MARKER
    try:
        marker = json.loads(marker_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-TRIAL-NOT-OWNED",
            f"non-empty trial root lacks a valid ownership receipt: {root}",
        ) from exc
    expected_keys = {
        "schemaVersion",
        "owner",
        "fixtureSha256",
        "files",
        "directories",
    }
    if not isinstance(marker, dict) or set(marker) != expected_keys:
        raise LifecycleError("WI-TRIAL-NOT-OWNED", "trial ownership receipt shape differs")
    fixture_hash = hashlib.sha256(fixture_bytes).hexdigest()
    expected_directories = _trial_expected_directories(expected_files)
    if (
        marker.get("schemaVersion") != 1
        or marker.get("owner") != TRIAL_OWNER
        or marker.get("fixtureSha256") != fixture_hash
        or set(marker.get("files", {})) != expected_files
        or set(marker.get("directories", [])) != expected_directories
    ):
        raise LifecycleError(
            "WI-TRIAL-NOT-OWNED",
            "trial ownership receipt is not target-bound to this exact fixture/output",
        )
    actual_files, actual_directories = _trial_tree(root)
    if actual_files != marker["files"] or actual_directories != expected_directories:
        raise LifecycleError(
            "WI-TRIAL-NOT-OWNED",
            "trial root bytes or membership differ from the completed ownership receipt",
        )


def _write_trial_receipt(
    root: Path,
    fixture_bytes: bytes,
    expected_files: set[str],
) -> None:
    actual_files, actual_directories = _trial_tree(root)
    expected_directories = _trial_expected_directories(expected_files)
    if set(actual_files) != expected_files or actual_directories != expected_directories:
        raise LifecycleError(
            "WI-TRIAL-OUTPUT",
            "trial output membership differs from the owned five-item manifest",
        )
    receipt = {
        "schemaVersion": 1,
        "owner": TRIAL_OWNER,
        "fixtureSha256": hashlib.sha256(fixture_bytes).hexdigest(),
        "files": actual_files,
        "directories": sorted(actual_directories),
    }
    _atomic_write(
        root / TRIAL_MARKER,
        (json.dumps(receipt, indent=2, sort_keys=True) + "\n").encode("utf-8"),
    )


def run_trial(root: Path, fixture_path: Path) -> tuple[str, str]:
    fixture_bytes = fixture_path.read_bytes()
    fixture = json.loads(fixture_bytes.decode("utf-8"))
    if not isinstance(fixture, dict):
        raise LifecycleError("WI-TRIAL-FIXTURE", "fixture must be an object")
    expected_files = _trial_expected_files(fixture)
    if _trial_root_has_payload(root):
        _prove_completed_trial(root, fixture_bytes, expected_files)
    root.mkdir(parents=True, exist_ok=True)
    items = fixture.get("items")
    assert isinstance(items, list)
    work_items = _work_items_root(root)
    for epic in fixture.get("supportingEpics", []):
        _atomic_write(
            work_items / "epics" / f"{epic['slug']}.md",
            (
                "---\n"
                "status: active\n"
                f"updated: {epic['updated']}\n"
                "---\n\n"
                f"# {epic['title']}\n"
            ).encode("utf-8"),
        )
    for item in items:
        kind = item["kind"]
        slug = item["slug"]
        _validate_slug(slug)
        if kind in {"active", "blocked"}:
            _atomic_write(
                work_items / "active" / slug / "status.md",
                _fixture_status(item).encode("utf-8"),
            )
        elif kind == "backlog":
            _atomic_write(
                work_items / "backlog" / f"{slug}.md",
                (
                    f"Task: {item['task']}\n"
                    f"Next action: {item['nextAction']}\n"
                    f"updated: {item['updated']}\n"
                ).encode("utf-8"),
            )
        elif kind == "roadmap":
            _atomic_write(
                work_items / "roadmaps" / f"{slug}.md",
                (
                    "format: roadmap-v1\n"
                    "status: active\n"
                    "owner: product-manager\n"
                    f"outcomes: {item['outcomes']}\n"
                    f"order: {item['order']}\n"
                    f"milestones-or-horizon: {item['milestone']}\n"
                    "review-trigger: trial completion\n"
                    "retention: archive monthly\n"
                    f"updated: {item['updated']}\n"
                ).encode("utf-8"),
            )
        elif kind == "archived":
            _atomic_write(
                work_items
                / "archive"
                / archive_month(item["closed"])
                / slug
                / "closure.md",
                (
                    f"Closed: {item['closed']}\n"
                    f"Outcome: {item['outcome']}\n"
                    "Evidence: five-item trial\n"
                    f"Residual risk: {item['residualRisk']}\n"
                ).encode("utf-8"),
            )
        else:
            raise LifecycleError("WI-TRIAL-FIXTURE", f"unknown trial kind: {kind}")
    first = refresh_readme(root)
    first_bytes = (work_items / "README.md").read_bytes()
    second = refresh_readme(root)
    second_bytes = (work_items / "README.md").read_bytes()
    if first != second or first_bytes != second_bytes:
        raise LifecycleError("WI-README-NONDETERMINISTIC", "repeat render differs")
    text = second_bytes.decode("utf-8")
    checkbox_lines = [line for line in text.splitlines() if line.startswith("- [")]
    if len(checkbox_lines) != 5 or any(
        not (line.startswith("- [ ]") or line.startswith("- [x]")) for line in checkbox_lines
    ):
        raise LifecycleError("WI-TRIAL-COUNT", "trial did not render five canonical checkboxes")
    positions = [text.index(f"## {section}") for section in README_SECTIONS]
    if positions != sorted(positions):
        raise LifecycleError("WI-TRIAL-SECTIONS", "README section order differs")
    if not all(token in text for token in ("[roadmap](", "[epic](", "[work item](")):
        raise LifecycleError("WI-TRIAL-LINKS", "progressive links are incomplete")
    _write_trial_receipt(root, fixture_bytes, expected_files)
    return first, second


LEGACY_PROJECTION_MANIFEST_DIR = "legacy-ledger-projection-manifests"
LEGACY_PROJECTION_REGISTRY = "legacy-ledger-projections.jsonl"
LEGACY_PROJECTION_RECEIPTS = "legacy-ledger-projection-receipts"
LEDGER_H1_ARTIFACT_BASE = "ledger-h1-compatibility"
LEDGER_H1_RELOCATION_OWNER = "mutate-work-item:ledger-h1-artifact-set-relocation-v1"
LEDGER_H1_RELOCATION_KIND = "ledger-h1-artifact-set-relocation-v1"
LEDGER_H1_RELOCATION_EVENT = "WI-LEDGER-H1-ARTIFACT-SET-RELOCATED"
LEDGER_H1_RELOCATION_MEMBERS = (
    (DECISION_H1_MANIFEST, "file"),
    (LEGACY_PROJECTION_MANIFEST_DIR, "directory"),
    (LEGACY_PROJECTION_REGISTRY, "file"),
    (LEGACY_PROJECTION_RECEIPTS, "directory"),
)
LEDGER_H1_RELOCATION_INTENT_FIELDS = {
    "schemaVersion", "owner", "kind", "status", "operationId", "recordedAt",
    "archiveOwner", "artifactBase", "receiptPath",
    "expectedArtifactSetSha256", "expectedRootContractSha256",
    "targetBaseBefore", "members", "rootContractBefore", "rootContractAfter",
    "receiptAfter",
}
LEDGER_H1_RELOCATION_MEMBER_FIELDS = {
    "logicalPath", "sourcePath", "targetPath", "kind", "byteLength", "sha256",
}
LEDGER_H1_RELOCATION_RECEIPT_FIELDS = {
    "schemaVersion", "status", "operationId", "archiveOwner", "artifactBase",
    "artifactSetSha256", "rootContractBeforeSha256", "rootContractAfterSha256",
    "recordedAt",
}
LEDGER_H1_RELOCATION_FAILURE_BOUNDARIES = frozenset(
    {
        "after-intent",
        "after-member-1",
        "after-member-2",
        "after-member-3",
        "after-member-4",
        "after-root-contract",
        "after-receipt",
    }
)
_PROJECTION_OPERATION_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", re.ASCII)


def _projection_fail(failure_id: str, message: str) -> None:
    raise LifecycleError(failure_id, message)


def _projection_object(data: bytes, label: str) -> dict:
    try:
        value = json.loads(
            data.decode("utf-8"),
            object_pairs_hook=_decision_compatibility_json_object,
        )
    except (
        UnicodeDecodeError,
        json.JSONDecodeError,
        _DecisionCompatibilityManifestDuplicateKey,
    ) as exc:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", f"{label} is not one JSON object")
        raise AssertionError from exc
    if not isinstance(value, dict):
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", f"{label} is not one JSON object")
    return value


def _projection_json(data: dict) -> bytes:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")


def _projection_operation(operation_id: str, recorded_at: str) -> None:
    if _PROJECTION_OPERATION_RE.fullmatch(operation_id) is None:
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "projection operation id is not bounded")
    _load_agent_run_ledger()._strict_migration_inputs(operation_id, recorded_at)


def _projection_paths(root: Path) -> tuple[Path, Path, Path]:
    work_items = _work_items_root(root)
    repository = work_items.parent
    manifests = _require_lifecycle_mutation_path(repository, work_items / LEGACY_PROJECTION_MANIFEST_DIR, failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID")
    registry = _require_lifecycle_mutation_path(repository, work_items / LEGACY_PROJECTION_REGISTRY, failure_id="WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE")
    receipts = _require_lifecycle_mutation_path(repository, work_items / LEGACY_PROJECTION_RECEIPTS, failure_id="WI-LEDGER-MIGRATION-RECEIPT-MISMATCH")
    return manifests, registry, receipts


def _historical_disposition_path(root: Path, validator: object) -> Path:
    """Resolve the validator-owned historical storage only for writer operations."""
    try:
        identity = validator.historical_artifact_disposition_storage_identity()
        identity = validator.confine_legacy_projection_identifier(
            identity, failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID"
        )
    except (AttributeError, TypeError, ValueError) as exc:
        _projection_fail(
            "WI-LEDGER-MIGRATION-MANIFEST-INVALID",
            "historical disposition storage identity is unavailable or invalid",
        )
        raise AssertionError from exc
    work_items = _work_items_root(root)
    return _require_lifecycle_mutation_path(
        work_items.parent, work_items / identity,
        failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID",
    )


def _projection_manifest_blobs(root: Path, manifests: Path, manifest_id: str, supplied: bytes) -> dict[str, bytes]:
    blobs: dict[str, bytes] = {}
    validator = _load_agent_run_ledger().load_validator()
    try:
        manifest_id = validator.confine_legacy_projection_identifier(
            manifest_id, failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID"
        )
    except ValueError as exc:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", f"projection manifest id is unsafe: {exc}")
        raise AssertionError from exc
    if manifests.exists():
        if not manifests.is_dir() or _lifecycle_path_has_reparse(manifests):
            _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "projection manifest directory is unsafe")
        for path in manifests.iterdir():
            if path.suffix != ".json" or _lifecycle_path_has_reparse(path):
                _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "projection manifest directory has unsafe member")
            try:
                safe = validator.confine_legacy_projection_path(
                    root, f"work-items/{LEGACY_PROJECTION_MANIFEST_DIR}/{path.name}",
                    prefix=("work-items", LEGACY_PROJECTION_MANIFEST_DIR), leaf_kind="file",
                    failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID",
                )
            except ValueError as exc:
                _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", f"projection manifest member is unsafe: {exc}")
                raise AssertionError from exc
            blobs[safe.name] = safe.read_bytes()
    name = f"{manifest_id}.json"
    current = blobs.get(name)
    if current is not None and current != supplied:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "create-only manifest bytes differ")
    blobs[name] = supplied
    return blobs


def _projection_registry_records(data: bytes) -> list[tuple[dict, bytes]]:
    records: list[tuple[dict, bytes]] = []
    for ordinal, line in enumerate(data.splitlines(keepends=True), start=1):
        record = _projection_object(line.rstrip(b"\r\n"), f"registry line {ordinal}")
        records.append((record, line))
    return records


def _projection_entry(
    manifest: dict,
    entry_id: str,
    raw_ordinal: int,
    root: Path,
    *,
    candidate_ledger_bytes: bytes | None = None,
) -> dict:
    manifest_id = manifest.get("manifestId")
    if not isinstance(manifest_id, str) or _PROJECTION_OPERATION_RE.fullmatch(manifest_id) is None:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "manifest id is invalid")
    entries = [entry for entry in manifest.get("entries", []) if isinstance(entry, dict) and entry.get("entryId") == entry_id]
    if len(entries) != 1 or not isinstance(raw_ordinal, int):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "manifest entry or raw ordinal is not unique")
    entry = entries[0]
    required = {"entryId", "profileId", "profileVersion", "workItem", "ledgerPath", "ledgerSha256", "rawLineOrdinals", "rawLineSha256", "projectedEvents", "projectedEventSha256"}
    if (
        not required <= set(entry)
        or set(entry) - (required | {"artifactSha256"})
        or not all(isinstance(entry[key], list) for key in ("rawLineOrdinals", "rawLineSha256", "projectedEvents", "projectedEventSha256"))
    ):
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "manifest entry shape is incomplete")
    ordinals = entry["rawLineOrdinals"]
    raw_digests = entry["rawLineSha256"]
    projected_events = entry["projectedEvents"]
    projected_digests = entry["projectedEventSha256"]
    if (
        not ordinals
        or not (len(ordinals) == len(raw_digests) == len(projected_events) == len(projected_digests))
        or any(not isinstance(value, int) or value < 1 for value in ordinals)
        or len(set(ordinals)) != len(ordinals)
        or any(not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None for value in (*raw_digests, *projected_digests))
        or any(not isinstance(value, dict) for value in projected_events)
    ):
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "manifest entry bindings are not one unique parallel set")
    try:
        index = entry["rawLineOrdinals"].index(raw_ordinal)
        raw_digest = entry["rawLineSha256"][index]
        projected = entry["projectedEvents"][index]
        projected_digest = entry["projectedEventSha256"][index]
    except (ValueError, IndexError):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "raw ordinal is not bound by the manifest entry")
    if (
        not isinstance(entry.get("entryId"), str)
        or not isinstance(entry.get("profileId"), str)
        or not isinstance(entry.get("profileVersion"), int)
        or entry["profileVersion"] < 1
        or not all(isinstance(value, str) for value in (entry["workItem"], entry["ledgerPath"], entry["ledgerSha256"], raw_digest, projected_digest))
        or re.fullmatch(r"[0-9a-f]{64}", entry["ledgerSha256"]) is None
        or not isinstance(projected, dict)
    ):
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "manifest entry value types are invalid")
    validator = _load_agent_run_ledger().load_validator()

    def controlled_path(value: str, label: str) -> Path:
        try:
            return validator.confine_legacy_projection_path(
                root, value, prefix=("work-items",), failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY"
            )
        except ValueError as exc:
            _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", f"{label} is unsafe: {exc}")
            raise AssertionError from exc

    item = controlled_path(entry["workItem"], "manifest work item")
    ledger = controlled_path(entry["ledgerPath"], "manifest ledger")
    target_errors: list[str] = []
    target = validator.classify_legacy_projection_target(
        item, ledger, target_errors, require_ledger=True
    )
    if (
        target is None
        or target_errors
        or target[1] != entry["workItem"]
        or ledger != item / "agent-runs.jsonl"
        or not item.is_dir()
        or not ledger.is_file()
    ):
        _projection_fail(
            "WI-LEDGER-MIGRATION-TARGET-IDENTITY",
            "; ".join(target_errors) or "manifest target is not one safe active or archive work-item ledger",
        )
    ledger_bytes = ledger.read_bytes() if candidate_ledger_bytes is None else candidate_ledger_bytes
    lines = ledger_bytes.splitlines(keepends=True)
    if _sha256_bytes(ledger_bytes) != entry["ledgerSha256"]:
        _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "manifest ledger digest differs")
    for bound_ordinal, bound_digest, bound_projected, bound_projected_digest in zip(
        ordinals, raw_digests, projected_events, projected_digests
    ):
        if bound_ordinal > len(lines) or _sha256_bytes(lines[bound_ordinal - 1]) != bound_digest:
            _projection_fail("WI-LEDGER-MIGRATION-TARGET-DIGEST", "manifest raw line digest differs")
        if _sha256_bytes(_projection_json(bound_projected)) != bound_projected_digest:
            _projection_fail("WI-LEDGER-MIGRATION-TARGET-DIGEST", "manifest projected event digest differs")
    return {**entry, "_item": item, "_ledger": ledger, "_ledgerBytes": ledger_bytes, "_rawDigest": raw_digest, "_projected": projected, "_projectedDigest": projected_digest}


def _projection_record(
    manifest: dict,
    manifest_bytes: bytes,
    entry_id: str,
    raw_ordinal: int,
    operation_group_id: str,
    group_member_index: int,
    group_member_count: int,
    recorded_at: str,
    root: Path,
    *,
    candidate_ledger_bytes: bytes | None = None,
) -> dict:
    entry = _projection_entry(
        manifest,
        entry_id,
        raw_ordinal,
        root,
        candidate_ledger_bytes=candidate_ledger_bytes,
    )
    operation_id = _projection_group_ids(operation_group_id, group_member_count)[group_member_index - 1]
    return {
        "schemaVersion": 2, "operationId": operation_id, "operationGroupId": operation_group_id,
        "groupMemberIndex": group_member_index, "groupMemberCount": group_member_count, "state": "apply",
        "profileId": entry["profileId"], "profileVersion": entry["profileVersion"],
        "manifestId": manifest["manifestId"], "manifestSha256": _sha256_bytes(manifest_bytes),
        "manifestEntryId": entry_id, "workItem": entry["workItem"], "ledgerPath": entry["ledgerPath"],
        "ledgerSha256": entry["ledgerSha256"], "rawLineOrdinal": raw_ordinal,
        "rawLineSha256": entry["_rawDigest"], "projectedEvent": entry["_projected"],
        "projectedEventSha256": entry["_projectedDigest"], "recordedAt": recorded_at,
    }


def _projection_confine_output_sink(path: Path, failure_id: str) -> tuple[Path, bool]:
    """Return one ordinary direct-child output sink before any content probe/write.

    Pre-existing links/reparse leaves are rejected through lstat.  This is a
    deterministic preflight only; hostile same-user rename races remain outside
    the existing lifecycle-lock claim.
    """
    parent = path.parent
    parent.mkdir(parents=True, exist_ok=True)
    try:
        parent_info = parent.lstat()
    except OSError as exc:
        raise LifecycleError(failure_id, "projection output parent is unavailable") from exc
    if _lifecycle_path_has_reparse(parent) or not stat.S_ISDIR(parent_info.st_mode):
        _projection_fail(failure_id, "projection output parent is unsafe")
    if path.parent != parent or path.name in {"", ".", ".."}:
        _projection_fail(failure_id, "projection output is not one direct child")
    try:
        info = path.lstat()
    except FileNotFoundError:
        return path, False
    except OSError as exc:
        raise LifecycleError(failure_id, "projection output leaf is unavailable") from exc
    if _lifecycle_path_has_reparse(path) or not stat.S_ISREG(info.st_mode):
        _projection_fail(failure_id, "projection output leaf is unsafe")
    return path, True


def _reserve_historical_disposition_output(
    dispositions: Path, target: Path, entry_cap: int
) -> Path:
    """Reserve one create-only historical output without consuming a replay slot."""
    target, replay = _projection_confine_output_sink(
        target, "WI-LEDGER-MIGRATION-MANIFEST-INVALID"
    )
    if replay:
        return target
    from itertools import islice
    entry_count = 0
    for candidate in islice(dispositions.iterdir(), entry_cap + 1):
        try:
            candidate.lstat()
        except OSError as exc:
            raise LifecycleError(
                "WI-LEDGER-MIGRATION-MANIFEST-INVALID",
                "historical disposition directory cannot be enumerated safely",
            ) from exc
        entry_count += 1
    if entry_count >= entry_cap:
        _projection_fail(
            "WI-LEDGER-MIGRATION-MANIFEST-INVALID",
            "historical disposition directory exceeds resource cap",
        )
    return target


def _projection_create_or_exact(path: Path, data: bytes, failure_id: str) -> bool:
    path, replay = _projection_confine_output_sink(path, failure_id)
    if replay:
        if path.read_bytes() != data:
            _projection_fail(failure_id, "create-only target differs after write")
        return True
    temporary: Path | None = None
    try:
        descriptor, name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
        temporary = Path(name)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError:
            path, replay = _projection_confine_output_sink(path, failure_id)
            if not replay:
                _projection_fail(failure_id, "projection output disappeared during create-only write")
        except OSError as exc:
            raise LifecycleError(failure_id, "atomic create-only write is unavailable") from exc
        path, _replay = _projection_confine_output_sink(path, failure_id)
        if path.read_bytes() != data:
            _projection_fail(failure_id, "create-only target differs after write")
        return replay
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _projection_reconcile_receipt(receipts: Path, facts: dict) -> None:
    try:
        operation_id = _load_agent_run_ledger().load_validator().confine_legacy_projection_identifier(
            facts.get("operationId"), failure_id="WI-LEDGER-MIGRATION-RECEIPT-MISMATCH"
        )
    except ValueError as exc:
        _projection_fail("WI-LEDGER-MIGRATION-RECEIPT-MISMATCH", f"projection receipt identifier is unsafe: {exc}")
        raise AssertionError from exc
    path = receipts / f"{operation_id}.json"
    _projection_create_or_exact(path, (json.dumps(facts, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8"), "WI-LEDGER-MIGRATION-RECEIPT-MISMATCH")


def _projection_candidate_errors(entry: dict, manifests: dict[str, bytes], registry_bytes: bytes) -> list[str]:
    validator = _load_agent_run_ledger().load_validator()
    return validator.validate_work_item(
        entry["_item"], validate_status_file=False,
        projection_manifest_blobs=manifests,
        projection_registry_bytes=registry_bytes,
    )


def _projection_group_ids(operation_id: str, count: int) -> list[str]:
    if count < 1:
        _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "projection group count must be positive")
    values = [operation_id] if count == 1 else [
        "m:" + _sha256_bytes(
            json.dumps([operation_id, index, count], ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        )
        for index in range(1, count + 1)
    ]
    if any(len(value) > 128 for value in values):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "derived projection member id exceeds its bounded grammar")
    return values


def _projection_group_facts(
    operation_id: str,
    lines: list[bytes],
    registry_before: bytes,
    registry_prefix: bytes,
) -> dict:
    record_hashes = [_sha256_bytes(line) for line in lines]
    return {
        "schemaVersion": 1,
        "operationId": operation_id,
        "recordSha256": record_hashes[0] if len(record_hashes) == 1 else record_hashes,
        "registryBeforeSha256": _sha256_bytes(registry_before),
        "registrySha256": _sha256_bytes(registry_prefix),
    }


def _projection_existing_group(
    records: list[tuple[dict, bytes]], child_ids: list[str], lines: list[bytes]
) -> tuple[bytes, bytes] | None:
    """Return exact before/after prefixes for one persisted append group.

    Receipt facts are derived from the durable prefix ending at this group, not
    from the current whole registry.  This keeps replays byte-stable after a
    later independent append.
    """
    positions: list[int] = []
    for child_id, expected_line in zip(child_ids, lines):
        matched = [index for index, (record, _physical) in enumerate(records) if record.get("operationId") == child_id]
        if len(matched) > 1:
            _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "projection operation id is duplicated")
        if not matched:
            return None
        index = matched[0]
        if records[index][1] != expected_line:
            _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "projection operation group differs from its exact inputs")
        positions.append(index)
    if positions != list(range(positions[0], positions[0] + len(positions))):
        _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "projection operation group is non-contiguous")
    before = b"".join(physical for _record, physical in records[:positions[0]])
    after = b"".join(physical for _record, physical in records[:positions[-1] + 1])
    return before, after


def _projection_require_replay_anchor(expected_registry_sha256: str, group_before: bytes, current_registry: bytes) -> None:
    """One replay rule for singleton and v2 groups, independent of later appends."""
    accepted = {_sha256_bytes(group_before), _sha256_bytes(current_registry)}
    if expected_registry_sha256 not in accepted:
        _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "replay expected registry digest differs from durable anchors")


def _apply_legacy_ledger_projection_locked(root: Path, manifest_bytes: bytes, entry_id: str, raw_ordinal: int, expected_registry_sha256: str, operation_id: str, recorded_at: str, *, inject_failure: str | None = None) -> dict:
    _projection_operation(operation_id, recorded_at)
    manifests_path, registry_path, receipts = _projection_paths(root)
    manifest = _projection_object(manifest_bytes, "manifest")
    manifest_id = manifest.get("manifestId")
    if not isinstance(manifest_id, str) or _PROJECTION_OPERATION_RE.fullmatch(manifest_id) is None:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "manifest id is required")
    manifests = _projection_manifest_blobs(Path(root).resolve(), manifests_path, manifest_id, manifest_bytes)
    before = registry_path.read_bytes() if registry_path.exists() else b""
    if registry_path.exists() and (not registry_path.is_file() or _lifecycle_path_has_reparse(registry_path)):
        _projection_fail("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "projection registry is unsafe")
    configured_entries = [row for row in manifest.get("entries", []) if isinstance(row, dict) and row.get("entryId") == entry_id]
    if len(configured_entries) != 1 or not configured_entries[0].get("rawLineOrdinals"):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "manifest entry is unavailable")
    repository = Path(root).resolve()
    if repository.name == "work-items" or _lifecycle_path_has_reparse(repository / "work-items"):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "projection writer requires one ordinary repository root")
    seed = _projection_entry(manifest, entry_id, raw_ordinal, repository)
    ordinals = seed["rawLineOrdinals"]
    child_ids = _projection_group_ids(operation_id, len(ordinals))
    records = [
        _projection_record(manifest, manifest_bytes, entry_id, ordinal, operation_id, index, len(ordinals), recorded_at, repository)
        for index, ordinal in enumerate(ordinals, start=1)
    ]
    lines = [_projection_json(record) + b"\n" for record in records]
    registry_records = _projection_registry_records(before)
    persisted = _projection_existing_group(registry_records, child_ids, lines)
    if persisted is not None:
        persisted_before, persisted_after = persisted
        _projection_require_replay_anchor(expected_registry_sha256, persisted_before, before)
        _projection_create_or_exact(manifests_path / f"{manifest_id}.json", manifest_bytes, "WI-LEDGER-MIGRATION-MANIFEST-INVALID")
        facts = _projection_group_facts(operation_id, lines, persisted_before, persisted_after)
        _projection_reconcile_receipt(receipts, facts)
        return {**facts, "replay": True}
    existing_ids = {record.get("operationId") for record, _physical in registry_records}
    if any(child_id in existing_ids for child_id in child_ids):
        _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "projection operation group is partial")
    if any(
        isinstance(existing_id, str)
        and existing_id.casefold() == child_id.casefold()
        and existing_id != child_id
        for existing_id in existing_ids
        for child_id in child_ids
    ):
        _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "projection operation id collides case-insensitively")
    if _sha256_bytes(before) != expected_registry_sha256:
        _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "projection registry digest changed")
    candidate = before + b"".join(lines)
    errors = _projection_candidate_errors(seed, manifests, candidate)
    if errors:
        _projection_fail("WI-LEDGER-MIGRATION-CANDIDATE-INVALID", "; ".join(errors))
    if inject_failure == "before-registry":
        _projection_fail("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "injected interruption before registry commit")
    try:
        _atomic_write(registry_path, candidate)
        if inject_failure == "corrupt-registry":
            registry_path.write_bytes(candidate + b"corrupt")
        actual = registry_path.read_bytes()
    except OSError as exc:
        raise LifecycleError("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "projection registry readback failed") from exc
    if actual != candidate:
        if actual == before:
            _projection_fail("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "projection registry remains exact before image")
        _projection_fail("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "projection registry is neither exact before nor after")
    if inject_failure == "after-registry":
        _projection_fail("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "injected interruption after registry commit")
    _projection_create_or_exact(manifests_path / f"{manifest_id}.json", manifest_bytes, "WI-LEDGER-MIGRATION-MANIFEST-INVALID")
    facts = _projection_group_facts(operation_id, lines, before, candidate)
    _projection_reconcile_receipt(receipts, facts)
    return {**facts, "replay": False}


_apply_legacy_ledger_projection_transaction = _lifecycle_participant(_apply_legacy_ledger_projection_locked)


def apply_legacy_ledger_projection(root: Path, manifest_bytes: bytes, entry_id: str, raw_ordinal: int, expected_registry_sha256: str, operation_id: str, recorded_at: str, *, dry_run: bool = False, inject_failure: str | None = None) -> dict:
    if dry_run:
        _projection_operation(operation_id, recorded_at)
        manifest = _projection_object(manifest_bytes, "manifest")
        entry = _projection_entry(manifest, entry_id, raw_ordinal, Path(root).resolve())
        child_ids = _projection_group_ids(operation_id, len(entry["rawLineOrdinals"]))
        return {"schemaVersion": 1, "dryRun": True, "byteInventory": {}, "operationIds": child_ids}
    return _apply_legacy_ledger_projection_transaction(root, manifest_bytes, entry_id, raw_ordinal, expected_registry_sha256, operation_id, recorded_at, inject_failure=inject_failure)


_LEGACY_SETTLEMENT_PROFILE = "identity-ledger-v1-string"
_LEGACY_SETTLEMENT_REQUEST_FIELDS = {
    "schemaVersion", "operationId", "recordedAt", "workItem",
    "expectedLedgerSha256", "profileId", "profileVersion", "settlements",
}
_LEGACY_SETTLEMENT_ROW_FIELDS = {"targetRunId", "disposition", "evidence"}
_LEGACY_SETTLEMENT_EVIDENCE_FIELDS = {"path", "sha256"}


def _legacy_settlement_fail(failure_id: str, message: str) -> None:
    raise LifecycleError(failure_id, message)


def _legacy_settlement_request(request_bytes: bytes) -> dict:
    request = _projection_object(request_bytes, "legacy ledger settlement request")
    if set(request) != _LEGACY_SETTLEMENT_REQUEST_FIELDS:
        _legacy_settlement_fail(
            "WI-LEDGER-LEGACY-PROFILE-UNSUPPORTED",
            "settlement request fields differ from schema version 1",
        )
    operation_id = request.get("operationId")
    recorded_at = request.get("recordedAt")
    _projection_operation(operation_id, recorded_at)
    if (
        request.get("schemaVersion") != 1
        or request.get("profileId") != _LEGACY_SETTLEMENT_PROFILE
        or request.get("profileVersion") != 1
        or not isinstance(request.get("workItem"), str)
        or SLUG_RE.fullmatch(request["workItem"]) is None
        or not isinstance(request.get("expectedLedgerSha256"), str)
        or re.fullmatch(r"[0-9a-f]{64}", request["expectedLedgerSha256"]) is None
        or not isinstance(request.get("settlements"), list)
    ):
        _legacy_settlement_fail(
            "WI-LEDGER-LEGACY-PROFILE-UNSUPPORTED",
            "settlement request identity or profile is invalid",
        )
    seen: set[str] = set()
    for row in request["settlements"]:
        if not isinstance(row, dict) or set(row) != _LEGACY_SETTLEMENT_ROW_FIELDS:
            _legacy_settlement_fail(
                "WI-LEDGER-LEGACY-SETTLEMENT-INCOMPLETE",
                "settlement row shape is invalid",
            )
        target = row.get("targetRunId")
        evidence = row.get("evidence")
        disposition = row.get("disposition")
        if (
            not isinstance(target, str)
            or len(target) < 8
            or target in seen
            or disposition not in {"satisfied-by-current-evidence", "preserve-open"}
            or not isinstance(evidence, list)
            or (disposition == "preserve-open" and evidence)
            or (disposition == "satisfied-by-current-evidence" and not evidence)
        ):
            _legacy_settlement_fail(
                "WI-LEDGER-LEGACY-SETTLEMENT-INCOMPLETE",
                "settlement targets, dispositions, and evidence must be exact and unique",
            )
        seen.add(target)
        for proof in evidence:
            if (
                not isinstance(proof, dict)
                or set(proof) != _LEGACY_SETTLEMENT_EVIDENCE_FIELDS
                or not isinstance(proof.get("path"), str)
                or not proof["path"]
                or not isinstance(proof.get("sha256"), str)
                or re.fullmatch(r"[0-9a-f]{64}", proof["sha256"]) is None
            ):
                _legacy_settlement_fail(
                    "WI-LEDGER-LEGACY-EVIDENCE-DRIFT",
                    "settlement evidence binding is invalid",
                )
    return request


def _legacy_settlement_evidence(root: Path, request: dict) -> None:
    root = Path(root).resolve()
    for row in request["settlements"]:
        for proof in row["evidence"]:
            relative = PurePosixPath(proof["path"])
            if relative.is_absolute() or not relative.parts or any(
                part in {"", ".", ".."} for part in relative.parts
            ):
                _legacy_settlement_fail(
                    "WI-LEDGER-LEGACY-EVIDENCE-DRIFT",
                    "settlement evidence path is not repository-relative",
                )
            candidate = root.joinpath(*relative.parts)
            if not candidate.is_file() or any(
                _lifecycle_path_has_reparse(root.joinpath(*relative.parts[:index]))
                for index in range(1, len(relative.parts) + 1)
            ):
                _legacy_settlement_fail(
                    "WI-LEDGER-LEGACY-EVIDENCE-DRIFT",
                    f"settlement evidence is missing or unsafe: {proof['path']}",
                )
            if _sha256_bytes(candidate.read_bytes()) != proof["sha256"]:
                _legacy_settlement_fail(
                    "WI-LEDGER-LEGACY-EVIDENCE-DRIFT",
                    f"settlement evidence digest changed: {proof['path']}",
                )


def _legacy_settlement_manifest(
    root: Path,
    item: Path,
    ledger_bytes: bytes,
    request_bytes: bytes,
    request: dict,
    *,
    legacy_line_count: int | None = None,
) -> tuple[dict, bytes, str, list[dict]]:
    all_lines = ledger_bytes.splitlines(keepends=True)
    count = len(all_lines) if legacy_line_count is None else legacy_line_count
    lines = all_lines[:count]
    if (
        not lines
        or count > len(all_lines)
        or any(not line.endswith(b"\n") or not line[:-1].strip() for line in all_lines)
    ):
        _legacy_settlement_fail(
            "WI-LEDGER-LEGACY-PROFILE-UNSUPPORTED",
            "legacy ledger must contain bounded nonblank newline-terminated rows",
        )
    try:
        events = [
            _projection_object(line.rstrip(b"\r\n"), f"legacy ledger line {ordinal}")
            for ordinal, line in enumerate(lines, start=1)
        ]
    except LifecycleError as exc:
        if exc.failure_id == "WI-LEDGER-MIGRATION-MANIFEST-INVALID":
            raise LifecycleError(
                "WI-LEDGER-LEGACY-PROFILE-UNSUPPORTED",
                "legacy ledger contains a malformed row",
            ) from exc
        raise
    manifest_id = f"legacy-settlement-{_sha256_bytes(request_bytes)[:32]}"
    entry_id = "identity-ledger-v1-string"
    entry = {
        "entryId": entry_id,
        "profileId": _LEGACY_SETTLEMENT_PROFILE,
        "profileVersion": 1,
        "workItem": item.relative_to(root).as_posix(),
        "ledgerPath": (item / "agent-runs.jsonl").relative_to(root).as_posix(),
        "ledgerSha256": _sha256_bytes(ledger_bytes),
        "rawLineOrdinals": list(range(1, len(lines) + 1)),
        "rawLineSha256": [_sha256_bytes(line) for line in lines],
        "projectedEvents": events,
        "projectedEventSha256": [_sha256_bytes(_projection_json(event)) for event in events],
    }
    manifest = {
        "schemaVersion": 1,
        "manifestId": manifest_id,
        "profiles": [
            {"profileId": _LEGACY_SETTLEMENT_PROFILE, "profileVersion": 1}
        ],
        "entries": [entry],
    }
    profile_errors: list[str] = []
    validator = _load_agent_run_ledger().load_validator()
    projected = validator._profile_projection(
        (_LEGACY_SETTLEMENT_PROFILE, 1), events, item, entry, profile_errors
    )
    if projected is None or profile_errors:
        _raise_legacy_settlement_validation(profile_errors)
    return manifest, _projection_json(manifest), entry_id, events


def _legacy_settlement_projection_candidate(
    root: Path,
    manifest: dict,
    manifest_bytes: bytes,
    entry_id: str,
    request: dict,
    ledger_bytes: bytes,
) -> tuple[dict[str, bytes], bytes]:
    manifests_path, registry_path, _receipts = _projection_paths(root)
    manifests = _projection_manifest_blobs(
        Path(root).resolve(), manifests_path, manifest["manifestId"], manifest_bytes
    )
    registry_before = registry_path.read_bytes() if registry_path.exists() else b""
    if registry_path.exists() and (
        not registry_path.is_file() or _lifecycle_path_has_reparse(registry_path)
    ):
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "projection registry is unsafe",
        )
    ordinals = manifest["entries"][0]["rawLineOrdinals"]
    records = [
        _projection_record(
            manifest,
            manifest_bytes,
            entry_id,
            ordinal,
            request["operationId"],
            index,
            len(ordinals),
            request["recordedAt"],
            Path(root).resolve(),
            candidate_ledger_bytes=ledger_bytes,
        )
        for index, ordinal in enumerate(ordinals, start=1)
    ]
    child_ids = _projection_group_ids(request["operationId"], len(records))
    existing_ids = {
        row.get("operationId")
        for row, _physical in _projection_registry_records(registry_before)
    }
    if any(child_id in existing_ids for child_id in child_ids):
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-REPLAY-MISMATCH",
            "settlement operation already has registry state without an exact replay receipt",
        )
    return manifests, registry_before + b"".join(
        _projection_json(record) + b"\n" for record in records
    )


def _raise_legacy_settlement_validation(errors: list[str]) -> None:
    if not errors:
        return
    preferred = next(
        (
            error for error in errors
            if error.startswith("WI-LEDGER-LEGACY-PROFILE-UNSUPPORTED:")
        ),
        errors[0],
    )
    failure_id = preferred.split(":", 1)[0]
    _legacy_settlement_fail(failure_id, "; ".join(errors))


def _legacy_settlement_target(root: Path, request_bytes: bytes) -> dict:
    root = Path(root).resolve()
    request = _legacy_settlement_request(request_bytes)
    _legacy_settlement_evidence(root, request)
    item = _work_items_root(root) / "active" / request["workItem"]
    ledger = item / "agent-runs.jsonl"
    if not item.is_dir() or not ledger.is_file() or _lifecycle_path_has_reparse(ledger):
        _legacy_settlement_fail(
            "WI-LEDGER-MIGRATION-TARGET-IDENTITY",
            "settlement target is not one ordinary active work-item ledger",
        )
    ledger_bytes = ledger.read_bytes()
    if _sha256_bytes(ledger_bytes) != request["expectedLedgerSha256"]:
        _legacy_settlement_fail(
            "WI-LEDGER-MIGRATION-LEDGER-DRIFT",
            "settlement ledger digest changed",
        )
    manifest, manifest_bytes, entry_id, events = _legacy_settlement_manifest(
        root, item, ledger_bytes, request_bytes, request
    )
    return {
        "request": request,
        "item": item,
        "ledger": ledger,
        "ledgerBytes": ledger_bytes,
        "manifest": manifest,
        "manifestBytes": manifest_bytes,
        "entryId": entry_id,
        "events": events,
    }


def _preflight_legacy_ledger_settlement(
    root: Path, request_bytes: bytes
) -> tuple[dict, dict]:
    root = Path(root).resolve()
    plan = _legacy_settlement_target(root, request_bytes)
    request = plan["request"]
    item = plan["item"]
    ledger_bytes = plan["ledgerBytes"]
    manifest = plan["manifest"]
    manifest_bytes = plan["manifestBytes"]
    entry_id = plan["entryId"]
    events = plan["events"]
    manifests, registry_candidate = _legacy_settlement_projection_candidate(
        root, manifest, manifest_bytes, entry_id, request, ledger_bytes
    )
    validator = _load_agent_run_ledger().load_validator()
    obligations: list[object] = []
    errors = validator.validate_work_item(
        item,
        strict_revise=False,
        validate_status_file=False,
        projection_manifest_blobs=manifests,
        projection_registry_bytes=registry_candidate,
        obligation_state_out=obligations,
    )
    _raise_legacy_settlement_validation(errors)
    if len(obligations) != 1:
        _legacy_settlement_fail(
            "WI-LEDGER-LEGACY-SETTLEMENT-INCOMPLETE",
            "existing reducer did not return one obligation state",
        )
    obligation_state = obligations[0]
    open_rows = tuple(obligation_state.open_revise) + tuple(obligation_state.open_launches)
    open_ids = [row.run_id for row in open_rows]
    requested_ids = [row["targetRunId"] for row in request["settlements"]]
    if len(requested_ids) != len(set(requested_ids)) or set(requested_ids) != set(open_ids):
        _legacy_settlement_fail(
            "WI-LEDGER-LEGACY-SETTLEMENT-INCOMPLETE",
            "settlement rows must exactly cover reducer-reported obligations",
        )
    result = {
        "schemaVersion": 1,
        "operationId": request["operationId"],
        "profileId": request["profileId"],
        "profileVersion": request["profileVersion"],
        "applied": False,
        "replay": False,
        "legacyRunIds": [event["runId"] for event in events],
        "openObligations": open_ids,
        "ledgerBeforeSha256": _sha256_bytes(ledger_bytes),
    }
    return result, {
        **plan,
        "manifests": manifests,
        "registryCandidate": registry_candidate,
        "obligationRows": {row.run_id: row for row in open_rows},
    }


def _legacy_settlement_replay(root: Path, request_bytes: bytes) -> dict | None:
    root = Path(root).resolve()
    request = _legacy_settlement_request(request_bytes)
    _legacy_settlement_evidence(root, request)
    manifests_path, registry_path, receipts_path = _projection_paths(root)
    receipt_path = receipts_path / f"{request['operationId']}.json"
    if not receipt_path.exists():
        return None
    if not receipt_path.is_file() or _lifecycle_path_has_reparse(receipt_path):
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-REPLAY-MISMATCH", "settlement receipt is unsafe"
        )
    receipt = _projection_object(receipt_path.read_bytes(), "legacy settlement receipt")
    item = _work_items_root(root) / "active" / request["workItem"]
    ledger = item / "agent-runs.jsonl"
    manifest_path = manifests_path / receipt.get("manifestName", "")
    checks = (
        receipt.get("schemaVersion") == 1,
        receipt.get("status") == "settled",
        receipt.get("operationId") == request["operationId"],
        receipt.get("requestSha256") == _sha256_bytes(request_bytes),
        ledger.is_file(),
        isinstance(receipt.get("ledgerAfterSha256"), str),
        isinstance(receipt.get("ledgerBeforeByteLength"), int),
        registry_path.is_file(),
        manifest_path.is_file(),
    )
    if not all(checks):
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-REPLAY-MISMATCH",
            "settlement receipt identity differs from the replay request",
        )
    ledger_bytes = ledger.read_bytes()
    before_length = receipt["ledgerBeforeByteLength"]
    if (
        _sha256_bytes(ledger_bytes) != receipt["ledgerAfterSha256"]
        or _sha256_bytes(ledger_bytes[:before_length]) != receipt.get("ledgerBeforeSha256")
        or _sha256_bytes(registry_path.read_bytes()) != receipt.get("registryAfterSha256")
        or _sha256_bytes(manifest_path.read_bytes()) != receipt.get("manifestSha256")
    ):
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-REPLAY-MISMATCH",
            "settlement replay post-image differs from its receipt",
        )
    result = receipt.get("result")
    if not isinstance(result, dict):
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-REPLAY-MISMATCH",
            "settlement receipt result is unavailable",
        )
    return {**result, "applied": True, "replay": True}


def _legacy_settlement_events(plan: dict) -> list[dict]:
    request = plan["request"]
    result: list[dict] = []
    for settlement in request["settlements"]:
        if settlement["disposition"] == "preserve-open":
            continue
        target = plan["obligationRows"][settlement["targetRunId"]]
        evidence = [
            {
                "kind": "manual-check",
                "ref": f"{target.run_id} {target.raw_line_sha256} current-evidence",
            }
        ]
        evidence.extend(
            {
                "kind": "artifact",
                "ref": proof["path"],
                "result": proof["sha256"],
            }
            for proof in settlement["evidence"]
        )
        run_id = "legacy-settlement-" + _sha256_bytes(
            f"{request['operationId']}\0{target.run_id}".encode("utf-8")
        )[:32]
        result.append(
            {
                "schemaVersion": 2,
                "runId": run_id,
                "workItem": plan["item"].name,
                "role": "lead",
                "executionRole": "main",
                "status": "completed",
                "gate": "none",
                "scope": ["ledger-recovery:closure-invalidation"],
                "eventKind": "closure-invalidation",
                "invalidatesRunId": target.run_id,
                "invalidatesEventSha256": target.raw_line_sha256,
                "evidence": evidence,
                "startedAt": request["recordedAt"],
                "updatedAt": request["recordedAt"],
            }
        )
    return result


def _legacy_settlement_validate_after_image(
    root: Path,
    result: dict,
    plan: dict,
) -> tuple[bytes, dict, bytes, dict[str, bytes], bytes, list[dict]]:
    settlement_events = _legacy_settlement_events(plan)
    suffix = b"".join(_projection_json(event) + b"\n" for event in settlement_events)
    candidate_ledger = plan["ledgerBytes"] + suffix
    final_manifest, final_manifest_bytes, entry_id, _events = (
        _legacy_settlement_manifest(
            Path(root).resolve(),
            plan["item"],
            candidate_ledger,
            _projection_json(plan["request"]),
            plan["request"],
            legacy_line_count=len(result["legacyRunIds"]),
        )
    )
    manifests, registry_candidate = _legacy_settlement_projection_candidate(
        Path(root).resolve(),
        final_manifest,
        final_manifest_bytes,
        entry_id,
        plan["request"],
        candidate_ledger,
    )
    candidate_path = plan["ledger"].with_suffix(".jsonl.tmp")
    if candidate_path.exists() or _lifecycle_path_has_reparse(candidate_path):
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "settlement candidate path is not empty",
        )
    try:
        _atomic_write(candidate_path, candidate_ledger)
        validator = _load_agent_run_ledger().load_validator()
        obligations: list[object] = []
        errors = validator.validate_work_item(
            plan["item"],
            ledger_path=candidate_path,
            strict_revise=False,
            validate_status_file=False,
            projection_manifest_blobs=manifests,
            projection_registry_bytes=registry_candidate,
            obligation_state_out=obligations,
        )
        _raise_legacy_settlement_validation(errors)
        if len(obligations) != 1:
            _legacy_settlement_fail(
                "WI-LEDGER-LEGACY-SETTLEMENT-INCOMPLETE",
                "after-image reducer did not return one obligation state",
            )
        expected_open = [
            row["targetRunId"]
            for row in plan["request"]["settlements"]
            if row["disposition"] == "preserve-open"
        ]
        actual_open = [row.run_id for row in obligations[0].open_revise]
        actual_open.extend(row.run_id for row in obligations[0].open_launches)
        if set(actual_open) != set(expected_open) or len(actual_open) != len(expected_open):
            _legacy_settlement_fail(
                "WI-LEDGER-LEGACY-SETTLEMENT-INCOMPLETE",
                "after-image obligations differ from explicit dispositions",
            )
    finally:
        candidate_path.unlink(missing_ok=True)
    return (
        candidate_ledger,
        final_manifest,
        final_manifest_bytes,
        manifests,
        registry_candidate,
        settlement_events,
    )


def _restore_legacy_settlement_snapshot(
    snapshots: Mapping[Path, bytes | None], created_directories: tuple[Path, ...]
) -> None:
    for path, before in reversed(tuple(snapshots.items())):
        if before is None:
            if path.exists():
                if not path.is_file() or _lifecycle_path_has_reparse(path):
                    raise OSError(f"unsafe rollback target: {path}")
                path.unlink()
        else:
            _atomic_write(path, before)
    for directory in reversed(created_directories):
        if directory.exists() and not any(directory.iterdir()):
            directory.rmdir()


def _settle_legacy_ledger_locked(
    root: Path, request_bytes: bytes, *, inject_failure: str | None = None
) -> dict:
    if inject_failure not in {
        None, "after-manifest", "after-registry", "after-ledger", "after-receipt"
    }:
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "unknown settlement failure boundary",
        )
    replay = _legacy_settlement_replay(root, request_bytes)
    if replay is not None:
        return replay
    result, plan = _preflight_legacy_ledger_settlement(root, request_bytes)
    (
        candidate_ledger,
        final_manifest,
        final_manifest_bytes,
        _manifests,
        registry_candidate,
        settlement_events,
    ) = _legacy_settlement_validate_after_image(root, result, plan)
    manifests_path, registry_path, receipts_path = _projection_paths(root)
    manifest_path = manifests_path / f"{final_manifest['manifestId']}.json"
    receipt_path = receipts_path / f"{plan['request']['operationId']}.json"
    participant_paths = (manifest_path, registry_path, plan["ledger"], receipt_path)
    snapshots = {
        path: path.read_bytes() if path.exists() and path.is_file() else None
        for path in participant_paths
    }
    created_directories = tuple(
        path for path in (manifests_path, receipts_path) if not path.exists()
    )
    final_result = {
        **result,
        "applied": True,
        "replay": False,
        "ledgerAfterSha256": _sha256_bytes(candidate_ledger),
        "settlementRunIds": [event["runId"] for event in settlement_events],
    }
    receipt = {
        "schemaVersion": 1,
        "status": "settled",
        "operationId": plan["request"]["operationId"],
        "recordedAt": plan["request"]["recordedAt"],
        "requestSha256": _sha256_bytes(request_bytes),
        "workItem": plan["item"].relative_to(Path(root).resolve()).as_posix(),
        "ledgerPath": plan["ledger"].relative_to(Path(root).resolve()).as_posix(),
        "ledgerBeforeSha256": _sha256_bytes(plan["ledgerBytes"]),
        "ledgerBeforeByteLength": len(plan["ledgerBytes"]),
        "ledgerAfterSha256": _sha256_bytes(candidate_ledger),
        "manifestName": manifest_path.name,
        "manifestSha256": _sha256_bytes(final_manifest_bytes),
        "registryBeforeSha256": _sha256_bytes(snapshots[registry_path] or b""),
        "registryAfterSha256": _sha256_bytes(registry_candidate),
        "settlements": plan["request"]["settlements"],
        "result": final_result,
    }
    receipt_bytes = _projection_json(receipt) + b"\n"
    try:
        _projection_create_or_exact(
            manifest_path,
            final_manifest_bytes,
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
        )
        if inject_failure == "after-manifest":
            raise OSError("injected failure after manifest")
        _atomic_write(registry_path, registry_candidate)
        if inject_failure == "after-registry":
            raise OSError("injected failure after registry")
        _atomic_write(plan["ledger"], candidate_ledger)
        if inject_failure == "after-ledger":
            raise OSError("injected failure after ledger")
        _projection_create_or_exact(
            receipt_path,
            receipt_bytes,
            "WI-LEDGER-COMPAT-REPLAY-MISMATCH",
        )
        if inject_failure == "after-receipt":
            raise OSError("injected failure after receipt")
        if (
            plan["ledger"].read_bytes() != candidate_ledger
            or registry_path.read_bytes() != registry_candidate
            or manifest_path.read_bytes() != final_manifest_bytes
            or receipt_path.read_bytes() != receipt_bytes
        ):
            raise OSError("settlement participant readback differs")
    except BaseException as exc:
        try:
            _restore_legacy_settlement_snapshot(snapshots, created_directories)
        except BaseException as rollback_exc:
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                f"settlement commit and rollback failed: {rollback_exc}",
            ) from exc
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "settlement commit failed; every participant restored to its exact preimage",
        ) from exc
    return final_result


_settle_legacy_ledger_transaction = _lifecycle_participant(
    _settle_legacy_ledger_locked
)


def _legacy_settlement_receipt_exists(root: Path, request_bytes: bytes) -> bool:
    request = _legacy_settlement_request(request_bytes)
    _manifests, _registry, receipts = _projection_paths(Path(root).resolve())
    return (receipts / f"{request['operationId']}.json").exists()


def settle_legacy_ledger(
    root: Path,
    request_bytes: bytes,
    *,
    apply_admitted: bool = False,
    inject_failure: str | None = None,
) -> dict:
    if apply_admitted:
        if not _legacy_settlement_receipt_exists(root, request_bytes):
            _legacy_settlement_target(root, request_bytes)
        return _settle_legacy_ledger_transaction(
            root, request_bytes, inject_failure=inject_failure
        )
    if inject_failure is not None:
        _legacy_settlement_fail(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "failure injection is apply-only",
        )
    replay = _legacy_settlement_replay(root, request_bytes)
    if replay is not None:
        return replay
    result, _plan = _preflight_legacy_ledger_settlement(root, request_bytes)
    return result


def _mixed_recovery_fail(failure_id: str, message: str) -> None:
    raise LifecycleError(f"WI-MIXED-LEDGER-{failure_id}", message)


def _mixed_recovery_request(request_bytes: bytes) -> dict:
    if not isinstance(request_bytes, bytes) or len(request_bytes) > 1_000_000:
        _mixed_recovery_fail("REQUEST", "request is absent or exceeds the bounded size")

    def unique_object(pairs: list[tuple[str, object]]) -> dict:
        result: dict = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate request key: {key}")
            result[key] = value
        return result

    try:
        request = json.loads(request_bytes.decode("utf-8"), object_pairs_hook=unique_object)
    except (UnicodeDecodeError, ValueError) as exc:
        _mixed_recovery_fail("REQUEST", f"request is not unique UTF-8 JSON: {exc}")
    if not isinstance(request, dict) or set(request) != {
        "schemaVersion", "operationId", "recordedAt", "workItem",
        "expectedLedgerSha256", "targets",
    } or request.get("schemaVersion") != 1:
        _mixed_recovery_fail("REQUEST", "request fields or version differ")
    operation_id = request.get("operationId")
    recorded_at = request.get("recordedAt")
    writer = _load_agent_run_ledger()
    try:
        writer._strict_migration_inputs(operation_id, recorded_at)
    except (writer.LedgerMigrationError, TypeError, ValueError) as exc:
        _mixed_recovery_fail("REQUEST", f"operation identity or UTC instant differs: {exc}")
    work_item = request.get("workItem")
    if not isinstance(work_item, str) or not re.fullmatch(
        r"work-items/active/[A-Za-z0-9][A-Za-z0-9._-]*", work_item, re.ASCII
    ):
        _mixed_recovery_fail("REQUEST", "workItem must name one active relative record")
    if not isinstance(request.get("expectedLedgerSha256"), str) or re.fullmatch(
        r"[0-9a-f]{64}", request["expectedLedgerSha256"], re.ASCII
    ) is None:
        _mixed_recovery_fail("REQUEST", "expectedLedgerSha256 must be lowercase SHA-256")
    targets = request.get("targets")
    if not isinstance(targets, list) or not targets or len(targets) > 10_000:
        _mixed_recovery_fail("REQUEST", "targets must be a bounded nonempty array")
    seen_ordinals: set[int] = set()
    seen_run_ids: set[str] = set()
    for target in targets:
        if not isinstance(target, dict):
            _mixed_recovery_fail("REQUEST", "target is not an object")
        action = target.get("action")
        digest_field = {
            "migrate-invalid-finding-class": "eventBodySha256",
            "dispose-invalid-terminal": "physicalLineSha256",
        }.get(action)
        if digest_field is None or set(target) != {
            "action", "rawLineOrdinal", "runId", digest_field, "launchRunId",
        }:
            _mixed_recovery_fail("REQUEST", "target action or digest codec differs")
        ordinal = target.get("rawLineOrdinal")
        run_id = target.get("runId")
        launch_id = target.get("launchRunId")
        digest = target.get(digest_field)
        if (
            type(ordinal) is not int or ordinal < 1 or ordinal in seen_ordinals
            or not isinstance(run_id, str) or not run_id
            or run_id.casefold() in seen_run_ids
            or not isinstance(launch_id, str) or not launch_id
            or not isinstance(digest, str)
            or re.fullmatch(r"[0-9a-f]{64}", digest, re.ASCII) is None
        ):
            _mixed_recovery_fail("REQUEST", "target identity is invalid or repeated")
        seen_ordinals.add(ordinal)
        seen_run_ids.add(run_id.casefold())
    return request


def _mixed_recovery_controls(
    item: Path, original: bytes, request: dict, writer: object, validator: object,
) -> tuple[list[dict], list[dict], list[dict]]:
    """Classify each physical row once and build only existing typed controls."""

    ledger = item / "agent-runs.jsonl"
    physical = original.splitlines(keepends=True)
    if not original.endswith(b"\n") or any(not line.strip() for line in physical):
        _mixed_recovery_fail("HISTORY", "mixed recovery requires complete nonblank physical lines")
    parse_errors: list[str] = []
    metadata: list[dict[str, object]] = []
    events = validator.load_jsonl(ledger, parse_errors, metadata, original)
    if parse_errors or len(events) != len(physical) or len(metadata) != len(events):
        _mixed_recovery_fail("HISTORY", "; ".join(parse_errors) or "physical row cardinality differs")
    if any(event.get("schemaVersion") not in (1, 2) for event in events):
        _mixed_recovery_fail("HISTORY", "history is not an integer V1/V2 ledger")
    by_target = {target["rawLineOrdinal"]: target for target in request["targets"]}
    by_run: dict[str, list[int]] = {}
    for position, event in enumerate(events):
        run_id = event.get("runId")
        if isinstance(run_id, str):
            by_run.setdefault(run_id.casefold(), []).append(position)
    run_positions = {key: tuple(value) for key, value in by_run.items()}
    seen: set[str] = set()
    invalid_ordinals: set[int] = set()
    for ordinal, event in enumerate(events, start=1):
        row_errors: list[str] = []
        validator.validate_event(event, item, seen, row_errors)
        orphan = bool(
            event.get("schemaVersion") == 2
            and event.get("eventKind") == "terminal"
            and event.get("status") == "completed"
            and not validator.terminal_has_valid_earlier_launch(
                events, ordinal - 1, item, run_positions
            )
        )
        if row_errors or orphan:
            invalid_ordinals.add(ordinal)
        if ordinal in by_target:
            target = by_target[ordinal]
            if (
                event.get("schemaVersion") != 2
                or event.get("eventKind") != "terminal"
                or event.get("runId") != target["runId"]
                or event.get("launchRunId") != target["launchRunId"]
                or any(field in event for field in (
                    "migrationAction", "migratesRunId", "invalidationMode",
                ))
            ):
                _mixed_recovery_fail("TARGET", f"target row {ordinal} is not an exact V2 terminal")
            digest_field = (
                "eventBodySha256" if target["action"] == "migrate-invalid-finding-class"
                else "physicalLineSha256"
            )
            actual_digest = (
                metadata[ordinal - 1]["sha256"] if digest_field == "eventBodySha256"
                else _sha256_bytes(physical[ordinal - 1])
            )
            if target[digest_field] != actual_digest:
                _mixed_recovery_fail("TARGET", f"target row {ordinal} {digest_field} differs")
            if not row_errors and not orphan:
                _mixed_recovery_fail("TARGET", f"target row {ordinal} has no invalid current relation")
    if invalid_ordinals != set(by_target):
        _mixed_recovery_fail("COVERAGE", "explicit targets do not cover exactly every invalid row")

    controls: list[dict] = []
    target_facts: list[dict] = []
    for target in sorted(request["targets"], key=lambda row: row["rawLineOrdinal"]):
        ordinal = target["rawLineOrdinal"]
        event = events[ordinal - 1]
        digest = target.get("eventBodySha256", target.get("physicalLineSha256"))
        common = {
            "schemaVersion": 2,
            "runId": f"mixed-recovery-{request['operationId']}-{ordinal}",
            "workItem": item.name,
            "role": "lead", "executionRole": "main", "status": "completed",
            "gate": "none", "startedAt": request["recordedAt"],
            "updatedAt": request["recordedAt"],
        }
        if target["action"] == "migrate-invalid-finding-class":
            replacement = {**event, "findingClass": "legacy-unclassified"}
            controls.append({
                **common,
                "scope": ["ledger-migration:invalid-finding-class"],
                "eventKind": "legacy-obligation-migration",
                "migrationAction": "apply", "normalizationKind": "invalid-finding-class",
                "migratesRunId": event["runId"],
                "migratesEventSha256": digest,
                "replacementEvent": replacement,
                "evidence": [{"kind": "manual-check", "ref":
                    f"invalid-finding-class {event['runId']} {digest} -> legacy-unclassified"}],
            })
            effective = replacement
        else:
            controls.append({
                **common,
                "scope": ["ledger-recovery:invalid-current-nonauthorizing"],
                "eventKind": "closure-invalidation",
                "invalidationMode": "invalid-current-nonauthorizing",
                "invalidatesRawLineOrdinal": ordinal,
                "invalidatesRunId": event["runId"],
                "invalidatesEventSha256": digest,
                "authorizing": False,
                "evidence": [{"kind": "manual-check", "ref":
                    f"approved exact target {event['runId']} {digest}"}],
            })
            effective = event
        target_facts.append({**target, "beforeEvent": event,
                             "afterEffectiveEvent": effective,
                             "disposed": target["action"] == "dispose-invalid-terminal"})
    return events, controls, target_facts


def recover_mixed_current_ledger(
    root: Path, request_bytes: bytes, *, apply_admitted: bool = False,
    inject_failure: str | None = None,
) -> dict:
    """Lifecycle-owned exact-prefix mixed V1/V2 repair; no-apply is the default."""

    request = _mixed_recovery_request(request_bytes)
    if inject_failure not in {None, "post-history-publish", "crash-post-history"}:
        _mixed_recovery_fail("REQUEST", "unsupported injection boundary")
    if inject_failure is not None and not apply_admitted:
        _mixed_recovery_fail("REQUEST", "failure injection is apply-only")
    root = Path(root).resolve()
    item = _active_migration_item(root, request["workItem"].split("/")[-1])
    ledger = _require_lifecycle_mutation_path(
        root, item / "agent-runs.jsonl", failure_id="WI-MIXED-LEDGER-DRIFT"
    )
    writer = _load_agent_run_ledger()
    validator = writer.load_validator()
    before_sha = request["expectedLedgerSha256"]
    request_sha = _sha256_bytes(request_bytes)
    history_path = item / f"agent-runs.history.{before_sha}.jsonl"
    receipt_path = item / f"agent-runs.mixed.{request['operationId']}.receipt.json"
    stage_path = ledger.with_suffix(".jsonl.tmp")
    try:
        with writer.ledger_write_lock(item):
            current = writer._noncanonical_read_owned_bytes(ledger, failure_id="DRIFT")
            current_is_original = _sha256_bytes(current) == before_sha
            history = writer._read_exact_history_blob(history_path, before_sha)
            if current_is_original:
                original = current
                if history is not None and history != original:
                    _mixed_recovery_fail("HISTORY", "pre-existing history differs")
            else:
                if history is None:
                    _mixed_recovery_fail("DRIFT", "changed ledger has no exact history blob")
                original = history
            events, controls, target_facts = _mixed_recovery_controls(
                item, original, request, writer, validator
            )
            suffix = b"".join(
                (writer.serialize_event(event) + "\n").encode("utf-8")
                for event in controls
            )
            candidate = original + suffix
            replay = not current_is_original
            if replay and current != candidate:
                _mixed_recovery_fail("DRIFT", "ledger is not the exact committed suffix")
            if receipt_path.exists() and not replay:
                _mixed_recovery_fail("RECEIPT", "receipt exists without committed ledger")
            stage_preexisting = stage_path.exists()
            stage_identity = writer._write_exact_staging_file(stage_path, candidate)
            obligations: list = []
            authority: list = []
            validation_errors = validator.validate_work_item(
                item, ledger_path=stage_path, strict_revise=False,
                validate_status_file=False, obligation_state_out=obligations,
                authority_state_out=authority,
            )
            if validation_errors or len(obligations) != 1 or len(authority) != 1:
                if not stage_preexisting and not writer.remove_exact_mixed_owned_file(
                    stage_path, candidate, stage_identity
                ):
                    _mixed_recovery_fail("RESIDUE", "invalid candidate and changed owned staging")
                _mixed_recovery_fail("CANDIDATE", "; ".join(validation_errors) or "candidate reduction incomplete")
            open_revise = [row.run_id for row in obligations[0].open_revise]
            open_launches = [row.run_id for row in obligations[0].open_launches]
            raw_revise = {str(event["runId"]) for event in events if event.get("schemaVersion") == 2 and event.get("gate") == "REVISE"}
            raw_launches = {str(event["runId"]) for event in events if event.get("eventKind") == "launch"}
            closed_revise = {
                str(closed)
                for ordinal, event in enumerate(events, start=1)
                if authority[0].get(ordinal, validator._NO_LEDGER_AUTHORITY).closer_eligible
                for closed in event.get("closesRunIds", ())
            }
            settled_launches = {
                str(event["launchRunId"])
                for ordinal, event in enumerate(events, start=1)
                if authority[0].get(ordinal, validator._NO_LEDGER_AUTHORITY).terminal_eligible
                and isinstance(event.get("launchRunId"), str)
            }
            if (
                raw_revise != (set(open_revise) | (raw_revise & closed_revise))
                or raw_launches != (set(open_launches) | (raw_launches & settled_launches))
            ):
                if not stage_preexisting and not writer.remove_exact_mixed_owned_file(stage_path, candidate, stage_identity):
                    _mixed_recovery_fail("RESIDUE", "obligation mismatch and changed owned staging")
                _mixed_recovery_fail("OBLIGATION", "raw review or launch identity was not conserved")
            axis_names = (
                "launchEligible", "terminalEligible", "reviseTargetEligible",
                "closerEligible", "artifactEvidenceEligible",
            )
            for fact in target_facts:
                mask = authority[0].get(fact["rawLineOrdinal"], validator._NO_LEDGER_AUTHORITY)
                fact["beforeAuthority"] = dict.fromkeys(axis_names, False)
                fact["afterAuthority"] = dict(zip(axis_names, (
                    mask.launch_eligible, mask.terminal_eligible,
                    mask.revise_target_eligible, mask.closer_eligible,
                    mask.artifact_evidence_eligible,
                )))
            result = {
                "applied": False, "replay": replay,
                "operationId": request["operationId"],
                "ledgerBeforeSha256": before_sha,
                "ledgerAfterSha256": _sha256_bytes(candidate),
                "historyPath": history_path.name,
                "targets": target_facts,
                "openReviseRunIds": open_revise,
                "openLaunchRunIds": open_launches,
                "settledReviseRunIds": sorted(raw_revise & closed_revise),
                "settledLaunchRunIds": sorted(raw_launches & settled_launches),
            }
            receipt = {
                "schemaVersion": 1, "operationId": request["operationId"],
                "recordedAt": request["recordedAt"],
                "requestSha256": request_sha,
                "ledgerBeforeSha256": before_sha,
                "ledgerBeforeByteLength": len(original),
                "historyPath": history_path.name,
                "historySha256": before_sha,
                "ledgerAfterSha256": _sha256_bytes(candidate),
                "ledgerAfterByteLength": len(candidate),
                "targets": target_facts,
                "openReviseRunIds": open_revise,
                "openLaunchRunIds": open_launches,
                "settledReviseRunIds": result["settledReviseRunIds"],
                "settledLaunchRunIds": result["settledLaunchRunIds"],
            }
            receipt_bytes = json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8") + b"\n"
            if replay:
                if history != original or current != candidate:
                    _mixed_recovery_fail("REPLAY", "history or committed suffix differs")
                if apply_admitted:
                    _projection_create_or_exact(receipt_path, receipt_bytes, "WI-MIXED-LEDGER-RECEIPT")
                if not stage_preexisting and not writer.remove_exact_mixed_owned_file(stage_path, candidate, stage_identity):
                    _mixed_recovery_fail("RESIDUE", "replay owned staging changed")
                return {**result, "applied": apply_admitted, "replay": True}
            if not apply_admitted:
                if not stage_preexisting and not writer.remove_exact_mixed_owned_file(stage_path, candidate, stage_identity):
                    _mixed_recovery_fail("RESIDUE", "no-apply owned staging changed")
                return result
            history_created = False
            history_identity = None
            replaced = False
            try:
                published_path, history_created, history_identity = writer.publish_mixed_current_history_blob(
                    item, before_sha, original
                )
                if published_path != history_path:
                    _mixed_recovery_fail("HISTORY", "history path changed")
                if inject_failure == "crash-post-history":
                    raise KeyboardInterrupt("injected abrupt history interruption")
                if inject_failure == "post-history-publish":
                    _mixed_recovery_fail("INJECTED", "injected handled pre-append failure")
                writer._replace_exact_staging_file(stage_path, ledger, candidate, stage_identity)
                replaced = True
                if writer._noncanonical_read_owned_bytes(ledger, failure_id="READBACK-INDETERMINATE") != candidate:
                    _mixed_recovery_fail("READBACK", "committed suffix readback differs")
                _projection_create_or_exact(receipt_path, receipt_bytes, "WI-MIXED-LEDGER-RECEIPT")
                if receipt_path.read_bytes() != receipt_bytes:
                    _mixed_recovery_fail("RECEIPT", "receipt readback differs")
                return {**result, "applied": True, "replay": False}
            except Exception as exc:
                if replaced:
                    _mixed_recovery_fail("COMMIT-INDETERMINATE", f"ledger changed; exact replay required: {exc}")
                try:
                    observed = writer._noncanonical_read_owned_bytes(
                        ledger, failure_id="READBACK-INDETERMINATE"
                    )
                except writer.LedgerNoncanonicalRecoveryError:
                    _mixed_recovery_fail("COMMIT-INDETERMINATE", "ledger cannot be read; preserve history for exact replay")
                if observed != original:
                    _mixed_recovery_fail("COMMIT-INDETERMINATE", "ledger may have changed; preserve history for exact replay")
                clean = True
                if not stage_preexisting:
                    clean = writer.remove_exact_mixed_owned_file(stage_path, candidate, stage_identity) and clean
                if not clean:
                    _mixed_recovery_fail("RESIDUE", "handled failure left changed or ambiguous owned staging")
                if history_created and history_identity is not None:
                    clean = writer.remove_exact_mixed_owned_file(history_path, original, history_identity) and clean
                if not clean:
                    _mixed_recovery_fail("RESIDUE", "handled failure left changed or ambiguous owned residue")
                if isinstance(exc, LifecycleError):
                    raise
                _mixed_recovery_fail("COMMIT", f"pre-append publication failed: {exc}")
    except (writer.LedgerNoncanonicalRecoveryError, writer.LedgerWriteLockError) as exc:
        _mixed_recovery_fail("WRITER", str(exc))


def _projection_active_records(records: list[tuple[dict, bytes]]) -> dict[str, tuple[dict, bytes]]:
    """Reduce exact apply/revoke lines without granting the registry new authority."""
    active: dict[str, tuple[dict, bytes]] = {}
    for record, physical in records:
        operation = record.get("operationId")
        if not isinstance(operation, str):
            _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "registry operation id is invalid")
        if record.get("state") == "apply":
            if operation in active:
                _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "registry apply operation id is duplicated")
            active[operation] = (record, physical)
        elif record.get("state") == "revoke":
            target = record.get("revokeOfOperationId")
            if not isinstance(target, str) or target not in active:
                _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "registry revoke lacks one earlier active apply")
            if record.get("revokeOfRecordSha256") != _sha256_bytes(active[target][1]):
                _projection_fail("WI-LEDGER-MIGRATION-TARGET-DIGEST", "registry revoke does not bind exact apply bytes")
            active.pop(target)
        else:
            _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "registry state is not apply or revoke")
    return active


def _projection_digest_list(value: object, expected_count: int) -> list[str]:
    values = [value] if isinstance(value, str) else value
    if (
        not isinstance(values, list)
        or len(values) != expected_count
        or any(not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None for digest in values)
    ):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-DIGEST", "revoke must bind every exact apply record digest")
    return values


def _projection_cli_record_digests(value: str) -> str | list[str]:
    """Accept the scalar legacy form or one JSON array for an atomic row group."""
    if not value.startswith("["):
        return value
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-DIGEST", "record digest group is not valid JSON")
    if not isinstance(parsed, list):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-DIGEST", "record digest group is not an array")
    return parsed


def _revoke_legacy_ledger_projection_locked(root: Path, apply_operation_id: str, apply_record_sha256: str | list[str], expected_registry_sha256: str, operation_id: str, recorded_at: str) -> dict:
    _projection_operation(operation_id, recorded_at)
    manifests_path, registry_path, receipts = _projection_paths(root)
    repository = Path(root).resolve()
    if repository.name == "work-items" or _lifecycle_path_has_reparse(repository / "work-items"):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "projection writer requires one ordinary repository root")
    if not registry_path.is_file() or _lifecycle_path_has_reparse(registry_path):
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "projection registry is unavailable")
    before = registry_path.read_bytes()
    records = _projection_registry_records(before)
    matching = [
        (index, record, physical) for index, (record, physical) in enumerate(records)
        if record.get("operationGroupId", record.get("operationId")) == apply_operation_id
    ]
    if matching:
        target_index, target_record, _physical = matching[0]
    else:
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "revoke target apply operation is unavailable")
    if target_record.get("state") != "apply":
        _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "revoke target is not an apply record")
    validator = _load_agent_run_ledger().load_validator()
    try:
        manifest_id = validator.confine_legacy_projection_identifier(
            target_record.get("manifestId"), failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID"
        )
        manifest_path = validator.confine_legacy_projection_path(
            repository, f"work-items/{LEGACY_PROJECTION_MANIFEST_DIR}/{manifest_id}.json",
            prefix=("work-items", LEGACY_PROJECTION_MANIFEST_DIR), leaf_kind="file",
            failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID",
        )
    except ValueError as exc:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", f"target manifest is unsafe: {exc}")
        raise AssertionError from exc
    manifest_bytes = manifest_path.read_bytes()
    manifest = _projection_object(manifest_bytes, "target manifest")
    entry = _projection_entry(manifest, target_record["manifestEntryId"], target_record["rawLineOrdinal"], repository)
    child_ids = _projection_group_ids(apply_operation_id, len(entry["rawLineOrdinals"]))
    apply_lines: list[bytes] = []
    apply_records: list[dict] = []
    apply_indices: list[int] = []
    for child_id, raw_ordinal in zip(child_ids, entry["rawLineOrdinals"]):
        matches = [(index, record, physical) for index, (record, physical) in enumerate(records) if record.get("operationId") == child_id]
        if len(matches) != 1 or matches[0][1].get("state") != "apply" or matches[0][1].get("rawLineOrdinal") != raw_ordinal:
            _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "revoke target apply group is partial or differs")
        apply_indices.append(matches[0][0])
        apply_lines.append(matches[0][2])
        apply_records.append(matches[0][1])
    if apply_indices != list(range(apply_indices[0], apply_indices[0] + len(apply_indices))):
        _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "revoke target apply group is non-contiguous")
    supplied_digests = _projection_digest_list(apply_record_sha256, len(apply_lines))
    if supplied_digests != [_sha256_bytes(line) for line in apply_lines]:
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-DIGEST", "revoke target does not bind exact apply group bytes")
    revoke_ids = _projection_group_ids(operation_id, len(child_ids))
    revokes = []
    for member_index, (revoke_id, apply_id, apply_line, apply_record) in enumerate(zip(revoke_ids, child_ids, apply_lines, apply_records), start=1):
        revokes.append({
            **{key: apply_record[key] for key in ("schemaVersion", "profileId", "profileVersion", "manifestId", "manifestSha256", "manifestEntryId", "workItem", "ledgerPath", "ledgerSha256", "rawLineOrdinal", "rawLineSha256", "projectedEvent", "projectedEventSha256")},
            "operationGroupId": operation_id, "groupMemberIndex": member_index, "groupMemberCount": len(revoke_ids),
            "operationId": revoke_id, "state": "revoke", "recordedAt": recorded_at,
            "revokeOfOperationId": apply_id, "revokeOfOperationGroupId": apply_operation_id, "revokeOfRecordSha256": _sha256_bytes(apply_line),
        })
    revoke_lines = [_projection_json(record) + b"\n" for record in revokes]
    persisted = _projection_existing_group(records, revoke_ids, revoke_lines)
    if persisted is not None:
        persisted_before, persisted_after = persisted
        _projection_require_replay_anchor(expected_registry_sha256, persisted_before, before)
        facts = _projection_group_facts(operation_id, revoke_lines, persisted_before, persisted_after)
        _projection_reconcile_receipt(receipts, facts)
        return {**facts, "replay": True}
    active = _projection_active_records(records)
    if any(child_id not in active for child_id in child_ids):
        _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "apply group is already revoked or partially active")
    for later, _physical in records[apply_indices[-1] + 1:]:
        if (
            later.get("manifestId") == target_record["manifestId"]
            and later.get("manifestEntryId") == target_record["manifestEntryId"]
            and later.get("state") in {"apply", "revoke"}
        ):
            _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "revoke is blocked by a later dependent entry operation")
    existing_ids = {record.get("operationId") for record, _physical in records}
    if any(revoke_id in existing_ids for revoke_id in revoke_ids):
        _projection_fail("WI-LEDGER-MIGRATION-TOPOLOGY", "revoke operation group is partial")
    if _sha256_bytes(before) != expected_registry_sha256:
        _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "projection registry digest changed")
    candidate = before + b"".join(revoke_lines)
    manifests = _projection_manifest_blobs(repository, manifests_path, manifest["manifestId"], manifest_bytes)
    baseline = b"".join(physical for index, (_record, physical) in enumerate(records) if index not in set(apply_indices))
    baseline_errors = _projection_candidate_errors(entry, manifests, baseline)
    candidate_errors = _projection_candidate_errors(entry, manifests, candidate)
    if Counter(candidate_errors) != Counter(baseline_errors):
        _projection_fail("WI-LEDGER-MIGRATION-CANDIDATE-INVALID", "; ".join(candidate_errors))
    try:
        _atomic_write(registry_path, candidate)
        actual = registry_path.read_bytes()
    except OSError as exc:
        raise LifecycleError("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "projection revoke registry readback failed") from exc
    if actual != candidate:
        _projection_fail("WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE", "projection revoke registry readback differs")
    facts = _projection_group_facts(operation_id, revoke_lines, before, candidate)
    _projection_reconcile_receipt(receipts, facts)
    return {**facts, "replay": False}


_revoke_legacy_ledger_projection_transaction = _lifecycle_participant(_revoke_legacy_ledger_projection_locked)


def revoke_legacy_ledger_projection(root: Path, apply_operation_id: str, apply_record_sha256: str | list[str], expected_registry_sha256: str, operation_id: str, recorded_at: str) -> dict:
    return _revoke_legacy_ledger_projection_transaction(root, apply_operation_id, apply_record_sha256, expected_registry_sha256, operation_id, recorded_at)


@dataclass(frozen=True)
class SealedPrefixActivationRequestV1:
    h1_manifest_path: str
    h1_manifest_bytes: bytes
    ledger_manifest_path: str
    ledger_manifest_bytes: bytes
    expected_registry_sha256: str
    recorded_at: str


@dataclass(frozen=True)
class SealedPrefixRevokeRequestV1:
    apply_receipt_path: str
    apply_receipt_sha256: str
    expected_registry_sha256: str
    recorded_at: str


@dataclass(frozen=True)
class LedgerH1ArtifactSetRelocationRequestV1:
    archive_owner: str
    expected_artifact_set_sha256: str
    expected_root_contract_sha256: str
    operation_id: str
    recorded_at: str


@dataclass(frozen=True)
class LedgerH1ArtifactSetLocationV1:
    physical_base: str
    phase: Literal["root", "settled-archive"]
    artifact_set_sha256: str
    operation_id: str | None
    receipt_path: str | None


@dataclass(frozen=True)
class SealedPrefixActivationPlanV1:
    state: Literal["apply", "revoke"]
    operation_group_id: str
    member_operation_ids: tuple[str, str]
    receipt_id: str
    ledger_manifest_path: str
    ledger_manifest_bytes: bytes
    h1_manifest_path: str
    h1_manifest_bytes: bytes
    registry_before_sha256: str
    registry_after_bytes: bytes
    receipt_path: str
    receipt_bytes: bytes
    replay: bool


_SEALED_PREFIX_POLICY = "2026-08-28-ledger-h1-compatibility-boundary"
_SEALED_PREFIX_PROFILE = "sealed-active-prefix-v1"
_SEALED_PREFIX_REGISTRY_PATH = f"work-items/{LEGACY_PROJECTION_REGISTRY}"
_SEALED_PREFIX_FAILURE_BOUNDARIES = frozenset(
    {
        "after-ledger-manifest",
        "after-h1-manifest",
        "after-registry-readback",
        "after-receipt-create",
    }
)


def _sealed_prefix_digest(domain: str, value: object) -> str:
    return hashlib.sha256(
        domain.encode("ascii") + b"\0" + _projection_json(value)
    ).hexdigest()


def _sealed_prefix_repository(root: Path) -> tuple[Path, Path]:
    work_items = _work_items_root(root)
    repository = work_items.parent
    _lifecycle_reject_unreduced_reparse(
        repository,
        failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY",
        message="sealed-prefix repository contains a link or reparse point",
    )
    return repository, work_items


def _sealed_prefix_path(
    repository: Path,
    relative: str,
    *,
    prefix: tuple[str, ...],
    failure_id: str,
) -> Path:
    if not isinstance(relative, str) or "\\" in relative:
        _projection_fail(failure_id, "sealed-prefix path is not canonical repository-relative text")
    pure = PurePosixPath(relative)
    if (
        pure.is_absolute()
        or relative != pure.as_posix()
        or any(part in {"", ".", ".."} for part in pure.parts)
        or tuple(pure.parts[: len(prefix)]) != prefix
    ):
        _projection_fail(failure_id, "sealed-prefix path escapes its structural scope")
    return _require_lifecycle_mutation_path(
        repository,
        repository.joinpath(*pure.parts),
        failure_id=failure_id,
    )


def _sealed_prefix_existing_bytes(path: Path, failure_id: str) -> bytes | None:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise LifecycleError(failure_id, "sealed-prefix participant cannot be inspected") from exc
    if _lifecycle_path_has_reparse(path) or not stat.S_ISREG(info.st_mode):
        _projection_fail(failure_id, "sealed-prefix participant is not a regular non-reparse file")
    try:
        return path.read_bytes()
    except OSError as exc:
        raise LifecycleError(failure_id, "sealed-prefix participant cannot be read") from exc


def _sealed_prefix_manifest(request: SealedPrefixActivationRequestV1) -> dict:
    if type(request) is not SealedPrefixActivationRequestV1:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "activation request type is invalid")
    if (
        not isinstance(request.h1_manifest_bytes, bytes)
        or not request.h1_manifest_bytes
        or not isinstance(request.ledger_manifest_bytes, bytes)
        or not request.ledger_manifest_bytes
        or re.fullmatch(r"[0-9a-f]{64}", request.expected_registry_sha256) is None
    ):
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "activation request byte/digest fields are invalid")
    try:
        _load_agent_run_ledger()._strict_migration_inputs(
            "sealed-prefix-activation",
            request.recorded_at,
        )
    except Exception as exc:
        raise LifecycleError(
            "WI-LEDGER-MIGRATION-TARGET-IDENTITY",
            "activation recorded-at is not strict UTC",
        ) from exc
    manifest = _projection_object(request.ledger_manifest_bytes, "sealed-prefix ledger manifest")
    required = {
        "schemaVersion",
        "manifestId",
        "policyDecision",
        "profiles",
        "entries",
        "openReviseIdentitySha256",
        "openReviseOracleSha256",
    }
    if set(manifest) != required or manifest.get("schemaVersion") != 2:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "sealed-prefix ledger manifest shape is invalid")
    manifest_id = manifest.get("manifestId")
    entries = manifest.get("entries")
    if (
        not isinstance(manifest_id, str)
        or _PROJECTION_OPERATION_RE.fullmatch(manifest_id) is None
        or manifest.get("policyDecision") != _SEALED_PREFIX_POLICY
        or manifest.get("profiles")
        != [{"profileId": _SEALED_PREFIX_PROFILE, "profileVersion": 1}]
        or not isinstance(entries, list)
        or len(entries) != 2
        or any(not isinstance(entry, dict) for entry in entries)
    ):
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "sealed-prefix ledger manifest identity/profile is invalid")
    entry_ids = [entry.get("entryId") for entry in entries]
    ledger_paths = [entry.get("ledgerPath") for entry in entries]
    if (
        any(not isinstance(value, str) or _PROJECTION_OPERATION_RE.fullmatch(value) is None for value in entry_ids)
        or len(set(entry_ids)) != 2
        or any(not isinstance(value, str) for value in ledger_paths)
        or ledger_paths != sorted(ledger_paths, key=lambda value: value.encode("utf-8"))
        or len(set(ledger_paths)) != 2
    ):
        _projection_fail("WI-LEDGER-COMPAT-MEMBER-ORDER", "sealed-prefix manifest entries are not uniquely ordered")
    return manifest


def _sealed_prefix_apply_records(
    manifest: dict,
    request: SealedPrefixActivationRequestV1,
) -> tuple[str, tuple[str, str], tuple[bytes, bytes]]:
    entries = manifest["entries"]
    manifest_sha = _sha256_bytes(request.ledger_manifest_bytes)
    h1_sha = _sha256_bytes(request.h1_manifest_bytes)
    group_id = "g-" + _sealed_prefix_digest(
        "orchestrarium:ledger-h1:registry-group:v1",
        [
            "apply",
            _SEALED_PREFIX_POLICY,
            manifest_sha,
            h1_sha,
            [entry["entryId"] for entry in entries],
        ],
    )
    member_ids = tuple(
        "m:" + _sealed_prefix_digest(
            "orchestrarium:ledger-h1:activation-member:v1",
            [group_id, index, entry["entryId"]],
        )
        for index, entry in enumerate(entries, start=1)
    )
    records = []
    for index, (entry, operation_id) in enumerate(
        zip(entries, member_ids),
        start=1,
    ):
        records.append(
            {
                "schemaVersion": 2,
                "operationId": operation_id,
                "operationGroupId": group_id,
                "groupMemberIndex": index,
                "groupMemberCount": 2,
                "state": "apply",
                "profileId": _SEALED_PREFIX_PROFILE,
                "profileVersion": 1,
                "policyDecision": _SEALED_PREFIX_POLICY,
                "manifestId": manifest["manifestId"],
                "manifestSha256": manifest_sha,
                "manifestEntryId": entry["entryId"],
                "h1ManifestPath": request.h1_manifest_path,
                "h1ManifestSha256": h1_sha,
                "workItem": entry["workItem"],
                "ledgerPath": entry["ledgerPath"],
                "prefixLineCount": entry["prefixLineCount"],
                "prefixByteLength": entry["prefixByteLength"],
                "prefixSha256": entry["prefixSha256"],
                "projectedViewSha256": entry["projectedViewSha256"],
                "recordedAt": request.recorded_at,
            }
        )
    lines = tuple(_projection_json(record) + b"\n" for record in records)
    return group_id, member_ids, lines


def _sealed_prefix_group_position(
    registry_bytes: bytes,
    group_id: str,
    member_ids: tuple[str, str],
    lines: tuple[bytes, bytes],
) -> tuple[bytes, bool]:
    physical = registry_bytes.splitlines(keepends=True)
    parsed: list[dict] = []
    for ordinal, line in enumerate(physical, start=1):
        if not line.endswith(b"\n"):
            _projection_fail("WI-LEDGER-COMPAT-ACTIVATION-PARTIAL", f"registry line {ordinal} is not LF-terminated")
        parsed.append(_projection_object(line[:-1], f"sealed-prefix registry line {ordinal}"))
    positions = [
        index
        for index, record in enumerate(parsed)
        if record.get("operationGroupId") == group_id
        or record.get("operationId") in member_ids
    ]
    if not positions:
        return registry_bytes, False
    if positions != [len(physical) - 2, len(physical) - 1]:
        _projection_fail("WI-LEDGER-COMPAT-ACTIVATION-PARTIAL", "sealed-prefix group is partial, interleaved, or not the registry tail")
    observed = tuple(physical[index] for index in positions)
    if observed != lines:
        _projection_fail("WI-LEDGER-COMPAT-REPLAY-MISMATCH", "sealed-prefix group identity has different bytes")
    return b"".join(physical[: positions[0]]), True


def _sealed_prefix_receipt(
    *,
    state: Literal["apply", "revoke"],
    group_id: str,
    member_ids: tuple[str, str],
    member_lines: tuple[bytes, bytes],
    policy: str,
    ledger_manifest_path: str,
    ledger_manifest_bytes: bytes,
    h1_manifest_path: str,
    h1_manifest_bytes: bytes,
    registry_before: bytes,
    registry_after: bytes,
    recorded_at: str,
) -> tuple[str, str, bytes]:
    before_sha = _sha256_bytes(registry_before)
    after_sha = _sha256_bytes(registry_after)
    receipt_id = "r-" + _sealed_prefix_digest(
        "orchestrarium:ledger-h1:receipt-id:v1",
        [state, group_id, before_sha, after_sha],
    )
    receipt = {
        "schemaVersion": 2,
        "receiptId": receipt_id,
        "state": state,
        "operationGroupId": group_id,
        "policyDecision": policy,
        "ledgerManifestPath": ledger_manifest_path,
        "ledgerManifestSha256": _sha256_bytes(ledger_manifest_bytes),
        "h1ManifestPath": h1_manifest_path,
        "h1ManifestSha256": _sha256_bytes(h1_manifest_bytes),
        "memberOperationIds": list(member_ids),
        "memberRecordSha256": [_sha256_bytes(line) for line in member_lines],
        "registryBeforeSha256": before_sha,
        "registryAfterSha256": after_sha,
        "recordedAt": recorded_at,
    }
    relative = f"work-items/{LEGACY_PROJECTION_RECEIPTS}/{receipt_id}.json"
    return receipt_id, relative, _projection_json(receipt) + b"\n"


def _sealed_prefix_candidate_contexts(
    repository: Path,
    *,
    ledger_bytes_by_path: Mapping[str, bytes],
    h1_manifest_path: str,
    h1_manifest_bytes: bytes,
    ledger_manifest_path: str,
    ledger_manifest_bytes: bytes,
    registry_bytes: bytes,
    receipt_bytes_by_path: Mapping[str, bytes],
    expected_state: Literal["active", "revoked"],
) -> Mapping[str, object]:
    validator = _load_agent_run_ledger().load_validator()
    artifacts = validator.LedgerCompatibilityArtifactSetV1(
        MappingProxyType(dict(ledger_bytes_by_path)),
        h1_manifest_path,
        h1_manifest_bytes,
        ledger_manifest_path,
        ledger_manifest_bytes,
        registry_bytes,
        MappingProxyType(dict(receipt_bytes_by_path)),
    )
    contexts = validator._load_effective_ledger_group(
        repository,
        compatibility_artifacts=artifacts,
    )
    if set(contexts) != set(ledger_bytes_by_path):
        failure_ids = {
            failure
            for context in contexts.values()
            for failure in context.observation.failure_ids
        }
        failure = sorted(failure_ids)[0] if failure_ids else "WI-LEDGER-COMPAT-ACTIVATION-PARTIAL"
        diagnostics = [
            diagnostic
            for context in contexts.values()
            for diagnostic in context.observation.diagnostics
        ]
        _projection_fail(failure, "; ".join(diagnostics) or "reader rejected sealed-prefix candidate")
    values = list(contexts.values())
    if expected_state == "active":
        if (
            not values
            or any(
                context.observation.activation_state != "active"
                or context.view is None
                for context in values
            )
            or len({id(context.invocation_token) for context in values}) != 1
        ):
            _projection_fail("WI-LEDGER-COMPAT-EFFECTIVE-VIEW-BYPASS", "reader did not return one active shared-token group")
    elif (
        not values
        or any(
            context.observation.activation_state != "revoked"
            or context.view is not None
            or any(
                any(
                    (
                        row.authority.launch_eligible,
                        row.authority.terminal_eligible,
                        row.authority.revise_target_eligible,
                        row.authority.closer_eligible,
                        row.authority.artifact_evidence_eligible,
                    )
                )
                for row in context.rows
            )
            for context in values
        )
    ):
        _projection_fail("WI-LEDGER-COMPAT-EFFECTIVE-VIEW-BYPASS", "reader did not fold the revoke candidate to zero authority")
    return contexts


def _sealed_prefix_apply_preflight(
    root: Path,
    request: SealedPrefixActivationRequestV1,
) -> tuple[SealedPrefixActivationPlanV1, Mapping[str, bytes]]:
    manifest = _sealed_prefix_manifest(request)
    repository, work_items = _sealed_prefix_repository(root)
    if request.h1_manifest_path != f"work-items/{DECISION_H1_MANIFEST}":
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "H1 manifest path is not canonical")
    expected_ledger_path = (
        f"work-items/{LEGACY_PROJECTION_MANIFEST_DIR}/{manifest['manifestId']}.json"
    )
    if request.ledger_manifest_path != expected_ledger_path:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "ledger manifest path does not match manifestId")
    h1_path = _sealed_prefix_path(
        repository,
        request.h1_manifest_path,
        prefix=("work-items",),
        failure_id="WI-DECISION-H1-MANIFEST-INVALID",
    )
    ledger_manifest_path = _sealed_prefix_path(
        repository,
        request.ledger_manifest_path,
        prefix=("work-items", LEGACY_PROJECTION_MANIFEST_DIR),
        failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID",
    )
    _preflight_current_decision_h1(root, manifest_bytes=request.h1_manifest_bytes)
    h1_payload = _projection_object(request.h1_manifest_bytes, "H1 manifest")
    if h1_payload.get("policyDecision") != manifest.get("policyDecision"):
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "H1 and ledger manifests name different policy decisions")

    ledger_bytes_by_path: dict[str, bytes] = {}
    for entry in manifest["entries"]:
        ledger_relative = entry.get("ledgerPath")
        work_item = entry.get("workItem")
        if (
            not isinstance(ledger_relative, str)
            or not isinstance(work_item, str)
            or ledger_relative != f"{work_item}/agent-runs.jsonl"
        ):
            _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "ledger manifest target identity is invalid")
        ledger_path = _sealed_prefix_path(
            repository,
            ledger_relative,
            prefix=("work-items", "active"),
            failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY",
        )
        raw = _sealed_prefix_existing_bytes(
            ledger_path,
            "WI-LEDGER-MIGRATION-TARGET-IDENTITY",
        )
        if raw is None:
            _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "manifest ledger is missing")
        ledger_bytes_by_path[ledger_relative] = raw

    registry_path = work_items / LEGACY_PROJECTION_REGISTRY
    registry_before_live = _sealed_prefix_existing_bytes(
        registry_path,
        "WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE",
    ) or b""
    group_id, member_ids, member_lines = _sealed_prefix_apply_records(
        manifest,
        request,
    )
    group_before, group_exists = _sealed_prefix_group_position(
        registry_before_live,
        group_id,
        member_ids,
        member_lines,
    )
    if group_exists:
        accepted_registry_hashes = {
            _sha256_bytes(group_before),
            _sha256_bytes(registry_before_live),
        }
        if request.expected_registry_sha256 not in accepted_registry_hashes:
            _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "replay registry digest differs from durable anchors")
        registry_after = registry_before_live
    else:
        if _sha256_bytes(registry_before_live) != request.expected_registry_sha256:
            _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "projection registry digest changed")
        group_before = registry_before_live
        registry_after = registry_before_live + b"".join(member_lines)
    receipt_id, receipt_relative, receipt_bytes = _sealed_prefix_receipt(
        state="apply",
        group_id=group_id,
        member_ids=member_ids,
        member_lines=member_lines,
        policy=manifest["policyDecision"],
        ledger_manifest_path=request.ledger_manifest_path,
        ledger_manifest_bytes=request.ledger_manifest_bytes,
        h1_manifest_path=request.h1_manifest_path,
        h1_manifest_bytes=request.h1_manifest_bytes,
        registry_before=group_before,
        registry_after=registry_after,
        recorded_at=request.recorded_at,
    )
    receipt_path = _sealed_prefix_path(
        repository,
        receipt_relative,
        prefix=("work-items", LEGACY_PROJECTION_RECEIPTS),
        failure_id="WI-LEDGER-COMPAT-RECEIPT-INVALID",
    )
    for path, wanted in (
        (h1_path, request.h1_manifest_bytes),
        (ledger_manifest_path, request.ledger_manifest_bytes),
    ):
        current = _sealed_prefix_existing_bytes(path, "WI-LEDGER-COMPAT-REPLAY-MISMATCH")
        if current is not None and current != wanted:
            _projection_fail("WI-LEDGER-COMPAT-REPLAY-MISMATCH", "create-only manifest bytes differ")
    current_receipt = _sealed_prefix_existing_bytes(
        receipt_path,
        "WI-LEDGER-COMPAT-RECEIPT-INVALID",
    )
    if group_exists:
        if current_receipt is None:
            _projection_fail("WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE", "complete registry group lacks its receipt")
        if current_receipt != receipt_bytes:
            _projection_fail("WI-LEDGER-COMPAT-REPLAY-MISMATCH", "activation receipt bytes differ")
    elif current_receipt is not None:
        _projection_fail("WI-LEDGER-COMPAT-REPLAY-MISMATCH", "activation receipt exists without its registry group")

    _sealed_prefix_candidate_contexts(
        repository,
        ledger_bytes_by_path=ledger_bytes_by_path,
        h1_manifest_path=request.h1_manifest_path,
        h1_manifest_bytes=request.h1_manifest_bytes,
        ledger_manifest_path=request.ledger_manifest_path,
        ledger_manifest_bytes=request.ledger_manifest_bytes,
        registry_bytes=registry_after,
        receipt_bytes_by_path={receipt_relative: receipt_bytes},
        expected_state="active",
    )
    plan = SealedPrefixActivationPlanV1(
        "apply",
        group_id,
        member_ids,
        receipt_id,
        request.ledger_manifest_path,
        request.ledger_manifest_bytes,
        request.h1_manifest_path,
        request.h1_manifest_bytes,
        _sha256_bytes(group_before),
        registry_after,
        receipt_relative,
        receipt_bytes,
        group_exists,
    )
    return plan, MappingProxyType(ledger_bytes_by_path)


def preflight_sealed_prefix_activation(
    root: Path,
    request: SealedPrefixActivationRequestV1,
) -> SealedPrefixActivationPlanV1:
    return _sealed_prefix_apply_preflight(root, request)[0]


def _sealed_prefix_inventory(
    root: Path,
    plan: SealedPrefixActivationPlanV1,
) -> dict[str, dict[str, object]]:
    if plan.replay:
        return {}
    repository, _work_items = _sealed_prefix_repository(root)
    values = {
        plan.ledger_manifest_path: plan.ledger_manifest_bytes,
        plan.h1_manifest_path: plan.h1_manifest_bytes,
        _SEALED_PREFIX_REGISTRY_PATH: plan.registry_after_bytes,
        plan.receipt_path: plan.receipt_bytes,
    }
    inventory: dict[str, dict[str, object]] = {}
    for relative, wanted in values.items():
        path = repository.joinpath(*PurePosixPath(relative).parts)
        current = _sealed_prefix_existing_bytes(
            path,
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
        )
        if current != wanted:
            inventory[relative] = {
                "byteLength": len(wanted),
                "sha256": _sha256_bytes(wanted),
            }
    return inventory


def _sealed_prefix_result(
    plan: SealedPrefixActivationPlanV1,
    *,
    dry_run: bool,
    inventory: dict[str, dict[str, object]],
) -> dict[str, object]:
    return {
        "state": plan.state,
        "readiness": "REPLAY" if plan.replay else "READY",
        "operationGroupId": plan.operation_group_id,
        "memberOperationIds": list(plan.member_operation_ids),
        "receiptId": plan.receipt_id,
        "receiptPath": plan.receipt_path,
        "receiptSha256": _sha256_bytes(plan.receipt_bytes),
        "registryBeforeSha256": plan.registry_before_sha256,
        "registryAfterSha256": _sha256_bytes(plan.registry_after_bytes),
        "byteInventory": inventory,
        "replay": plan.replay,
        "dryRun": dry_run,
    }


def _sealed_prefix_revalidate(
    root: Path,
    request: SealedPrefixActivationRequestV1,
    ledger_bytes_by_path: Mapping[str, bytes],
    registry_expected: bytes,
) -> None:
    transaction = _CURRENT_LIFECYCLE_TRANSACTION.get()
    if transaction is None:
        _projection_fail("WI-LIFECYCLE-LOCK-IDENTITY", "sealed-prefix mutation lacks lifecycle transaction")
    transaction.verify()
    _preflight_current_decision_h1(root, manifest_bytes=request.h1_manifest_bytes)
    repository, work_items = _sealed_prefix_repository(root)
    for relative, expected in ledger_bytes_by_path.items():
        path = repository.joinpath(*PurePosixPath(relative).parts)
        if _sealed_prefix_existing_bytes(path, "WI-LEDGER-MIGRATION-LEDGER-DRIFT") != expected:
            _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "manifest ledger changed during activation")
    registry = _sealed_prefix_existing_bytes(
        work_items / LEGACY_PROJECTION_REGISTRY,
        "WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE",
    ) or b""
    if registry != registry_expected:
        _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "registry changed during activation")


def _sealed_prefix_restore(
    path: Path,
    before: bytes | None,
    wanted: bytes,
    failure_id: str,
) -> None:
    current = _sealed_prefix_existing_bytes(path, failure_id)
    if before is None:
        if current is None:
            return
        if current != wanted:
            _projection_fail(failure_id, "rollback target differs from transaction-owned bytes")
        path.unlink()
        return
    if current == before:
        return
    if current != wanted:
        _projection_fail(failure_id, "rollback target is neither exact before nor owned after")
    _atomic_write(path, before)
    if path.read_bytes() != before:
        _projection_fail(failure_id, "rollback readback differs")


def _sealed_prefix_remove_empty_created_dirs(paths: Iterable[tuple[Path, bool]]) -> None:
    for path, existed in paths:
        if existed:
            continue
        try:
            path.rmdir()
        except (FileNotFoundError, OSError):
            pass


def _apply_sealed_prefix_activation_locked(
    root: Path,
    request: SealedPrefixActivationRequestV1,
    *,
    inject_failure: str | None = None,
) -> dict[str, object]:
    if inject_failure is not None and inject_failure not in _SEALED_PREFIX_FAILURE_BOUNDARIES:
        _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "unknown activation failure boundary")
    plan, ledger_bytes_by_path = _sealed_prefix_apply_preflight(root, request)
    inventory = _sealed_prefix_inventory(root, plan)
    if plan.replay:
        return _sealed_prefix_result(plan, dry_run=False, inventory={})
    repository, work_items = _sealed_prefix_repository(root)
    ledger_path = repository.joinpath(*PurePosixPath(plan.ledger_manifest_path).parts)
    h1_path = repository.joinpath(*PurePosixPath(plan.h1_manifest_path).parts)
    registry_path = work_items / LEGACY_PROJECTION_REGISTRY
    receipt_path = repository.joinpath(*PurePosixPath(plan.receipt_path).parts)
    participants = (
        (ledger_path, _sealed_prefix_existing_bytes(ledger_path, "WI-LEDGER-COMPAT-REPLAY-MISMATCH"), plan.ledger_manifest_bytes),
        (h1_path, _sealed_prefix_existing_bytes(h1_path, "WI-LEDGER-COMPAT-REPLAY-MISMATCH"), plan.h1_manifest_bytes),
        (registry_path, _sealed_prefix_existing_bytes(registry_path, "WI-LEDGER-MIGRATION-COMMIT-INDETERMINATE"), plan.registry_after_bytes),
        (receipt_path, _sealed_prefix_existing_bytes(receipt_path, "WI-LEDGER-COMPAT-RECEIPT-INVALID"), plan.receipt_bytes),
    )
    created_dirs = (
        (ledger_path.parent, ledger_path.parent.exists()),
        (receipt_path.parent, receipt_path.parent.exists()),
    )
    registry_before = participants[2][1] or b""
    receipt_committed = False
    try:
        _sealed_prefix_revalidate(root, request, ledger_bytes_by_path, registry_before)
        _projection_create_or_exact(
            ledger_path,
            plan.ledger_manifest_bytes,
            "WI-LEDGER-COMPAT-REPLAY-MISMATCH",
        )
        if inject_failure == "after-ledger-manifest":
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "injected failure after ledger manifest")
        _sealed_prefix_revalidate(root, request, ledger_bytes_by_path, registry_before)
        _projection_create_or_exact(
            h1_path,
            plan.h1_manifest_bytes,
            "WI-LEDGER-COMPAT-REPLAY-MISMATCH",
        )
        if inject_failure == "after-h1-manifest":
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "injected failure after H1 manifest")
        _sealed_prefix_revalidate(root, request, ledger_bytes_by_path, registry_before)
        registry_path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write(registry_path, plan.registry_after_bytes)
        if registry_path.read_bytes() != plan.registry_after_bytes:
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "registry readback differs")
        if inject_failure == "after-registry-readback":
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "injected failure after registry readback")
        _sealed_prefix_revalidate(
            root,
            request,
            ledger_bytes_by_path,
            plan.registry_after_bytes,
        )
        _projection_create_or_exact(
            receipt_path,
            plan.receipt_bytes,
            "WI-LEDGER-COMPAT-RECEIPT-INVALID",
        )
        receipt_committed = receipt_path.read_bytes() == plan.receipt_bytes
        if not receipt_committed:
            _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "activation receipt readback differs")
        if inject_failure == "after-receipt-create":
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "injected failure after receipt create")
        return _sealed_prefix_result(plan, dry_run=False, inventory=inventory)
    except BaseException:
        if not receipt_committed:
            for path, before, wanted in reversed(participants):
                _sealed_prefix_restore(
                    path,
                    before,
                    wanted,
                    "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                )
            _sealed_prefix_remove_empty_created_dirs(reversed(created_dirs))
        raise


_apply_sealed_prefix_activation_transaction = _lifecycle_participant(
    _apply_sealed_prefix_activation_locked
)


def apply_sealed_prefix_activation(
    root: Path,
    request: SealedPrefixActivationRequestV1,
    *,
    dry_run: bool = False,
    inject_failure: str | None = None,
) -> dict[str, object]:
    if dry_run:
        if inject_failure is not None:
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "dry-run forbids failure injection")
        plan = preflight_sealed_prefix_activation(root, request)
        return _sealed_prefix_result(
            plan,
            dry_run=True,
            inventory=_sealed_prefix_inventory(root, plan),
        )
    return _apply_sealed_prefix_activation_transaction(
        root,
        request,
        inject_failure=inject_failure,
    )


def _sealed_prefix_revoke_preflight(
    root: Path,
    request: SealedPrefixRevokeRequestV1,
) -> tuple[SealedPrefixActivationPlanV1, Mapping[str, bytes]]:
    if type(request) is not SealedPrefixRevokeRequestV1:
        _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "revoke request type is invalid")
    if (
        re.fullmatch(r"[0-9a-f]{64}", request.apply_receipt_sha256) is None
        or re.fullmatch(r"[0-9a-f]{64}", request.expected_registry_sha256) is None
    ):
        _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "revoke request digest is invalid")
    try:
        _load_agent_run_ledger()._strict_migration_inputs(
            "sealed-prefix-revoke",
            request.recorded_at,
        )
    except Exception as exc:
        raise LifecycleError("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "revoke recorded-at is not strict UTC") from exc
    repository, work_items = _sealed_prefix_repository(root)
    apply_receipt_path = _sealed_prefix_path(
        repository,
        request.apply_receipt_path,
        prefix=("work-items", LEGACY_PROJECTION_RECEIPTS),
        failure_id="WI-LEDGER-COMPAT-RECEIPT-INVALID",
    )
    apply_receipt_bytes = _sealed_prefix_existing_bytes(
        apply_receipt_path,
        "WI-LEDGER-COMPAT-RECEIPT-INVALID",
    )
    if apply_receipt_bytes is None or _sha256_bytes(apply_receipt_bytes) != request.apply_receipt_sha256:
        _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "apply receipt is missing or differs")
    apply_receipt = _projection_object(apply_receipt_bytes, "apply receipt")
    if (
        apply_receipt.get("schemaVersion") != 2
        or apply_receipt.get("state") != "apply"
        or request.apply_receipt_path
        != f"work-items/{LEGACY_PROJECTION_RECEIPTS}/{apply_receipt.get('receiptId')}.json"
    ):
        _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "apply receipt identity is invalid")
    ledger_manifest_relative = apply_receipt.get("ledgerManifestPath")
    h1_manifest_relative = apply_receipt.get("h1ManifestPath")
    if not isinstance(ledger_manifest_relative, str) or not isinstance(h1_manifest_relative, str):
        _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "apply receipt manifest paths are invalid")
    ledger_manifest_path = _sealed_prefix_path(
        repository,
        ledger_manifest_relative,
        prefix=("work-items", LEGACY_PROJECTION_MANIFEST_DIR),
        failure_id="WI-LEDGER-MIGRATION-MANIFEST-INVALID",
    )
    h1_manifest_path = _sealed_prefix_path(
        repository,
        h1_manifest_relative,
        prefix=("work-items",),
        failure_id="WI-DECISION-H1-MANIFEST-INVALID",
    )
    ledger_manifest_bytes = _sealed_prefix_existing_bytes(ledger_manifest_path, "WI-LEDGER-MIGRATION-MANIFEST-INVALID")
    h1_manifest_bytes = _sealed_prefix_existing_bytes(h1_manifest_path, "WI-DECISION-H1-MANIFEST-INVALID")
    if ledger_manifest_bytes is None or h1_manifest_bytes is None:
        _projection_fail("WI-LEDGER-COMPAT-ACTIVATION-PARTIAL", "apply manifests are missing")
    if (
        _sha256_bytes(ledger_manifest_bytes) != apply_receipt.get("ledgerManifestSha256")
        or _sha256_bytes(h1_manifest_bytes) != apply_receipt.get("h1ManifestSha256")
    ):
        _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "apply manifest digest differs")
    manifest = _projection_object(ledger_manifest_bytes, "sealed-prefix ledger manifest")
    entries = manifest.get("entries")
    if not isinstance(entries, list) or len(entries) != 2:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "revoke manifest entries are invalid")
    ledger_bytes_by_path: dict[str, bytes] = {}
    for entry in entries:
        if not isinstance(entry, dict) or not isinstance(entry.get("ledgerPath"), str):
            _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "revoke ledger entry is invalid")
        ledger_path = _sealed_prefix_path(
            repository,
            entry["ledgerPath"],
            prefix=("work-items", "active"),
            failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY",
        )
        raw = _sealed_prefix_existing_bytes(ledger_path, "WI-LEDGER-MIGRATION-TARGET-IDENTITY")
        if raw is None:
            _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "revoke ledger is missing")
        if (
            len(raw) != entry.get("prefixByteLength")
            or _sha256_bytes(raw) != entry.get("prefixSha256")
        ):
            _projection_fail("WI-LEDGER-COMPAT-REVOKE-AFTER-SUFFIX", "revoke refuses a ledger with suffix or prefix drift")
        ledger_bytes_by_path[entry["ledgerPath"]] = raw
    registry_path = work_items / LEGACY_PROJECTION_REGISTRY
    registry_live = _sealed_prefix_existing_bytes(registry_path, "WI-LEDGER-COMPAT-ACTIVATION-PARTIAL")
    if registry_live is None:
        _projection_fail("WI-LEDGER-COMPAT-ACTIVATION-PARTIAL", "projection registry is missing")
    physical = registry_live.splitlines(keepends=True)
    parsed = [
        _projection_object(line[:-1], f"revoke registry line {index}")
        for index, line in enumerate(physical, start=1)
        if line.endswith(b"\n")
    ]
    apply_ids = apply_receipt.get("memberOperationIds")
    apply_hashes = apply_receipt.get("memberRecordSha256")
    if not isinstance(apply_ids, list) or not isinstance(apply_hashes, list) or len(apply_ids) != 2 or len(apply_hashes) != 2:
        _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "apply receipt member arrays are invalid")
    apply_positions = [
        next((index for index, record in enumerate(parsed) if record.get("operationId") == operation_id), -1)
        for operation_id in apply_ids
    ]
    if apply_positions[0] < 0 or apply_positions[1] != apply_positions[0] + 1:
        _projection_fail("WI-LEDGER-COMPAT-ACTIVATION-PARTIAL", "apply registry group is missing or noncontiguous")
    apply_lines = tuple(physical[index] for index in apply_positions)
    apply_records = tuple(parsed[index] for index in apply_positions)
    if [_sha256_bytes(line) for line in apply_lines] != apply_hashes:
        _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "apply registry member digest differs")
    apply_registry = b"".join(physical[: apply_positions[-1] + 1])
    _sealed_prefix_candidate_contexts(
        repository,
        ledger_bytes_by_path=ledger_bytes_by_path,
        h1_manifest_path=h1_manifest_relative,
        h1_manifest_bytes=h1_manifest_bytes,
        ledger_manifest_path=ledger_manifest_relative,
        ledger_manifest_bytes=ledger_manifest_bytes,
        registry_bytes=apply_registry,
        receipt_bytes_by_path={request.apply_receipt_path: apply_receipt_bytes},
        expected_state="active",
    )
    manifest_sha = _sha256_bytes(ledger_manifest_bytes)
    h1_sha = _sha256_bytes(h1_manifest_bytes)
    group_id = "g-" + _sealed_prefix_digest(
        "orchestrarium:ledger-h1:registry-group:v1",
        [
            "revoke",
            manifest["policyDecision"],
            manifest_sha,
            h1_sha,
            [entry["entryId"] for entry in entries],
        ],
    )
    member_ids = tuple(
        "m:" + _sealed_prefix_digest(
            "orchestrarium:ledger-h1:activation-member:v1",
            [group_id, index, entry["entryId"]],
        )
        for index, entry in enumerate(entries, start=1)
    )
    revoke_records = []
    for index, (entry, operation_id, apply_id, apply_line, apply_record) in enumerate(
        zip(entries, member_ids, apply_ids, apply_lines, apply_records),
        start=1,
    ):
        retained = {
            key: apply_record[key]
            for key in (
                "schemaVersion", "profileId", "profileVersion", "policyDecision",
                "manifestId", "manifestSha256", "manifestEntryId", "h1ManifestPath",
                "h1ManifestSha256", "workItem", "ledgerPath", "prefixLineCount",
                "prefixByteLength", "prefixSha256", "projectedViewSha256",
            )
        }
        revoke_records.append(
            {
                **retained,
                "operationId": operation_id,
                "operationGroupId": group_id,
                "groupMemberIndex": index,
                "groupMemberCount": 2,
                "state": "revoke",
                "recordedAt": request.recorded_at,
                "revokeOfOperationId": apply_id,
                "revokeOfOperationGroupId": apply_receipt["operationGroupId"],
                "revokeOfRecordSha256": _sha256_bytes(apply_line),
            }
        )
    revoke_lines = tuple(_projection_json(record) + b"\n" for record in revoke_records)
    group_before, group_exists = _sealed_prefix_group_position(
        registry_live,
        group_id,
        member_ids,
        revoke_lines,
    )
    accepted_registry_hashes = (
        {_sha256_bytes(group_before), _sha256_bytes(registry_live)}
        if group_exists
        else {_sha256_bytes(registry_live)}
    )
    if request.expected_registry_sha256 not in accepted_registry_hashes:
        _projection_fail(
            "WI-LEDGER-MIGRATION-LEDGER-DRIFT",
            "revoke registry digest differs from the current or exact replay anchor",
        )
    registry_after = registry_live if group_exists else registry_live + b"".join(revoke_lines)
    receipt_id, receipt_relative, receipt_bytes = _sealed_prefix_receipt(
        state="revoke",
        group_id=group_id,
        member_ids=member_ids,
        member_lines=revoke_lines,
        policy=manifest["policyDecision"],
        ledger_manifest_path=ledger_manifest_relative,
        ledger_manifest_bytes=ledger_manifest_bytes,
        h1_manifest_path=h1_manifest_relative,
        h1_manifest_bytes=h1_manifest_bytes,
        registry_before=group_before,
        registry_after=registry_after,
        recorded_at=request.recorded_at,
    )
    receipt_path = _sealed_prefix_path(
        repository,
        receipt_relative,
        prefix=("work-items", LEGACY_PROJECTION_RECEIPTS),
        failure_id="WI-LEDGER-COMPAT-RECEIPT-INVALID",
    )
    current_receipt = _sealed_prefix_existing_bytes(receipt_path, "WI-LEDGER-COMPAT-RECEIPT-INVALID")
    if group_exists:
        if current_receipt is None:
            _projection_fail("WI-LEDGER-COMPAT-ACTIVATION-INCOMPLETE", "complete revoke group lacks receipt")
        if current_receipt != receipt_bytes:
            _projection_fail("WI-LEDGER-COMPAT-REPLAY-MISMATCH", "revoke receipt bytes differ")
    elif current_receipt is not None:
        _projection_fail("WI-LEDGER-COMPAT-REPLAY-MISMATCH", "revoke receipt exists without group")
    _sealed_prefix_candidate_contexts(
        repository,
        ledger_bytes_by_path=ledger_bytes_by_path,
        h1_manifest_path=h1_manifest_relative,
        h1_manifest_bytes=h1_manifest_bytes,
        ledger_manifest_path=ledger_manifest_relative,
        ledger_manifest_bytes=ledger_manifest_bytes,
        registry_bytes=registry_after,
        receipt_bytes_by_path={
            request.apply_receipt_path: apply_receipt_bytes,
            receipt_relative: receipt_bytes,
        },
        expected_state="revoked",
    )
    plan = SealedPrefixActivationPlanV1(
        "revoke", group_id, member_ids, receipt_id,
        ledger_manifest_relative, ledger_manifest_bytes,
        h1_manifest_relative, h1_manifest_bytes,
        _sha256_bytes(group_before), registry_after,
        receipt_relative, receipt_bytes, group_exists,
    )
    return plan, MappingProxyType(ledger_bytes_by_path)


def preflight_sealed_prefix_revoke(
    root: Path,
    request: SealedPrefixRevokeRequestV1,
) -> SealedPrefixActivationPlanV1:
    return _sealed_prefix_revoke_preflight(root, request)[0]


def _revoke_sealed_prefix_activation_locked(
    root: Path,
    request: SealedPrefixRevokeRequestV1,
    *,
    inject_failure: str | None = None,
) -> dict[str, object]:
    if inject_failure not in {None, "after-registry-readback", "after-receipt-create"}:
        _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "unknown revoke failure boundary")
    plan, ledger_bytes = _sealed_prefix_revoke_preflight(root, request)
    inventory = _sealed_prefix_inventory(root, plan)
    if plan.replay:
        return _sealed_prefix_result(plan, dry_run=False, inventory={})
    repository, work_items = _sealed_prefix_repository(root)
    registry_path = work_items / LEGACY_PROJECTION_REGISTRY
    receipt_path = repository.joinpath(*PurePosixPath(plan.receipt_path).parts)
    registry_before = registry_path.read_bytes()
    receipt_before = _sealed_prefix_existing_bytes(receipt_path, "WI-LEDGER-COMPAT-RECEIPT-INVALID")
    receipt_dir_existed = receipt_path.parent.exists()
    receipt_committed = False
    try:
        transaction = _CURRENT_LIFECYCLE_TRANSACTION.get()
        if transaction is None:
            _projection_fail("WI-LIFECYCLE-LOCK-IDENTITY", "sealed-prefix revoke lacks lifecycle transaction")
        transaction.verify()
        for relative, expected in ledger_bytes.items():
            path = repository.joinpath(*PurePosixPath(relative).parts)
            if path.read_bytes() != expected:
                _projection_fail("WI-LEDGER-COMPAT-REVOKE-AFTER-SUFFIX", "ledger changed during revoke")
        if registry_path.read_bytes() != registry_before:
            _projection_fail("WI-LEDGER-MIGRATION-LEDGER-DRIFT", "registry changed during revoke")
        _atomic_write(registry_path, plan.registry_after_bytes)
        if registry_path.read_bytes() != plan.registry_after_bytes:
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "revoke registry readback differs")
        if inject_failure == "after-registry-readback":
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "injected failure after revoke registry")
        transaction.verify()
        for relative, expected in ledger_bytes.items():
            path = repository.joinpath(*PurePosixPath(relative).parts)
            if path.read_bytes() != expected:
                _projection_fail("WI-LEDGER-COMPAT-REVOKE-AFTER-SUFFIX", "ledger changed before revoke receipt")
        _projection_create_or_exact(receipt_path, plan.receipt_bytes, "WI-LEDGER-COMPAT-RECEIPT-INVALID")
        receipt_committed = receipt_path.read_bytes() == plan.receipt_bytes
        if not receipt_committed:
            _projection_fail("WI-LEDGER-COMPAT-RECEIPT-INVALID", "revoke receipt readback differs")
        if inject_failure == "after-receipt-create":
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "injected failure after revoke receipt")
        return _sealed_prefix_result(plan, dry_run=False, inventory=inventory)
    except BaseException:
        if not receipt_committed:
            _sealed_prefix_restore(
                registry_path,
                registry_before,
                plan.registry_after_bytes,
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            )
            _sealed_prefix_restore(
                receipt_path,
                receipt_before,
                plan.receipt_bytes,
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            )
            _sealed_prefix_remove_empty_created_dirs(((receipt_path.parent, receipt_dir_existed),))
        raise


_revoke_sealed_prefix_activation_transaction = _lifecycle_participant(
    _revoke_sealed_prefix_activation_locked
)


def revoke_sealed_prefix_activation(
    root: Path,
    request: SealedPrefixRevokeRequestV1,
    *,
    dry_run: bool = False,
    inject_failure: str | None = None,
) -> dict[str, object]:
    if dry_run:
        if inject_failure is not None:
            _projection_fail("WI-LEDGER-COMPAT-COMMIT-INDETERMINATE", "dry-run forbids failure injection")
        plan = preflight_sealed_prefix_revoke(root, request)
        return _sealed_prefix_result(
            plan,
            dry_run=True,
            inventory=_sealed_prefix_inventory(root, plan),
        )
    return _revoke_sealed_prefix_activation_transaction(
        root,
        request,
        inject_failure=inject_failure,
    )


@dataclass(frozen=True)
class _LedgerH1ArtifactSetRelocationPlanV1:
    repository: Path
    work_items: Path
    archive_owner: Path
    artifact_base: Path
    receipt_path: Path
    artifact_set_sha256: str
    root_contract_path: Path
    root_contract_before: bytes
    root_contract_after: bytes | None
    members: tuple[dict[str, object], ...]
    receipt_bytes: bytes


def _ledger_h1_relocation_fail(message: str) -> None:
    raise LifecycleError("WI-LEDGER-COMPAT-SET-TOPOLOGY", message)


def _ledger_h1_relocation_request(
    request: LedgerH1ArtifactSetRelocationRequestV1,
) -> tuple[str, str]:
    if type(request) is not LedgerH1ArtifactSetRelocationRequestV1:
        _ledger_h1_relocation_fail("H1 artifact-set relocation request type is invalid")
    expected_artifact_set_sha256 = _normalize_sha256_input(
        request.expected_artifact_set_sha256
    )
    expected_root_contract_sha256 = _normalize_sha256_input(
        request.expected_root_contract_sha256
    )
    if (
        not isinstance(request.archive_owner, str)
        or not isinstance(expected_artifact_set_sha256, str)
        or SHA256_RE.fullmatch(expected_artifact_set_sha256) is None
        or not isinstance(expected_root_contract_sha256, str)
        or SHA256_RE.fullmatch(expected_root_contract_sha256) is None
        or not isinstance(request.operation_id, str)
        or _PROJECTION_OPERATION_RE.fullmatch(request.operation_id) is None
    ):
        _ledger_h1_relocation_fail("H1 artifact-set relocation request is invalid")
    try:
        _load_agent_run_ledger()._strict_migration_inputs(
            request.operation_id,
            request.recorded_at,
        )
    except Exception as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "H1 artifact-set relocation recorded-at is not strict UTC",
        ) from exc
    return expected_artifact_set_sha256, expected_root_contract_sha256


def _ledger_h1_archive_owner(
    repository: Path,
    work_items: Path,
    relative: str,
) -> Path:
    if "\\" in relative:
        _ledger_h1_relocation_fail("archive owner is not canonical repository-relative text")
    pure = PurePosixPath(relative)
    if (
        pure.is_absolute()
        or relative != pure.as_posix()
        or len(pure.parts) != 4
        or pure.parts[:2] != ("work-items", "archive")
        or re.fullmatch(r"\d{4}-\d{2}", pure.parts[2], re.ASCII) is None
    ):
        _ledger_h1_relocation_fail(
            "archive owner must name one exact monthly archived work item"
        )
    try:
        archive_month_value = datetime.strptime(pure.parts[2], "%Y-%m")
    except ValueError as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "archive owner month is not a calendar month",
        ) from exc
    if archive_month_value.strftime("%Y-%m") != pure.parts[2]:
        _ledger_h1_relocation_fail("archive owner month is not canonical")
    _validate_slug(pure.parts[3])
    archive_owner = _require_lifecycle_mutation_path(
        repository,
        repository.joinpath(*pure.parts),
        failure_id="WI-LEDGER-COMPAT-SET-TOPOLOGY",
    )
    if archive_owner.parent.parent != work_items / "archive":
        _ledger_h1_relocation_fail("archive owner escapes the monthly work-item archive")
    if not archive_owner.is_dir() or _lifecycle_path_has_reparse(archive_owner):
        _ledger_h1_relocation_fail("archive owner is not one ordinary archived work item")
    _archived_work_item_entry(archive_owner)
    return archive_owner


def _ledger_h1_directory_snapshot(path: Path) -> tuple[int, str]:
    rows: list[dict[str, object]] = []
    try:
        children = sorted(path.iterdir(), key=lambda child: child.name.encode("utf-8"))
    except OSError as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "H1 artifact directory is unreadable",
        ) from exc
    for child in children:
        if _lifecycle_path_has_reparse(child) or not child.is_file():
            _ledger_h1_relocation_fail(
                "H1 artifact directories must contain only ordinary flat files"
            )
        try:
            raw = child.read_bytes()
        except OSError as exc:
            raise LifecycleError(
                "WI-LEDGER-COMPAT-SET-TOPOLOGY",
                "H1 artifact directory member is unreadable",
            ) from exc
        rows.append(
            {
                "name": child.name,
                "byteLength": len(raw),
                "sha256": _sha256_bytes(raw),
            }
        )
    directory_digest = hashlib.sha256(
        b"orchestrarium:ledger-h1-artifact-directory:v1\0"
        + _projection_json(rows)
    ).hexdigest()
    return sum(int(row["byteLength"]) for row in rows), directory_digest


def _ledger_h1_member_snapshot(
    path: Path,
    *,
    kind: str,
) -> tuple[int, str]:
    if _lifecycle_path_has_reparse(path):
        _ledger_h1_relocation_fail("H1 artifact-set member is a link or reparse point")
    if kind == "file":
        if not path.is_file():
            _ledger_h1_relocation_fail("H1 artifact-set file member is missing")
        try:
            raw = path.read_bytes()
        except OSError as exc:
            raise LifecycleError(
                "WI-LEDGER-COMPAT-SET-TOPOLOGY",
                "H1 artifact-set file member is unreadable",
            ) from exc
        return len(raw), _sha256_bytes(raw)
    if kind != "directory" or not path.is_dir():
        _ledger_h1_relocation_fail("H1 artifact-set directory member is missing")
    return _ledger_h1_directory_snapshot(path)


def _ledger_h1_artifact_set_digest_version(
    members: Iterable[Mapping[str, object]],
    *,
    version: Literal[1, 2],
) -> str:
    rows: list[dict[str, object]] = []
    for member in sorted(
        members,
        key=lambda row: str(row["logicalPath"]).encode("utf-8"),
    ):
        row = {
            "logicalPath": member["logicalPath"],
            "kind": member["kind"],
        }
        if version == 2 or member["kind"] == "file":
            row.update(
                {
                    "byteLength": member["byteLength"],
                    "sha256": member["sha256"],
                }
            )
        rows.append(row)
    return hashlib.sha256(
        f"orchestrarium:ledger-h1-artifact-set:v{version}\0".encode("ascii")
        + _projection_json(rows)
    ).hexdigest()


def _ledger_h1_artifact_set_digest_v1(
    members: Iterable[Mapping[str, object]],
) -> str:
    return _ledger_h1_artifact_set_digest_version(members, version=1)


def _ledger_h1_artifact_set_digest(
    members: Iterable[Mapping[str, object]],
) -> str:
    return _ledger_h1_artifact_set_digest_version(members, version=2)


def _ledger_h1_lexically_exists(path: Path) -> bool:
    try:
        path.lstat()
    except FileNotFoundError:
        return False
    except OSError as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "H1 artifact-set path cannot be inspected",
        ) from exc
    return True


def _ledger_h1_members_at_base(
    repository: Path,
    base: Path,
) -> tuple[dict[str, object], ...]:
    members: list[dict[str, object]] = []
    for name, kind in LEDGER_H1_RELOCATION_MEMBERS:
        path = base / name
        byte_length, sha256 = _ledger_h1_member_snapshot(path, kind=kind)
        members.append(
            {
                "logicalPath": f"work-items/{name}",
                "sourcePath": path.relative_to(repository).as_posix(),
                "targetPath": path.relative_to(repository).as_posix(),
                "kind": kind,
                "byteLength": byte_length,
                "sha256": sha256,
            }
        )
    members.sort(key=lambda row: str(row["logicalPath"]).encode("utf-8"))
    return tuple(members)


def _ledger_h1_archive_bases(repository: Path, work_items: Path) -> tuple[Path, ...]:
    archive = work_items / "archive"
    if not _ledger_h1_lexically_exists(archive):
        return ()
    _lifecycle_reject_unreduced_reparse(
        archive,
        failure_id="WI-LEDGER-COMPAT-SET-TOPOLOGY",
        message="H1 archive root contains a link or reparse point",
    )
    if not archive.is_dir():
        _ledger_h1_relocation_fail("H1 archive root is not a directory")
    bases: list[Path] = []
    try:
        months = sorted(archive.iterdir(), key=lambda path: path.name.encode("utf-8"))
        for month in months:
            if not month.is_dir():
                continue
            _lifecycle_reject_unreduced_reparse(
                month,
                failure_id="WI-LEDGER-COMPAT-SET-TOPOLOGY",
                message="H1 archive month contains a link or reparse point",
            )
            for owner in sorted(
                month.iterdir(), key=lambda path: path.name.encode("utf-8")
            ):
                if not owner.is_dir():
                    continue
                base = owner / LEDGER_H1_ARTIFACT_BASE
                if _ledger_h1_lexically_exists(base):
                    _lifecycle_reject_unreduced_reparse(
                        base,
                        failure_id="WI-LEDGER-COMPAT-SET-TOPOLOGY",
                        message="H1 archived artifact base contains a link or reparse point",
                    )
                    bases.append(base)
    except OSError as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "H1 archive topology is unreadable",
        ) from exc
    return tuple(bases)


def _ledger_h1_root_profile_observed(work_items: Path) -> bool:
    h1 = work_items / DECISION_H1_MANIFEST
    if _ledger_h1_lexically_exists(h1):
        return True
    profile_marker = _SEALED_PREFIX_PROFILE.encode("ascii")
    policy_marker = _SEALED_PREFIX_POLICY.encode("ascii")
    manifests = work_items / LEGACY_PROJECTION_MANIFEST_DIR
    registry = work_items / LEGACY_PROJECTION_REGISTRY
    receipts = work_items / LEGACY_PROJECTION_RECEIPTS
    try:
        if manifests.is_dir() and any(
            profile_marker in (raw := path.read_bytes()) or policy_marker in raw
            for path in manifests.iterdir()
            if path.is_file() and path.suffix == ".json"
        ):
            return True
        if registry.is_file():
            registry_bytes = registry.read_bytes()
            if profile_marker in registry_bytes or policy_marker in registry_bytes:
                return True
        if receipts.is_dir():
            for path in receipts.iterdir():
                if not path.is_file() or path.suffix != ".json":
                    continue
                raw = path.read_bytes()
                if (
                    profile_marker in raw
                    or policy_marker in raw
                    or b'"ledgerManifestPath"' in raw
                    or b'"h1ManifestPath"' in raw
                    or re.search(rb'"schemaVersion"\s*:\s*2(?:\D|$)', raw)
                    is not None
                ):
                    return True
    except OSError:
        return True
    return False


def _ledger_h1_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    value: dict[str, object] = {}
    for key, item in pairs:
        if key in value:
            _ledger_h1_relocation_fail(f"H1 settlement repeats JSON key: {key}")
        value[key] = item
    return value


def _ledger_h1_receipt_object(path: Path) -> tuple[dict[str, object], bytes]:
    if _lifecycle_path_has_reparse(path) or not path.is_file():
        _ledger_h1_relocation_fail("settled H1 archive lacks one ordinary receipt")
    try:
        raw = path.read_bytes()
        receipt = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=_ledger_h1_json_object,
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "settled H1 archive receipt is unreadable",
        ) from exc
    if not isinstance(receipt, dict):
        _ledger_h1_relocation_fail("settled H1 archive receipt is not one object")
    return receipt, raw


def _ledger_h1_validate_receipt(
    repository: Path,
    base: Path,
    receipt: Mapping[str, object],
    artifact_set_sha256_v1: str,
    artifact_set_sha256_v2: str,
) -> None:
    base_relative = base.relative_to(repository).as_posix()
    archive_owner = base.parent.relative_to(repository).as_posix()
    root_after = receipt.get("rootContractAfterSha256")
    schema_version = receipt.get("schemaVersion")
    receipt_artifact_set_sha256 = (
        artifact_set_sha256_v1
        if schema_version == 1
        else artifact_set_sha256_v2
        if schema_version == 2
        else None
    )
    if (
        set(receipt) != LEDGER_H1_RELOCATION_RECEIPT_FIELDS
        or receipt_artifact_set_sha256 is None
        or receipt.get("status") != "settled"
        or receipt.get("archiveOwner") != archive_owner
        or receipt.get("artifactBase") != base_relative
        or receipt.get("artifactSetSha256") != receipt_artifact_set_sha256
        or not isinstance(receipt.get("operationId"), str)
        or _PROJECTION_OPERATION_RE.fullmatch(str(receipt["operationId"])) is None
        or not isinstance(receipt.get("recordedAt"), str)
        or not isinstance(receipt.get("rootContractBeforeSha256"), str)
        or SHA256_RE.fullmatch(str(receipt["rootContractBeforeSha256"])) is None
        or (
            root_after is not None
            and (
                not isinstance(root_after, str)
                or SHA256_RE.fullmatch(root_after) is None
            )
        )
    ):
        _ledger_h1_relocation_fail("settled H1 archive receipt binding differs")


def resolve_ledger_h1_artifact_set_location(
    root: Path,
) -> LedgerH1ArtifactSetLocationV1 | None:
    """Resolve one complete root set or one exact settled archived set."""

    unresolved = _lifecycle_unresolved_absolute(Path(root))
    _lifecycle_reject_unreduced_reparse(
        unresolved,
        failure_id="WI-LEDGER-COMPAT-SET-TOPOLOGY",
        message="H1 repository root contains a link or reparse point",
    )
    resolved = unresolved.resolve()
    work_items = resolved if resolved.name == "work-items" else resolved / "work-items"
    repository = work_items.parent
    if not work_items.is_dir() or _lifecycle_path_has_reparse(work_items):
        return None
    root_presence = tuple(
        _ledger_h1_lexically_exists(work_items / name)
        for name, _kind in LEDGER_H1_RELOCATION_MEMBERS
    )
    root_observed = _ledger_h1_root_profile_observed(work_items)
    archive_bases = _ledger_h1_archive_bases(repository, work_items)
    if root_observed and not all(root_presence):
        _ledger_h1_relocation_fail("root H1 artifact set is partial")
    if root_observed and all(root_presence) and archive_bases:
        _ledger_h1_relocation_fail("root and archived H1 artifact sets coexist")
    if len(archive_bases) > 1:
        _ledger_h1_relocation_fail("more than one archived H1 artifact set exists")
    if root_observed and all(root_presence):
        members = _ledger_h1_members_at_base(repository, work_items)
        return LedgerH1ArtifactSetLocationV1(
            "work-items",
            "root",
            _ledger_h1_artifact_set_digest(members),
            None,
            None,
        )
    if not archive_bases:
        return None
    base = archive_bases[0]
    if not base.is_dir():
        _ledger_h1_relocation_fail("archived H1 artifact base is not a directory")
    try:
        _archived_work_item_entry(base.parent)
    except LifecycleError as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "archived H1 artifact base has no valid work-item owner",
        ) from exc
    members = _ledger_h1_members_at_base(repository, base)
    artifact_set_sha256_v2 = _ledger_h1_artifact_set_digest(members)
    artifact_set_sha256_v1 = _ledger_h1_artifact_set_digest_v1(members)
    receipt_path = base / "relocation-receipt.json"
    receipt, _raw = _ledger_h1_receipt_object(receipt_path)
    _ledger_h1_validate_receipt(
        repository,
        base,
        receipt,
        artifact_set_sha256_v1,
        artifact_set_sha256_v2,
    )
    return LedgerH1ArtifactSetLocationV1(
        base.relative_to(repository).as_posix(),
        "settled-archive",
        artifact_set_sha256_v2,
        str(receipt["operationId"]),
        receipt_path.relative_to(repository).as_posix(),
    )


def _ledger_h1_root_contract_after(
    work_items: Path,
    expected_sha256: str,
) -> tuple[Path, bytes, bytes | None]:
    contract_path = work_items / ROOT_CONTRACT_FILE
    if _lifecycle_path_has_reparse(contract_path) or not contract_path.is_file():
        _ledger_h1_relocation_fail("root contract with both H1 declarations is required")
    try:
        before = contract_path.read_bytes()
        contract = json.loads(
            before.decode("utf-8"),
            object_pairs_hook=_root_contract_json_object,
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "root contract is unreadable",
        ) from exc
    if _sha256_bytes(before) != expected_sha256:
        _ledger_h1_relocation_fail("root contract compare-and-swap digest changed")
    required = {LEGACY_PROJECTION_MANIFEST_DIR, LEGACY_PROJECTION_RECEIPTS}
    auxiliary = contract.get("auxiliaryRoots") if isinstance(contract, dict) else None
    if (
        not isinstance(auxiliary, dict)
        or not required.issubset(auxiliary)
        or any(auxiliary[name] != {"kind": "flat-json"} for name in required)
    ):
        _ledger_h1_relocation_fail("root contract lacks the two exact H1 declarations")
    after_contract = dict(contract)
    after_auxiliary = dict(auxiliary)
    for name in required:
        after_auxiliary.pop(name)
    if not after_auxiliary:
        after = None
    else:
        after_contract["auxiliaryRoots"] = after_auxiliary
        after = _migration_receipt_bytes(after_contract)
    return contract_path, before, after


def _ledger_h1_relocation_preflight(
    root: Path,
    request: LedgerH1ArtifactSetRelocationRequestV1,
) -> _LedgerH1ArtifactSetRelocationPlanV1:
    expected_artifact_set_sha256, expected_root_contract_sha256 = (
        _ledger_h1_relocation_request(request)
    )
    work_items = _work_items_root(
        root,
        root_failure_id="WI-LEDGER-COMPAT-SET-TOPOLOGY",
    )
    repository = work_items.parent
    archive_owner = _ledger_h1_archive_owner(
        repository,
        work_items,
        request.archive_owner,
    )
    artifact_base = _require_lifecycle_mutation_path(
        repository,
        archive_owner / LEDGER_H1_ARTIFACT_BASE,
        failure_id="WI-LEDGER-COMPAT-SET-TOPOLOGY",
    )
    receipt_path = artifact_base / "relocation-receipt.json"
    if artifact_base.exists():
        _ledger_h1_relocation_fail("H1 artifact-set archive target already exists")
    members: list[dict[str, object]] = []
    for name, kind in LEDGER_H1_RELOCATION_MEMBERS:
        source = work_items / name
        target = artifact_base / name
        byte_length, sha256 = _ledger_h1_member_snapshot(source, kind=kind)
        members.append(
            {
                "logicalPath": f"work-items/{name}",
                "sourcePath": source.relative_to(repository).as_posix(),
                "targetPath": target.relative_to(repository).as_posix(),
                "kind": kind,
                "byteLength": byte_length,
                "sha256": sha256,
            }
        )
    members.sort(key=lambda row: str(row["logicalPath"]).encode("utf-8"))
    artifact_set_sha256 = _ledger_h1_artifact_set_digest(members)
    if artifact_set_sha256 != expected_artifact_set_sha256:
        _ledger_h1_relocation_fail("H1 artifact-set compare-and-swap digest changed")
    root_contract_path, root_contract_before, root_contract_after = (
        _ledger_h1_root_contract_after(
            work_items,
            expected_root_contract_sha256,
        )
    )
    receipt_payload = {
        "schemaVersion": 2,
        "status": "settled",
        "operationId": request.operation_id,
        "archiveOwner": request.archive_owner,
        "artifactBase": artifact_base.relative_to(repository).as_posix(),
        "artifactSetSha256": artifact_set_sha256,
        "rootContractBeforeSha256": _sha256_bytes(root_contract_before),
        "rootContractAfterSha256": (
            _sha256_bytes(root_contract_after)
            if root_contract_after is not None
            else None
        ),
        "recordedAt": request.recorded_at,
    }
    receipt_bytes = _migration_receipt_bytes(receipt_payload)
    return _LedgerH1ArtifactSetRelocationPlanV1(
        repository,
        work_items,
        archive_owner,
        artifact_base,
        receipt_path,
        artifact_set_sha256,
        root_contract_path,
        root_contract_before,
        root_contract_after,
        tuple(members),
        receipt_bytes,
    )


def _ledger_h1_relocation_result(
    plan: _LedgerH1ArtifactSetRelocationPlanV1,
    request: LedgerH1ArtifactSetRelocationRequestV1,
    *,
    applied: bool,
    replay: bool,
) -> dict[str, object]:
    return {
        "schemaVersion": 1,
        "status": "settled" if applied else "ready",
        "operationId": request.operation_id,
        "archiveOwner": request.archive_owner,
        "artifactBase": plan.artifact_base.relative_to(plan.repository).as_posix(),
        "artifactSetSha256": plan.artifact_set_sha256,
        "applied": applied,
        "replay": replay,
        **({"event": LEDGER_H1_RELOCATION_EVENT} if applied else {}),
    }


def _ledger_h1_relocation_intent(
    plan: _LedgerH1ArtifactSetRelocationPlanV1,
    request: LedgerH1ArtifactSetRelocationRequestV1,
) -> dict[str, object]:
    return {
        "schemaVersion": 1,
        "owner": LEDGER_H1_RELOCATION_OWNER,
        "kind": LEDGER_H1_RELOCATION_KIND,
        "status": "intent",
        "operationId": request.operation_id,
        "recordedAt": request.recorded_at,
        "archiveOwner": request.archive_owner,
        "artifactBase": plan.artifact_base.relative_to(plan.repository).as_posix(),
        "receiptPath": plan.receipt_path.relative_to(plan.repository).as_posix(),
        "expectedArtifactSetSha256": plan.artifact_set_sha256,
        "expectedRootContractSha256": _sha256_bytes(plan.root_contract_before),
        "targetBaseBefore": None,
        "members": [dict(member) for member in plan.members],
        "rootContractBefore": _b64(plan.root_contract_before),
        "rootContractAfter": _b64(plan.root_contract_after),
        "receiptAfter": _b64(plan.receipt_bytes),
    }


def _validate_ledger_h1_relocation_intent_shape(
    root: Path,
    intent: Mapping[str, object],
    intent_path: Path,
) -> None:
    operation_id = intent.get("operationId")
    recorded_at = intent.get("recordedAt")
    archive_owner = intent.get("archiveOwner")
    artifact_base = intent.get("artifactBase")
    receipt_path = intent.get("receiptPath")
    members = intent.get("members")
    if (
        not isinstance(operation_id, str)
        or _PROJECTION_OPERATION_RE.fullmatch(operation_id) is None
        or not isinstance(recorded_at, str)
        or not isinstance(archive_owner, str)
        or not isinstance(artifact_base, str)
        or artifact_base != f"{archive_owner}/{LEDGER_H1_ARTIFACT_BASE}"
        or not isinstance(receipt_path, str)
        or receipt_path != f"{artifact_base}/relocation-receipt.json"
        or intent.get("targetBaseBefore") is not None
        or not isinstance(intent.get("expectedArtifactSetSha256"), str)
        or SHA256_RE.fullmatch(str(intent["expectedArtifactSetSha256"])) is None
        or not isinstance(intent.get("expectedRootContractSha256"), str)
        or SHA256_RE.fullmatch(str(intent["expectedRootContractSha256"])) is None
        or not isinstance(members, list)
        or len(members) != len(LEDGER_H1_RELOCATION_MEMBERS)
    ):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "H1 relocation intent binding differs",
        )
    try:
        _load_agent_run_ledger()._strict_migration_inputs(operation_id, recorded_at)
    except Exception as exc:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "H1 relocation intent operation or time differs",
        ) from exc
    expected_intent_path = _transition_intent_path(root, operation_id)
    if expected_intent_path.absolute() != intent_path.absolute():
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "H1 relocation intent path differs from its operation id",
        )
    for relative in (archive_owner, artifact_base, receipt_path):
        _intent_path(root, relative)
    expected_members = {
        f"work-items/{name}": (name, kind)
        for name, kind in LEDGER_H1_RELOCATION_MEMBERS
    }
    expected_logical_paths = sorted(
        expected_members,
        key=lambda value: value.encode("utf-8"),
    )
    logical_paths: list[str] = []
    for member in members:
        if (
            not isinstance(member, dict)
            or set(member) != LEDGER_H1_RELOCATION_MEMBER_FIELDS
            or not isinstance(member.get("logicalPath"), str)
            or member["logicalPath"] not in expected_members
            or not isinstance(member.get("sourcePath"), str)
            or member["sourcePath"] != member["logicalPath"]
            or not isinstance(member.get("targetPath"), str)
            or not isinstance(member.get("kind"), str)
            or type(member.get("byteLength")) is not int
            or int(member["byteLength"]) < 0
            or not isinstance(member.get("sha256"), str)
            or SHA256_RE.fullmatch(str(member["sha256"])) is None
        ):
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
                "H1 relocation intent member differs",
            )
        name, kind = expected_members[str(member["logicalPath"])]
        if (
            member["kind"] != kind
            or member["targetPath"] != f"{artifact_base}/{name}"
        ):
            raise LifecycleError(
                "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
                "H1 relocation intent member binding differs",
            )
        logical_paths.append(str(member["logicalPath"]))
        _intent_path(root, str(member["sourcePath"]))
        _intent_path(root, str(member["targetPath"]))
    if logical_paths != expected_logical_paths:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "H1 relocation intent members differ from the complete sorted set",
        )
    root_before = _unb64(intent.get("rootContractBefore"))
    root_after = _unb64(intent.get("rootContractAfter"))
    receipt_after = _unb64(intent.get("receiptAfter"))
    if (
        root_before is None
        or receipt_after is None
        or _sha256_bytes(root_before) != intent["expectedRootContractSha256"]
    ):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "H1 relocation intent byte images differ",
        )
    try:
        receipt = json.loads(receipt_after.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "H1 relocation intent receipt after-image is invalid",
        ) from exc
    if (
        not isinstance(receipt, dict)
        or set(receipt) != LEDGER_H1_RELOCATION_RECEIPT_FIELDS
        or receipt.get("schemaVersion") != 2
        or receipt.get("operationId") != operation_id
        or receipt.get("recordedAt") != recorded_at
        or receipt.get("archiveOwner") != archive_owner
        or receipt.get("artifactBase") != artifact_base
        or receipt.get("artifactSetSha256")
        != intent["expectedArtifactSetSha256"]
        or receipt.get("rootContractBeforeSha256")
        != intent["expectedRootContractSha256"]
        or receipt.get("rootContractAfterSha256")
        != (_sha256_bytes(root_after) if root_after is not None else None)
    ):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "H1 relocation intent receipt binding differs",
        )


def _ledger_h1_exact_member_at(
    path: Path,
    member: Mapping[str, object],
    *,
    failure_id: str,
) -> None:
    try:
        byte_length, sha256 = _ledger_h1_member_snapshot(
            path,
            kind=str(member["kind"]),
        )
    except LifecycleError as exc:
        raise LifecycleError(failure_id, "H1 relocation member cannot be proven") from exc
    if byte_length != member["byteLength"] or sha256 != member["sha256"]:
        raise LifecycleError(failure_id, "H1 relocation member bytes differ")


def _ledger_h1_intent_distribution(
    root: Path,
    intent: Mapping[str, object],
) -> tuple[tuple[Mapping[str, object], Path, Path, str], ...]:
    distribution: list[tuple[Mapping[str, object], Path, Path, str]] = []
    for member in intent["members"]:
        source = _intent_path(root, str(member["sourcePath"]))
        target = _intent_path(root, str(member["targetPath"]))
        source_exists = _ledger_h1_lexically_exists(source)
        target_exists = _ledger_h1_lexically_exists(target)
        if source_exists and target_exists:
            _ledger_h1_relocation_fail("H1 relocation member exists at root and target")
        if not source_exists and not target_exists:
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "H1 relocation member exists at neither owned location",
            )
        selected = source if source_exists else target
        _ledger_h1_exact_member_at(
            selected,
            member,
            failure_id="WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
        )
        distribution.append((member, source, target, "source" if source_exists else "target"))
    return tuple(distribution)


def _ledger_h1_current_contract(path: Path) -> bytes | None:
    if not _ledger_h1_lexically_exists(path):
        return None
    if _lifecycle_path_has_reparse(path) or not path.is_file():
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 root contract identity differs",
        )
    try:
        return path.read_bytes()
    except OSError as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 root contract is unreadable",
        ) from exc


def _ledger_h1_apply_contract_after(
    root: Path,
    contract_path: Path,
    before: bytes,
    after: bytes | None,
) -> None:
    current = _ledger_h1_current_contract(contract_path)
    if current == after:
        return
    if current != before:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 root contract is neither exact before nor exact after",
        )
    if after is None:
        contract_path.unlink()
    else:
        _atomic_write(contract_path, after)
    _transition_fsync_directory(contract_path.parent)
    if _ledger_h1_current_contract(contract_path) != after:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 root contract after-image readback differs",
        )


def _ledger_h1_restore_before_receipt(
    root: Path,
    intent_path: Path,
    intent: Mapping[str, object],
) -> None:
    receipt_path = _intent_path(root, str(intent["receiptPath"]))
    if _ledger_h1_lexically_exists(receipt_path):
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 rollback is forbidden after receipt commit",
        )
    distribution = _ledger_h1_intent_distribution(root, intent)
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    artifact_base = _intent_path(root, str(intent["artifactBase"]))
    for member, source, target, side in reversed(distribution):
        if side == "target":
            source.parent.mkdir(parents=True, exist_ok=True)
            os.replace(target, source)
            _ledger_h1_exact_member_at(
                source,
                member,
                failure_id="WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            )
    contract_path = repository / "work-items" / ROOT_CONTRACT_FILE
    root_before = _unb64(intent.get("rootContractBefore"))
    root_after = _unb64(intent.get("rootContractAfter"))
    if root_before is None:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 rollback lacks a root contract before-image",
        )
    current = _ledger_h1_current_contract(contract_path)
    if current != root_before:
        if current != root_after:
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "H1 rollback root contract cannot be proven",
            )
        _atomic_write(contract_path, root_before)
    try:
        artifact_base.rmdir()
    except FileNotFoundError:
        pass
    except OSError as exc:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 rollback target base is not empty",
        ) from exc
    intent_path.unlink(missing_ok=True)
    _transition_fsync_directory(intent_path.parent)


def _ledger_h1_settle_receipt(
    root: Path,
    intent: Mapping[str, object],
) -> bytes:
    receipt_path = _intent_path(root, str(intent["receiptPath"]))
    wanted = _unb64(intent.get("receiptAfter"))
    if wanted is None:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 relocation receipt after-image is absent",
        )
    if _ledger_h1_lexically_exists(receipt_path):
        try:
            current = receipt_path.read_bytes()
        except OSError as exc:
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "H1 relocation receipt is unreadable",
            ) from exc
        if current != wanted:
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "H1 relocation receipt differs from exact after-image",
            )
    else:
        _atomic_write(receipt_path, wanted)
        _transition_fsync_directory(receipt_path.parent)
    if receipt_path.read_bytes() != wanted:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 relocation receipt readback differs",
        )
    return wanted


def _recover_ledger_h1_artifact_set_relocation(
    root: Path,
    intent_path: Path,
    intent: Mapping[str, object],
) -> dict[str, object] | None:
    _validate_ledger_h1_relocation_intent_shape(root, intent, intent_path)
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    artifact_base = _intent_path(root, str(intent["artifactBase"]))
    archive_bases = _ledger_h1_archive_bases(
        repository,
        repository / "work-items",
    )
    if any(base != artifact_base for base in archive_bases):
        _ledger_h1_relocation_fail("a second archived H1 artifact set blocks recovery")
    distribution = _ledger_h1_intent_distribution(root, intent)
    source_count = sum(side == "source" for _member, _source, _target, side in distribution)
    receipt_path = _intent_path(root, str(intent["receiptPath"]))
    root_before = _unb64(intent.get("rootContractBefore"))
    root_after = _unb64(intent.get("rootContractAfter"))
    if root_before is None:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 recovery lacks root contract before-image",
        )
    contract_path = repository / "work-items" / ROOT_CONTRACT_FILE
    if source_count == len(distribution):
        if _ledger_h1_current_contract(contract_path) != root_before:
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "root-only H1 recovery lacks exact contract before-image",
            )
        if _ledger_h1_lexically_exists(receipt_path):
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "root-only H1 recovery unexpectedly has a receipt",
            )
        if _ledger_h1_lexically_exists(artifact_base):
            try:
                artifact_base.rmdir()
            except OSError as exc:
                raise LifecycleError(
                    "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                    "root-only H1 recovery target is not empty",
                ) from exc
        intent_path.unlink()
        _transition_fsync_directory(intent_path.parent)
        return None
    if _ledger_h1_lexically_exists(receipt_path) and source_count:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "split H1 recovery unexpectedly has a receipt",
        )
    artifact_base.mkdir(exist_ok=True)
    for member, source, target, side in distribution:
        if side == "source":
            os.replace(source, target)
            _ledger_h1_exact_member_at(
                target,
                member,
                failure_id="WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            )
    _transition_fsync_directory(repository / "work-items")
    _transition_fsync_directory(artifact_base)
    final_distribution = _ledger_h1_intent_distribution(root, intent)
    if any(side != "target" for _member, _source, _target, side in final_distribution):
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 recovery did not converge to the target set",
        )
    _ledger_h1_apply_contract_after(
        root,
        contract_path,
        root_before,
        root_after,
    )
    _ledger_h1_settle_receipt(root, intent)
    location = resolve_ledger_h1_artifact_set_location(root)
    if (
        location is None
        or location.phase != "settled-archive"
        or location.artifact_set_sha256 != intent["expectedArtifactSetSha256"]
        or location.operation_id != intent["operationId"]
    ):
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 recovery settlement cannot be proven",
        )
    intent_path.unlink(missing_ok=True)
    _transition_fsync_directory(intent_path.parent)
    return {
        "schemaVersion": 1,
        "status": "settled",
        "operationId": intent["operationId"],
        "archiveOwner": intent["archiveOwner"],
        "artifactBase": intent["artifactBase"],
        "artifactSetSha256": intent["expectedArtifactSetSha256"],
        "applied": True,
        "replay": False,
        "event": LEDGER_H1_RELOCATION_EVENT,
    }


def _ledger_h1_replay_result(
    root: Path,
    request: LedgerH1ArtifactSetRelocationRequestV1,
    *,
    applied: bool,
) -> dict[str, object] | None:
    expected_artifact_set_sha256, expected_root_contract_sha256 = (
        _ledger_h1_relocation_request(request)
    )
    location = resolve_ledger_h1_artifact_set_location(root)
    if location is None or location.phase == "root":
        return None
    repository = Path(root).resolve()
    if repository.name == "work-items":
        repository = repository.parent
    receipt_path = repository.joinpath(*PurePosixPath(location.receipt_path or "").parts)
    receipt, _raw = _ledger_h1_receipt_object(receipt_path)
    if (
        receipt.get("operationId") != request.operation_id
        or receipt.get("recordedAt") != request.recorded_at
        or receipt.get("archiveOwner") != request.archive_owner
        or location.artifact_set_sha256 != expected_artifact_set_sha256
        or receipt.get("rootContractBeforeSha256")
        != expected_root_contract_sha256
    ):
        _ledger_h1_relocation_fail("settled H1 replay inputs differ")
    return {
        "schemaVersion": 1,
        "status": "settled",
        "operationId": request.operation_id,
        "archiveOwner": request.archive_owner,
        "artifactBase": location.physical_base,
        "artifactSetSha256": location.artifact_set_sha256,
        "applied": applied,
        "replay": True,
        **({"event": LEDGER_H1_RELOCATION_EVENT} if applied else {}),
    }


def _relocate_ledger_h1_artifact_set_locked(
    root: Path,
    request: LedgerH1ArtifactSetRelocationRequestV1,
    *,
    inject_failure: str | None = None,
) -> dict[str, object]:
    if inject_failure not in {None, *LEDGER_H1_RELOCATION_FAILURE_BOUNDARIES}:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "unknown H1 relocation failure boundary",
        )
    _recover_all_transitions(root)
    replay = _ledger_h1_replay_result(root, request, applied=True)
    if replay is not None:
        return replay
    plan = _ledger_h1_relocation_preflight(root, request)
    intent = _ledger_h1_relocation_intent(plan, request)
    intent_path = _transition_intent_path(root, request.operation_id)
    if _ledger_h1_lexically_exists(intent_path):
        raise LifecycleError(
            "WI-LIFECYCLE-TRANSITION-INTENT-INVALID",
            "H1 relocation intent still exists after recovery",
        )
    intent_path.parent.mkdir(parents=True, exist_ok=True)
    _atomic_write(intent_path, _migration_receipt_bytes(intent))
    _transition_fsync_directory(intent_path.parent)
    receipt_committed = False
    try:
        if inject_failure == "after-intent":
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "injected failure after H1 relocation intent",
            )
        plan.artifact_base.mkdir()
        _transition_fsync_directory(plan.archive_owner)
        for index, member in enumerate(plan.members, start=1):
            source = plan.repository.joinpath(
                *PurePosixPath(str(member["sourcePath"])).parts
            )
            target = plan.repository.joinpath(
                *PurePosixPath(str(member["targetPath"])).parts
            )
            os.replace(source, target)
            _ledger_h1_intent_distribution(root, intent)
            if inject_failure == f"after-member-{index}":
                raise LifecycleError(
                    "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                    f"injected failure after H1 relocation member {index}",
                )
        _transition_fsync_directory(plan.work_items)
        _transition_fsync_directory(plan.artifact_base)
        if any(
            side != "target"
            for _member, _source, _target, side in _ledger_h1_intent_distribution(
                root, intent
            )
        ):
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "H1 relocation target validation is incomplete",
            )
        _ledger_h1_apply_contract_after(
            root,
            plan.root_contract_path,
            plan.root_contract_before,
            plan.root_contract_after,
        )
        if inject_failure == "after-root-contract":
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "injected failure after H1 root contract",
            )
        _ledger_h1_settle_receipt(root, intent)
        receipt_committed = True
        if inject_failure == "after-receipt":
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "injected failure after H1 relocation receipt",
            )
        location = resolve_ledger_h1_artifact_set_location(root)
        if (
            location is None
            or location.phase != "settled-archive"
            or location.artifact_set_sha256 != plan.artifact_set_sha256
        ):
            raise LifecycleError(
                "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
                "H1 relocation settlement cannot be proven",
            )
        intent_path.unlink()
        _transition_fsync_directory(intent_path.parent)
        return _ledger_h1_relocation_result(
            plan,
            request,
            applied=True,
            replay=False,
        )
    except BaseException:
        if not receipt_committed:
            _ledger_h1_restore_before_receipt(root, intent_path, intent)
        raise


_relocate_ledger_h1_artifact_set_transaction = _lifecycle_participant(
    _relocate_ledger_h1_artifact_set_locked
)


def relocate_ledger_h1_artifact_set(
    root: Path,
    request: LedgerH1ArtifactSetRelocationRequestV1,
    *,
    apply: bool = False,
    inject_failure: str | None = None,
) -> dict[str, object]:
    if type(apply) is not bool:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-SET-TOPOLOGY",
            "H1 relocation apply must be an exact boolean",
        )
    if apply:
        return _relocate_ledger_h1_artifact_set_transaction(
            root,
            request,
            inject_failure=inject_failure,
        )
    if inject_failure is not None:
        raise LifecycleError(
            "WI-LEDGER-COMPAT-COMMIT-INDETERMINATE",
            "H1 artifact-set preflight forbids failure injection",
        )
    replay = _ledger_h1_replay_result(root, request, applied=False)
    if replay is not None:
        return replay
    plan = _ledger_h1_relocation_preflight(root, request)
    return _ledger_h1_relocation_result(
        plan,
        request,
        applied=False,
        replay=False,
    )


def _write_historical_artifact_disposition_locked(
    root: Path, disposition_bytes: bytes, *, allow_legacy: bool = False
) -> dict:
    validator = _load_agent_run_ledger().load_validator()
    dispositions = _historical_disposition_path(root, validator)
    try:
        disposition_cap, disposition_count_cap = validator.historical_artifact_disposition_resource_caps()
    except (AttributeError, TypeError, ValueError) as exc:
        _projection_fail(
            "WI-LEDGER-MIGRATION-MANIFEST-INVALID",
            "historical disposition resource policy is unavailable or invalid",
        )
        raise AssertionError from exc
    if (
        type(disposition_cap) is not int
        or type(disposition_count_cap) is not int
        or disposition_cap < 1
        or disposition_count_cap < 1
    ):
        _projection_fail(
            "WI-LEDGER-MIGRATION-MANIFEST-INVALID",
            "historical disposition resource policy is unavailable or invalid",
        )
    if len(disposition_bytes) > disposition_cap:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "historical disposition exceeds resource cap")
    disposition = _projection_object(disposition_bytes, "historical disposition")
    if not allow_legacy and disposition.get("schemaVersion") != 2:
        _projection_fail(
            "WI-LEDGER-MIGRATION-MANIFEST-INVALID",
            "neutral historical disposition requires schemaVersion 2",
        )
    work_item = disposition.get("workItem")
    archive_identity = disposition.get("archiveIdentity")
    if not isinstance(work_item, str) or not isinstance(archive_identity, str):
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "historical disposition lacks exact identity")
    repository = Path(root).resolve()
    try:
        validator.confine_legacy_projection_identifier(
            archive_identity, failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY"
        )
        archive = validator.confine_legacy_projection_path(
            repository, work_item, prefix=("work-items", "archive"), leaf_kind="directory",
            failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY",
        )
    except ValueError as exc:
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", f"historical artifact disposition target is unsafe: {exc}")
        raise AssertionError from exc
    if disposition.get("schemaVersion") == 2:
        ledger = archive / "agent-runs.jsonl"
        target_errors: list[str] = []
        classified = validator.classify_legacy_projection_target(
            archive, ledger, target_errors, require_ledger=True
        )
        if classified is None or target_errors:
            _projection_fail(
                "WI-LEDGER-MIGRATION-TARGET-IDENTITY",
                "; ".join(target_errors) or "archive ledger target is unsafe",
            )
        try:
            ledger_bytes = ledger.read_bytes()
        except OSError as exc:
            raise LifecycleError("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "archive ledger is unavailable") from exc
        raw_metadata: list[dict[str, object]] = []
        ledger_errors: list[str] = []
        events = validator.load_jsonl(ledger, ledger_errors, raw_metadata, ledger_bytes)
        exception, errors = validator.validate_historical_artifact_disposition_v2(
            disposition, archive, ledger_bytes, events, raw_metadata
        )
        if ledger_errors or errors or exception is None:
            _projection_fail(
                "WI-LEDGER-MIGRATION-MANIFEST-INVALID",
                "; ".join([*ledger_errors, *errors]) or "historical disposition does not authorize one missing artifact",
            )
        try:
            disposition_id = validator.confine_legacy_projection_identifier(
                disposition.get("dispositionId"), failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY"
            )
        except ValueError as exc:
            _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", f"disposition output identifier is unsafe: {exc}")
            raise AssertionError from exc
        target = _reserve_historical_disposition_output(
            dispositions, dispositions / f"{disposition_id}.json", disposition_count_cap
        )
        replay = _projection_create_or_exact(target, disposition_bytes, "WI-LEDGER-MIGRATION-MANIFEST-INVALID")
        return {"schemaVersion": 2, "dispositionId": disposition_id, "replay": replay}
    errors = validator.validate_manifest_bound_irrecoverable_disposition(disposition, archive_identity, archive)
    if errors:
        _projection_fail("WI-LEDGER-MIGRATION-MANIFEST-INVALID", "; ".join(errors))
    try:
        receipt = validator.confine_legacy_projection_path(
            repository, f"{work_item}/lifecycle-transition-receipt.json",
            prefix=("work-items", "archive"), leaf_kind="file",
            failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY",
        )
    except ValueError as exc:
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", f"archive transition receipt is unsafe: {exc}")
        raise AssertionError from exc
    try:
        observed = json.loads(receipt.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise LifecycleError("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "archive identity receipt is unavailable") from exc
    if not isinstance(observed, dict) or observed.get("operationId") != archive_identity:
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", "archive identity differs")
    try:
        archive_identity = validator.confine_legacy_projection_identifier(
            archive_identity, failure_id="WI-LEDGER-MIGRATION-TARGET-IDENTITY"
        )
    except ValueError as exc:
        _projection_fail("WI-LEDGER-MIGRATION-TARGET-IDENTITY", f"disposition output identifier is unsafe: {exc}")
        raise AssertionError from exc
    target = _reserve_historical_disposition_output(
        dispositions, dispositions / f"{archive_identity}.json", disposition_count_cap
    )
    replay = _projection_create_or_exact(target, disposition_bytes, "WI-LEDGER-MIGRATION-MANIFEST-INVALID")
    return {"schemaVersion": 1, "archiveIdentity": archive_identity, "replay": replay}


_write_historical_artifact_disposition_transaction = _lifecycle_participant(
    _write_historical_artifact_disposition_locked
)


def write_historical_artifact_disposition(root: Path, disposition_bytes: bytes) -> dict:
    """Write/replay one neutral V2 historical disposition."""
    return _write_historical_artifact_disposition_transaction(root, disposition_bytes)


def _write_legacy_ledger_irrecoverable_disposition_locked(root: Path, disposition_bytes: bytes) -> dict:
    """Compatibility adapter for the legacy V1/V2 command and Python surface."""
    return _write_historical_artifact_disposition_locked(
        root, disposition_bytes, allow_legacy=True
    )


_write_legacy_ledger_irrecoverable_disposition_transaction = _lifecycle_participant(
    _write_legacy_ledger_irrecoverable_disposition_locked
)


def write_legacy_ledger_irrecoverable_disposition(root: Path, disposition_bytes: bytes) -> dict:
    return _write_legacy_ledger_irrecoverable_disposition_transaction(root, disposition_bytes)


def _successor_import_tree(root: Path) -> list[tuple[str, bytes]]:
    """Capture every ordinary leaf without following a source or archive alias."""

    failure = "WI-SUCCESSOR-IMPORT-UNSAFE-INPUT"
    _lifecycle_reject_unreduced_reparse(root, failure_id=failure, message="unsafe tree root")
    try:
        if not stat.S_ISDIR(root.lstat().st_mode):
            raise OSError("tree root is not a directory")
    except OSError as exc:
        raise LifecycleError(failure, "tree root is unavailable") from exc
    pending = [root]
    files: list[tuple[str, bytes]] = []
    while pending:
        directory = pending.pop()
        try:
            with os.scandir(directory) as iterator:
                children = sorted(iterator, key=lambda entry: entry.name)
        except OSError as exc:
            raise LifecycleError(failure, "tree cannot be enumerated") from exc
        for entry in children:
            path = Path(entry.path)
            try:
                info = entry.stat(follow_symlinks=False)
                unsafe = entry.is_symlink() or bool(
                    getattr(info, "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
                )
            except OSError as exc:
                raise LifecycleError(failure, "tree entry cannot be inspected") from exc
            if unsafe:
                raise LifecycleError(failure, "tree contains a link or reparse entry")
            if stat.S_ISDIR(info.st_mode):
                pending.append(path)
            elif stat.S_ISREG(info.st_mode):
                snapshot = _capture_file_snapshot(
                    path, failure_id=failure,
                    maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
                    require_single_link=True,
                )
                files.append((path.relative_to(root).as_posix(), snapshot.data))
            else:
                raise LifecycleError(failure, "tree contains a nonordinary entry")
    return sorted(files)


def _successor_import_tree_digest(files: Iterable[tuple[str, bytes]]) -> str:
    digest = hashlib.sha256()
    for path, data in files:
        name = path.encode("utf-8")
        digest.update(len(name).to_bytes(8, "big"))
        digest.update(name)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)
    return digest.hexdigest()


def _successor_import_index(
    work_items: Path, old: str, new: str, disposition: dict,
) -> tuple[dict, bytes]:
    failure = "WI-SUCCESSOR-LINK-UNMAPPED"
    path = work_items / "index.md"
    before = _capture_file_snapshot(
        path, failure_id=failure, maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
        require_single_link=True,
    ).data
    try:
        text = before.decode("utf-8")
    except UnicodeError as exc:
        raise LifecycleError(failure, "compatibility index is not UTF-8") from exc
    row_before = disposition.get("indexRowBefore")
    row_after = disposition.get("indexRowAfter")
    if not all(isinstance(row, str) and row.endswith("\n") for row in (row_before, row_after)):
        raise LifecycleError(failure, "one complete index row disposition is required")
    rows = text.splitlines(keepends=True)
    old_status = work_items / "active" / old / "status.md"
    new_status = work_items / "active" / new / "status.md"
    old_active = work_items / "active" / old
    old_rows = [
        row for row in rows
        if any(_markdown_href_resolves(path.parent, link.href, old_status)
               for link in _markdown_local_links(row))
    ]
    if len(old_rows) != 1 or old_rows[0] != row_before or rows.count(row_before) != 1:
        raise LifecycleError(failure, "index old-active row is absent or ambiguous")
    old_root = old_active.resolve()
    old_targets = [
        target
        for row in rows for link in _markdown_local_links(row)
        if (parts := _local_markdown_href_parts(link.href)) is not None
        for target in ((path.parent / parts[0]).resolve(),)
        if target == old_root or old_root in target.parents
    ]
    if old_targets != [old_status.resolve()]:
        raise LifecycleError(failure, "index contains another old-active link")
    after_links = list(_markdown_local_links(row_after))
    visible_row = row_after
    for link in reversed(after_links):
        visible_row = visible_row[:link.href_start] + visible_row[link.href_end:]
    def names_visible_slug(slug: str) -> bool:
        return re.search(
            rf"(?<![A-Za-z0-9_.-]){re.escape(slug)}(?![A-Za-z0-9_.-])",
            visible_row,
        ) is not None

    if not names_visible_slug(new) or names_visible_slug(old) or sum(
        _markdown_href_resolves(path.parent, link.href, new_status) for link in after_links
    ) != 1 or any(
        (path.parent / parts[0]).resolve() == old_active.resolve()
        or old_active.resolve() in (path.parent / parts[0]).resolve().parents
        for link in after_links
        if (parts := _local_markdown_href_parts(link.href)) is not None
    ):
        raise LifecycleError(failure, "replacement index row does not name the successor status")
    after = text.replace(row_before, row_after, 1).encode("utf-8")
    return {
        "path": "work-items/index.md",
        "beforeSha256": _sha256_bytes(before),
        "afterSha256": _sha256_bytes(after),
        "afterBase64": _b64(after),
        "targetPath": f"work-items/active/{new}/status.md",
    }, after


def _successor_import_links(
    root: Path, work_items: Path, source: Path, new: str,
    bindings: list[dict], dispositions: dict,
) -> list[dict]:
    failure = "WI-SUCCESSOR-LINK-UNMAPPED"
    reference = f"work-item:{source.name}"
    try:
        observed = _incoming_link_result(
            root, [source], reference, strict_consumer_reads=True,
        )["references"]
    except LifecycleError as exc:
        raise LifecycleError(failure, "incoming-link scan could not classify consumers") from exc
    supplied = dispositions.get("references")
    if not isinstance(supplied, list) or any(not isinstance(row, dict) for row in supplied):
        raise LifecycleError(failure, "incoming references require an exact disposition list")
    if any(
        not all(isinstance(row.get(field), str) for field in ("consumer", "kind", "value"))
        for row in supplied
    ):
        raise LifecycleError(failure, "incoming references require string identities")
    for row in supplied:
        required = (
            {"consumer", "kind", "value", "target"}
            if row["kind"] == "physical"
            else {"consumer", "kind", "value", "meaning"}
        )
        choice = row.get("target") if row["kind"] == "physical" else row.get("meaning")
        if row["kind"] not in {"physical", "logical"} or set(row) != required or not isinstance(choice, str):
            raise LifecycleError(failure, "incoming reference disposition has invalid shape")
    def key(row: dict) -> tuple:
        return row.get("consumer"), row.get("kind"), row.get("value")
    observed_keys = [key(row) for row in observed]
    supplied_keys = [key(row) for row in supplied]
    if Counter(observed_keys) != Counter(supplied_keys) or len(set(supplied_keys)) != len(supplied_keys):
        raise LifecycleError(failure, "incoming-reference dispositions are incomplete or ambiguous")
    allowed_targets = {row["targetPath"] for row in bindings}
    allowed_targets.add(f"work-items/active/{new}/status.md")
    plans: list[dict] = []
    for consumer_name in sorted({row["consumer"] for row in supplied}):
        relative = PurePosixPath(consumer_name)
        if (not consumer_name or relative.is_absolute() or ".." in relative.parts
                or relative.parts[0] == "archive" or ":" in consumer_name
                or "\\" in consumer_name):
            raise LifecycleError(failure, "incoming consumer is not a mutable work-item file")
        consumer = work_items.joinpath(*relative.parts)
        before = _capture_file_snapshot(
            consumer, failure_id=failure,
            maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
            require_single_link=True,
        ).data
        try:
            text = before.decode("utf-8")
        except UnicodeError as exc:
            raise LifecycleError(failure, "incoming consumer is not UTF-8") from exc
        replacements: list[tuple[int, int, str]] = []
        for row in (item for item in supplied if item["consumer"] == consumer_name):
            if row["kind"] == "logical":
                if row.get("meaning") not in {"historical-predecessor", "current-successor"} or row["value"] != reference:
                    raise LifecycleError(failure, "logical reference has no reviewed meaning")
                if row["meaning"] == "current-successor":
                    if text.count(reference) != 1:
                        raise LifecycleError(failure, "current logical reference is ambiguous")
                continue
            if row["kind"] != "physical" or row.get("target") not in allowed_targets:
                raise LifecycleError(failure, "physical reference has no bound target")
            matches = [link for link in _markdown_local_links(text) if link.href == row["value"]]
            if len(matches) != 1:
                raise LifecycleError(failure, "physical reference occurrence is ambiguous")
            target = work_items.parent.joinpath(*PurePosixPath(row["target"]).parts)
            suffix = _local_markdown_href_parts(row["value"])
            if suffix is None:
                raise LifecycleError(failure, "physical reference is not local")
            new_href = _relative_link(consumer.parent, target) + suffix[1]
            replacements.append((matches[0].href_start, matches[0].href_end, new_href))
        for start, end, new_href in sorted(replacements, reverse=True):
            text = text[:start] + new_href + text[end:]
        if any(
            row["kind"] == "logical" and row["meaning"] == "current-successor"
            for row in supplied if row["consumer"] == consumer_name
        ):
            text = text.replace(reference, f"work-item:{new}", 1)
        after = text.encode("utf-8")
        plans.append({
            "consumer": f"work-items/{consumer_name}",
            "beforeSha256": _sha256_bytes(before),
            "afterSha256": _sha256_bytes(after),
            "afterBase64": _b64(after),
            "references": sorted(
                (row for row in supplied if row["consumer"] == consumer_name),
                key=lambda row: (row["kind"], row["value"]),
            ),
        })
    return plans


def _successor_import_shadow_readme(
    root: Path, work_items: Path, source: Path, new: str, status_data: bytes,
    static_guide: str, links: list[dict], index_after: bytes,
) -> tuple[bytes, list[dict]]:
    planned_inputs: dict[str, bytes] = {}
    with tempfile.TemporaryDirectory(prefix="work-items-successor-readme-") as directory:
        shadow_root = Path(directory)
        shadow_work_items = shadow_root / "work-items"
        try:
            shutil.copytree(work_items, shadow_work_items, symlinks=True)
            shutil.rmtree(shadow_work_items / source.relative_to(work_items))
            shadow_status = shadow_work_items / "active" / new / "status.md"
            shadow_status.parent.mkdir(parents=True)
            shadow_status.write_bytes(status_data)
            (shadow_work_items / "index.md").write_bytes(index_after)
            for link in links:
                relative = PurePosixPath(link["consumer"]).relative_to("work-items")
                after = base64.b64decode(link["afterBase64"], validate=True)
                shadow_work_items.joinpath(*relative.parts).write_bytes(after)
                planned_inputs[relative.as_posix()] = after
            transaction_token = _CURRENT_LIFECYCLE_TRANSACTION.set(None)
            composer_token = _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.set(None)
            try:
                rendered = render_readme_bytes(
                    shadow_root, static_guide_override=static_guide,
                )
                entries = collect_readme_entries(shadow_root)
                sources = sorted({
                    path.relative_to(shadow_work_items).as_posix()
                    for entry in entries for path in entry.source_paths
                })
            finally:
                _CURRENT_LIFECYCLE_OUTCOME_COMPOSER.reset(composer_token)
                _CURRENT_LIFECYCLE_TRANSACTION.reset(transaction_token)
        except (LifecycleError, OSError) as exc:
            raise LifecycleError(
                "WI-SUCCESSOR-READMODEL-INVALID", "unique-location shadow cannot render"
            ) from exc
    snapshot = []
    for relative in sources:
        if relative == f"active/{new}/status.md":
            data = status_data
        elif relative in planned_inputs:
            data = planned_inputs[relative]
        else:
            data = _capture_file_snapshot(
                work_items.joinpath(*PurePosixPath(relative).parts),
                failure_id="WI-SUCCESSOR-READMODEL-INVALID",
                maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
                require_single_link=True,
            ).data
        snapshot.append({"path": f"work-items/{relative}", "sha256": _sha256_bytes(data)})
    return rendered, snapshot


def preflight_import_active_successor(
    root: Path, predecessor_slug: str, successor_slug: str, status_data: bytes,
    dispositions: dict, operation_id: str,
) -> dict:
    """Bind one exceptional dual-location import; never write to the candidate."""

    _validate_slug(predecessor_slug)
    _validate_slug(successor_slug)
    if predecessor_slug.casefold() == successor_slug.casefold() or not re.fullmatch(
        r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", operation_id or ""
    ):
        raise LifecycleError("WI-SUCCESSOR-IDENTITY-CONFLICT", "distinct identity and bounded operation ID required")
    if not isinstance(dispositions, dict) or set(dispositions) != {
        "indexRowBefore", "indexRowAfter", "references",
    }:
        raise LifecycleError("WI-SUCCESSOR-LINK-UNMAPPED", "link dispositions have invalid shape")
    _validate_active_status_bytes(status_data)
    occurrences = _authoritative_field_occurrences(status_data.decode("utf-8"))
    fields = _parse_fields(status_data.decode("utf-8"))
    if (fields.get("template") != "staged" or fields.get("status") != "active"
            or fields.get("reopens") != predecessor_slug
            or sum(name == "reopens" for _, name, _, _ in occurrences) != 1):
        raise LifecycleError("WI-CATEGORY-STATUS-INVALID", "successor status must be staged, active and reopen the predecessor")
    work_items = _work_items_root(root)
    predecessor = CATEGORIES["work-item"]
    locations = _category_locations(root, predecessor, predecessor_slug)
    active = work_items / "active" / predecessor_slug
    archives = [path for path in locations if path.parent.parent == work_items / "archive"]
    def occupied(path: Path) -> bool:
        try:
            path.lstat()
            return True
        except FileNotFoundError:
            return False
        except OSError as exc:
            raise LifecycleError("WI-SUCCESSOR-IDENTITY-CONFLICT", "identity location cannot be inspected") from exc

    archive_root = work_items / "archive"
    months = [path for path in archive_root.iterdir() if path.is_dir()] if archive_root.is_dir() else []
    def occupied_locations(slug: str) -> set[Path]:
        candidates = [work_items / "backlog" / f"{slug}.md", work_items / "active" / slug]
        candidates.extend(month / slug for month in months)
        return {path for path in candidates if occupied(path)}

    if (len(locations) != 2 or active not in locations or len(archives) != 1
            or occupied_locations(predecessor_slug) != {active, archives[0]}
            or occupied_locations(successor_slug)):
        raise LifecycleError("WI-SUCCESSOR-IDENTITY-CONFLICT", "predecessor dual pair or empty successor identity is absent")
    archive = archives[0]
    source_files = _successor_import_tree(active)
    archive_files = _successor_import_tree(archive)
    source_map = dict(source_files)
    archive_map = dict(archive_files)
    if (not source_files or "status.md" not in source_map
            or "agent-runs.jsonl" not in source_map
            or "agent-runs.jsonl" not in archive_map
            or "bug-dispositions-receipt.json" not in archive_map):
        raise LifecycleError("WI-SUCCESSOR-IMPORT-UNSAFE-INPUT", "source or archive lacks required leaves")
    _status_entry(root, active)
    ledger = source_map["agent-runs.jsonl"]
    archived_ledger = archive_map["agent-runs.jsonl"]
    if (not ledger or not ledger.endswith(b"\n") or not archived_ledger.startswith(ledger)):
        raise LifecycleError("WI-SUCCESSOR-LEDGER-DIVERGENCE", "source ledger is not an exact archived prefix")
    errors, _events, _runtime = _validator_module().validate_archived_ledger_obligations(archive)
    if errors:
        raise LifecycleError("WI-SUCCESSOR-LEDGER-DIVERGENCE", "; ".join(errors))
    bindings = []
    for relative, data in source_files:
        if relative == "agent-runs.jsonl":
            kind = "archive-ledger-prefix"
            target = archive / relative
        elif relative != "status.md" and relative in archive_map and archive_map[relative] == data:
            kind = "archive-equal"
            target = archive / relative
        else:
            kind = "successor-copy"
            target = work_items / "active" / successor_slug / "imported-source" / relative
        bindings.append({
            "sourceRelativePath": relative,
            "sourceSha256": _sha256_bytes(data),
            "kind": kind,
            "targetPath": f"work-items/{target.relative_to(work_items).as_posix()}",
        })
    index, index_after = _successor_import_index(
        work_items, predecessor_slug, successor_slug, dispositions,
    )
    links = _successor_import_links(
        root, work_items, active, successor_slug, bindings, dispositions,
    )
    readme_path = work_items / "README.md"
    readme_before = _capture_file_snapshot(
        readme_path, failure_id="WI-README-MARKERS",
        maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP,
        require_single_link=True,
    ).data
    static_guide = _static_guide(readme_path)
    readme_after, canonical_inputs = _successor_import_shadow_readme(
        root, work_items, active, successor_slug, status_data, static_guide,
        links, index_after,
    )
    if (readme_after.count(f"active/{successor_slug}/status.md".encode()) < 1
            or readme_after.count(f"archive/{archive.parent.name}/{predecessor_slug}/closure.md".encode()) != 1):
        raise LifecycleError("WI-SUCCESSOR-READMODEL-INVALID", "shadow does not contain one successor and predecessor archive")
    readme = {
        "path": "work-items/README.md",
        "beforeSha256": _sha256_bytes(readme_before),
        "afterSha256": _sha256_bytes(readme_after),
        "afterBase64": _b64(readme_after),
    }
    wire = {
        "schemaVersion": 1,
        "owner": "mutate-work-item:import-active-successor-preflight-v1",
        "operationId": operation_id,
        "predecessor": predecessor_slug,
        "successor": successor_slug,
        "sourceTreeSha256": _successor_import_tree_digest(source_files),
        "archiveTreeSha256": _successor_import_tree_digest(archive_files),
        "archiveReceiptSha256": _sha256_bytes(archive_map["bug-dispositions-receipt.json"]),
        "archiveFiles": [
            {"path": relative, "sha256": _sha256_bytes(data)}
            for relative, data in archive_files
        ],
        "fileBindings": bindings,
        "ledgerArchivePrefix": {
            "byteCount": len(ledger), "lineCount": len(ledger.splitlines()),
            "prefixSha256": _sha256_bytes(ledger),
            "archiveLedgerSha256": _sha256_bytes(archived_ledger),
        },
        "statusSha256": _sha256_bytes(status_data),
        "compatibilityIndex": index,
        "links": links,
        "readme": readme,
        "canonicalInputs": canonical_inputs,
    }
    canonical = (json.dumps(wire, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    return {
        **wire, "digest": _sha256_bytes(canonical), "canonicalBytes": canonical,
        "compatibilityIndex": {**index, "afterBytes": index_after},
        "readme": {**readme, "afterBytes": readme_after},
    }


def _successor_import_plan_bytes(plan: dict) -> bytes:
    return (json.dumps(plan, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def _successor_import_stage_paths(operation_id: str) -> tuple[str, str]:
    base = f".scratch/work-items-lifecycle-successor-imports/{operation_id}"
    return f"{base}/source", f"{base}/successor"


def _validate_successor_import_intent(
    root: Path, path: Path, intent: dict, raw: bytes,
) -> None:
    failure = "WI-SUCCESSOR-IMPORT-RECOVERY"
    operation = intent.get("operationId")
    plan = intent.get("plan")
    if (
        intent.get("status") != "intent"
        or not isinstance(operation, str)
        or not isinstance(plan, dict)
        or raw != _migration_receipt_bytes(intent)
        or path.absolute() != _transition_intent_path(root, operation).absolute()
    ):
        raise LifecycleError(failure, "successor import intent shape or identity differs")
    if (
        plan.get("schemaVersion") != 1
        or set(plan) != SUCCESSOR_IMPORT_PLAN_FIELDS
        or plan.get("owner") != "mutate-work-item:import-active-successor-preflight-v1"
        or plan.get("operationId") != operation
        or not isinstance(plan.get("predecessor"), str)
        or not isinstance(plan.get("successor"), str)
        or not isinstance(intent.get("preflightDigest"), str)
        or _sha256_bytes(_successor_import_plan_bytes(plan)) != intent["preflightDigest"]
    ):
        raise LifecycleError(failure, f"operation={operation} phase=intent plan digest differs")
    old, new = plan["predecessor"], plan["successor"]
    _validate_slug(old)
    _validate_slug(new)
    hold, stage = _successor_import_stage_paths(operation)
    archive_parts = PurePosixPath(intent.get("archivePath", "")).parts
    if (
        intent.get("sourcePath") != f"work-items/active/{old}"
        or intent.get("successorPath") != f"work-items/active/{new}"
        or len(archive_parts) != 4
        or archive_parts[:2] != ("work-items", "archive")
        or not re.fullmatch(r"\d{4}-\d{2}", archive_parts[2])
        or archive_parts[3] != old
        or intent.get("sourceHoldPath") != hold
        or intent.get("successorStagePath") != stage
        or intent.get("receiptPath") != f"work-items/active/{new}/{SUCCESSOR_IMPORT_RECEIPT}"
    ):
        raise LifecycleError(failure, f"operation={operation} phase=intent paths differ")
    try:
        status_data = base64.b64decode(intent["statusData"], validate=True)
    except (KeyError, TypeError, ValueError) as exc:
        raise LifecycleError(failure, f"operation={operation} phase=intent status differs") from exc
    if _sha256_bytes(status_data) != plan.get("statusSha256"):
        raise LifecycleError(failure, f"operation={operation} phase=intent status hash differs")
    expected_images = {}
    for row in (*plan.get("links", []), plan.get("compatibilityIndex"), plan.get("readme")):
        if not isinstance(row, dict):
            raise LifecycleError(failure, f"operation={operation} phase=intent image plan differs")
        name = row.get("consumer", row.get("path"))
        if not isinstance(name, str) or name in expected_images:
            raise LifecycleError(failure, f"operation={operation} phase=intent image path differs")
        expected_images[name] = row
    images = intent.get("images")
    if not isinstance(images, list) or [row.get("path") for row in images if isinstance(row, dict)] != sorted(expected_images):
        raise LifecycleError(failure, f"operation={operation} phase=intent image set differs")
    for image in images:
        if not isinstance(image, dict) or set(image) != {
            "path", "beforeBase64", "afterBase64", "beforeSha256", "afterSha256",
        }:
            raise LifecycleError(failure, f"operation={operation} phase=intent image shape differs")
        name = image["path"]
        planned = expected_images.get(name)
        if planned is None or not name.startswith("work-items/") or "\\" in name:
            raise LifecycleError(failure, f"operation={operation} phase=intent image is outside work-items")
        physical = _intent_path(root, name)
        parts = PurePosixPath(name).parts
        if (
            ".." in parts or "archive" in parts or
            parts[:3] in {("work-items", "active", old), ("work-items", "active", new)}
        ):
            raise LifecycleError(failure, f"operation={operation} phase=intent image is immutable")
        if physical != _intent_path(root, planned.get("consumer", planned.get("path"))):
            raise LifecycleError(failure, f"operation={operation} phase=intent image target differs")
        try:
            before = base64.b64decode(image["beforeBase64"], validate=True)
            after = base64.b64decode(image["afterBase64"], validate=True)
        except (TypeError, ValueError) as exc:
            raise LifecycleError(failure, f"operation={operation} phase=intent image encoding differs") from exc
        if (
            _sha256_bytes(before) != image["beforeSha256"]
            or _sha256_bytes(after) != image["afterSha256"]
            or image["beforeSha256"] != planned.get("beforeSha256")
            or image["afterSha256"] != planned.get("afterSha256")
            or image["afterBase64"] != planned.get("afterBase64")
        ):
            raise LifecycleError(failure, f"operation={operation} phase=intent image hash differs")
    for name in (
        "sourcePath", "archivePath", "successorPath", "sourceHoldPath",
        "successorStagePath", "receiptPath",
    ):
        _intent_path(root, intent[name])


def _successor_import_source_bytes(path: Path, plan: dict, failure: str) -> dict[str, bytes]:
    try:
        files = _successor_import_tree(path)
    except LifecycleError as exc:
        raise LifecycleError(failure, "source tree cannot be captured") from exc
    expected = {row["sourceRelativePath"]: row["sourceSha256"] for row in plan["fileBindings"]}
    if (
        len(expected) != len(plan["fileBindings"])
        or {name: _sha256_bytes(data) for name, data in files} != expected
        or _successor_import_tree_digest(files) != plan["sourceTreeSha256"]
    ):
        raise LifecycleError(failure, "source tree differs from bound preflight")
    return dict(files)


def _successor_import_archive_bytes(path: Path, plan: dict, failure: str) -> dict[str, bytes]:
    try:
        files = _successor_import_tree(path)
    except LifecycleError as exc:
        raise LifecycleError(failure, "archive tree cannot be captured") from exc
    expected = {row["path"]: row["sha256"] for row in plan["archiveFiles"]}
    if (
        len(expected) != len(plan["archiveFiles"])
        or {name: _sha256_bytes(data) for name, data in files} != expected
        or _successor_import_tree_digest(files) != plan["archiveTreeSha256"]
        or _sha256_bytes(dict(files)["bug-dispositions-receipt.json"]) != plan["archiveReceiptSha256"]
    ):
        raise LifecycleError(failure, "archive tree differs from bound preflight")
    return dict(files)


def _successor_import_successor_files(
    plan: dict, status_data: bytes, source_files: dict[str, bytes],
) -> dict[str, bytes]:
    expected = {"status.md": status_data}
    for row in plan["fileBindings"]:
        if row["kind"] == "successor-copy":
            expected[f"imported-source/{row['sourceRelativePath']}"] = source_files[row["sourceRelativePath"]]
    return expected


def _successor_import_check_stage(
    path: Path, expected: dict[str, bytes], *, complete: bool,
) -> None:
    failure = "WI-SUCCESSOR-IMPORT-RECOVERY"
    if not path.exists():
        if complete:
            raise LifecycleError(failure, f"stage is absent: {path.name}")
        return
    try:
        observed = dict(_successor_import_tree(path))
    except LifecycleError as exc:
        raise LifecycleError(failure, f"stage is unsafe: {path.name}") from exc
    if any(name not in expected or data != expected[name] for name, data in observed.items()):
        raise LifecycleError(failure, f"stage bytes differ: {path.name}")
    if complete and set(observed) != set(expected):
        raise LifecycleError(failure, f"stage is incomplete: {path.name}")


def _successor_import_images(root: Path, plan: dict) -> list[dict]:
    images = []
    for row in (*plan["links"], plan["compatibilityIndex"], plan["readme"]):
        name = row.get("consumer", row.get("path"))
        path = _intent_path(root, name)
        before = _capture_file_snapshot(
            path, failure_id="WI-SUCCESSOR-IMPORT-DRIFT",
            maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP, require_single_link=True,
        ).data
        after = base64.b64decode(row["afterBase64"], validate=True)
        if _sha256_bytes(before) != row["beforeSha256"] or _sha256_bytes(after) != row["afterSha256"]:
            raise LifecycleError("WI-SUCCESSOR-IMPORT-DRIFT", f"bound image changed: {name}")
        images.append({
            "path": name, "beforeBase64": _b64(before), "afterBase64": _b64(after),
            "beforeSha256": row["beforeSha256"], "afterSha256": row["afterSha256"],
        })
    return sorted(images, key=lambda row: row["path"])


def _successor_import_receipt(
    plan: dict, digest: str, dispositions: dict, successor_tree_sha256: str,
) -> dict:
    return {
        **plan,
        "owner": SUCCESSOR_IMPORT_OWNER,
        "state": "committed",
        "preflightDigest": digest,
        "dispositionsSha256": _sha256_bytes(_successor_import_plan_bytes(dispositions)),
        "successorTreeSha256ExcludingReceipt": successor_tree_sha256,
        "receiptPath": f"work-items/active/{plan['successor']}/{SUCCESSOR_IMPORT_RECEIPT}",
    }


def _successor_import_reconstruct_source(root: Path, receipt: dict) -> dict[str, bytes]:
    failure = "WI-SUCCESSOR-IMPORT-RECOVERY"
    source: dict[str, bytes] = {}
    for row in receipt["fileBindings"]:
        target = _intent_path(root, row["targetPath"])
        try:
            data = _capture_file_snapshot(
                target, failure_id=failure,
                maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP, require_single_link=True,
            ).data
        except LifecycleError as exc:
            raise LifecycleError(failure, f"settled binding is absent: {row['sourceRelativePath']}") from exc
        if row["kind"] == "archive-ledger-prefix":
            byte_count = receipt["ledgerArchivePrefix"]["byteCount"]
            data = data[:byte_count]
        if _sha256_bytes(data) != row["sourceSha256"]:
            raise LifecycleError(failure, f"settled binding differs: {row['sourceRelativePath']}")
        source[row["sourceRelativePath"]] = data
    if (
        len(source) != len(receipt["fileBindings"])
        or _successor_import_tree_digest(sorted(source.items())) != receipt["sourceTreeSha256"]
    ):
        raise LifecycleError(failure, "settled source map is incomplete")
    return source


def _verify_successor_import_settlement(
    root: Path, receipt_path: Path,
    *, operation_id: str | None = None, digest: str | None = None,
    predecessor: str | None = None, successor: str | None = None,
    status_data: bytes | None = None, dispositions: dict | None = None,
) -> dict:
    failure = "WI-SUCCESSOR-IMPORT-RECOVERY"
    try:
        raw = _capture_file_snapshot(
            receipt_path, failure_id=failure,
            maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP, require_single_link=True,
        ).data
        receipt = json.loads(raw.decode("utf-8"))
    except (LifecycleError, OSError, UnicodeError, ValueError) as exc:
        raise LifecycleError(failure, "successor receipt cannot be read") from exc
    if (
        not isinstance(receipt, dict)
        or set(receipt) != SUCCESSOR_IMPORT_RECEIPT_FIELDS
        or raw != _migration_receipt_bytes(receipt)
        or receipt.get("schemaVersion") != 1
        or receipt.get("owner") != SUCCESSOR_IMPORT_OWNER
        or receipt.get("state") != "committed"
        or receipt.get("receiptPath") != receipt_path.relative_to(_work_items_root(root).parent).as_posix()
    ):
        raise LifecycleError(failure, "successor receipt shape or location differs")
    preflight_wire = {key: receipt[key] for key in SUCCESSOR_IMPORT_PLAN_FIELDS}
    preflight_wire["owner"] = "mutate-work-item:import-active-successor-preflight-v1"
    if _sha256_bytes(_successor_import_plan_bytes(preflight_wire)) != receipt["preflightDigest"]:
        raise LifecycleError(failure, "successor receipt preflight binding differs")
    if (
        (operation_id is not None and receipt.get("operationId") != operation_id)
        or (digest is not None and receipt.get("preflightDigest") != digest)
        or (predecessor is not None and receipt.get("predecessor") != predecessor)
        or (successor is not None and receipt.get("successor") != successor)
        or (status_data is not None and receipt.get("statusSha256") != _sha256_bytes(status_data))
        or (
            dispositions is not None
            and receipt.get("dispositionsSha256")
            != _sha256_bytes(_successor_import_plan_bytes(dispositions))
        )
    ):
        raise LifecycleError("WI-SUCCESSOR-IDENTITY-CONFLICT", "settled replay inputs differ")
    work_items = _work_items_root(root)
    old, new = receipt["predecessor"], receipt["successor"]
    archive = work_items / "archive"
    archives = [path for path in archive.glob(f"*/{old}") if path.is_dir()]
    if len(archives) != 1 or (work_items / "active" / old).exists():
        raise LifecycleError(failure, "settled predecessor identity differs")
    _successor_import_archive_bytes(archives[0], receipt, failure)
    active = work_items / "active" / new
    if not active.is_dir() or (active / "agent-runs.jsonl").exists():
        raise LifecycleError(failure, "settled successor identity differs")
    files = dict(_successor_import_tree(active))
    if SUCCESSOR_IMPORT_RECEIPT not in files or files[SUCCESSOR_IMPORT_RECEIPT] != raw:
        raise LifecycleError(failure, "settled successor receipt is not in its tree")
    files.pop(SUCCESSOR_IMPORT_RECEIPT)
    if _successor_import_tree_digest(sorted(files.items())) != receipt.get("successorTreeSha256ExcludingReceipt"):
        raise LifecycleError(failure, "settled successor tree differs")
    _successor_import_reconstruct_source(root, receipt)
    for row in (*receipt["links"], receipt["compatibilityIndex"], receipt["readme"]):
        path = _intent_path(root, row.get("consumer", row.get("path")))
        observed = _capture_file_snapshot(
            path, failure_id=failure,
            maximum_bytes=LEDGER_LOCATION_PROOF_BYTE_CAP, require_single_link=True,
        ).data
        if _sha256_bytes(observed) != row["afterSha256"]:
            raise LifecycleError(failure, f"settled consumer differs: {path.name}")
    index_target = _intent_path(root, receipt["compatibilityIndex"]["targetPath"])
    if not index_target.is_file() or index_target != active / "status.md":
        raise LifecycleError("WI-SUCCESSOR-LINK-UNMAPPED", "settled index target differs")
    for consumer in receipt["links"]:
        for row in consumer["references"]:
            if row["kind"] == "physical" and not _intent_path(root, row["target"]).is_file():
                raise LifecycleError("WI-SUCCESSOR-LINK-UNMAPPED", "settled physical target is absent")
    check_readme(root)
    if (
        resolve_category(root, f"work-item:{old}") != archives[0]
        or resolve_category(root, f"work-item:{new}") != active
    ):
        raise LifecycleError(failure, "settled category readback differs")
    return receipt


def _successor_import_release_stage_parent(stage_root: Path) -> None:
    parent = stage_root.parent
    if not parent.exists():
        return
    _lifecycle_reject_unreduced_reparse(
        parent, failure_id="WI-SUCCESSOR-IMPORT-RECOVERY",
        message="successor staging parent is unsafe",
    )
    try:
        parent.rmdir()
    except OSError as exc:
        if any(parent.iterdir()):
            return
        raise LifecycleError(
            "WI-SUCCESSOR-IMPORT-RECOVERY", "empty successor staging parent remains"
        ) from exc


@_lifecycle_participant
def _recover_successor_import(root: Path, intent_path: Path, intent: dict) -> dict | None:
    operation = intent["operationId"]
    failure = "WI-SUCCESSOR-IMPORT-RECOVERY"
    try:
        repository = _work_items_root(root).parent
        source = _intent_path(repository, intent["sourcePath"])
        archive = _intent_path(repository, intent["archivePath"])
        successor = _intent_path(repository, intent["successorPath"])
        hold = _intent_path(repository, intent["sourceHoldPath"])
        stage = _intent_path(repository, intent["successorStagePath"])
        stage_root = hold.parent
        receipt_path = _intent_path(repository, intent["receiptPath"])
        plan = intent["plan"]
        status_data = base64.b64decode(intent["statusData"], validate=True)
        if stage_root.exists():
            if not stage_root.is_dir() or _lifecycle_path_has_reparse(stage_root):
                raise LifecycleError(failure, "stage root is unsafe")
            with os.scandir(stage_root) as entries:
                if {entry.name for entry in entries} - {"source", "successor"}:
                    raise LifecycleError(failure, "stage root has an unowned member")
        _successor_import_archive_bytes(archive, plan, failure)
        if receipt_path.exists():
            settled = _verify_successor_import_settlement(
                repository, receipt_path,
                operation_id=operation, digest=intent["preflightDigest"],
                predecessor=plan["predecessor"], successor=plan["successor"],
                status_data=status_data,
            )
            original = _successor_import_reconstruct_source(repository, settled)
            expected_successor = _successor_import_successor_files(plan, status_data, original)
            _successor_import_check_stage(hold, original, complete=False)
            _successor_import_check_stage(stage, expected_successor, complete=False)
            if stage_root.exists():
                _remove_scratch_tree(stage_root)
            _successor_import_release_stage_parent(stage_root)
            intent_path.unlink()
            return settled
        source_here = source.is_dir()
        hold_here = hold.is_dir()
        if source_here == hold_here:
            raise LifecycleError(failure, "source and held custody are missing or duplicated")
        source_files = _successor_import_source_bytes(
            source if source_here else hold, plan, failure,
        )
        expected_successor = _successor_import_successor_files(
            plan, status_data, source_files,
        )
        _successor_import_check_stage(stage, expected_successor, complete=False)
        if successor.exists():
            if source_here:
                raise LifecycleError(failure, "successor exists before source custody")
            _successor_import_check_stage(successor, expected_successor, complete=True)
        current_images = []
        for image in intent["images"]:
            path = _intent_path(repository, image["path"])
            before = base64.b64decode(image["beforeBase64"], validate=True)
            after = base64.b64decode(image["afterBase64"], validate=True)
            current = _read_lifecycle_image(
                path, before, after, failure_id=failure, require_single_link=True,
            )
            if current not in {before, after}:
                raise LifecycleError(failure, f"consumer image differs: {image['path']}")
            current_images.append((path, before, current))
        for path, before, current in current_images:
            if current != before:
                _atomic_write(path, before)
        if successor.exists():
            _remove_scratch_tree(successor)
        if stage.exists():
            _remove_scratch_tree(stage)
        if hold_here:
            source.parent.mkdir(parents=True, exist_ok=True)
            os.replace(hold, source)
        if stage_root.exists():
            _remove_scratch_tree(stage_root)
        _successor_import_release_stage_parent(stage_root)
        intent_path.unlink()
        _successor_import_source_bytes(source, plan, failure)
        return None
    except BaseException as exc:
        raise LifecycleError(
            failure,
            f"operation={operation} phase=recovery: {exc}",
        ) from exc


def apply_import_active_successor(
    root: Path, predecessor_slug: str, successor_slug: str, status_data: bytes,
    dispositions: dict, operation_id: str, preflight_digest: str,
    *, inject_failure_at: str | None = None,
) -> dict:
    """Settle one preflight-bound dual work-item identity through owner custody."""

    work_items = _work_items_root(root)
    repository = work_items.parent
    _validate_slug(predecessor_slug)
    _validate_slug(successor_slug)
    intent_path = _transition_intent_path(repository, operation_id)
    successor = work_items / "active" / successor_slug
    receipt_path = successor / SUCCESSOR_IMPORT_RECEIPT
    if intent_path.exists():
        raise LifecycleError(
            "WI-SUCCESSOR-IMPORT-RECOVERY",
            f"operation={operation_id} phase=pending-intent: recover-transition is required",
        )
    if receipt_path.exists():
        _verify_successor_import_settlement(
            repository, receipt_path,
            operation_id=operation_id, digest=preflight_digest,
            predecessor=predecessor_slug, successor=successor_slug,
            status_data=status_data, dispositions=dispositions,
        )
        return {
            "state": "committed", "alreadySettled": True,
            "receiptPath": receipt_path.relative_to(repository).as_posix(),
        }
    if successor.exists():
        raise LifecycleError("WI-SUCCESSOR-IDENTITY-CONFLICT", "successor is occupied without an exact receipt")
    if not isinstance(preflight_digest, str) or SHA256_RE.fullmatch(preflight_digest) is None:
        raise LifecycleError("WI-SUCCESSOR-IMPORT-DRIFT", "matching preflight digest is required")
    try:
        plan_result = preflight_import_active_successor(
            repository, predecessor_slug, successor_slug, status_data,
            dispositions, operation_id,
        )
    except LifecycleError as exc:
        if exc.failure_id == "WI-SUCCESSOR-IDENTITY-CONFLICT":
            raise
        raise LifecycleError("WI-SUCCESSOR-IMPORT-DRIFT", f"preflight input changed: {exc.failure_id}") from exc
    if plan_result["digest"] != preflight_digest:
        raise LifecycleError("WI-SUCCESSOR-IMPORT-DRIFT", "preflight digest differs")
    plan = json.loads(plan_result["canonicalBytes"])
    locations = _category_locations(repository, CATEGORIES["work-item"], predecessor_slug)
    archives = [path for path in locations if path.parent.parent == work_items / "archive"]
    if len(archives) != 1:
        raise LifecycleError("WI-SUCCESSOR-IDENTITY-CONFLICT", "archived predecessor is not unique")
    archive = archives[0]
    source = work_items / "active" / predecessor_slug
    source_files = _successor_import_source_bytes(source, plan, "WI-SUCCESSOR-IMPORT-DRIFT")
    _successor_import_archive_bytes(archive, plan, "WI-SUCCESSOR-IMPORT-DRIFT")
    expected_successor = _successor_import_successor_files(plan, status_data, source_files)
    images = _successor_import_images(repository, plan)
    hold_relative, stage_relative = _successor_import_stage_paths(operation_id)
    hold = _intent_path(repository, hold_relative)
    stage = _intent_path(repository, stage_relative)
    stage_root = hold.parent
    if stage_root.exists():
        raise LifecycleError("WI-SUCCESSOR-IMPORT-RECOVERY", "operation staging already exists")
    intent = {
        "schemaVersion": 1, "owner": SUCCESSOR_IMPORT_OWNER,
        "kind": SUCCESSOR_IMPORT_KIND, "status": "intent",
        "operationId": operation_id, "preflightDigest": preflight_digest,
        "sourcePath": source.relative_to(repository).as_posix(),
        "archivePath": archive.relative_to(repository).as_posix(),
        "successorPath": successor.relative_to(repository).as_posix(),
        "sourceHoldPath": hold_relative, "successorStagePath": stage_relative,
        "receiptPath": receipt_path.relative_to(repository).as_posix(),
        "plan": plan, "statusData": _b64(status_data), "images": images,
    }
    intent_bytes = _migration_receipt_bytes(intent)
    if len(intent_bytes) > TRANSITION_INTENT_FILE_BYTE_CAP:
        raise LifecycleError("WI-SUCCESSOR-IMPORT-DRIFT", "preflight plan exceeds intent byte limit")
    intent_path = _require_lifecycle_mutation_path(
        repository, intent_path, failure_id="WI-SUCCESSOR-IMPORT-RECOVERY",
    )
    _atomic_write(intent_path, intent_bytes)
    _transition_fsync_directory(intent_path.parent)
    phase = "stage-successor"
    try:
        for relative, data in sorted(expected_successor.items()):
            target = _require_lifecycle_mutation_path(
                repository, stage.joinpath(*PurePosixPath(relative).parts),
                failure_id="WI-SUCCESSOR-IMPORT-RECOVERY",
            )
            _atomic_write(target, data)
        _successor_import_check_stage(stage, expected_successor, complete=True)
        if inject_failure_at == "before-source-hold":
            raise LifecycleError("WI-SUCCESSOR-IMPORT-RECOVERY", "injected before-source-hold")
        phase = "revalidate-before-publish"
        rebound = preflight_import_active_successor(
            repository, predecessor_slug, successor_slug, status_data,
            dispositions, operation_id,
        )
        if rebound["digest"] != preflight_digest:
            raise LifecycleError("WI-SUCCESSOR-IMPORT-DRIFT", "bound inputs changed before publish")
        phase = "source-hold"
        os.replace(source, hold)
        if inject_failure_at == "after-source-hold":
            raise LifecycleError("WI-SUCCESSOR-IMPORT-RECOVERY", "injected after-source-hold")
        phase = "successor-publish"
        os.replace(stage, successor)
        if inject_failure_at == "after-successor-publish":
            raise LifecycleError("WI-SUCCESSOR-IMPORT-RECOVERY", "injected after-successor-publish")
        phase = "links-publish"
        for image in images:
            if image["path"] == "work-items/README.md":
                continue
            path = _intent_path(repository, image["path"])
            before = base64.b64decode(image["beforeBase64"], validate=True)
            after = base64.b64decode(image["afterBase64"], validate=True)
            if _read_lifecycle_image(path, before, failure_id="WI-SUCCESSOR-IMPORT-DRIFT") != before:
                raise LifecycleError("WI-SUCCESSOR-IMPORT-DRIFT", f"consumer drifted: {image['path']}")
            _atomic_write(path, after)
        if inject_failure_at == "after-links-publish":
            raise LifecycleError("WI-SUCCESSOR-IMPORT-RECOVERY", "injected after-links-publish")
        phase = "readme-publish"
        readme = next(row for row in images if row["path"] == "work-items/README.md")
        readme_path = _intent_path(repository, readme["path"])
        before = base64.b64decode(readme["beforeBase64"], validate=True)
        after = base64.b64decode(readme["afterBase64"], validate=True)
        if _read_lifecycle_image(readme_path, before, failure_id="WI-SUCCESSOR-IMPORT-DRIFT") != before:
            raise LifecycleError("WI-SUCCESSOR-IMPORT-DRIFT", "README drifted before publish")
        _atomic_write(readme_path, after)
        check_readme(repository)
        if inject_failure_at == "after-readme-publish":
            raise LifecycleError("WI-SUCCESSOR-IMPORT-RECOVERY", "injected after-readme-publish")
        phase = "receipt-publish"
        successor_tree = _successor_import_tree(successor)
        if dict(successor_tree) != expected_successor:
            raise LifecycleError("WI-SUCCESSOR-IMPORT-RECOVERY", "successor staged bytes differ")
        receipt = _successor_import_receipt(
            plan, preflight_digest, dispositions,
            _successor_import_tree_digest(successor_tree),
        )
        _atomic_write(receipt_path, _migration_receipt_bytes(receipt))
        _transition_fsync_directory(receipt_path.parent)
        if inject_failure_at == "after-receipt-publish":
            raise LifecycleError("WI-SUCCESSOR-IMPORT-RECOVERY", "injected after-receipt-publish")
        phase = "settlement-verify"
        _verify_successor_import_settlement(
            repository, receipt_path, operation_id=operation_id,
            digest=preflight_digest, predecessor=predecessor_slug,
            successor=successor_slug, status_data=status_data,
            dispositions=dispositions,
        )
        phase = "cleanup"
        _recover_successor_import(repository, intent_path, intent)
        return {
            "state": "committed", "alreadySettled": False,
            "receiptPath": receipt_path.relative_to(repository).as_posix(),
        }
    except BaseException as exc:
        if isinstance(exc, LifecycleError) and exc.failure_id in {
            "WI-SUCCESSOR-IMPORT-RECOVERY", "WI-SUCCESSOR-IMPORT-DRIFT",
            "WI-SUCCESSOR-LINK-UNMAPPED",
        }:
            if exc.failure_id == "WI-SUCCESSOR-IMPORT-RECOVERY":
                raise LifecycleError(
                    exc.failure_id,
                    f"operation={operation_id} phase={inject_failure_at or phase}: {exc}",
                ) from exc
            raise
        raise LifecycleError(
            "WI-SUCCESSOR-IMPORT-RECOVERY",
            f"operation={operation_id} phase={phase}: {exc}",
        ) from exc


def _successor_import_json_pairs(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise LifecycleError("WI-SUCCESSOR-LINK-UNMAPPED", "link dispositions repeat a JSON key")
        result[key] = value
    return result


def _read_arg_file(path: str) -> bytes:
    return Path(path).read_bytes()


def _add_root(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--root", default=".", help="Repository or work-items root")


def _add_injection(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--inject-readme-failure",
        choices=("after-canonical",),
        help=argparse.SUPPRESS,
    )


def _parse_partial_recovery_status_bindings(values: list[str]) -> dict[str, str]:
    bindings: dict[str, str] = {}
    for value in values:
        if value.count("=") != 1:
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-COVERAGE",
                "target status preimage must be <reference>=<sha256>",
            )
        reference, digest = value.split("=", 1)
        if (
            reference in bindings
            or reference not in PARTIAL_MIGRATION_RECOVERY_TARGETS
            or not re.fullmatch(r"[0-9A-Fa-f]{64}", digest)
        ):
            raise _partial_recovery_fail(
                "WI-PARTIAL-MIGRATION-RECOVERY-COVERAGE",
                "target status preimage bindings differ from the exact incident",
            )
        bindings[reference] = digest.upper()
    if set(bindings) != set(PARTIAL_MIGRATION_RECOVERY_TARGETS):
        raise _partial_recovery_fail(
            "WI-PARTIAL-MIGRATION-RECOVERY-COVERAGE",
            "both exact incident target status preimages are required",
        )
    return bindings


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("candidate", "start", "update", "close", "reopen"):
        command = sub.add_parser(name)
        _add_root(command)
        _add_injection(command)
        command.add_argument("--slug", required=True)
        if name == "candidate":
            command.add_argument("--file", required=True)
        elif name in {"start", "update"}:
            command.add_argument("--status-file", required=True)
        elif name == "close":
            command.add_argument("--closure-file", required=True)
            command.add_argument("--terminal-instant", required=True)
        else:
            command.add_argument("--successor-slug", required=True)
            command.add_argument("--status-file", required=True)
    convert_legacy = sub.add_parser("convert-legacy-candidate")
    _add_root(convert_legacy)
    _add_injection(convert_legacy)
    convert_legacy.add_argument("--slug", required=True)
    convert_legacy.add_argument("--file", required=True)
    retire_legacy = sub.add_parser("retire-legacy-backlog")
    _add_root(retire_legacy)
    _add_injection(retire_legacy)
    retire_legacy.add_argument("--slug", required=True)
    retire_legacy.add_argument("--disposition-file", required=True)
    retire_legacy.add_argument("--terminal-instant", required=True)
    refresh = sub.add_parser("refresh")
    _add_root(refresh)
    refresh.add_argument("--reset-static-guide", action="store_true")
    refresh.add_argument("--expected-readme-sha256")
    resolve = sub.add_parser("resolve")
    _add_root(resolve)
    target = resolve.add_mutually_exclusive_group(required=True)
    target.add_argument("--reference")
    target.add_argument("--legacy-path")
    audit_parser = sub.add_parser("audit")
    _add_root(audit_parser)
    audit_mode = audit_parser.add_mutually_exclusive_group()
    audit_mode.add_argument("--output")
    audit_mode.add_argument("--verify-migration")
    recover_transition = sub.add_parser("recover-transition")
    _add_root(recover_transition)
    recover_transition.add_argument("--operation-id", required=True)
    recover_transition.add_argument("--apply", action="store_true")
    migrate = sub.add_parser("migrate")
    _add_root(migrate)
    migrate_mode = migrate.add_mutually_exclusive_group(required=True)
    migrate_mode.add_argument("--reference")
    migrate_mode.add_argument("--inventory")
    migrate.add_argument("--incoming-links-inventory")
    migrate.add_argument("--apply-admitted", action="store_true")
    migrate.add_argument("--render-readme", action="store_true")
    migrate.add_argument("--byte-check", action="store_true")
    terminalize = sub.add_parser("terminalize-v1")
    _add_root(terminalize)
    terminalize.add_argument("--inventory", required=True)
    terminalize.add_argument("--terminal-at", required=True)
    terminalize.add_argument("--authorization-marker", required=True)
    terminalize.add_argument("--receipt", required=True)
    recovery = sub.add_parser("recover-partial-migration-v1")
    _add_root(recovery)
    recovery.add_argument("--inventory", required=True)
    recovery.add_argument("--expected-inventory-sha256", required=True)
    recovery.add_argument("--expected-readme-sha256", required=True)
    recovery.add_argument(
        "--target-status-preimage",
        action="append",
        required=True,
        help="Exact <reference>=<sha256> incident status preimage; repeat twice",
    )
    recovery.add_argument("--receipt", required=True)
    recovery.add_argument("--apply-admitted", action="store_true")
    recovery.add_argument("--render-readme", action="store_true")
    recovery.add_argument("--byte-check", action="store_true")
    normalize = sub.add_parser(
        "normalize-current-identity",
        help="Atomically replace one noncanonical current flat-record identity",
    )
    _add_root(normalize)
    normalize.add_argument("--category", required=True, help="Lifecycle category")
    normalize.add_argument(
        "--source",
        required=True,
        help="Repository-relative source path under work-items/",
    )
    normalize.add_argument(
        "--target-slug", required=True, help="Canonical replacement slug"
    )
    normalize.add_argument(
        "--inventory", required=True, help="Repository .scratch/ inventory path"
    )
    normalize.add_argument(
        "--receipt", help="Repository .scratch/ settled receipt path"
    )
    normalize.add_argument(
        "--prepare-only",
        action="store_true",
        help="Write the exact byte-bound inventory without mutating work-items",
    )
    normalize.add_argument(
        "--inject-failure-at",
        choices=("after-rewrites", "after-move", "after-readme"),
        help=argparse.SUPPRESS,
    )
    apply_legacy = sub.add_parser("migrate-legacy-ledger-obligation")
    _add_root(apply_legacy)
    apply_legacy.add_argument("--slug", required=True)
    apply_legacy.add_argument("--target-run-id", required=True)
    apply_legacy.add_argument("--target-event-sha256", required=True)
    apply_legacy.add_argument("--expected-ledger-sha256", required=True)
    apply_legacy.add_argument("--operation-id", required=True)
    apply_legacy.add_argument("--recorded-at", required=True)
    apply_legacy.add_argument(
        "--normalization-kind",
        choices=("invalid-finding-class", "remove-string-scratch-evidence"),
        default="invalid-finding-class",
    )
    apply_legacy.add_argument(
        "--inject-failure",
        choices=("after-anchor", "post-replace-corrupt"),
        help=argparse.SUPPRESS,
    )
    revoke_legacy = sub.add_parser("revoke-legacy-ledger-obligation")
    _add_root(revoke_legacy)
    revoke_legacy.add_argument("--slug", required=True)
    revoke_legacy.add_argument("--apply-run-id", required=True)
    revoke_legacy.add_argument("--apply-event-sha256", required=True)
    revoke_legacy.add_argument("--expected-ledger-sha256", required=True)
    revoke_legacy.add_argument("--operation-id", required=True)
    revoke_legacy.add_argument("--recorded-at", required=True)
    settle_legacy = sub.add_parser("settle-legacy-ledger")
    _add_root(settle_legacy)
    settle_legacy.add_argument("--request-file", required=True)
    settle_legacy.add_argument("--apply-admitted", action="store_true")
    recover_mixed = sub.add_parser("recover-mixed-current-ledger")
    _add_root(recover_mixed)
    recover_mixed.add_argument("--request-file", required=True)
    recover_mixed.add_argument("--apply-admitted", action="store_true")
    projection_apply = sub.add_parser("apply-legacy-ledger-projection")
    _add_root(projection_apply)
    projection_apply.add_argument("--manifest-file", required=True)
    projection_apply.add_argument("--manifest-entry-id")
    projection_apply.add_argument("--raw-line-ordinal", type=int)
    projection_apply.add_argument("--expected-registry-sha256", required=True)
    projection_apply.add_argument("--operation-id")
    projection_apply.add_argument("--recorded-at", required=True)
    projection_apply.add_argument("--ledger-manifest-path")
    projection_apply.add_argument("--h1-manifest-file")
    projection_apply.add_argument("--h1-manifest-path")
    projection_apply.add_argument("--dry-run", action="store_true")
    projection_revoke = sub.add_parser("revoke-legacy-ledger-projection")
    _add_root(projection_revoke)
    projection_revoke.add_argument("--apply-operation-id")
    projection_revoke.add_argument("--apply-record-sha256")
    projection_revoke.add_argument("--expected-registry-sha256", required=True)
    projection_revoke.add_argument("--operation-id")
    projection_revoke.add_argument("--recorded-at", required=True)
    projection_revoke.add_argument("--apply-receipt-path")
    projection_revoke.add_argument("--apply-receipt-sha256")
    projection_revoke.add_argument("--dry-run", action="store_true")
    h1_relocation = sub.add_parser("relocate-ledger-h1-artifact-set")
    _add_root(h1_relocation)
    h1_relocation.add_argument("--archive-owner", required=True)
    h1_relocation.add_argument("--expected-artifact-set-sha256", required=True)
    h1_relocation.add_argument("--expected-root-contract-sha256", required=True)
    h1_relocation.add_argument("--operation-id", required=True)
    h1_relocation.add_argument("--recorded-at", required=True)
    h1_relocation.add_argument("--apply", action="store_true")
    projection_disposition = sub.add_parser("write-legacy-ledger-irrecoverable-disposition")
    _add_root(projection_disposition)
    projection_disposition.add_argument("--disposition-file", required=True)
    historical_disposition = sub.add_parser("write-historical-artifact-disposition")
    _add_root(historical_disposition)
    historical_disposition.add_argument("--disposition-file", required=True)
    successor_import = sub.add_parser("import-active-successor")
    _add_root(successor_import)
    successor_import.add_argument("--predecessor-slug", required=True)
    successor_import.add_argument("--successor-slug", required=True)
    successor_import.add_argument("--status-file", required=True)
    successor_import.add_argument("--links-file", required=True)
    successor_import.add_argument("--operation-id", required=True)
    successor_import.add_argument("--apply", action="store_true")
    successor_import.add_argument("--preflight-digest")
    archive_successor = sub.add_parser("archive-with-successor")
    _add_root(archive_successor)
    archive_successor.add_argument("--slug", required=True)
    archive_successor.add_argument("--closure-file", required=True)
    archive_successor.add_argument("--terminal-instant", required=True)
    archive_successor.add_argument("--successor-slug", required=True)
    archive_successor.add_argument("--successor-file", required=True)
    archive_successor.add_argument("--operation-id", required=True)
    archive_successor.add_argument("--expected-ledger-sha256", required=True)
    archive_successor.add_argument("--expected-readme-sha256", required=True)
    archive_successor.add_argument("--obligation-transfer-file")
    archive_successor.add_argument(
        "--inject-failure-at", choices=tuple(f"T{i}" for i in range(10)), help=argparse.SUPPRESS
    )
    supersede_bug = sub.add_parser("supersede-current-bug")
    _add_root(supersede_bug)
    supersede_bug.add_argument("--slug", required=True)
    supersede_bug.add_argument("--successor-record", required=True)
    supersede_bug.add_argument("--successor-binding-file", required=True)
    supersede_bug.add_argument("--terminal-instant", required=True)
    supersede_bug.add_argument("--incoming-links-inventory", required=True)
    supersede_bug.add_argument("--expected-bug-sha256", required=True)
    supersede_bug.add_argument("--expected-readme-sha256", required=True)
    supersede_bug.add_argument("--operation-id", required=True)
    supersede_bug.add_argument("--apply", action="store_true", required=True)
    supersede_bug.add_argument(
        "--inject-failure-at",
        choices=tuple(f"B{i}" for i in range(8)),
        help=argparse.SUPPRESS,
    )
    fixed_bug = sub.add_parser("archive-fixed-bug")
    _add_root(fixed_bug)
    fixed_bug.add_argument("--slug", required=True)
    fixed_bug.add_argument("--terminal-instant", required=True)
    fixed_bug.add_argument("--resolution", required=True)
    fixed_bug.add_argument("--evidence", required=True)
    fixed_bug.add_argument("--apply", action="store_true")
    release = sub.add_parser("release-retained-scratch")
    _add_root(release)
    release.add_argument("--slug", required=True)
    release.add_argument("--terminal-run-id", required=True)
    release.add_argument("--expected-event-sha256", required=True)
    release.add_argument("--entry-id", required=True)
    release.add_argument("--artifact", required=True)
    release.add_argument("--rationale", required=True)
    release.add_argument("--apply", action="store_true")
    trial = sub.add_parser("trial")
    _add_root(trial)
    trial.add_argument("--fixture", required=True)
    return parser


def _emit_lifecycle_cleanup_diagnostics(
    observer: LifecycleDiagnosticObserver | None,
) -> None:
    if observer is None or observer.state != "delivered":
        return
    bundle = observer.snapshot
    if bundle is None or not bundle.cleanupFailures:
        return
    total = len(bundle.cleanupFailures)
    for index, record in enumerate(bundle.cleanupFailures, start=1):
        payload = {
            "causeType": record.causeType,
            "diagnostic": record.diagnostic,
            "failureId": record.failureId,
            "index": index,
            "phase": record.phase,
            "resource": record.resource,
            "total": total,
        }
        print(
            "CLEANUP-FAILURE: "
            + json.dumps(payload, sort_keys=True, separators=(",", ":"))
        )
    print(
        "CLEANUP-SUMMARY: "
        + json.dumps(
            {"count": total, "rollback": bundle.rollback},
            sort_keys=True,
            separators=(",", ":"),
        )
    )


def _project_current_bug_supersession_cli_failure(error: BaseException) -> str:
    if isinstance(error, LifecycleError):
        return f"{error.failure_id}: current bug supersession rejected"
    if isinstance(error, (OSError, UnicodeError, json.JSONDecodeError)):
        return "WI-IO: required current bug supersession input could not be read"
    return (
        "WI-BUG-SUPERSESSION-UNEXPECTED: "
        "current bug supersession failed unexpectedly"
    )


def main(argv: list[str]) -> int:
    args = build_parser().parse_args(argv)
    root = Path(args.root)
    lifecycle_diagnostic_observer = None
    try:
        if args.command == "candidate":
            result = create_candidate(
                root,
                args.slug,
                _read_arg_file(args.file),
                inject_readme_failure=bool(args.inject_readme_failure),
            )
            print(result)
        elif args.command == "convert-legacy-candidate":
            result = convert_legacy_candidate(
                root,
                args.slug,
                _read_arg_file(args.file),
                inject_readme_failure=bool(args.inject_readme_failure),
            )
            print(result)
        elif args.command == "retire-legacy-backlog":
            result = retire_legacy_backlog(
                root,
                args.slug,
                _read_arg_file(args.disposition_file),
                args.terminal_instant,
                inject_readme_failure=bool(args.inject_readme_failure),
            )
            print(result)
        elif args.command == "start":
            result = start_item(
                root,
                args.slug,
                _read_arg_file(args.status_file),
                inject_readme_failure=bool(args.inject_readme_failure),
            )
            print(result)
        elif args.command == "update":
            result = update_status(
                root,
                args.slug,
                _read_arg_file(args.status_file),
                inject_readme_failure=bool(args.inject_readme_failure),
            )
            print(result)
        elif args.command == "close":
            result = close_item(
                root,
                args.slug,
                _read_arg_file(args.closure_file),
                args.terminal_instant,
                inject_readme_failure=bool(args.inject_readme_failure),
            )
            print(result)
        elif args.command == "reopen":
            result = reopen_item(
                root,
                args.slug,
                args.successor_slug,
                _read_arg_file(args.status_file),
                inject_readme_failure=bool(args.inject_readme_failure),
            )
            print(result)
        elif args.command == "refresh":
            if args.reset_static_guide:
                if not args.expected_readme_sha256:
                    raise LifecycleError(
                        "WI-README-REPAIR-TARGET-MISMATCH",
                        "--reset-static-guide requires --expected-readme-sha256",
                    )
                readme_hash = reset_readme_static_guide(
                    root,
                    args.expected_readme_sha256,
                )
            else:
                if args.expected_readme_sha256:
                    raise LifecycleError(
                        "WI-README-REPAIR-TARGET-MISMATCH",
                        "--expected-readme-sha256 requires --reset-static-guide",
                    )
                readme_hash = refresh_readme(root)
            print(f"README-SHA256: {readme_hash}")
        elif args.command == "resolve":
            if args.reference:
                print(resolve_category(root, args.reference))
            else:
                print(f"WI-LEGACY-READ-COMPAT {resolve_legacy_path(root, args.legacy_path)}")
        elif args.command == "recover-transition":
            if not args.apply:
                raise LifecycleError(
                    "WI-LIFECYCLE-TRANSITION-RECOVERY-REQUIRED",
                    "recover-transition requires explicit --apply",
                )
            intent_path = _transition_intent_path(root, args.operation_id)
            if not intent_path.is_file():
                raise LifecycleError(
                    "WI-LIFECYCLE-TRANSITION-RECOVERY-REQUIRED",
                    f"no pending transition for operation: {args.operation_id}",
                )
            _transition_intent_operation_id(root, intent_path)
            recovered = _recover_transition(root, intent_path)
            outcome = "rolled-back" if recovered is None else "settled"
            print(
                "RECOVER-TRANSITION: "
                f"operation={args.operation_id} outcome={outcome}"
            )
            print("next=audit")
        elif args.command == "audit":
            if args.output:
                inventory = write_migration_inventory(root, Path(args.output))
                print(f"migration_rows={len(inventory['rows'])}")
            elif args.verify_migration:
                rows = verify_migration_inventory(
                    root, Path(args.verify_migration)
                )
                print(f"migration_rows={rows}")
            else:
                for legacy_path in audit(root):
                    print(f"{LEGACY_READ_CLASSIFICATION} {legacy_path}")
            print("AUDIT: PASS")
        elif args.command == "migrate":
            if args.inventory:
                if not (
                    args.apply_admitted
                    and args.render_readme
                    and args.byte_check
                ):
                    raise LifecycleError(
                        "WI-CATEGORY-MIGRATION-INVENTORY",
                        "inventory migration requires --apply-admitted, "
                        "--render-readme, and --byte-check",
                    )
                rows, readme_hash = apply_migration_inventory(
                    root,
                    Path(args.inventory),
                    render_readme=args.render_readme,
                    byte_check=args.byte_check,
                )
                print("MIGRATION: PASS")
                print(f"migration_rows={rows}")
                print("readme_byte_check=PASS")
                print("source_target_disjoint=PASS")
                if readme_hash:
                    print(f"readme_sha256={readme_hash}")
            else:
                if args.apply_admitted or args.render_readme or args.byte_check:
                    raise LifecycleError(
                        "WI-CATEGORY-MIGRATION-INVENTORY",
                        "bulk migration flags require --inventory",
                    )
                migrate_legacy(
                    root,
                    args.reference,
                    incoming_links_inventory=(
                        Path(args.incoming_links_inventory)
                        if args.incoming_links_inventory
                        else None
                    ),
                )
        elif args.command == "terminalize-v1":
            rows, replay = terminalize_v1_inventory(
                root,
                Path(args.inventory),
                terminal_at=args.terminal_at,
                authorization_marker=args.authorization_marker,
                receipt_path=Path(args.receipt),
            )
            if replay:
                print(f"TERMINALIZE-V1: PASS rows={rows} replay=true")
            else:
                print(
                    f"TERMINALIZE-V1: PASS rows={rows} "
                    f"marker={args.authorization_marker}"
                )
        elif args.command == "recover-partial-migration-v1":
            lifecycle_diagnostic_observer = LifecycleDiagnosticObserver()
            result = recover_partial_migration_v1(
                root,
                Path(args.inventory),
                expected_inventory_sha256=args.expected_inventory_sha256,
                expected_readme_sha256=args.expected_readme_sha256,
                target_status_preimages=_parse_partial_recovery_status_bindings(
                    args.target_status_preimage
                ),
                receipt_path=Path(args.receipt),
                apply_admitted=args.apply_admitted,
                render_readme=args.render_readme,
                byte_check=args.byte_check,
                diagnostic_observer=lifecycle_diagnostic_observer,
            )
            print(
                "PARTIAL-MIGRATION-RECOVERY: PASS "
                f"receipt_sha256={result.receipt_sha256} "
                f"audit={result.audit}"
            )
        elif args.command == "normalize-current-identity":
            if args.prepare_only:
                if args.receipt:
                    raise LifecycleError(
                        "WI-IDENTITY-NORMALIZE-INVENTORY",
                        "--prepare-only does not accept --receipt",
                    )
                inventory = write_current_identity_normalization_inventory(
                    root,
                    args.category,
                    args.source,
                    args.target_slug,
                    Path(args.inventory),
                )
                print(f"NORMALIZE-CURRENT-IDENTITY: INVENTORY rows={len(inventory['rows'])}")
            else:
                if not args.receipt:
                    raise LifecycleError(
                        "WI-IDENTITY-NORMALIZE-INVENTORY",
                        "normalization apply requires --receipt",
                    )
                target, replay = normalize_current_identity(
                    root,
                    args.category,
                    args.source,
                    args.target_slug,
                    Path(args.inventory),
                    Path(args.receipt),
                    inject_failure_at=args.inject_failure_at,
                )
                print(
                    "NORMALIZE-CURRENT-IDENTITY: PASS "
                    f"target={target} replay={'true' if replay else 'false'}"
                )
        elif args.command == "migrate-legacy-ledger-obligation":
            result = migrate_legacy_ledger_obligation(
                root,
                args.slug,
                args.target_run_id,
                args.target_event_sha256,
                args.expected_ledger_sha256,
                args.operation_id,
                args.recorded_at,
                normalization_kind=args.normalization_kind,
                inject_failure=args.inject_failure,
            )
            print(
                "WI-LEDGER-MIGRATION-COMMITTED "
                f"operation={result['operationId']} after={result['afterLedgerSha256']}"
            )
        elif args.command == "revoke-legacy-ledger-obligation":
            result = revoke_legacy_ledger_obligation(
                root,
                args.slug,
                args.apply_run_id,
                args.apply_event_sha256,
                args.expected_ledger_sha256,
                args.operation_id,
                args.recorded_at,
            )
            print(
                "WI-LEDGER-MIGRATION-REVOKED "
                f"operation={result['operationId']} after={result['afterLedgerSha256']}"
            )
        elif args.command == "settle-legacy-ledger":
            result = settle_legacy_ledger(
                root,
                _read_arg_file(args.request_file),
                apply_admitted=args.apply_admitted,
            )
            print(
                json.dumps(
                    result,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
            )
        elif args.command == "recover-mixed-current-ledger":
            result = recover_mixed_current_ledger(
                root, _read_arg_file(args.request_file),
                apply_admitted=args.apply_admitted,
            )
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        elif args.command == "apply-legacy-ledger-projection":
            v2_values = (
                args.ledger_manifest_path,
                args.h1_manifest_file,
                args.h1_manifest_path,
            )
            legacy_values = (
                args.manifest_entry_id,
                args.raw_line_ordinal,
                args.operation_id,
            )
            if any(value is not None for value in v2_values):
                if any(value is None for value in v2_values) or any(
                    value is not None for value in legacy_values
                ):
                    raise LifecycleError(
                        "WI-LEDGER-COMPAT-CLI-ARGS",
                        "sealed-prefix apply requires every V2 argument and forbids V1 arguments",
                    )
                request = SealedPrefixActivationRequestV1(
                    h1_manifest_path=args.h1_manifest_path,
                    h1_manifest_bytes=_read_arg_file(args.h1_manifest_file),
                    ledger_manifest_path=args.ledger_manifest_path,
                    ledger_manifest_bytes=_read_arg_file(args.manifest_file),
                    expected_registry_sha256=args.expected_registry_sha256,
                    recorded_at=args.recorded_at,
                )
                result = apply_sealed_prefix_activation(
                    root,
                    request,
                    dry_run=args.dry_run,
                )
            else:
                if any(value is None for value in legacy_values):
                    raise LifecycleError(
                        "WI-LEDGER-COMPAT-CLI-ARGS",
                        "legacy projection apply requires every V1 argument",
                    )
                result = apply_legacy_ledger_projection(
                    root, _read_arg_file(args.manifest_file), args.manifest_entry_id,
                    args.raw_line_ordinal, args.expected_registry_sha256,
                    args.operation_id, args.recorded_at, dry_run=args.dry_run,
                )
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        elif args.command == "revoke-legacy-ledger-projection":
            v2_values = (args.apply_receipt_path, args.apply_receipt_sha256)
            legacy_values = (
                args.apply_operation_id,
                args.apply_record_sha256,
                args.operation_id,
            )
            if any(value is not None for value in v2_values):
                if any(value is None for value in v2_values) or any(
                    value is not None for value in legacy_values
                ):
                    raise LifecycleError(
                        "WI-LEDGER-COMPAT-CLI-ARGS",
                        "sealed-prefix revoke requires every V2 argument and forbids V1 arguments",
                    )
                request = SealedPrefixRevokeRequestV1(
                    apply_receipt_path=args.apply_receipt_path,
                    apply_receipt_sha256=args.apply_receipt_sha256,
                    expected_registry_sha256=args.expected_registry_sha256,
                    recorded_at=args.recorded_at,
                )
                result = revoke_sealed_prefix_activation(
                    root,
                    request,
                    dry_run=args.dry_run,
                )
            else:
                if any(value is None for value in legacy_values) or args.dry_run:
                    raise LifecycleError(
                        "WI-LEDGER-COMPAT-CLI-ARGS",
                        "legacy projection revoke requires every V1 argument and forbids dry-run",
                    )
                result = revoke_legacy_ledger_projection(
                    root, args.apply_operation_id, _projection_cli_record_digests(args.apply_record_sha256),
                    args.expected_registry_sha256, args.operation_id, args.recorded_at,
                )
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        elif args.command == "relocate-ledger-h1-artifact-set":
            result = relocate_ledger_h1_artifact_set(
                root,
                LedgerH1ArtifactSetRelocationRequestV1(
                    archive_owner=args.archive_owner,
                    expected_artifact_set_sha256=args.expected_artifact_set_sha256,
                    expected_root_contract_sha256=args.expected_root_contract_sha256,
                    operation_id=args.operation_id,
                    recorded_at=args.recorded_at,
                ),
                apply=args.apply,
            )
            print(
                json.dumps(
                    result,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
            )
        elif args.command == "write-legacy-ledger-irrecoverable-disposition":
            result = write_legacy_ledger_irrecoverable_disposition(
                root, _read_arg_file(args.disposition_file),
            )
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        elif args.command == "write-historical-artifact-disposition":
            result = write_historical_artifact_disposition(
                root, _read_arg_file(args.disposition_file),
            )
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        elif args.command == "archive-with-successor":
            result = archive_with_successor(
                root,
                args.slug,
                _read_arg_file(args.closure_file),
                args.terminal_instant,
                args.successor_slug,
                _read_arg_file(args.successor_file),
                args.operation_id,
                args.expected_ledger_sha256,
                args.expected_readme_sha256,
                obligation_transfer_data=(
                    _read_arg_file(args.obligation_transfer_file)
                    if args.obligation_transfer_file else None
                ),
                inject_failure_at=args.inject_failure_at,
            )
            print(
                "WI-LIFECYCLE-TRANSITION-COMMITTED "
                f"operation={result['operationId']} readme={result['readmeSha256']}"
            )
        elif args.command == "supersede-current-bug":
            result = supersede_current_bug(
                root,
                args.slug,
                Path(args.successor_record),
                _read_arg_file(args.successor_binding_file),
                args.terminal_instant,
                _read_arg_file(args.incoming_links_inventory),
                args.expected_bug_sha256,
                args.expected_readme_sha256,
                args.operation_id,
                inject_failure_at=args.inject_failure_at,
            )
            print(
                "WI-BUG-SUPERSESSION-COMMITTED "
                f"operation={result['operationId']} readme={result['readmeSha256']}"
            )
        elif args.command == "archive-fixed-bug":
            if not args.apply:
                raise LifecycleError(
                    "WI-FIXED-BUG-APPLY-REQUIRED", "archive-fixed-bug requires explicit --apply",
                )
            result = archive_fixed_bug(
                root, args.slug, args.terminal_instant, args.resolution, args.evidence,
            )
            print(
                "WI-FIXED-BUG-ARCHIVE-COMMITTED "
                f"operation={result['operationId']} readme={result['readmeSha256']}"
            )
        elif args.command == "release-retained-scratch":
            result = release_retained_scratch(
                root, args.slug, terminal_run_id=args.terminal_run_id,
                expected_event_sha256=args.expected_event_sha256,
                entry_id=args.entry_id, artifact=args.artifact,
                rationale=args.rationale, apply=args.apply,
            )
            print(f"WI-SCRATCH-RELEASE-SETTLED receipt={result.relative_to(Path(os.path.abspath(root))).as_posix()}")
        elif args.command == "import-active-successor":
            if args.apply:
                if not args.preflight_digest:
                    raise LifecycleError(
                        "WI-SUCCESSOR-IMPORT-DRIFT",
                        "apply requires the matching preflight digest",
                    )
            elif args.preflight_digest:
                raise LifecycleError(
                    "WI-SUCCESSOR-IMPORT-APPLY-UNAVAILABLE",
                    "preflight digest is reserved for an admitted apply operation",
                )
            dispositions = json.loads(
                _read_arg_file(args.links_file), object_pairs_hook=_successor_import_json_pairs,
            )
            if args.apply:
                result = apply_import_active_successor(
                    root, args.predecessor_slug, args.successor_slug,
                    _read_arg_file(args.status_file), dispositions,
                    args.operation_id, args.preflight_digest,
                )
                print(json.dumps(result, sort_keys=True))
                return 0
            result = preflight_import_active_successor(
                root, args.predecessor_slug, args.successor_slug,
                _read_arg_file(args.status_file), dispositions, args.operation_id,
            )
            wire = {
                key: value for key, value in result.items() if key != "canonicalBytes"
            }
            for field in ("compatibilityIndex", "readme"):
                wire[field] = {
                    key: value for key, value in wire[field].items() if key != "afterBytes"
                }
            print(json.dumps(wire, sort_keys=True))
        elif args.command == "trial":
            first, second = run_trial(root, Path(args.fixture))
            print("TRIAL: PASS")
            print("items=5")
            print(f"sections={'|'.join(README_SECTIONS)}")
            print(f"readme_sha256_1={first}")
            print(f"readme_sha256_2={second}")
        return 0
    except LifecycleError as exc:
        if args.command == "supersede-current-bug":
            print(_project_current_bug_supersession_cli_failure(exc))
        else:
            print(f"{exc.failure_id}: {exc}")
        _emit_lifecycle_cleanup_diagnostics(lifecycle_diagnostic_observer)
        return 1
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        if args.command == "supersede-current-bug":
            print(_project_current_bug_supersession_cli_failure(exc))
        else:
            print(f"WI-IO: {exc}")
        _emit_lifecycle_cleanup_diagnostics(lifecycle_diagnostic_observer)
        return 1
    except Exception as exc:
        if args.command == "supersede-current-bug":
            print(_project_current_bug_supersession_cli_failure(exc))
            _emit_lifecycle_cleanup_diagnostics(lifecycle_diagnostic_observer)
            return 1
        _emit_lifecycle_cleanup_diagnostics(lifecycle_diagnostic_observer)
        raise
    except BaseException:
        _emit_lifecycle_cleanup_diagnostics(lifecycle_diagnostic_observer)
        raise


LIFECYCLE_PUBLIC_APIS = (
    "resolve_category",
    "work_item_dependency_state",
    "resolve_legacy_path",
    "collect_readme_entries",
    "render_readme_bytes",
    "refresh_readme",
    "reset_readme_static_guide",
    "check_readme",
    "create_candidate",
    "convert_legacy_candidate",
    "retire_legacy_backlog",
    "start_item",
    "update_status",
    "close_item",
    "reopen_item",
    "preflight_import_active_successor",
    "apply_import_active_successor",
    "audit_categories",
    "audit",
    "write_current_identity_normalization_inventory",
    "normalize_current_identity",
    "migrate_legacy_ledger_obligation",
    "revoke_legacy_ledger_obligation",
    "archive_with_successor",
    "supersede_current_bug",
    "archive_fixed_bug",
    "build_migration_inventory",
    "write_migration_inventory",
    "migrate_legacy",
    "terminalize_v1_inventory",
    "apply_migration_inventory",
    "recover_partial_migration_v1",
    "verify_migration_inventory",
    "reopen_category_record",
    "run_trial",
)
for _lifecycle_api_name in LIFECYCLE_PUBLIC_APIS:
    globals()[_lifecycle_api_name] = _lifecycle_participant(
        globals()[_lifecycle_api_name]
    )


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
